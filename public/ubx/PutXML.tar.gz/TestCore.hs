module TestCore where

import Text.XML.PutXML.DTD.SubType
import Text.XML.PutXML.Lenses.Lib
import Text.XML.PutXML.Generic.Rewrite
import Text.XML.PutXML.Update.AST
import Text.XML.PutXML.Update.CoreAST
import Text.XML.PutXML.Lenses.Pf
import Text.XML.PutXML.DTD.Type as Type
import Text.XML.PutXML.Lenses.View
import Text.XML.PutXML.Lenses.ViewPf
import Generics.Putlenses.Language
import Generics.Putlenses.Putlens
import Generics.Putlenses.Examples.Examples
import Data.Map (Map(..))
import qualified Data.Map as Map
import Data.Set (Set(..))
import qualified Data.Set as Set
import Control.Monad
import Control.Monad.State (State,MonadState,StateT)
import qualified Control.Monad.State as State
import Control.Monad.Identity
import Control.Monad.Reader (Reader(..),MonadReader(..),ReaderT(..))
import qualified Control.Monad.Reader as Reader
import Control.Monad.Trans
import Text.XML.PutXML.XQuery.UXQ
import Text.XML.PutXML.XQuery.UXQToVal
import Text.XML.PutXML.XQuery.CPathToLens
import Text.XML.PutXML.Update.Patterns
import Text.XML.PutXML.XQuery.UXQToRef
import Text.XML.PutXML.XQuery.CPathToRef
import Text.XML.PutXML.Update.CoreToLenses
import Text.XML.PutXML.Update.UpdateToCore
import Text.XML.PutXML.DTD.Normalize
import Text.XML.HaXml.DtdToHaskell.TypeDef hiding (ppTypeDef,mangle,List,Any,String)
import Text.XML.HaXml.ShowXmlLazy
import Text.XML.HaXml.Namespaces
import Text.XML.HaXml.DtdToHaskell.Convert
import Text.XML.HaXml.XmlContent hiding (List,String)

import qualified Addrbook
import qualified Index
import qualified Bookstore
import qualified Books
import qualified Fromtokyo
import qualified People
import qualified Section
import qualified Sec
import qualified Netscape
import qualified Xbel
import qualified Code
import qualified Model

import System.IO
import System.Environment
import Text.XML.PutXML.Update.Parser
import Text.ParserCombinators.Parsec
import Text.XML.PutXML.Update.Token

parseProgram :: String -> IO Program
parseProgram filename = do
	file <- readFile filename
	let tokenLst = parse t "" file
	case tokenLst of
		Left err -> error "token err"
		Right tokLst -> return $ nParser (tokLst)

testAddrbook = do
	s <- (fReadXml "Test/addrbook/s.xml"):: IO Addrbook.Addrbook
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/addrbook/v.xml"):: IO Index.Addrbook
	putStrLn "##### modified view #####"
	putStrLn $ show v'
		
	ast <- parseProgram "Test/addrbook/addrbook.upd"
	
	let tenv = (Map.mapKeys ("s:"++) Addrbook.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Index.typeEnv)
	cast <- program2core tenv ast
	putStrLn $ show cast
	lns <- evalcprogram cast tenv (typeof :: Type Addrbook.Addrbook) (typeof :: Type Index.Addrbook)
	let v = get lns s
	putStrLn "##### original view #####"
	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'
	
testBookstore = do
	s <- (fReadXml "Test/bookstore/s.xml"):: IO Bookstore.Bookstore
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/bookstore/v.xml"):: IO Books.Books
	putStrLn "##### modified view #####"
	putStrLn $ show v'
		
	ast <- parseProgram "Test/bookstore/bookstore.upd"
	
	let tenv = (Map.mapKeys ("s:"++) Bookstore.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Books.typeEnv)
	cast <- program2core tenv ast
	putStrLn $ show cast
	lns <- evalcprogram cast tenv (typeof :: Type Bookstore.Bookstore) (typeof :: Type Books.Books)
	let v = get lns s
	putStrLn "##### original view #####"
	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'
	
testPeople = do
	s <- (fReadXml "Test/people/s.xml"):: IO People.People
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/people/v.xml"):: IO Fromtokyo.Fromtokyo
	putStrLn "##### modified view #####"
	putStrLn $ show v'
		
	ast <- parseProgram "Test/people/people.upd"

	let tenv = (Map.mapKeys ("s:"++) People.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Fromtokyo.typeEnv)
	cast <- program2core tenv ast
	putStrLn $ show cast
	lns <- evalcprogram cast tenv (typeof :: Type People.People) (typeof :: Type Fromtokyo.Fromtokyo)
	let v = get lns s
	putStrLn "##### original view #####"
	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'
	
testPeople2 = do
	s <- (fReadXml "Test/people/s.xml"):: IO People.People
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/people/v.xml"):: IO Fromtokyo.Fromtokyo
	putStrLn "##### modified view #####"
	putStrLn $ show v'
		
	ast <- parseProgram "Test/people/people2.upd"
	
	let tenv = (Map.mapKeys ("s:"++) People.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Fromtokyo.typeEnv)
	cast <- program2core tenv ast
	putStrLn $ show cast
	lns <- evalcprogram cast tenv (typeof :: Type People.People) (typeof :: Type Fromtokyo.Fromtokyo)
	let v = get lns s
	putStrLn "##### original view #####"
	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'

testSections = do
	s <- (fReadXml "Test/nestedsections/s.xml"):: IO Section.Sections
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/nestedsections/v.xml"):: IO Sec.Secs
	putStrLn "##### modified view #####"
	putStrLn $ show v'
		
	ast <- parseProgram "Test/nestedsections/sections.upd"
	
	let tenv = (Map.mapKeys ("s:"++) Section.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Sec.typeEnv)
	cast <- program2core tenv ast
	putStrLn $ show cast
	lns <- evalcprogram cast tenv (typeof :: Type Section.Sections) (typeof :: Type Sec.Secs)
	let v = get lns s
	putStrLn "##### original view #####"
	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'

testSections2 = do
	s <- (fReadXml "Test/nestedsections/s.xml"):: IO Section.Sections
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/nestedsections/v.xml"):: IO Sec.Secs
	putStrLn "##### modified view #####"
	putStrLn $ show v'
		
	ast <- parseProgram "Test/nestedsections/sections2.upd"
	
	let tenv = (Map.mapKeys ("s:"++) Section.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Sec.typeEnv)
	cast <- program2core tenv ast
	putStrLn $ show cast
	lns <- evalcprogram cast tenv (typeof :: Type Section.Sections) (typeof :: Type Sec.Secs)
	let v = get lns s
	putStrLn "##### original view #####"
	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'

-- this is to be generated by bookmarkTypes from bookmark.upd
bookmarkNc = (List (Either (Data (Name "dt" "Dt") typeof :: Type Netscape.Dt) (Data (Name "dd" "Dd") typeof :: Type Netscape.Dd)))
bookmarkXc = (List (Either (Data (Name "bookmark" "Bookmark") typeof :: Type Xbel.Bookmark) (Data (Name "folder" "Folder") typeof :: Type Xbel.Folder)))
bookmarkTypeEnv = Map.insert "Nc" (DynT bookmarkNc) $ Map.insert "Xc" (DynT bookmarkXc) $ Map.empty

testBookmarks = do
	s <- (fReadXml "Test/bookmark/netscape.xml"):: IO Netscape.Html
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/bookmark/xbel.xml"):: IO Xbel.Xbel
	putStrLn "##### modified view #####"
	putStrLn $ show v'
		
	ast <- parseProgram "Test/bookmark/bookmark.upd"

	let tenv = (Map.mapKeys ("s:"++) Netscape.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Xbel.typeEnv) `Map.union` bookmarkTypeEnv
	cast <- program2core tenv ast
	putStrLn $ show cast
	lns <- evalcprogram cast tenv (typeof :: Type Netscape.Html) (typeof :: Type Xbel.Xbel)
	let v = get lns s
	putStrLn "##### original view #####"
	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'

testConstructor = do
	s <- (fReadXml "Test/constructor/s.xml"):: IO Code.Mainclass
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/constructor/v.xml"):: IO Model.Initials
	putStrLn "##### modified view #####"
	putStrLn $ show v'
		
	ast <- parseProgram "Test/constructor/uC.upd"

	let tenv = (Map.mapKeys ("s:"++) Code.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Model.typeEnv)
	cast <- program2core tenv ast
	putStrLn $ show cast
	lns <- evalcprogram cast tenv (typeof :: Type Code.Mainclass) (typeof :: Type Model.Initials)
	let v = get lns s
	putStrLn "##### original view #####"
	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'

--testCollapse :: IO ()
--testCollapse = do
--	lns <- collapseT Int (Either (Prod Int (List Int)) Int)
--	print $ simpleput (put2lens lns) (Left (1,[])) 5

testNormalize :: IO ()
testNormalize = do
--	View f b <- normalizeT Type.Identity (Prod (List Int) (List $ Either Int String))
--	print b
--	View g c <- normalizeT Type.Identity $ List $ Prod Int (Either (List String) One)
--	print c
--	View g d <- normalizeT Type.Identity $ List $ Either Int $ Either One Int
--	print d
	let x = (Tag "addrbook" (Prod (Tag "index" (List Int)) (List String)))
	View h e <- normalizeT Type.Identity x
	print e

testFilter :: IO ()
testFilter = do
	print $ simpleput (put2lens filterleftPut) [Left 1,Right 'a',Right 'b'] []
	print $ simpleput (put2lens filterleftPut) [Left 1,Left 3,Right 'a',Left 2,Right 'b'] [5,6]
	
	print $ simpleput (put2lens filterrightPut) [Left 1,Right 'a',Right 'b'] []
	print $ simpleput (put2lens filterrightPut) [Left 1,Left 2] ['c']
	
	print $ simpleput (put2lens $ filterPut True .< keepfstPut) [Left 1,Right 'a',Right 'b'] []
	print $ simpleput (put2lens $ filterPut True .< keepfstPut) [Left 1,Left 2] ['c']

testNorm :: IO ()
testNorm = do
	ViewPf (Put2Lens -> f) t <- (norm' >>>> clu) (Prod (Either Int $ Tag "n" String) (Either Int Bool))
	print $ t

testXList :: IO ()
testXList = do
	View f (List Int)  :: View Identity [Int] <- (mkXList >>> xlist2list) (List Int)
	print $ get (put2lens f) [1,2,3,4]
	print $ simplecreate (put2lens f) [5,6,7,8,9]
	print $ simpleput (put2lens f) [1,2,3,4] [5,6,7,8,9]

testSubtype :: IO ()
testSubtype = do
	lns <- evalsubtypeput Type.Identity (Either (Prod Int Int) Int) (List Int)
	let lns' = unsafeInvPut "" lns
	print $ get (put2lens lns') $ Left (1,2)
	print $ simplecreate (put2lens lns') [1,2]

testSubtype2 :: IO ()
testSubtype2 = do
	lns <- evalsubtypeput Type.Identity (List (List Int)) (List Int)
	let lns' = unsafeInvPut "" lns
	print $ get (put2lens lns') $ [[1],[2]]
	print $ simpleput (put2lens lns') [[1],[2]] [1,2,3,4,5,6]

testListify :: IO ()
testListify = do
	lns <- listifyT Int (List Int)
	print $ get (put2lens lns) [1,2,3,4]
	print $ simplecreate (put2lens lns) [5,6,7,8,9]
	print $ simpleput (put2lens lns) [1,2,3,4] [5,6,7,8,9]
	
-- converts a type with children of the same type into a list
listifyPfT :: (MonadPlus m,Monad lensm,Eq x) => Type x -> RulePfQ m lensm [x]
listifyPfT x = undefined --gmapPfQ [] CatPut (rule x)
--	where
--	rule :: (MonadPlus m,Monad lensm,Eq x) => Type x -> RulePfQ m lensm [x]
--	rule x t = case teq t x of { Just Type.Eq -> return UnwrapPut; Nothing -> error "listifyPfT" }

-- converts a type with children of the same type into a list
listifyT :: (MonadPlus m,Monad lensm,Eq x) => Type x -> RuleQ m lensm [x]
listifyT x = gmapQ [] catPut (rule x)
	where
	rule :: (MonadPlus m,Monad lensm,Eq x) => Type x -> RuleQ m lensm [x]
	rule x t = case teq t x of { Just Type.Eq -> return unwrapPut; Nothing -> error "listifyT" }
	