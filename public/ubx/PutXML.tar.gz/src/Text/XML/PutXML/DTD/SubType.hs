module Text.XML.PutXML.DTD.SubType where

import Text.XML.PutXML.Lenses.ViewPf
import Text.XML.PutXML.DTD.Type as T
import Text.XML.HaXml.DtdToHaskell.TypeDef hiding (List,Any,String)
import Text.XML.PutXML.Lenses.View hiding (Ref)
import Generics.Putlenses.Putlens
import Generics.Putlenses.Language
import Generics.Putlenses.Examples.Examples
import Control.Monad
import Data.Maybe
import Control.Monad.State (State(..),MonadState(..),StateT)
import qualified Control.Monad.State as State
import Text.XML.PutXML.Lenses.Pf
import Data.Map (Map(..))
import qualified Data.Map as Map
import Text.PrettyPrint.HughesPJ
import Control.Monad.Trans
import Data.List

import Debug.Trace

-- * Normalization

norm' :: (MonadPlus m,Monad lensm) => RulePfT m lensm
norm' r = do
	ViewPf f r' <- (lnfy >>>> rotate) r
	case nul r of
		Just nl -> do
			ViewPf g a <- delphi (Either One r')
			return $ ViewPf (CompPut (Either One r') (nl `EitherLPut` f) g) a
		Nothing -> do
			ViewPf g a <- delphi r'
			return $ ViewPf (CompPut r' f g) a

nul :: (MonadPlus m,Monad lensm) => Type a -> m (Pf (PutlensM lensm a ()))
nul One = return IdPut
nul (getLiteral -> Just l) = mzero
nul (getAttEl -> Just (l,t)) = mzero
nul (Prod r1 r2) = do
	f <- nul r1
	g <- nul r2
	return $ CompPut (Prod One One) (f `ProdPut` g) AddfstOnePut
nul (Either r1 r2) = (do
	f <- nul r1
	return $ CompPut r1 InjlPut f)
		`mplus` (do
	g <- nul r2
	return $ CompPut r2 InjrPut g)
nul (List r) = return NilPut

lnfy :: (MonadPlus m,Monad st) => RulePfT m st
lnfy One = return $ ViewPf BotPut Zero
lnfy (getLiteral -> Just l) = return $ ViewPf RemsndOnePut (Prod l One)
lnfy a@(isAttEl -> True) = return $ ViewPf RemsndOnePut (Prod a One)
lnfy (List r) = do
	let x = Prod r (List r)
	ViewPf f a <- lnfy2 x
	return $ ViewPf (CompPut x ConsPut f) a
lnfy (Either r1 r2) = do
	ViewPf f a <- lnfy r1
	ViewPf g b <- lnfy r2
	return $ ViewPf (f `SumPut` g) (Either a b)
lnfy (Prod One r) = do
	ViewPf f a <- lnfy r
	return $ ViewPf (CompPut r AddfstOnePut f) a
lnfy (Prod (getLiteral -> Just l) r') = nopPf (Prod l r')
lnfy a@(Prod (isAttEl -> True) r') = nopPf a
lnfy (Prod (Prod r1 r2) r3) = do
	let x = Prod r1 (Prod r2 r3)
	ViewPf f a <- lnfy x
	return $ ViewPf (CompPut x AssoclPut f) a
lnfy (Prod (Either r1 r2) r3) = do
	let x = Either (Prod r1 r3) (Prod r2 r3)
	ViewPf f a <- lnfy x
	return $ ViewPf (CompPut x UndistlPut f) a
lnfy (Prod (List r1) r2) = do
	ViewPf f a <- lnfy2 (Prod (List r1) r2)
	ViewPf g b <- lnfy r2
	let x = Prod (Either One (Prod r1 (List r1))) r2
	    y = Either (Prod One r2) (Prod (Prod r1 (List r1)) r2)
	    z = Either r2 (Prod (List r1) r2)
	    w = Either (Prod (List r1) r2) r2
	    lns = CompPut x (InnPut `ProdPut` IdPut) $ CompPut y UndistlPut
	        $ CompPut z (AddfstOnePut `SumPut` (UnconsPut `ProdPut` IdPut))
	        $ CompPut w CoswapPut (f `SumPut` g)
	return $ ViewPf lns (Either a b)
lnfy a = error $ "lnfy: " ++ show a

lnfy2 :: (MonadPlus m,Monad st) => RulePfT m st
lnfy2 (Prod One a) = return $ ViewPf BotPut Zero
lnfy2 (Prod (getLiteral -> Just l) r') = nopPf (Prod l r')
lnfy2 a@(Prod (isAttEl -> True) r') = nopPf a
lnfy2 (Prod (List r1) r2) = do
	ViewPf f a <- lnfy2 (Prod r1 (Prod (List r1) r2))
	let x = Prod (Prod r1 (List r1)) r2
	    y = Prod r1 (Prod (List r1) r2)
	return $ ViewPf (CompPut x (ConsPut `ProdPut` IdPut) $ CompPut y AssoclPut f) a
lnfy2 (Prod (Either r1 r2) r3) = do
	ViewPf f a <- lnfy2 (Prod r1 r3)
	ViewPf g b <- lnfy2 (Prod r2 r3)
	let x = Either (Prod r1 r3) (Prod r2 r3)
	return $ ViewPf (CompPut x UndistlPut (f `SumPut` g)) (Either a b)
lnfy2 (Prod (Prod One r1) r2) = do
	let x = Prod r1 r2
	ViewPf f a <- lnfy2 x
	return $ ViewPf (CompPut x (AddfstOnePut `ProdPut` IdPut) f) a
lnfy2 (Prod (Prod (getLiteral -> Just l) r1) r2) = do
	return $ ViewPf AssoclPut (Prod l (Prod r1 r2))
lnfy2 (Prod (Prod lr@(isAttEl -> True) r1) r2) = do
	return $ ViewPf AssoclPut (Prod lr (Prod r1 r2))
lnfy2 (Prod (Prod (Prod r1 r2) r3) r4) = do
	let x = Prod (Prod r1 (Prod r2 r3)) r4
	ViewPf f a <- lnfy2 x
	return $ ViewPf (CompPut x (AssoclPut `ProdPut` IdPut) f) a
lnfy2 (Prod (Prod (Either r1 r2) r3) r4) = do
	let x = Prod (Either (Prod r1 r3) (Prod r2 r3)) r4
	ViewPf f a <- lnfy2 x
	return $ ViewPf (CompPut x (UndistlPut `ProdPut` IdPut) f) a
lnfy2 (Prod (Prod (List r1) r2) r3) = do
    let p23 = Prod r2 r3
        p11 = Prod r1 (List r1)
    ViewPf f a <- lnfy2 (Prod (List r1) p23)
    ViewPf g b <- lnfy2 p23
    let x = Prod (List r1) p23
        y = Prod (Either One p11) p23
        z = Either (Prod One p23) (Prod p11 p23)
        w = Either p23 (Prod (List r1) p23)
        u = Either (Prod (List r1) p23) p23
        lns = CompPut x AssoclPut $ CompPut y (InnPut `ProdPut` IdPut)
            $ CompPut z UndistlPut $ CompPut w (AddfstOnePut `SumPut` (UnconsPut `ProdPut` IdPut))
            $ CompPut u CoswapPut (f `SumPut` g)
    return $ ViewPf lns (Either a b)

rotate :: (MonadPlus m,Monad st) => RulePfT m st
rotate Zero = return $ ViewPf IdPut Zero
rotate (Prod r1 r2) = nopPf (Prod r1 r2)
rotate (Either Zero r) = do
	ViewPf f a <- rotate r
	return $ ViewPf (IdPut `SumPut` f) (Either Zero a)
rotate (Either (Prod r1 r2) r3) = do
	ViewPf f a <- rotate r3
	return $ ViewPf (IdPut `SumPut` f) (Either (Prod r1 r2) a)
rotate (Either (Either r1 r2) r3) = do
    ViewPf f a <- rotate (Either r2 r3)
    ViewPf g b <- rotate (Either r1 a)
    let x = Either r1 a
        y = Either r1 (Either r2 r3)
    return $ ViewPf (CompPut y CoassoclPut $ CompPut x (IdPut `SumPut` f) g) b

delphi :: (MonadPlus m,Monad st) => RulePfT m st
delphi Zero = nopPf Zero
delphi One = nopPf One
delphi (Prod r1 r2) = nopPf (Prod r1 r2)
delphi (Either Zero Zero) = return $ ViewPf BotPut Zero
delphi (Either Zero r) = do
	ViewPf f a <- delphi r
	return $ ViewPf (CompPut r InjrPut f) a
delphi (Either One Zero) = return $ ViewPf InjlPut One
delphi (Either One r) = do
	ViewPf f r' <- delphi r
	let x = Either One r'
	ViewPf g a <- delphi2 (isPhi r') x
	return $ ViewPf (CompPut x (IdPut `SumPut` f) g) a
delphi (Either (Prod r1 r2) Zero) = return $ ViewPf InjlPut (Prod r1 r2)
delphi (Either (Prod r1 r2) r3) = do
	ViewPf f r3' <- delphi r3
	let x = Either (Prod r1 r2) r3'
	ViewPf g a <- delphi2 (isPhi r3') x
	return $ ViewPf (CompPut x (IdPut `SumPut` f) g) a

delphi2 :: (MonadPlus m,Monad st) => Bool -> RulePfT m st
delphi2 True (Either r1 r2) = return $ ViewPf InjlPut r1
delphi2 False r = nopPf r

isPhi :: Type a -> Bool
isPhi Zero = True
isPhi _ = False

clu :: (MonadPlus m,Monad st) => RulePfT m st
clu One = nopPf One
clu (Prod r1 r2) = do
	let x = Either (Prod r1 r2) Zero
	return $ ViewPf (CompPut x UninjlPut UninjlPut) (Either (Either (Prod r1 r2) Zero) Zero)
clu (Either One r) = do
	ViewPf f a <- clu r
	return $ ViewPf (IdPut `SumPut` f) (Either One a)
clu a@(Either p1 r) = do
	v <- clu r
	clu' v a
clu' :: (MonadPlus m,Monad st) => ViewPf st b -> RulePf m st (Either a b)
clu' (ViewPf f (Either (Either p2 rs) us)) (Either p1 r) = do
	ViewPf g b <- clu2 (eqclu p1 p2) (Either p1 (Either (Either p2 rs) us))
	let x = Either p1 (Either (Either p2 rs) us)
	return $ ViewPf (CompPut x (IdPut `SumPut` f) g) b

clu2 :: (MonadPlus m,Monad st) => Bool -> RulePfT m st
clu2 True (Either p1 (Either (Either p2 rs) us)) =
	return $ ViewPf CoassocrPut (Either (Either p1 (Either p2 rs)) us)
clu2 False (Either p1 (Either (Either p2 rs') Zero)) = do
	ViewPf f a <- clu p1
	let x = Either a (Either p2 rs')
	return $ ViewPf (CompPut x (f `SumPut` InjlPut) CoswapPut) (Either (Either p2 rs') a)
clu2 False (Either p1 (Either (Either p2 rs) (Either (Either p3 rs') us))) = do
	ViewPf f a <- clu2 (eqclu p1 p3) (Either p1 (Either (Either p3 rs') us))
	let x = Either (Either p2 rs) (Either p1 (Either (Either p3 rs') us))
	return $ ViewPf (CompPut x CosubrPut (IdPut `SumPut` f)) (Either (Either p2 rs) a)

eqclu :: Type a -> Type b -> Bool	
eqclu (Prod (getLiteral -> Just l1) r1') (Prod (getLiteral -> Just l2) r2') = teqBool l1 l2
eqclu (Prod (getAttEl -> Just (l1,_)) r1') (Prod (getAttEl -> Just (l2,_)) r2') = l1 == l2
eqclu a b = error $ "eqclu: " ++ show a ++ "\t" ++show b

-- * Clu to KAG: type-level function used by the main rule of the extended Antimirov's ALgorithm

meetlist :: Eq a => MonadPlus m => Type a -> m [DynType]
meetlist (Meet a b) = do
	xs <- meetlist a
	ys <- meetlist b
	return (xs++ys)
meetlist a = return [DynT a]

clutokag :: MonadPlus m => Type a -> m (DynType,[DynType])
clutokag (Either (Prod (getLiteral -> Just l) r') rs) = do
	DynT (Meet (Either (Prod l1 Tau) (Prod l2 r')) ms) <- hcf (Either (Prod l r') rs)
	DynT (Either (Prod l1 Tau) (Prod l2 Zero)) <- meetlast ms
	DynT gs <- meetinits ms
	xs <- meetlist gs
	return $ (DynT (Prod l1 r'),xs)
clutokag (Either (Prod lr@(getAttEl -> Just (l,DynT r)) r') rs) = do
	DynT (Meet (Either (Prod (Tag l1 Zero) Tau) (Prod (Tag l2 Tau) r')) ms) <- hcf (Either (Prod (Tag l r) r') rs)
	DynT (Either (Prod (Tag l1 r) Tau) (Prod (Tag l2 Tau) Zero)) <- meetlast ms
	DynT gs <- meetinits ms
	xs <- meetlist gs
	return $ (DynT (Prod (Tag l1 r) r'),xs)
	
meetlast :: MonadPlus m => Type a -> m DynType
meetlast (Either m1 m2) = return $ DynT (Either m1 m2)
meetlast (Meet hd tl) = meetlast tl

meetinits :: MonadPlus m => Type a -> m DynType
meetinits (Either m1 m2) = return $ DynT Tau
meetinits (Meet hd (Either m1 m2)) = return $ DynT hd
meetinits (Meet hd (Meet hd' tl)) = do
	DynT i <- meetinits (Meet hd' tl)
	return $ DynT (Meet hd i)

hcf :: MonadPlus m => Type a -> m DynType
hcf (Either (Prod (getLiteral -> Just l) r') rs) = do
	s' <- gatherLiteral (Either (Prod l r') rs)
	let ps' = pwrset s'
	    is' = revset ps'
	    uris' = map unionset is'
	mkhcfLiteral l uris'
hcf (Either (Prod (getAttEl -> Just (l,DynT r)) r') rs) = do
	(s,s') <- gather (Either (Prod (Tag l r) r') rs)
	let is = pwrset s
	    ps' = pwrset s'
	    is' = revset ps'
	    uris = map unionset is
	    uris' = map unionset is'
	mkhcf l uris uris'

gather :: MonadPlus m => Type a -> m ([DynType],[DynType])
gather Zero = return ([],[])
gather (Either (Prod (getAttEl -> Just (l,DynT r)) r') rs) = do
	(s,s') <- gather rs
	return $ (DynT r:s,DynT r':s')

gatherLiteral :: MonadPlus m => Type a -> m [DynType]
gatherLiteral Zero = return []
gatherLiteral (Either (Prod (getLiteral -> Just l) r') rs) = do
	s' <- gatherLiteral rs
	return (DynT r':s')

revset :: [a] -> [a]
revset = reverse

pwrset :: [a] -> [[a]]
pwrset [] = [[]]
pwrset (x:xs) = let xxs = pwrset xs
                    xxs' = map (x:) xxs
                in xxs++xxs'

unionset :: [DynType] -> DynType
unionset [] = DynT Zero
unionset (x:[]) = x
unionset (DynT x:xs) = applyDynT (\a -> DynT (Either x a)) (unionset xs)

mkhcf :: MonadPlus m => String -> [DynType] -> [DynType] -> m DynType
mkhcf l [DynT r] [DynT r'] = return $ DynT (Either (Prod (Tag l r) Tau) (Prod (Tag l Tau) r'))
mkhcf l (DynT r:rs) (DynT r':rs') = do
	DynT b <- mkhcf l rs rs'
	let a = Either (Prod (Tag l r) Tau) (Prod (Tag l Tau) r')
	return $ DynT (Meet a b)

mkhcfLiteral :: Eq a => MonadPlus m => Type a -> [DynType] -> m DynType
mkhcfLiteral l [DynT r'] = return $ DynT (Either (Prod l Tau) (Prod l r'))
mkhcfLiteral l (DynT r':rs') = do
	DynT b <- mkhcfLiteral l rs'
	let a = Either l (Prod l r')
	return $ DynT (Meet a b)

-- * Rewrite System

evalsubtype :: (Eq a,Eq b,MonadPlus m) => Type a -> Type b -> m (Lens b a)
evalsubtype a b = liftM (evalPfWithDecls (LnsM T.Identity b a)) (subtype a b)

evalsubtypeOne :: (Eq a,Eq b,MonadPlus m) => Type a -> Type b -> m (Lens b a)
evalsubtypeOne a b = liftM (evalPfWithDecls (LnsM T.Identity b a)) (subtypeOne a b)

-- the properties of subtyping guarantees that both functions are total
isomorphism :: (Eq a,Eq b,MonadPlus m) => Type a -> Type b -> m (Iso a b)
isomorphism a b = do
	fwdLns <- evalsubtype a b
	bwdLns <- evalsubtype b a
	return $ Iso (simplecreate fwdLns) (simplecreate bwdLns)

isomorphismput :: (Eq a,Eq b,MonadPlus m,Monad lensm) => TypeM lensm -> Type a -> Type b -> m (PutlensM lensm a b)
isomorphismput lensm a b = do
	fwdLns <- evalsubtype a b
	bwdLns <- evalsubtype b a
	return $ isoPut (simplecreate bwdLns) (simplecreate fwdLns)

-- the properties of subtyping guarantees that both functions are total
isomorphismPf :: (Eq a,Eq b,MonadPlus m,Monad lensm) => TypeM lensm -> Type a -> Type b -> (StateT Prevs m) (Pf (PutlensM lensm a b))
isomorphismPf lensm a b = do
	fwdLns <- evalsubtype a b
	bwdLns <- evalsubtype b a
	return $ Val (PutlnsM lensm a b) $ isoPut (simplecreate bwdLns) (simplecreate fwdLns)

subtype :: (Eq a,Eq b,MonadPlus m) => Type a -> Type b -> m (PfWithDecls (Lens b a))
subtype a b = do PfWithDecls lns decls <- subtypeput T.Identity a b
                 return $ PfWithDecls (Put2Lens lns) decls

subtypeOne :: (Eq a,Eq b,MonadPlus m) => Type a -> Type b -> m (PfWithDecls (Lens b a))
subtypeOne a b = do PfWithDecls lns decls <- subtypeputOne T.Identity a b
                    return $ PfWithDecls (Put2Lens lns) decls

evalsubtypeput :: (Eq a,Eq b,MonadPlus m,Monad lensm) => TypeM lensm -> Type a -> Type b -> m (PutlensM lensm b a)
evalsubtypeput m a b = liftM (evalPfWithDecls (PutlnsM m b a)) (subtypeput m a b)

evalsubtypeputOne :: (Eq a,Eq b,MonadPlus m,Monad lensm) => TypeM lensm -> Type a -> Type b -> m (PutlensM lensm b a)
evalsubtypeputOne m a b = liftM (evalPfWithDecls (PutlnsM m b a)) (subtypeputOne m a b)

subtypeput :: (Eq a,Eq b,MonadPlus m,Monad lensm) => TypeM lensm -> Type a -> Type b -> m (PfWithDecls (PutlensM lensm b a))
subtypeput st a b = do
	(lns,(_,rules)) <- State.runStateT (subtypeputWithDecls st a b) ([],Map.empty)
	return (PfWithDecls lns rules)
	
subtypeputOne :: (Eq a,Eq b,MonadPlus m,Monad lensm) => TypeM lensm -> Type a -> Type b -> m (PfWithDecls (PutlensM lensm b a))
subtypeputOne st a b = do
	(lns,(_,rules)) <- State.runStateT (subtypeputOneWithDecls st a b) ([],Map.empty)
	return (PfWithDecls lns rules)

subtypeputWithDecls :: (Eq a,Eq b,MonadPlus m,Monad lensm) => TypeM lensm -> Type a -> Type b -> (StateT Prevs m) (Pf (PutlensM lensm b a))
subtypeputWithDecls st a b = {-trace ("subtyping: "++show a ++" subtype of "++show b) $ -} applyCoIndOrdinaryRules cfgOri st a b
-- `mplus` (error $ "subtyping failed \n" ++ show a ++ "\n" ++ show b)

subtypeputOneWithDecls :: (Eq a,Eq b,MonadPlus m,Monad lensm) => TypeM lensm -> Type a -> Type b -> (StateT Prevs m) (Pf (PutlensM lensm b a))
subtypeputOneWithDecls st a b = {-trace ("subtyping1: "++show a ++" subtype of "++show b) $ -} applyCoIndOrdinaryRules cfgOne st a b
-- `mplus` (error $ "subtyping1 failed \n" ++ show a ++ "\n" ++ show b)
type SubRuleM m = StateT Prevs m

type SubRulePf m lensm a b = TypeM lensm -> Type a -> Type b -> SubRuleM m (Pf (PutlensM lensm b a))
type SubRulePfT m = forall lensm e a b . (Monad lensm,Eq a,Eq b) => SubRulePf m lensm a b

newDecl :: (Monad m) => String -> SubRuleM m String
newDecl "" = newDecl "f1"
newDecl s = do
	(ds,prevs) <- State.get
	case elem s ds of
		True -> newDecl (init s ++ [succ (last s)])
		False -> State.put (s:ds,prevs) >> return s

updatePrevs :: (MonadPlus m) => (Map String DynPf -> Map String DynPf) -> SubRuleM m ()
updatePrevs f = do
	(names,prevs) <- State.get
	State.put (names,f prevs)

lookupRule :: Bool -> TypeM lensm -> Type a -> Type b -> PrevRules -> Maybe (String,Pf (PutlensM lensm b a))
lookupRule bool m a b rules = lookupRule' bool m a b (Map.assocs rules)

lookupRule' :: Bool -> TypeM lensm -> Type a -> Type b -> [(String,DynPf)] -> Maybe (String,Pf (PutlensM lensm b a))
lookupRule' bool m a b [] = Nothing
lookupRule' bool m a b ((name,DynPf (PutlnsM m' b' a') lns):xs) = case tMeq m m' of
		Just EqM -> case teq a a' of
			Just Eq -> case teq b b' of
				Just Eq -> if bool
					then if isPrefixOf "ordSub" name then return (name,lns) else lookupRule' bool m a b xs -- ordinary co-induction
					else if isPrefixOf "lnfSub" name then return (name,lns) else lookupRule' bool m a b xs -- lnf co-induction
				Nothing -> lookupRule' bool m a b xs
			Nothing -> lookupRule' bool m a b xs
		Nothing -> lookupRule' bool m a b xs

-- coinduction principle: if the current constraint has already been verified (or is trying to be verified), remove it from the proof obligations
coInd :: MonadPlus m => Bool -> SubRulePfT m -> SubRulePfT m
coInd bool r st a b = do
	(names,prevs) <- State.get
	case lookupRule bool st a b prevs of
		Just (name,lns) -> return lns
		Nothing -> r st a b

-- applies a rule by adding the current constraint as a reference (required for coinduction) and updating it with the actual declaration in the end
applyRule :: MonadPlus m => Bool -> String -> SubRulePfT m -> SubRulePfT m
applyRule bool name r st a b = do
	newName <- if bool then newDecl ("ordSub"++name++"1") else newDecl ("lnfSub"++name++"1")
	let ref = Variable newName (PutlnsM st b a)
	updatePrevs (Map.insert newName $ DynPf (PutlnsM st b a) ref) -- add a reference (a promise that this constraint is solved, required for coinduction)
	lns <- r st a b
	{-trace (name++": "++show a ++ " <: " ++ show b) $ -}
	updatePrevs (Map.insert newName $ DynPf (PutlnsM st b a) lns) -- replaces the old reference, since we now have a value
	return $ ref

-- apply a rule but first checks wether the current constraint has already been solved coinductively
applyCoIndRule :: MonadPlus m => Bool -> String -> SubRulePfT m -> SubRulePfT m
applyCoIndRule bool name r = coInd bool (applyRule bool name r)

-- applies one or more rules
applyRules :: MonadPlus m => Bool -> [(String,SubRulePfT m)] -> SubRulePfT m
applyRules bool [(n,r)] st a b = applyRule bool n r st a b
applyRules bool ((n,r):rs) st a b = applyRule bool n r st a b `mplus` applyRules bool rs st a b

-- apply one or more rules but first checks whether the current constraint has already been solved coinductively
applyCoIndRules :: MonadPlus m => Bool -> [(String,SubRulePfT m)] -> SubRulePfT m
applyCoIndRules b l = coInd b (applyRules b l)

data Cfg m = Cfg { ordinary :: MonadPlus m => [(String,SubRulePfT m)], lnf :: MonadPlus m => [(String,SubRulePfT m)] }

cfgOri :: MonadPlus m => Cfg m
cfgOri = Cfg ordinaryRules (lnfRules cfgOri)
cfgOne :: MonadPlus m => Cfg m
cfgOne = Cfg ordinaryOneRules (lnfRules cfgOne)

-- ** Ordinary containment rules

applyCoIndOrdinaryRules :: MonadPlus m => Cfg m -> SubRulePfT m
applyCoIndOrdinaryRules cfg st a b = applyCoIndRules True (ordinary cfg) st a b `mplus` applyRule True "last" (lastR cfg) st a b

applyListCoIndOrdinaryRules :: (Eq a,MonadPlus m,Monad st) => Cfg m -> TypeM st -> Type a -> [DynType] -> SubRuleM m ()
applyListCoIndOrdinaryRules cfg st a [] = return ()
applyListCoIndOrdinaryRules cfg st a (DynT b:bs) = do
	applyCoIndOrdinaryRules cfg st a b
	applyListCoIndOrdinaryRules cfg st a bs
	
ordinaryRules :: MonadPlus m => [(String,SubRulePfT m)]
ordinaryRules = 
	[ ("noAttrs",noAttrs cfgOri),("phi",phi cfgOri),("taut",taut cfgOri),("tau",tau cfgOri) -- basic
	, ("oneOne",oneOne cfgOri),("prodOne",prodOne cfgOri),("sumOne",sumOne cfgOri),("listOne",listOne cfgOri) -- rhs is ()
	, ("litLit",litLit cfgOri),("elEl",elEl cfgOri),("sumLit",sumLit cfgOri),("sumEl",sumEl cfgOri),("prodLit1",prodLit1 cfgOri),("prodLit2",prodLit2 cfgOri),("prodEl1",prodEl1 cfgOri),("prodEl2",prodEl2 cfgOri) -- rhs is l[R]
	, ("oneProd",oneProd cfgOri),("litProd1",litProd1 cfgOri),("litProd2",litProd2 cfgOri),("elProd1",elProd1 cfgOri),("elProd2",elProd2 cfgOri) -- rhs is (R,R)
	, ("prodProd1",prodProd1 cfgOri),("prodProd2",prodProd2 cfgOri),("prodProd3",prodProd3 cfgOri) -- rhs is (R,R)
	, ("sumProd",sumProd cfgOri),("listProd1",listProd1 cfgOri),("listProd2",listProd2 cfgOri) -- rhs is (R,R)
	, ("oneSum1",oneSum1 cfgOri),("oneSum2",oneSum2 cfgOri),("oneSum3",oneSum3 cfgOri) -- rhs is R|R
	, ("litSum1",litSum1 cfgOri),("elSum1",elSum1 cfgOri),("litSum2",litSum2 cfgOri),("elSum2",elSum2 cfgOri),("litSum3",litSum3 cfgOri),("elSum3",elSum3 cfgOri) -- RHS is R|R
	, ("prodSum1",prodSum1 cfgOri),("prodSum2",prodSum2 cfgOri),("prodSum3",prodSum3 cfgOri) -- RHS is R|R
	, ("listSum1",listSum1 cfgOri),("listSum2",listSum2 cfgOri),("listSum3",listSum3 cfgOri) -- RHS is R|R
	, ("sumSum",sumSum cfgOri) -- RHS is R|R
	, ("oneList",oneList cfgOri),("litList",litList cfgOri),("elList",elList cfgOri),("prodList",prodList1 cfgOri) -- RHS is *
	, ("prodList2",prodList2 cfgOri),("sumList",sumList cfgOri),("listList",listList cfgOri) -- RHS is *
--	, ("last",lastR)
	]

ordinaryOneRules :: MonadPlus m => [(String,SubRulePfT m)]
ordinaryOneRules = 
	[ ("noAttrs",noAttrs cfgOne),("phi",phi cfgOne),("taut",taut cfgOne),("tau",tau cfgOne),("oneString",oneString cfgOne) -- basic
	, ("oneOne",oneOne cfgOne),("prodOne",prodOne cfgOne),("sumOne",sumOne cfgOne),("listOne",listOne cfgOne) -- rhs is ()
	, ("litLit",litLit cfgOne),("elEl",elEl cfgOne),("sumLit",sumLit cfgOne),("sumEl",sumEl cfgOne),("prodLit1",prodLit1 cfgOne),("prodLit2",prodLit2 cfgOne),("prodEl1",prodEl1 cfgOne),("prodEl2",prodEl2 cfgOne) -- rhs is l[R]
	, ("oneProd",oneProd cfgOne),("litProd1",litProd1 cfgOne),("litProd2",litProd2 cfgOne),("elProd1",elProd1 cfgOne),("elProd2",elProd2 cfgOne) -- rhs is (R,R)
	, ("prodProd1",prodProd1 cfgOne),("prodProd2",prodProd2 cfgOne),("prodProd3",prodProd3 cfgOne) -- rhs is (R,R)
	, ("sumProd",sumProd cfgOne),("listProd1",listProd1 cfgOne),("listProd2",listProd2 cfgOne) -- rhs is (R,R)
	, ("oneSum1",oneSum1 cfgOne),("oneSum2",oneSum2 cfgOne),("oneSum3",oneSum3 cfgOne) -- rhs is R|R
	, ("litSum1",litSum1 cfgOne),("elSum1",elSum1 cfgOne),("litSum2",litSum2 cfgOne),("elSum2",elSum2 cfgOne),("litSum3",litSum3 cfgOne),("elSum3",elSum3 cfgOne) -- RHS is R|R
	, ("prodSum1",prodSum1 cfgOne),("prodSum2",prodSum2 cfgOne),("prodSum3",prodSum3 cfgOne) -- RHS is R|R
	, ("listSum1",listSum1 cfgOne),("listSum2",listSum2 cfgOne),("listSum3",listSum3 cfgOne) -- RHS is R|R
	, ("sumSum",sumSum cfgOne) -- RHS is R|R
	, ("oneList",oneList cfgOne),("litList",litList cfgOne),("elList",elList cfgOne),("prodList",prodList1 cfgOne) -- RHS is *
	, ("prodList2",prodList2 cfgOne),("sumList",sumList cfgOne),("listList",listList cfgOne) -- RHS is *
--	, ("last",lastR)
	]

-- a speial subtyping rule to remove the C_Attrs constructors added by HaXml
noAttrs :: MonadPlus m => Cfg m -> SubRulePfT m
noAttrs cfg st (Data (Name "@" _) a) b = do
	f <- applyCoIndOrdinaryRules cfg st a b
	return $ CompPut a f OutPut
noAttrs cfg st a (Data (Name "@" _) b) = do
	f <- applyCoIndOrdinaryRules cfg st a b
	return $ CompPut b InnPut f
noAttrs cfg st _ _ = mzero

phi :: MonadPlus m => Cfg m -> SubRulePfT m
phi cfg st Zero r = return BotPut
phi cfg st _ _ = mzero

taut :: MonadPlus m => Cfg m -> SubRulePfT m
taut cfg st r r' = case teq r r' of { Just Eq -> return IdPut; Nothing -> mzero }

tau :: MonadPlus m => Cfg m -> SubRulePfT m
tau cfg st r Tau = return BotPut
tau cfg st _ _ = mzero

oneOne :: MonadPlus m => Cfg m -> SubRulePfT m
oneOne cfg st One One = return IdPut
oneOne cfg st _ _ = mzero

prodOne :: MonadPlus m => Cfg m -> SubRulePfT m
prodOne cfg st (Prod r1 r2) One = do
	f <- applyCoIndOrdinaryRules cfg st r1 One
	g <- applyCoIndOrdinaryRules cfg st r2 One
	return $ CompPut (Prod One One) RemfstOnePut (f `ProdPut` g)
prodOne cfg st _ _ = mzero

sumOne :: MonadPlus m => Cfg m -> SubRulePfT m
sumOne cfg st (Either r1 r2) One = do
	f <- applyCoIndOrdinaryRules cfg st r1 One
	g <- applyCoIndOrdinaryRules cfg st r2 One
	return $ EitherREPut (f `SumPut` g)
sumOne cfg st _ _ = mzero

listOne :: MonadPlus m => Cfg m -> SubRulePfT m
listOne cfg st (List r) One = do
	f <- applyCoIndOrdinaryRules cfg st r One
	return $ (CompPut (List One) ListOneREPut (MapPut f))
listOne cfg st _ _ = mzero

litLit :: MonadPlus m => Cfg m -> SubRulePfT m
litLit cfg st (getLiteral -> Just l1) (getLiteral -> Just l2) = case teq l1 l2 of
	Just Eq -> return IdPut
	Nothing -> mzero
litLit cfg st _ _ = mzero
	
-- special subtyping rule for the case when <a></a> <: <a>str<a/>
oneString :: MonadPlus m => Cfg m -> SubRulePfT m
oneString cfg st One String = return $ FromStringPut One
oneString cfg st _ _ = mzero
	
elEl :: MonadPlus m => Cfg m -> SubRulePfT m
elEl cfg st lr1@(getVPfAttEl -> Just (l1,ViewPf f1 r1)) lr2@(getVPfAttEl -> Just (l2,ViewPf f2 r2)) = do
	guard (l1 == l2)
	f <- applyCoIndOrdinaryRules cfg st r1 r2
	f1' <- inv (PutlnsM st lr1 r1) f1
	return $ CompPut r2 f2 $ CompPut r1 f f1'
elEl cfg st _ _ = mzero

sumLit :: MonadPlus m => Cfg m -> SubRulePfT m
sumLit cfg st (Either r1 r2) (getLiteral -> Just l3) = do
	f <- applyCoIndOrdinaryRules cfg st r1 l3
	g <- applyCoIndOrdinaryRules cfg st r2 l3
	return $ EitherREPut (f `SumPut` g)
sumLit cfg st _ _ = mzero

sumEl :: MonadPlus m => Cfg m -> SubRulePfT m
sumEl cfg st (Either r1 r2) lr3@(getAttEl -> Just (l3,_)) = do
	f <- applyCoIndOrdinaryRules cfg st r1 lr3
	g <- applyCoIndOrdinaryRules cfg st r2 lr3
	return $ EitherREPut (f `SumPut` g)
sumEl cfg st _ _ = mzero

prodLit1 :: MonadPlus m => Cfg m -> SubRulePfT m
prodLit1 cfg st (Prod r1 r2) (getLiteral -> Just l3) = do
	f <- applyCoIndOrdinaryRules cfg st r1 l3
	g <- applyCoIndOrdinaryRules cfg st r2 One
	return $ CompPut (Prod l3 One) RemsndOnePut (f `ProdPut` g)
prodLit1 cfg st _ _ = mzero

prodLit2 :: MonadPlus m => Cfg m -> SubRulePfT m
prodLit2 cfg st (Prod r1 r2) (getLiteral -> Just l3) = do
	g <- applyCoIndOrdinaryRules cfg st r2 l3
	f <- applyCoIndOrdinaryRules cfg st r1 One
	return $ CompPut (Prod One l3) RemfstOnePut (f `ProdPut` g)
prodLit2 cfg st _ _ = mzero

prodEl1 :: MonadPlus m => Cfg m -> SubRulePfT m
prodEl1 cfg st (Prod r1 r2) lr3@(getAttEl -> Just (l3,_)) = do
	f <- applyCoIndOrdinaryRules cfg st r1 lr3
	g <- applyCoIndOrdinaryRules cfg st r2 One
	return $ CompPut (Prod lr3 One) RemsndOnePut (f `ProdPut` g)
prodEl1 cfg st _ _ = mzero
	
prodEl2 :: MonadPlus m => Cfg m -> SubRulePfT m
prodEl2 cfg st (Prod r1 r2) lr3@(getAttEl -> Just (l3,_)) = do
	g <- applyCoIndOrdinaryRules cfg st r2 lr3
	f <- applyCoIndOrdinaryRules cfg st r1 One
	return $ CompPut (Prod One lr3) RemfstOnePut (f `ProdPut` g)
prodEl2 cfg st _ _ = mzero

oneProd :: MonadPlus m => Cfg m -> SubRulePfT m
oneProd cfg st One (Prod r1 r2) = do
	f <- applyCoIndOrdinaryRules cfg st One r1
	g <- applyCoIndOrdinaryRules cfg st One r2
	return $ CompPut (Prod One One) (f `ProdPut` g) AddfstOnePut
oneProd cfg st _ _ = mzero

litProd1 :: MonadPlus m => Cfg m -> SubRulePfT m
litProd1 cfg st (getLiteral -> Just l1) (Prod r2 r3) = do
	f <- applyCoIndOrdinaryRules cfg st l1 r2
	g <- applyCoIndOrdinaryRules cfg st One r3
	return $ CompPut (Prod l1 One) (f `ProdPut` g) AddsndOnePut
litProd1 cfg st _ _ = mzero
	
litProd2 :: MonadPlus m => Cfg m -> SubRulePfT m
litProd2 cfg st (getLiteral -> Just l1) (Prod r2 r3) = do
	f <- applyCoIndOrdinaryRules cfg st One r2
	g <- applyCoIndOrdinaryRules cfg st l1 r3
	return $ CompPut (Prod One l1) (f `ProdPut` g) AddfstOnePut
litProd2 cfg st _ _ = mzero

elProd1 :: MonadPlus m => Cfg m -> SubRulePfT m
elProd1 cfg st lr1@(getAttEl -> Just (l1,_)) (Prod r2 r3) = do
	f <- applyCoIndOrdinaryRules cfg st lr1 r2
	g <- applyCoIndOrdinaryRules cfg st One r3
	return $ CompPut (Prod lr1 One) (f `ProdPut` g) AddsndOnePut
elProd1 cfg st _ _ = mzero

elProd2 :: MonadPlus m => Cfg m -> SubRulePfT m
elProd2 cfg st lr1@(getAttEl -> Just (l1,_)) (Prod r2 r3) = do
	f <- applyCoIndOrdinaryRules cfg st One r2
	g <- applyCoIndOrdinaryRules cfg st lr1 r3
	return $ CompPut (Prod One lr1) (f `ProdPut` g) AddfstOnePut
elProd2 cfg st _ _ = mzero

prodProd1 :: MonadPlus m => Cfg m -> SubRulePfT m
prodProd1 cfg st (Prod r1 r2) (Prod r3 r4) = do
	f <- applyCoIndOrdinaryRules cfg st (Prod r1 r2) r3
	g <- applyCoIndOrdinaryRules cfg st One r4
	return $ CompPut (Prod (Prod r1 r2) One) (f `ProdPut` g) AddsndOnePut
prodProd1 cfg st _ _ = mzero

prodProd2 :: MonadPlus m => Cfg m -> SubRulePfT m
prodProd2 cfg st (Prod r1 r2) (Prod r3 r4) = do
	f <- applyCoIndOrdinaryRules cfg st r1 r3
	g <- applyCoIndOrdinaryRules cfg st r2 r4
	return (f `ProdPut` g)
prodProd2 cfg st _ _ = mzero

prodProd3 :: MonadPlus m => Cfg m -> SubRulePfT m
prodProd3 cfg st (Prod r1 r2) (Prod r3 r4) = do
	f <- applyCoIndOrdinaryRules cfg st One r3
	g <- applyCoIndOrdinaryRules cfg st (Prod r1 r2) r4
	return $ CompPut (Prod One (Prod r1 r2)) (f `ProdPut` g) AddfstOnePut
prodProd3 cfg st _ _ = mzero

sumProd :: MonadPlus m => Cfg m -> SubRulePfT m
sumProd cfg st (Either r1 r2) (Prod r3 r4) = do
	f <- applyCoIndOrdinaryRules cfg st r1 (Prod r3 r4)
	g <- applyCoIndOrdinaryRules cfg st r2 (Prod r3 r4)
	return $ EitherREPut (f `SumPut` g)
sumProd cfg st _ _ = mzero

listProd1 :: MonadPlus m => Cfg m -> SubRulePfT m
listProd1 cfg st (List r1) (Prod r2 r3) = do
	f <- applyCoIndOrdinaryRules cfg st (List r1) r2
	g <- applyCoIndOrdinaryRules cfg st One r3
	return $ CompPut (Prod (List r1) One) (f `ProdPut` g) AddsndOnePut
listProd1 cfg st _ _ = mzero

listProd2 :: MonadPlus m => Cfg m -> SubRulePfT m
listProd2 cfg st (List r1) (Prod r2 r3) = do
	g <- applyCoIndOrdinaryRules cfg st (List r1) r3
	f <- applyCoIndOrdinaryRules cfg st One r2
	return $ CompPut (Prod One (List r1)) (f `ProdPut` g) AddfstOnePut
listProd2 cfg st _ _ = mzero

oneSum1 :: MonadPlus m => Cfg m -> SubRulePfT m
oneSum1 cfg st One (Either r1 r2) = do
	f <- applyCoIndOrdinaryRules cfg st One r1
	g <- applyCoIndOrdinaryRules cfg st One r2
	return $ CompPut (Either One One) (f `SumPut` g) InjlSPut
oneSum1 cfg st _ _ = mzero

oneSum2 :: MonadPlus m => Cfg m -> SubRulePfT m
oneSum2 cfg st One (Either r1 r2) = do
	f <- applyCoIndOrdinaryRules cfg st One r1
	return $ CompPut r1 InjlPut f
oneSum2 cfg st _ _ = mzero

oneSum3 :: MonadPlus m => Cfg m -> SubRulePfT m
oneSum3 cfg st One (Either r1 r2) = do
	f <- applyCoIndOrdinaryRules cfg st One r2
	return $ CompPut r2 InjrPut f
oneSum3 cfg st _ _ = mzero

litSum1 :: MonadPlus m => Cfg m -> SubRulePfT m
litSum1 cfg st (getLiteral -> Just l1) (Either r2 r3) = do
	f <- applyCoIndOrdinaryRules cfg st l1 r2
	g <- applyCoIndOrdinaryRules cfg st l1 r3
	return $ CompPut (Either l1 l1) (f `SumPut` g) InjlSPut
litSum1 cfg st _ _ = mzero

elSum1 :: MonadPlus m => Cfg m -> SubRulePfT m
elSum1 cfg st lr1@(getAttEl -> Just (l1,_)) (Either r2 r3) = do
	f <- applyCoIndOrdinaryRules cfg st lr1 r2
	g <- applyCoIndOrdinaryRules cfg st lr1 r3
	return $ CompPut (Either lr1 lr1) (f `SumPut` g) InjlSPut
elSum1 cfg st _ _ = mzero

litSum2 :: MonadPlus m => Cfg m -> SubRulePfT m
litSum2 cfg st (getLiteral -> Just l1) (Either r2 r3) = do
	f <- applyCoIndOrdinaryRules cfg st l1 r2
	return $ CompPut r2 InjlPut f 
litSum2 cfg st _ _ = mzero

elSum2 :: MonadPlus m => Cfg m -> SubRulePfT m
elSum2 cfg st lr1@(getAttEl -> Just (l1,_)) (Either r2 r3) = do
	f <- applyCoIndOrdinaryRules cfg st lr1 r2
	return $ CompPut r2 InjlPut f 
elSum2 cfg st _ _ = mzero

litSum3 :: MonadPlus m => Cfg m -> SubRulePfT m
litSum3 cfg st (getLiteral -> Just l1) (Either r2 r3) = do
	f <- applyCoIndOrdinaryRules cfg st l1 r3
	return $ CompPut r3 InjrPut f 
litSum3 cfg st _ _ = mzero

elSum3 :: MonadPlus m => Cfg m -> SubRulePfT m
elSum3 cfg st lr1@(getAttEl -> Just (l1,_)) (Either r2 r3) = do
	f <- applyCoIndOrdinaryRules cfg st lr1 r3
	return $ CompPut r3 InjrPut f 
elSum3 cfg st _ _ = mzero

prodSum1 :: MonadPlus m => Cfg m -> SubRulePfT m
prodSum1 cfg st (Prod r1 r2) (Either r3 r4) = do
	f <- applyCoIndOrdinaryRules cfg st (Prod r1 r2) r3
	g <- applyCoIndOrdinaryRules cfg st (Prod r1 r2) r4
	return $ CompPut (Either (Prod r1 r2) (Prod r1 r2)) (f `SumPut` g) InjlSPut
prodSum1 cfg st _ _ = mzero

prodSum2 :: MonadPlus m => Cfg m -> SubRulePfT m
prodSum2 cfg st (Prod r1 r2) (Either r3 r4) = do
	f <- applyCoIndOrdinaryRules cfg st (Prod r1 r2) r3
	return $ CompPut r3 InjlPut f
prodSum2 cfg st _ _ = mzero

prodSum3 :: MonadPlus m => Cfg m -> SubRulePfT m
prodSum3 cfg st (Prod r1 r2) (Either r3 r4) = do
	f <- applyCoIndOrdinaryRules cfg st (Prod r1 r2) r4
	return $ CompPut r4 InjrPut f
prodSum3 cfg st _ _ = mzero

listSum1 :: MonadPlus m => Cfg m -> SubRulePfT m
listSum1 cfg st (List r1) (Either r2 r3) = do
	f <- applyCoIndOrdinaryRules cfg st (List r1) r2
	g <- applyCoIndOrdinaryRules cfg st (List r1) r3
	return $ CompPut (Either (List r1) (List r1)) (f `SumPut` g) InjlSPut
listSum1 cfg st _ _ = mzero

listSum2 :: MonadPlus m => Cfg m -> SubRulePfT m
listSum2 cfg st (List r1) (Either r2 r3) = do
	f <- applyCoIndOrdinaryRules cfg st (List r1) r2
	return $ CompPut r2 InjlPut f
listSum2 cfg st _ _ = mzero

listSum3 :: MonadPlus m => Cfg m -> SubRulePfT m
listSum3 cfg st (List r1) (Either r2 r3) = do
	f <- applyCoIndOrdinaryRules cfg st (List r1) r3
	return $ CompPut r3 InjrPut f
listSum3 cfg st _ _ = mzero

sumSum :: MonadPlus m => Cfg m -> SubRulePfT m
sumSum cfg st (Either r1 r2) (Either r3 r4) = do
	f <- applyCoIndOrdinaryRules cfg st r1 (Either r3 r4)
	g <- applyCoIndOrdinaryRules cfg st r2 (Either r3 r4)
	return $ EitherREPut (f `SumPut` g)
sumSum cfg st _ _ = mzero

oneList :: MonadPlus m => Cfg m -> SubRulePfT m
oneList cfg st One (List r1) = return NilPut --KeepDefPut
oneList cfg st _ _ = mzero

litList :: MonadPlus m => Cfg m -> SubRulePfT m
litList cfg st (getLiteral -> Just l1) (List r2) = do
	f <- applyCoIndOrdinaryRules cfg st l1 r2
	return $ CompPut r2 (wrapPutPf r2) f
--	return $ CompPut r2 (unheadPutPf st r2) f
litList cfg st _ _ = mzero

elList :: MonadPlus m => Cfg m -> SubRulePfT m
elList cfg st lr1@(getAttEl -> Just (l1,_)) (List r2) = do
	f <- applyCoIndOrdinaryRules cfg st lr1 r2
	return $ CompPut r2 (wrapPutPf r2) f
--	return $ CompPut r2 (unheadPutPf st r2) f
elList cfg st _ _ = mzero

--unheadPutPf :: (Monad lensm,Eq a) => TypeM lensm -> -> Type a -> Pf (PutlensM lensm e [a] a)
--unheadPutPf st a = CompPut (Prod a (List a)) ConsPut KeepsndDefPut

prodList1 :: MonadPlus m => Cfg m -> SubRulePfT m
--prodList1 cfg (Prod r1 r2) (List r3) = do
--	f <- applyCoIndOrdinaryRules cfg st r1 (List r3)
--	g <- applyCoIndOrdinaryRules cfg st r2 (List r3)
prodList1 cfg st _ _ = mzero

prodList2 :: MonadPlus m => Cfg m -> SubRulePfT m
prodList2 cfg st (Prod r1 r2) (List r3) = do
	f <- applyCoIndOrdinaryRules cfg st (Prod r1 r2) r3
	return $ CompPut r3 (wrapPutPf r3) f
--	return $ CompPut r3 (unheadPutPf st r3) f
prodList2 cfg st _ _ = mzero

sumList :: MonadPlus m => Cfg m -> SubRulePfT m
sumList cfg st (Either r1 r2) (List r3) = do
	f <- applyCoIndOrdinaryRules cfg st r1 (List r3)
	g <- applyCoIndOrdinaryRules cfg st r2 (List r3)
	return $ EitherREPut (f `SumPut` g)
sumList cfg st _ _ = mzero

listList :: MonadPlus m => Cfg m -> SubRulePfT m
--listList cfg (List r1) (List r2) = do
--	f <- applyCoIndOrdinaryRules cfg st r1 (List r2)
--	return $ 
listList cfg st _ _ = mzero

lastR :: MonadPlus m => Cfg m -> SubRulePfT m
lastR cfg st r1 r2 = do
	ViewPf f n1 <- norm' r1
	ViewPf g b2 <- (norm' >>>> clu) r2
	h <- applyCoIndlnfRules cfg st n1 b2
	f' <- inv (PutlnsM st r1 n1) f
	return $ CompPut b2 g $ CompPut n1 h f'
	
-- * Normalized containment rules

applyCoIndlnfRules :: MonadPlus m => Cfg m -> SubRulePfT m
applyCoIndlnfRules cfg = applyCoIndRules False (lnf cfg)
	
lnfRules :: MonadPlus m => Cfg m -> [(String,SubRulePfT m)]
lnfRules cfg =
	[ ("mM1lnf",mM1lnf cfg) {-, ("mC1lnf",mC1lnf)-}
	, ("oneOnelnf",oneOnelnf cfg),("sumNormlnf",sumNormlnf cfg)
	, ("normSum1lnf",normSum1lnf cfg),("normSum2lnf",normSum2lnf cfg)
	]
	
mM1lnf :: MonadPlus m => Cfg m -> SubRulePfT m
mM1lnf cfg st (Prod (getLiteral ->Just l1) r1) (Prod (getLiteral -> Just l2) r2) = do
	case teq l1 l2 of
		Just Eq -> do
			f <- applyCoIndOrdinaryRules cfg st r1 r2
			return (IdPut `ProdPut` f)
		Nothing -> mzero
mM1lnf cfg st (Prod lr1'@(getVPfAttElM st -> Just (l1,ViewPf f1 r1')) r1) (Prod lr2'@(getVPfAttElM st -> Just (l2,ViewPf f2 r2')) r2) = do
	if l1 == l2
		then do
			g <- applyCoIndOrdinaryRules cfg st r1 r2
			h <- applyCoIndOrdinaryRules cfg st r1' r2'
			f1' <- inv (PutlnsM st lr1' r1') f1
			return $ (CompPut r2' f2 $ CompPut r1' h f1') `ProdPut` g
		else mzero
mM1lnf cfg st _ _ = mzero

mC1lnf :: MonadPlus m => Cfg m -> SubRulePfT m
mC1lnf cfg st a@(Prod (getAttEl -> Just (l0,_)) t) b@(Either (Prod (getAttEl -> Just (l1,_)) r1') rs) = do
	guard (l0 == l1)
	(DynT k,gs) <- clutokag b
	f <- applyCoIndOrdinaryRules cfg st a k
	applyListCoIndOrdinaryRules cfg st a gs -- we don't need the result
	g <- applyCoIndOrdinaryRules cfg T.Identity b k
	return $ CompPut k (UnsafeInvPut "mC1lnf" g) f
mC1lnf cfg st _ _ = mzero

oneOnelnf :: MonadPlus m => Cfg m -> SubRulePfT m
oneOnelnf cfg st One One = return IdPut
oneOnelnf cfg st _ _ = mzero

sumNormlnf :: MonadPlus m => Cfg m -> SubRulePfT m
sumNormlnf cfg st (Either n1 n2) b3 = do
	f <- applyCoIndlnfRules cfg st n1 b3
	g <- applyCoIndlnfRules cfg st n2 b3
	return $ EitherREPut (f `SumPut` g)
sumNormlnf cfg st _ _ = mzero

normSum1lnf :: MonadPlus m => Cfg m -> SubRulePfT m
normSum1lnf cfg st n1 (Either b2 b3) = do
	f <- applyCoIndlnfRules cfg st n1 b2
	return $ CompPut b2 InjlPut f
normSum1lnf cfg st _ _ = mzero

normSum2lnf :: MonadPlus m => Cfg m -> SubRulePfT m
normSum2lnf cfg st n1 (Either b2 b3) = do
	f <- applyCoIndlnfRules cfg st n1 b3
	return $ CompPut b3 InjrPut f
normSum2lnf cfg st _ _ = mzero











