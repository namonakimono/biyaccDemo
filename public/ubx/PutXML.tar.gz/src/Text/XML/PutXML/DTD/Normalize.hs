module Text.XML.PutXML.DTD.Normalize where

import Text.XML.PutXML.Lenses.Default
import Text.XML.PutXML.DTD.SubType
import Text.XML.PutXML.Lenses.ViewPf
import Text.XML.PutXML.DTD.Type as Type
import Text.XML.HaXml.DtdToHaskell.TypeDef hiding (List,Any,String)
import Text.XML.PutXML.Lenses.View hiding (Ref)
import Generics.Putlenses.Putlens as Putlens
import Generics.Putlenses.Language
import Generics.Putlenses.Examples.Examples
import Control.Monad
import Data.Maybe
import Control.Monad.State (State(..),MonadState(..),StateT)
import qualified Control.Monad.State as State
import Text.XML.PutXML.Lenses.Pf
import Data.Map (Map(..))
import qualified Data.Map as Map
import Text.PrettyPrint.HughesPJ
import Control.Monad.Trans
import Data.List
import Text.XML.PutXML.Lenses.Lib

import Debug.Trace

subtypeputNormWithDecls :: (Eq a,Eq b,MonadPlus m,Monad lensm) => TypeM lensm -> Type a -> Type b -> (StateT Prevs m) (Pf (PutlensM lensm b a))
subtypeputNormWithDecls lensm a b = do
	ViewPf f b' <- normalizePfT lensm b
	RefPf g a' <- normalizeViewPfT lensm a
	if isUnambiguous a' && isUnambiguous b'
		then do
			sub <- subtypeputWithDecls lensm a' b'
			return $ CompPut b' f $ CompPut a' sub g
		else fail $ "subtyping: types not normalized " ++ show a' ++ "\n" ++ show b'

subtypeputOneNormWithDecls :: (Eq a,Eq b,MonadPlus m,Monad lensm) => TypeM lensm -> Type a -> Type b -> (StateT Prevs m) (Pf (PutlensM lensm b a))
subtypeputOneNormWithDecls lensm a b = do 
	ViewPf f b' <- normalizePfT lensm b
	RefPf g a' <- normalizeViewPfT lensm a
	if isUnambiguous a' && isUnambiguous b'
		then do
			sub <- subtypeputOneWithDecls lensm a' b'
			return $ CompPut b' f $ CompPut a' sub g
		else fail $ "subtyping1: types not normalized " ++ show a' ++ "\n" ++ show b'

normalizeViewPfT :: (MonadPlus m,Monad lensm) => TypeM lensm -> RefRulePfT m lensm
normalizeViewPfT lensm a = do
	ViewPf f a' <- manyPf (oncePf (removeProdOnePf |||| assocRightPf |||| rec)) a
	f' <- inv (PutlnsM lensm a a') f
	return $ RefPf f' a'
  where rec :: (MonadPlus m,Monad lensm) => RulePfT m lensm
        rec (Tag n t) = do { ViewPf f t' <- many1Pf (oncePf (removeProdOnePf |||| assocRightPf |||| rec)) t; return $ ViewPf f (Tag n t') }
        rec a = mzero

-- expands an arbitrary type into a right-nested sum of products
sumsprods :: (MonadPlus m,Monad lensm) => RuleT m lensm
sumsprods = many (once (distribute ||| coassocRight ||| assocRight ||| rec))
  where rec :: (MonadPlus m,Monad lensm) => RuleT m lensm
        rec (Tag n t) = do { View f t' <- many1 (once (distribute ||| coassocRight ||| assocRight ||| rec)) t; return $ View f (Tag n t') }
        rec a = mzero

sumsprodsPf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
sumsprodsPf = manyPf (oncePf (distributePf |||| coassocRightPf |||| assocRightPf |||| rec))
  where rec :: (MonadPlus m,Monad lensm) => RulePfT m lensm
        rec (Tag n t) = do { ViewPf f t' <- many1Pf (oncePf (distributePf |||| coassocRightPf |||| assocRightPf |||| rec)) t; return $ ViewPf f (Tag n t') }
        rec a = mzero

-- TODO: make this test precise! by using existing automata algorithms?
isUnambiguous :: Eq a => Type a -> Bool
isUnambiguous a = isJust (sumsprods a >>= \(View (put2lensErr "isUnambiguous" -> _) a') -> guard (isUnambiguous' a'))

isUnambiguous' :: Eq a => Type a -> Bool
isUnambiguous' One = True
isUnambiguous' (getLiteral -> Just a) = True
isUnambiguous' (Cut a) = False
isUnambiguous' (Data (Name "@" _) a) = isUnambiguous' a
isUnambiguous' (Tag n a) = isUnambiguous' a
isUnambiguous' (Data n t) = True -- datatypes are assumed to be normalized
isUnambiguous' (TypeRef ref t) = True -- references are assumed to be normalized
isUnambiguous' (Prod a@(isEmptyType -> True) b) = False
isUnambiguous' (Prod a (Prod b@(isEmptyType -> True) c)) = False
isUnambiguous' (Prod a b) = isUnambiguous' a && isUnambiguousProd a b
isUnambiguous' (Either a b) = case evalsubtype a b of
	Just sub -> False
	Nothing -> isUnambiguous' a && isUnambiguousEither a b
isUnambiguous' (List a) = isUnambiguous' a && isUnambiguousList a

isUnambiguousProd :: (Eq a,Eq b) => Type a -> Type b -> Bool
isUnambiguousProd l (Prod a b) = case isomorphism (Prod l a) l of
	Just sub -> False
	Nothing -> case isomorphism (Prod l a) a of
		Just sub -> False
		Nothing -> isUnambiguous' a && isUnambiguousProd a b
isUnambiguousProd l a = case isomorphism (Prod l a) l of
	Just sub -> False
	Nothing -> case isomorphism (Prod l a) a of
		Just sub -> False
		Nothing -> isUnambiguous' a

isUnambiguousEither :: (Eq a,Eq b) => Type a -> Type b -> Bool
isUnambiguousEither l (Either a b) = case evalsubtype a l of
	Just sub -> False
	Nothing -> isUnambiguous' a && isUnambiguousEither l b
isUnambiguousEither l a = case evalsubtype a l of
	Just sub -> False
	Nothing -> isUnambiguous' a

isUnambiguousList :: Eq a => Type a -> Bool
isUnambiguousList (Either (isEmptyType -> True) b) = False
isUnambiguousList (Either a (Either (isEmptyType -> True) c)) = False
isUnambiguousList (Either a (Either b c)) = isUnambiguousList (Either (Either a b) c)
isUnambiguousList (Either a (isEmptyType -> True)) = False
isUnambiguousList a@(isEmptyType -> True) = False
isUnambiguousList a = case isomorphism (List a) a of
	Just sub -> False
	Nothing -> case isomorphism (List a) (Either a One) of
		Just sub -> False
		Nothing -> True

normalizeT :: (MonadPlus m,Monad lensm) => TypeM lensm -> RuleT m lensm
normalizeT lensm = sumsprods >>> cutT lensm

-- deletes all cuts but preserve the empty values (inside lists) that would be lost by subtyping
cutT :: (MonadPlus m,Monad lensm) => TypeM lensm -> RuleT m lensm
cutT lensm (getLiteral -> Just a) = nop a
cutT lensm One = nop One
cutT lensm (Cut a) = return $ View (keepDefPut a) One -- notice that cuts inside lists are deleted before this rule
cutT lensm (Data (Name "@" _) a) = cutT lensm a >>= \(View f b) -> return $ View (innPut .< f) b
cutT lensm (Tag n a) = do { View f b <- cutT lensm a; return $ View f (Tag n b) } -- tags may need to be normalized
cutT lensm a@(Data n t) = nop a -- datatypes are assumed to be normalized
cutT lensm a@(TypeRef ref t) = nop a -- references are assumed to be normalized
cutT lensm (Prod a@(isEmptyType -> True) b) = do
	View f b' <- cutT lensm b
	return $ View ((keepDefPut a ><< idPut) .< addfstOnePut .< f) b'
cutT lensm (Prod a (Prod b@(isEmptyType -> True) c)) = do
	View f ac' <- cutT lensm (Prod a c)
	return $ View ((idPut ><< ((keepDefPut b ><< idPut) .< addfstOnePut)) .< f) ac'
cutT lensm (Prod a b) = do -- depth-first: the types are already normalized, so it is okay to use subtyping
	View f a' <- cutT lensm a
	View g b' <- cutT lensm b
	View h ab' <- prodT lensm a' b'
	return $ View ((f ><< g) .< h) ab'
cutT lensm (Either a b) = do -- depth-first: subtyping here is safe as a lens because the types are already normalized (no (a*,a*) or (a|a))
	View f a' <- (cutT lensm) a
	View g b' <- (cutT lensm) b
	case evalsubtypeput Type.Identity a' b' of
		Just sub -> do
			let p y = isJust (Putlens.getM sub y)
--			return $ View ((f -|-< g) .< ifVthenelsePut p (injlPut .< unsafeInvPut sub) injrPut) b'
			let choose (Just (Left s)) v = return $ p v
			    choose (Just (Right s)) v = return False
			    choose Nothing v = return $ p v
			return $ View (((f .< unsafeInvPut "cutTeither" sub) -|-< g) .< injPut choose) b'
		Nothing -> do
			View h ab' <- eitherT a' b'
			return $ View ((f -|-< g) .< h) ab'
cutT lensm (List a) = do
	ViewList g b <- listT a -- first try to remove empty choices (before cutting them)
	View h c <- cutT lensm b -- then try to remove other ambiguities
	View f d <- removeListT lensm (List c) -- then end up trying to remove the list itself (like (a*)*))
	return $ View (g .< mapPut h .< f) d

--removeEitherCuts :: (MonadPlus m,Monad lensm) => TypeM lensm -> RuleT m lensm
--removeEitherCuts lensm (Either a b) = do
--	View f a' <- removeEitherCuts lensm a
--	View g b' <- removeEitherCuts lensm b
--	return $ View (f -|-< g) (Either a' b')
--removeEitherCuts lensm (Cut a) = return $ View (keepDefPut a) One
--removeEitherCuts lensm a = return $ View idPut a

-- assumes that the inner type of a list is normalized, and normalizes the list by eventually removing it
removeListT :: (MonadPlus m,Monad lensm) => TypeM lensm -> RuleT m lensm
removeListT lensm (List a@(isEmptyType -> True)) = return $ View (mapPut (keepDefPut a) .< listOneEqPut) One
removeListT lensm (List a) = case isomorphismput lensm (List a) a of -- like (a*)* 
	Just sub -> return $ View sub a
	Nothing -> case isomorphismput lensm (List a) (Either a One) of -- like (a+)*
		Just sub -> return $ View sub (Either a One)
		Nothing -> return $ View idPut (List a)

-- given a left type and a right product of types, tries to merge the current type from left-to-right with the right-side type
prodT :: (Eq l,Eq p,MonadPlus m,Monad lensm) => TypeM lensm -> Type l -> Type p -> m (View lensm (l,p))
prodT lensm l (Prod a b) = case isomorphismput lensm (Prod l a) l of
	Just sub -> do
		View f lb' <- prodT lensm l b
		return $ View (assocrPut .< (sub ><< idPut) .< f) lb'
	Nothing -> case isomorphismput lensm (Prod l a) a of
		Just sub -> return $ View (assocrPut .< (sub ><< idPut)) (Prod a b)
		Nothing -> return $ View idPut (Prod l (Prod a b))
prodT lensm l a = case isomorphismput lensm (Prod l a) l of
	Just sub -> return $ View sub l
	Nothing -> case isomorphismput lensm (Prod l a) a of
		Just sub -> return $ View sub a
		Nothing -> return $ View idPut (Prod l a)

-- given a left type and a right sum of types, checks if any right choice is a subtype of the left reference type
-- assumes a right-nested sum of products, and preserves it
eitherT :: (Eq l,Eq e,MonadPlus m,Monad lensm) => Type l -> Type e -> m (View lensm (Either l e))
eitherT l (Either a b) = case evalsubtypeput Type.Identity a l of
	Just sub -> do
		let p xs = isJust (Putlens.getM sub xs)
		View f b' <- eitherT l b
		let choose (Just (Left s)) v = return False
		    choose (Just (Right s)) v = return $ not $ p v
		    choose Nothing v = return $ not $ p v
		return $ View (coassocrPut .< ((idPut -|-< unsafeInvPut "eitherT" sub) .< injPut choose -|-< idPut) .< f) b'
--		return $ View (coassocrPut .< (ifVthenelsePut p (injrPut .< unsafeInvPut sub) injlPut -|-< idPut) .< f) b'
	Nothing -> do
		View f b' <- eitherT l b
		return $ View (cosubrPut .< (idPut -|-< f)) (Either a b')
eitherT l a = case evalsubtypeput Type.Identity a l of
	Just sub -> do
		let p xs = isJust (Putlens.getM sub xs)
		let choose (Just (Left s)) v = return False
		    choose (Just (Right s)) v = return $ not $ p v
		    choose Nothing v = return $ not $ p v
		return $ View ((idPut -|-< unsafeInvPut "eitherT" sub) .< injPut choose) l
--		return $ View (ifVthenelsePut p (injrPut .< unsafeInvPut sub) injlPut) l
	Nothing -> return $ View idPut (Either l a)

data ViewList m a where
	ViewList :: (Monad m,Eq b) => PutlensM m [a] [b] -> Type b -> ViewList m a

-- Filter empty types from a list
-- assumes a right-nested sum of products, and preserves right-nested sums-of-products form
listT :: (Eq a,MonadPlus m,Monad lensm) => Type a -> m (ViewList lensm a)
listT (Either (isEmptyType -> True) b) = do
	ViewList f x <- listT b
	return $ ViewList (filterrightPut .< f) x
listT (Either a (Either (isEmptyType -> True) c)) = do
	ViewList f x <- listT (Either a c)
	return $ ViewList (mapPut cosubrPut .< filterrightPut .< f) x
listT (Either a (Either b c)) = do
	ViewList f x <- listT (Either (Either a b) c)
	View g y <- try coassocRight x
	return $ ViewList (mapPut coassocrPut .< f .< mapPut g) y
listT (Either a (isEmptyType -> True)) = return $ ViewList filterleftPut a
listT a = return $ ViewList idPut a

normalizePfT :: (MonadPlus m,Monad lensm) => TypeM lensm -> RulePfT (StateT Prevs m) lensm
normalizePfT lensm = sumsprodsPf >>>> cutPfT lensm

-- deletes all cuts but preserve the empty values (inside lists) that would be lost by subtyping
cutPfT :: (MonadPlus m,Monad lensm) => TypeM lensm -> RulePfT (StateT Prevs m) lensm
cutPfT lensm (getLiteral -> Just a) = nopPf a
cutPfT lensm One = nopPf One
cutPfT lensm (Cut a) = return $ ViewPf KeepDefPut One -- notice that cuts inside lists are deleted before this rule
cutPfT lensm (Data (Name "@" _) a) = cutPfT lensm a >>= \(ViewPf f b) -> return $ ViewPf (CompPut a InnPut f) b
cutPfT lensm (Tag n a) = do { ViewPf f b <- cutPfT lensm a; return $ ViewPf f (Tag n b) } -- tags may need to be normalized
cutPfT lensm a@(Data n t) = nopPf a -- datatypes are assumed to be normalized
cutPfT lensm a@(TypeRef ref t) = nopPf a -- references are assumed to be normalized
cutPfT lensm (Prod a@(isEmptyType -> True) b) = do
	ViewPf f b' <- cutPfT lensm b
	return $ ViewPf (CompPut (Prod One b) (KeepDefPut `ProdPut` IdPut) $ CompPut b AddfstOnePut f) b'
cutPfT lensm (Prod a (Prod b@(isEmptyType -> True) c)) = do
	ViewPf f ac' <- cutPfT lensm (Prod a c)
	return $ ViewPf (CompPut (Prod a c) (IdPut `ProdPut` (CompPut (Prod One c) (KeepDefPut `ProdPut` IdPut) AddfstOnePut)) f) ac'
cutPfT lensm (Prod a b) = do -- depth-first: the types are already normalized, so it is okay to use subtyping
	ViewPf f a' <- cutPfT lensm a
	ViewPf g b' <- cutPfT lensm b
	ViewPf h ab' <- prodPfT lensm a' b'
	return $ ViewPf (CompPut (Prod a' b') (f `ProdPut` g) h) ab'
cutPfT lensm (Either a b) = do -- depth-first: subtyping here is safe as a lens because the types are already normalized (no (a*,a*) or (a|a))
	ViewPf f a' <- (removeEitherCutsPf lensm >>>> cutPfT lensm) a
	ViewPf g b' <- (removeEitherCutsPf lensm >>>> cutPfT lensm) b
	aux1 lensm a f a' b g b' `mplus` aux2 lensm a f a' b g b'
  where aux1,aux2 :: (Eq a,Eq b,Eq a',Eq b',MonadPlus m,Monad lensm) => TypeM lensm -> Type a -> Pf (PutlensM lensm a a') -> Type a' -> Type b -> Pf (PutlensM lensm b b') -> Type b' -> StateT Prevs m (ViewPf lensm (Either a b))
        aux1 lensm a f a' b g b' = do
			sub <- subtypeputWithDecls Type.Identity a' b'
			esub <- evalUpdPutlnsM Type.Identity b' a' sub
			let p y = isJust (Putlens.getM esub y)
			let choose (Just (Left s)) v = return $ p v
			    choose (Just (Right s)) v = return False
			    choose Nothing v = return $ p v
			return $ ViewPf (CompPut (Either b' b') ((CompPut a' f (UnsafeInvPut "cutTeither1" sub)) `SumPut` g) (InjPut choose)) b'
--			return $ ViewPf (CompPut (Either a' b') (f `SumPut` g) $ IfVthenelsePut p (CompPut a' InjlPut $ UnsafeInvPut sub) InjrPut) b'
        aux2 lensm a f a' b g b' = do
			ViewPf h ab' <- eitherPfT lensm a' b'
			return $ ViewPf (CompPut (Either a' b') (f `SumPut` g) h) ab'	
cutPfT lensm (List a) = do
	ViewListPf g b <- listPfT a -- first try to remove empty choices (before cutting them)
	ViewPf h c <- cutPfT lensm b -- then try to remove other ambiguities
	ViewPf f d <- removeListPfT lensm (List c) -- then end up trying to remove the list itself (like (a*)*))
	return $ ViewPf (CompPut (List b) g $ CompPut (List c) (MapPut h) f) d

removeEitherCutsPf :: (MonadPlus m,Monad lensm) => TypeM lensm -> RulePfT m lensm
removeEitherCutsPf lensm (Either a b) = do
	ViewPf f a' <- removeEitherCutsPf lensm a
	ViewPf g b' <- removeEitherCutsPf lensm b
	return $ ViewPf (f `SumPut` g) (Either a' b')
removeEitherCutsPf lensm (Cut a) = return $ ViewPf KeepDefPut One
removeEitherCutsPf lensm a = return $ ViewPf IdPut a

-- assumes that the inner type of a list is normalized, and normalizes the list by eventually removing it
removeListPfT :: (MonadPlus m,Monad lensm) => TypeM lensm -> RulePfT (StateT Prevs m) lensm
removeListPfT lensm (List a@(isEmptyType -> True)) = return $ ViewPf (CompPut (List One) (MapPut KeepDefPut) ListOneEqPut) One
removeListPfT lensm (List a) = do { sub <- isomorphismPf lensm (List a) a; return $ ViewPf sub a }
	`mplus`                    do { sub <- isomorphismPf lensm (List a) (Either a One); return $ ViewPf sub (Either a One) }
	`mplus`                    return (ViewPf IdPut (List a))

-- given a left type and a right product of types, tries to merge the current type from left-to-right with the right-side type
prodPfT :: (Eq l,Eq p,MonadPlus m,Monad lensm) => TypeM lensm -> Type l -> Type p -> (StateT Prevs m) (ViewPf lensm (l,p))
prodPfT lensm l (Prod a b) =
	        do { sub <- isomorphismPf lensm (Prod l a) l; ViewPf f lb' <- prodPfT lensm l b; return $ ViewPf (CompPut (Prod (Prod l a) b) AssocrPut $ CompPut (Prod l b) (sub `ProdPut` IdPut) f) lb' }
	`mplus` do { sub <- isomorphismPf lensm (Prod l a) a; return $ ViewPf (CompPut (Prod (Prod l a) b) AssocrPut (sub `ProdPut` IdPut)) (Prod a b) }
	`mplus` return (ViewPf IdPut (Prod l (Prod a b)))
prodPfT lensm l a = do { sub <- isomorphismPf lensm (Prod l a) l; return $ ViewPf sub l }
	`mplus`         do { sub <- isomorphismPf lensm (Prod l a) a; return $ ViewPf sub a }
	`mplus`         return (ViewPf IdPut (Prod l a))

-- given a left type and a right sum of types, checks if any right choice is a subtype of the left reference type
-- assumes a right-nested sum of products, and preserves it
eitherPfT :: (Eq l,Eq e,MonadPlus m,Monad lensm) => TypeM lensm -> Type l -> Type e -> (StateT Prevs m) (ViewPf lensm (Either l e))
eitherPfT lensm l (Either a b) = (do
	sub <- subtypeputWithDecls Type.Identity a l
	f <- evalUpdPutlnsM Type.Identity l a sub
	let p xs = isNothing (Putlens.getM f xs)
	ViewPf f b' <- eitherPfT lensm l b
	let choose (Just (Left s)) v = return True
	    choose (Just (Right s)) v = return $ p v
	    choose Nothing v = return $ p v
	return $ ViewPf (CompPut (Either (Either l a) b) CoassocrPut $ CompPut (Either l b) ((CompPut (Either l l) (IdPut `SumPut` (UnsafeInvPut "cuTeither" sub)) (InjPut choose)) `SumPut` IdPut) f) b')
--	return $ ViewPf (CompPut (Either (Either l a) b) CoassocrPut $ CompPut (Either l b) (IfVthenelsePut p (CompPut a InjrPut $ UnsafeInvPut sub) InjlPut `SumPut` IdPut) f) b')
  `mplus` (do
	ViewPf f b' <- eitherPfT lensm l b
	return $ ViewPf (CompPut (Either a (Either l b)) CosubrPut (IdPut `SumPut` f)) (Either a b'))	
eitherPfT lensm l a = (do
	sub <- subtypeputWithDecls Type.Identity a l
	f <- evalUpdPutlnsM Type.Identity l a sub
	let p xs = isNothing (Putlens.getM f xs)
	let choose (Just (Left s)) v = return True
	    choose (Just (Right s)) v = return $ p v
	    choose Nothing v = return $ p v
	return $ ViewPf (CompPut (Either l l) (IdPut `SumPut` UnsafeInvPut ("eitherPfT: "++show l ++ "\n"++show a) sub) (InjPut choose)) l)
--	return $ ViewPf (IfVthenelsePut p (CompPut a InjrPut $ UnsafeInvPut sub) InjlPut) l)
  `mplus` return (ViewPf IdPut (Either l a))

data ViewListPf m a where
	ViewListPf :: (Monad m,Eq b) => Pf (PutlensM m [a] [b]) -> Type b -> ViewListPf m a

-- Filter empty types from a list
-- assumes a right-nested sum of products, and preserves right-nested sums-of-products form
listPfT :: (Eq a,MonadPlus m,Monad lensm) => Type a -> (StateT Prevs m) (ViewListPf lensm a)
listPfT (Either (isEmptyType -> True) b) = do
	ViewListPf f x <- listPfT b
	return $ ViewListPf (CompPut (List b) FilterrightPut f) x
listPfT (Either a (Either b@(isEmptyType -> True) c)) = do
	ViewListPf f x <- listPfT (Either a c)
	return $ ViewListPf (CompPut (List $ Either b (Either a c)) (MapPut CosubrPut) $ CompPut (List $ Either a c) FilterrightPut f) x
listPfT (Either a (Either b c)) = do
	ViewListPf f x <- listPfT (Either (Either a b) c)
	ViewPf g y <- tryPf coassocRightPf x
	return $ ViewListPf (CompPut (List $ Either (Either a b) c) (MapPut CoassocrPut) $ CompPut (List x) f $ MapPut g) y
listPfT (Either a (isEmptyType -> True)) = return $ ViewListPf FilterleftPut a
listPfT a = return $ ViewListPf IdPut a

