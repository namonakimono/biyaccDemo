{-# OPTIONS_GHC -w #-}
module Text.XML.PutXML.Update.Parser where
import Text.XML.PutXML.Update.Token 
import Data.Char
import Data.List
import qualified Data.Text as T
import Data.Maybe
import Text.XML.HXT.DOM.QualifiedName as HXTQN
import Text.XML.PutXML.Update.AST 
import Text.XML.PutXML.XQuery.UXQ

import Text.XML.PutXML.XPath.HXT.XPathDataTypes as XPath

-- parser produced by Happy Version 1.18.10

data HappyAbsSyn 
	= HappyTerminal (Token)
	| HappyErrorToken Int
	| HappyAbsSyn4 (Program)
	| HappyAbsSyn5 ([ImportSchema])
	| HappyAbsSyn6 (ImportSchema)
	| HappyAbsSyn7 ([VarBind])
	| HappyAbsSyn8 (VarBind)
	| HappyAbsSyn9 (Start)
	| HappyAbsSyn10 ([XQExpr])
	| HappyAbsSyn11 ([Decl])
	| HappyAbsSyn12 (Decl)
	| HappyAbsSyn13 (Procedure)
	| HappyAbsSyn14 ([(ProcVar, AstType)])
	| HappyAbsSyn15 ((ProcVar, AstType))
	| HappyAbsSyn16 ([Stmt])
	| HappyAbsSyn17 (Stmt)
	| HappyAbsSyn18 ([(Pat, Stmts)])
	| HappyAbsSyn19 ((Pat, Stmts))
	| HappyAbsSyn20 ([WhereCond])
	| HappyAbsSyn21 (WhereCond)
	| HappyAbsSyn22 (BoolExpr)
	| HappyAbsSyn23 (Upd)
	| HappyAbsSyn24 (Maybe Pat)
	| HappyAbsSyn25 (Maybe MatchCond)
	| HappyAbsSyn26 ([ViewStmt])
	| HappyAbsSyn27 (ViewStmt)
	| HappyAbsSyn28 (MatchCond)
	| HappyAbsSyn29 (XQExpr)
	| HappyAbsSyn31 (XPath.Op)
	| HappyAbsSyn34 (CPath)
	| HappyAbsSyn36 ([Pat])
	| HappyAbsSyn37 (Pat)
	| HappyAbsSyn38 (VarP)
	| HappyAbsSyn39 (AstType)

{- to allow type-synonyms as our monads (likely
 - with explicitly-specified bind and return)
 - in Haskell98, it seems that with
 - /type M a = .../, then /(HappyReduction M)/
 - is not allowed.  But Happy is a
 - code-generator that can just substitute it.
type HappyReduction m = 
	   Int 
	-> (Token)
	-> HappyState (Token) (HappyStk HappyAbsSyn -> [(Token)] -> m HappyAbsSyn)
	-> [HappyState (Token) (HappyStk HappyAbsSyn -> [(Token)] -> m HappyAbsSyn)] 
	-> HappyStk HappyAbsSyn 
	-> [(Token)] -> m HappyAbsSyn
-}

action_0,
 action_1,
 action_2,
 action_3,
 action_4,
 action_5,
 action_6,
 action_7,
 action_8,
 action_9,
 action_10,
 action_11,
 action_12,
 action_13,
 action_14,
 action_15,
 action_16,
 action_17,
 action_18,
 action_19,
 action_20,
 action_21,
 action_22,
 action_23,
 action_24,
 action_25,
 action_26,
 action_27,
 action_28,
 action_29,
 action_30,
 action_31,
 action_32,
 action_33,
 action_34,
 action_35,
 action_36,
 action_37,
 action_38,
 action_39,
 action_40,
 action_41,
 action_42,
 action_43,
 action_44,
 action_45,
 action_46,
 action_47,
 action_48,
 action_49,
 action_50,
 action_51,
 action_52,
 action_53,
 action_54,
 action_55,
 action_56,
 action_57,
 action_58,
 action_59,
 action_60,
 action_61,
 action_62,
 action_63,
 action_64,
 action_65,
 action_66,
 action_67,
 action_68,
 action_69,
 action_70,
 action_71,
 action_72,
 action_73,
 action_74,
 action_75,
 action_76,
 action_77,
 action_78,
 action_79,
 action_80,
 action_81,
 action_82,
 action_83,
 action_84,
 action_85,
 action_86,
 action_87,
 action_88,
 action_89,
 action_90,
 action_91,
 action_92,
 action_93,
 action_94,
 action_95,
 action_96,
 action_97,
 action_98,
 action_99,
 action_100,
 action_101,
 action_102,
 action_103,
 action_104,
 action_105,
 action_106,
 action_107,
 action_108,
 action_109,
 action_110,
 action_111,
 action_112,
 action_113,
 action_114,
 action_115,
 action_116,
 action_117,
 action_118,
 action_119,
 action_120,
 action_121,
 action_122,
 action_123,
 action_124,
 action_125,
 action_126,
 action_127,
 action_128,
 action_129,
 action_130,
 action_131,
 action_132,
 action_133,
 action_134,
 action_135,
 action_136,
 action_137,
 action_138,
 action_139,
 action_140,
 action_141,
 action_142,
 action_143,
 action_144,
 action_145,
 action_146,
 action_147,
 action_148,
 action_149,
 action_150,
 action_151,
 action_152,
 action_153,
 action_154,
 action_155,
 action_156,
 action_157,
 action_158,
 action_159,
 action_160,
 action_161,
 action_162,
 action_163,
 action_164,
 action_165,
 action_166,
 action_167,
 action_168,
 action_169,
 action_170,
 action_171,
 action_172,
 action_173,
 action_174,
 action_175,
 action_176,
 action_177,
 action_178,
 action_179,
 action_180,
 action_181,
 action_182,
 action_183,
 action_184,
 action_185,
 action_186,
 action_187,
 action_188,
 action_189,
 action_190,
 action_191,
 action_192,
 action_193,
 action_194,
 action_195,
 action_196,
 action_197,
 action_198,
 action_199,
 action_200,
 action_201,
 action_202,
 action_203,
 action_204,
 action_205,
 action_206,
 action_207,
 action_208,
 action_209,
 action_210,
 action_211,
 action_212,
 action_213,
 action_214,
 action_215,
 action_216,
 action_217,
 action_218,
 action_219,
 action_220,
 action_221,
 action_222,
 action_223,
 action_224,
 action_225,
 action_226,
 action_227,
 action_228,
 action_229,
 action_230,
 action_231,
 action_232,
 action_233,
 action_234,
 action_235,
 action_236,
 action_237,
 action_238,
 action_239,
 action_240,
 action_241,
 action_242,
 action_243,
 action_244,
 action_245,
 action_246,
 action_247,
 action_248,
 action_249,
 action_250,
 action_251,
 action_252,
 action_253,
 action_254,
 action_255,
 action_256,
 action_257,
 action_258,
 action_259,
 action_260,
 action_261,
 action_262,
 action_263,
 action_264,
 action_265,
 action_266,
 action_267,
 action_268,
 action_269,
 action_270,
 action_271,
 action_272,
 action_273,
 action_274,
 action_275,
 action_276,
 action_277,
 action_278,
 action_279,
 action_280,
 action_281,
 action_282,
 action_283,
 action_284,
 action_285,
 action_286,
 action_287,
 action_288,
 action_289,
 action_290,
 action_291,
 action_292,
 action_293,
 action_294,
 action_295,
 action_296,
 action_297,
 action_298,
 action_299,
 action_300,
 action_301,
 action_302,
 action_303,
 action_304,
 action_305,
 action_306,
 action_307,
 action_308,
 action_309,
 action_310,
 action_311,
 action_312,
 action_313,
 action_314,
 action_315,
 action_316,
 action_317,
 action_318,
 action_319,
 action_320,
 action_321,
 action_322,
 action_323,
 action_324,
 action_325,
 action_326,
 action_327,
 action_328,
 action_329,
 action_330,
 action_331,
 action_332,
 action_333,
 action_334,
 action_335,
 action_336,
 action_337,
 action_338,
 action_339,
 action_340,
 action_341,
 action_342,
 action_343,
 action_344,
 action_345,
 action_346,
 action_347,
 action_348,
 action_349,
 action_350,
 action_351,
 action_352,
 action_353,
 action_354,
 action_355,
 action_356,
 action_357,
 action_358,
 action_359,
 action_360,
 action_361,
 action_362,
 action_363,
 action_364,
 action_365,
 action_366,
 action_367,
 action_368,
 action_369,
 action_370,
 action_371,
 action_372,
 action_373,
 action_374,
 action_375,
 action_376,
 action_377,
 action_378,
 action_379,
 action_380,
 action_381,
 action_382,
 action_383,
 action_384,
 action_385,
 action_386,
 action_387,
 action_388,
 action_389,
 action_390,
 action_391,
 action_392,
 action_393,
 action_394,
 action_395 :: () => Int -> ({-HappyReduction (HappyIdentity) = -}
	   Int 
	-> (Token)
	-> HappyState (Token) (HappyStk HappyAbsSyn -> [(Token)] -> (HappyIdentity) HappyAbsSyn)
	-> [HappyState (Token) (HappyStk HappyAbsSyn -> [(Token)] -> (HappyIdentity) HappyAbsSyn)] 
	-> HappyStk HappyAbsSyn 
	-> [(Token)] -> (HappyIdentity) HappyAbsSyn)

happyReduce_1,
 happyReduce_2,
 happyReduce_3,
 happyReduce_4,
 happyReduce_5,
 happyReduce_6,
 happyReduce_7,
 happyReduce_8,
 happyReduce_9,
 happyReduce_10,
 happyReduce_11,
 happyReduce_12,
 happyReduce_13,
 happyReduce_14,
 happyReduce_15,
 happyReduce_16,
 happyReduce_17,
 happyReduce_18,
 happyReduce_19,
 happyReduce_20,
 happyReduce_21,
 happyReduce_22,
 happyReduce_23,
 happyReduce_24,
 happyReduce_25,
 happyReduce_26,
 happyReduce_27,
 happyReduce_28,
 happyReduce_29,
 happyReduce_30,
 happyReduce_31,
 happyReduce_32,
 happyReduce_33,
 happyReduce_34,
 happyReduce_35,
 happyReduce_36,
 happyReduce_37,
 happyReduce_38,
 happyReduce_39,
 happyReduce_40,
 happyReduce_41,
 happyReduce_42,
 happyReduce_43,
 happyReduce_44,
 happyReduce_45,
 happyReduce_46,
 happyReduce_47,
 happyReduce_48,
 happyReduce_49,
 happyReduce_50,
 happyReduce_51,
 happyReduce_52,
 happyReduce_53,
 happyReduce_54,
 happyReduce_55,
 happyReduce_56,
 happyReduce_57,
 happyReduce_58,
 happyReduce_59,
 happyReduce_60,
 happyReduce_61,
 happyReduce_62,
 happyReduce_63,
 happyReduce_64,
 happyReduce_65,
 happyReduce_66,
 happyReduce_67,
 happyReduce_68,
 happyReduce_69,
 happyReduce_70,
 happyReduce_71,
 happyReduce_72,
 happyReduce_73,
 happyReduce_74,
 happyReduce_75,
 happyReduce_76,
 happyReduce_77,
 happyReduce_78,
 happyReduce_79,
 happyReduce_80,
 happyReduce_81,
 happyReduce_82,
 happyReduce_83,
 happyReduce_84,
 happyReduce_85,
 happyReduce_86,
 happyReduce_87,
 happyReduce_88,
 happyReduce_89,
 happyReduce_90,
 happyReduce_91,
 happyReduce_92,
 happyReduce_93,
 happyReduce_94,
 happyReduce_95,
 happyReduce_96,
 happyReduce_97,
 happyReduce_98,
 happyReduce_99,
 happyReduce_100,
 happyReduce_101,
 happyReduce_102,
 happyReduce_103,
 happyReduce_104,
 happyReduce_105,
 happyReduce_106,
 happyReduce_107,
 happyReduce_108,
 happyReduce_109,
 happyReduce_110,
 happyReduce_111,
 happyReduce_112,
 happyReduce_113,
 happyReduce_114,
 happyReduce_115,
 happyReduce_116,
 happyReduce_117,
 happyReduce_118,
 happyReduce_119,
 happyReduce_120,
 happyReduce_121,
 happyReduce_122,
 happyReduce_123,
 happyReduce_124,
 happyReduce_125,
 happyReduce_126,
 happyReduce_127,
 happyReduce_128,
 happyReduce_129,
 happyReduce_130,
 happyReduce_131,
 happyReduce_132,
 happyReduce_133,
 happyReduce_134,
 happyReduce_135,
 happyReduce_136,
 happyReduce_137,
 happyReduce_138,
 happyReduce_139,
 happyReduce_140,
 happyReduce_141,
 happyReduce_142,
 happyReduce_143,
 happyReduce_144,
 happyReduce_145,
 happyReduce_146,
 happyReduce_147,
 happyReduce_148,
 happyReduce_149,
 happyReduce_150 :: () => ({-HappyReduction (HappyIdentity) = -}
	   Int 
	-> (Token)
	-> HappyState (Token) (HappyStk HappyAbsSyn -> [(Token)] -> (HappyIdentity) HappyAbsSyn)
	-> [HappyState (Token) (HappyStk HappyAbsSyn -> [(Token)] -> (HappyIdentity) HappyAbsSyn)] 
	-> HappyStk HappyAbsSyn 
	-> [(Token)] -> (HappyIdentity) HappyAbsSyn)

action_0 (40) = happyShift action_4
action_0 (4) = happyGoto action_5
action_0 (5) = happyGoto action_2
action_0 (6) = happyGoto action_3
action_0 _ = happyFail

action_1 (40) = happyShift action_4
action_1 (5) = happyGoto action_2
action_1 (6) = happyGoto action_3
action_1 _ = happyFail

action_2 (40) = happyShift action_4
action_2 (106) = happyShift action_10
action_2 (6) = happyGoto action_7
action_2 (7) = happyGoto action_8
action_2 (8) = happyGoto action_9
action_2 _ = happyFail

action_3 _ = happyReduce_2

action_4 (102) = happyShift action_6
action_4 _ = happyFail

action_5 (112) = happyAccept
action_5 _ = happyFail

action_6 (55) = happyShift action_15
action_6 _ = happyFail

action_7 _ = happyReduce_3

action_8 (42) = happyShift action_14
action_8 (106) = happyShift action_10
action_8 (8) = happyGoto action_12
action_8 (9) = happyGoto action_13
action_8 _ = happyFail

action_9 _ = happyReduce_5

action_10 (90) = happyShift action_11
action_10 _ = happyFail

action_11 (43) = happyShift action_23
action_11 _ = happyFail

action_12 _ = happyReduce_6

action_13 (41) = happyShift action_21
action_13 (44) = happyShift action_22
action_13 (11) = happyGoto action_18
action_13 (12) = happyGoto action_19
action_13 (13) = happyGoto action_20
action_13 _ = happyFail

action_14 (90) = happyShift action_17
action_14 _ = happyFail

action_15 (102) = happyShift action_16
action_15 _ = happyFail

action_16 _ = happyReduce_4

action_17 (102) = happyShift action_28
action_17 _ = happyFail

action_18 (41) = happyShift action_21
action_18 (44) = happyShift action_22
action_18 (12) = happyGoto action_27
action_18 (13) = happyGoto action_20
action_18 _ = happyReduce_1

action_19 _ = happyReduce_12

action_20 _ = happyReduce_14

action_21 (105) = happyShift action_26
action_21 _ = happyFail

action_22 (102) = happyShift action_25
action_22 _ = happyFail

action_23 (86) = happyShift action_24
action_23 _ = happyFail

action_24 (103) = happyShift action_32
action_24 _ = happyFail

action_25 (86) = happyShift action_31
action_25 _ = happyFail

action_26 (90) = happyShift action_30
action_26 _ = happyFail

action_27 _ = happyReduce_13

action_28 (86) = happyShift action_29
action_28 _ = happyFail

action_29 (47) = happyShift action_49
action_29 (73) = happyShift action_50
action_29 (76) = happyShift action_51
action_29 (81) = happyShift action_52
action_29 (84) = happyShift action_53
action_29 (97) = happyShift action_54
action_29 (99) = happyShift action_55
action_29 (102) = happyShift action_56
action_29 (103) = happyShift action_57
action_29 (104) = happyShift action_58
action_29 (106) = happyShift action_59
action_29 (108) = happyShift action_60
action_29 (109) = happyShift action_61
action_29 (110) = happyShift action_62
action_29 (10) = happyGoto action_45
action_29 (30) = happyGoto action_46
action_29 (34) = happyGoto action_47
action_29 (35) = happyGoto action_48
action_29 _ = happyReduce_11

action_30 (73) = happyShift action_40
action_30 (81) = happyShift action_41
action_30 (86) = happyShift action_42
action_30 (102) = happyShift action_43
action_30 (105) = happyShift action_44
action_30 (39) = happyGoto action_39
action_30 _ = happyFail

action_31 (48) = happyShift action_36
action_31 (50) = happyShift action_37
action_31 (106) = happyShift action_38
action_31 (14) = happyGoto action_34
action_31 (15) = happyGoto action_35
action_31 _ = happyReduce_19

action_32 (87) = happyShift action_33
action_32 _ = happyFail

action_33 _ = happyReduce_7

action_34 (87) = happyShift action_110
action_34 (94) = happyShift action_111
action_34 _ = happyFail

action_35 _ = happyReduce_17

action_36 (106) = happyShift action_109
action_36 _ = happyFail

action_37 (106) = happyShift action_108
action_37 _ = happyFail

action_38 (55) = happyShift action_107
action_38 _ = happyFail

action_39 (65) = happyShift action_103
action_39 (91) = happyShift action_104
action_39 (92) = happyShift action_105
action_39 (93) = happyShift action_106
action_39 _ = happyReduce_15

action_40 (88) = happyShift action_102
action_40 _ = happyFail

action_41 (102) = happyShift action_101
action_41 _ = happyFail

action_42 (73) = happyShift action_40
action_42 (81) = happyShift action_41
action_42 (86) = happyShift action_42
action_42 (87) = happyShift action_100
action_42 (102) = happyShift action_43
action_42 (105) = happyShift action_44
action_42 (39) = happyGoto action_99
action_42 _ = happyFail

action_43 (88) = happyShift action_97
action_43 (95) = happyShift action_98
action_43 _ = happyFail

action_44 _ = happyReduce_140

action_45 (87) = happyShift action_95
action_45 (94) = happyShift action_96
action_45 _ = happyFail

action_46 _ = happyReduce_9

action_47 (82) = happyShift action_84
action_47 (83) = happyShift action_85
action_47 (88) = happyShift action_86
action_47 (90) = happyShift action_87
action_47 (91) = happyShift action_88
action_47 (93) = happyShift action_89
action_47 (97) = happyShift action_90
action_47 (98) = happyShift action_91
action_47 (100) = happyShift action_92
action_47 (101) = happyShift action_93
action_47 (102) = happyShift action_94
action_47 (31) = happyGoto action_83
action_47 _ = happyReduce_85

action_48 (95) = happyShift action_82
action_48 _ = happyFail

action_49 (106) = happyShift action_81
action_49 _ = happyFail

action_50 (47) = happyShift action_49
action_50 (73) = happyShift action_50
action_50 (76) = happyShift action_51
action_50 (81) = happyShift action_52
action_50 (84) = happyShift action_53
action_50 (88) = happyShift action_79
action_50 (97) = happyShift action_54
action_50 (98) = happyShift action_80
action_50 (99) = happyShift action_55
action_50 (102) = happyShift action_56
action_50 (103) = happyShift action_57
action_50 (104) = happyShift action_58
action_50 (106) = happyShift action_59
action_50 (108) = happyShift action_60
action_50 (109) = happyShift action_61
action_50 (110) = happyShift action_62
action_50 (30) = happyGoto action_78
action_50 (34) = happyGoto action_47
action_50 (35) = happyGoto action_48
action_50 _ = happyFail

action_51 (73) = happyShift action_40
action_51 (81) = happyShift action_74
action_51 (86) = happyShift action_75
action_51 (102) = happyShift action_76
action_51 (105) = happyShift action_44
action_51 (106) = happyShift action_77
action_51 (37) = happyGoto action_71
action_51 (38) = happyGoto action_72
action_51 (39) = happyGoto action_73
action_51 _ = happyFail

action_52 (102) = happyShift action_70
action_52 _ = happyFail

action_53 (73) = happyShift action_68
action_53 (81) = happyShift action_52
action_53 (97) = happyShift action_54
action_53 (99) = happyShift action_55
action_53 (102) = happyShift action_56
action_53 (103) = happyShift action_57
action_53 (104) = happyShift action_58
action_53 (106) = happyShift action_59
action_53 (108) = happyShift action_60
action_53 (109) = happyShift action_61
action_53 (34) = happyGoto action_69
action_53 (35) = happyGoto action_48
action_53 _ = happyFail

action_54 (73) = happyShift action_68
action_54 (81) = happyShift action_52
action_54 (97) = happyShift action_54
action_54 (99) = happyShift action_55
action_54 (102) = happyShift action_56
action_54 (103) = happyShift action_57
action_54 (104) = happyShift action_58
action_54 (106) = happyShift action_59
action_54 (108) = happyShift action_60
action_54 (109) = happyShift action_61
action_54 (34) = happyGoto action_67
action_54 (35) = happyGoto action_48
action_54 _ = happyFail

action_55 _ = happyReduce_103

action_56 (86) = happyShift action_65
action_56 (88) = happyShift action_66
action_56 (95) = happyReduce_127
action_56 _ = happyReduce_124

action_57 (86) = happyShift action_64
action_57 _ = happyReduce_111

action_58 _ = happyReduce_112

action_59 _ = happyReduce_110

action_60 _ = happyReduce_113

action_61 _ = happyReduce_114

action_62 (102) = happyShift action_63
action_62 _ = happyFail

action_63 (80) = happyShift action_155
action_63 (102) = happyShift action_156
action_63 (111) = happyShift action_157
action_63 (32) = happyGoto action_153
action_63 (33) = happyGoto action_154
action_63 _ = happyFail

action_64 (87) = happyShift action_152
action_64 _ = happyFail

action_65 (47) = happyShift action_49
action_65 (73) = happyShift action_50
action_65 (76) = happyShift action_51
action_65 (81) = happyShift action_52
action_65 (84) = happyShift action_53
action_65 (87) = happyShift action_151
action_65 (97) = happyShift action_54
action_65 (99) = happyShift action_55
action_65 (102) = happyShift action_56
action_65 (103) = happyShift action_57
action_65 (104) = happyShift action_58
action_65 (106) = happyShift action_59
action_65 (108) = happyShift action_60
action_65 (109) = happyShift action_61
action_65 (110) = happyShift action_62
action_65 (10) = happyGoto action_150
action_65 (30) = happyGoto action_46
action_65 (34) = happyGoto action_47
action_65 (35) = happyGoto action_48
action_65 _ = happyReduce_11

action_66 (47) = happyShift action_49
action_66 (73) = happyShift action_50
action_66 (76) = happyShift action_51
action_66 (81) = happyShift action_52
action_66 (84) = happyShift action_53
action_66 (97) = happyShift action_54
action_66 (99) = happyShift action_55
action_66 (102) = happyShift action_56
action_66 (103) = happyShift action_57
action_66 (104) = happyShift action_58
action_66 (106) = happyShift action_59
action_66 (108) = happyShift action_60
action_66 (109) = happyShift action_61
action_66 (110) = happyShift action_62
action_66 (30) = happyGoto action_149
action_66 (34) = happyGoto action_47
action_66 (35) = happyGoto action_48
action_66 _ = happyFail

action_67 (88) = happyShift action_86
action_67 (97) = happyShift action_90
action_67 (98) = happyShift action_91
action_67 _ = happyReduce_104

action_68 (88) = happyShift action_79
action_68 (98) = happyShift action_80
action_68 _ = happyFail

action_69 (85) = happyShift action_148
action_69 (88) = happyShift action_86
action_69 (97) = happyShift action_90
action_69 (98) = happyShift action_91
action_69 _ = happyFail

action_70 _ = happyReduce_120

action_71 (77) = happyShift action_147
action_71 _ = happyFail

action_72 _ = happyReduce_133

action_73 (65) = happyShift action_103
action_73 (91) = happyShift action_104
action_73 (92) = happyShift action_105
action_73 (93) = happyShift action_106
action_73 _ = happyReduce_137

action_74 (102) = happyShift action_146
action_74 _ = happyFail

action_75 (73) = happyShift action_40
action_75 (81) = happyShift action_74
action_75 (86) = happyShift action_75
action_75 (87) = happyShift action_100
action_75 (102) = happyShift action_76
action_75 (105) = happyShift action_44
action_75 (106) = happyShift action_77
action_75 (36) = happyGoto action_143
action_75 (37) = happyGoto action_144
action_75 (38) = happyGoto action_72
action_75 (39) = happyGoto action_145
action_75 _ = happyFail

action_76 (88) = happyShift action_142
action_76 (95) = happyShift action_98
action_76 _ = happyFail

action_77 (55) = happyShift action_141
action_77 _ = happyReduce_136

action_78 (74) = happyShift action_140
action_78 _ = happyFail

action_79 (47) = happyShift action_49
action_79 (73) = happyShift action_50
action_79 (76) = happyShift action_51
action_79 (81) = happyShift action_52
action_79 (84) = happyShift action_53
action_79 (97) = happyShift action_54
action_79 (99) = happyShift action_55
action_79 (102) = happyShift action_56
action_79 (103) = happyShift action_57
action_79 (104) = happyShift action_58
action_79 (106) = happyShift action_59
action_79 (108) = happyShift action_60
action_79 (109) = happyShift action_61
action_79 (110) = happyShift action_62
action_79 (30) = happyGoto action_139
action_79 (34) = happyGoto action_47
action_79 (35) = happyGoto action_48
action_79 _ = happyFail

action_80 (73) = happyShift action_68
action_80 (81) = happyShift action_52
action_80 (91) = happyShift action_138
action_80 (97) = happyShift action_54
action_80 (99) = happyShift action_55
action_80 (102) = happyShift action_56
action_80 (103) = happyShift action_57
action_80 (104) = happyShift action_58
action_80 (106) = happyShift action_59
action_80 (108) = happyShift action_60
action_80 (109) = happyShift action_61
action_80 (34) = happyGoto action_137
action_80 (35) = happyGoto action_48
action_80 _ = happyFail

action_81 (78) = happyShift action_136
action_81 _ = happyFail

action_82 (95) = happyShift action_135
action_82 _ = happyFail

action_83 (73) = happyShift action_68
action_83 (81) = happyShift action_52
action_83 (97) = happyShift action_54
action_83 (99) = happyShift action_55
action_83 (102) = happyShift action_56
action_83 (103) = happyShift action_57
action_83 (104) = happyShift action_58
action_83 (106) = happyShift action_59
action_83 (108) = happyShift action_60
action_83 (109) = happyShift action_61
action_83 (34) = happyGoto action_134
action_83 (35) = happyGoto action_48
action_83 _ = happyFail

action_84 (90) = happyShift action_133
action_84 _ = happyReduce_92

action_85 (90) = happyShift action_132
action_85 _ = happyReduce_93

action_86 (47) = happyShift action_49
action_86 (73) = happyShift action_50
action_86 (76) = happyShift action_51
action_86 (81) = happyShift action_52
action_86 (84) = happyShift action_53
action_86 (97) = happyShift action_54
action_86 (99) = happyShift action_55
action_86 (102) = happyShift action_56
action_86 (103) = happyShift action_57
action_86 (104) = happyShift action_58
action_86 (106) = happyShift action_59
action_86 (108) = happyShift action_60
action_86 (109) = happyShift action_61
action_86 (110) = happyShift action_62
action_86 (30) = happyGoto action_131
action_86 (34) = happyGoto action_47
action_86 (35) = happyGoto action_48
action_86 _ = happyFail

action_87 _ = happyReduce_90

action_88 _ = happyReduce_98

action_89 _ = happyReduce_96

action_90 (73) = happyShift action_68
action_90 (81) = happyShift action_52
action_90 (97) = happyShift action_54
action_90 (99) = happyShift action_55
action_90 (102) = happyShift action_56
action_90 (103) = happyShift action_57
action_90 (104) = happyShift action_58
action_90 (106) = happyShift action_59
action_90 (108) = happyShift action_60
action_90 (109) = happyShift action_61
action_90 (34) = happyGoto action_130
action_90 (35) = happyGoto action_48
action_90 _ = happyFail

action_91 (73) = happyShift action_128
action_91 (81) = happyShift action_52
action_91 (91) = happyShift action_129
action_91 (97) = happyShift action_54
action_91 (99) = happyShift action_55
action_91 (102) = happyShift action_56
action_91 (103) = happyShift action_57
action_91 (104) = happyShift action_58
action_91 (106) = happyShift action_59
action_91 (108) = happyShift action_60
action_91 (109) = happyShift action_61
action_91 (34) = happyGoto action_127
action_91 (35) = happyGoto action_48
action_91 _ = happyFail

action_92 (90) = happyShift action_126
action_92 _ = happyFail

action_93 _ = happyReduce_97

action_94 _ = happyReduce_99

action_95 _ = happyReduce_8

action_96 (47) = happyShift action_49
action_96 (73) = happyShift action_50
action_96 (76) = happyShift action_51
action_96 (81) = happyShift action_52
action_96 (84) = happyShift action_53
action_96 (97) = happyShift action_54
action_96 (99) = happyShift action_55
action_96 (102) = happyShift action_56
action_96 (103) = happyShift action_57
action_96 (104) = happyShift action_58
action_96 (106) = happyShift action_59
action_96 (108) = happyShift action_60
action_96 (109) = happyShift action_61
action_96 (110) = happyShift action_62
action_96 (30) = happyGoto action_125
action_96 (34) = happyGoto action_47
action_96 (35) = happyGoto action_48
action_96 _ = happyFail

action_97 (73) = happyShift action_40
action_97 (81) = happyShift action_41
action_97 (86) = happyShift action_42
action_97 (102) = happyShift action_43
action_97 (105) = happyShift action_44
action_97 (39) = happyGoto action_124
action_97 _ = happyFail

action_98 (73) = happyShift action_122
action_98 (102) = happyShift action_123
action_98 _ = happyFail

action_99 (65) = happyShift action_103
action_99 (87) = happyShift action_120
action_99 (91) = happyShift action_104
action_99 (92) = happyShift action_105
action_99 (93) = happyShift action_106
action_99 (94) = happyShift action_121
action_99 _ = happyFail

action_100 _ = happyReduce_145

action_101 (88) = happyShift action_119
action_101 _ = happyFail

action_102 (73) = happyShift action_40
action_102 (81) = happyShift action_41
action_102 (86) = happyShift action_42
action_102 (102) = happyShift action_43
action_102 (105) = happyShift action_44
action_102 (39) = happyGoto action_118
action_102 _ = happyFail

action_103 (73) = happyShift action_40
action_103 (81) = happyShift action_41
action_103 (86) = happyShift action_42
action_103 (102) = happyShift action_43
action_103 (105) = happyShift action_44
action_103 (39) = happyGoto action_117
action_103 _ = happyFail

action_104 _ = happyReduce_141

action_105 _ = happyReduce_149

action_106 _ = happyReduce_150

action_107 (73) = happyShift action_40
action_107 (81) = happyShift action_41
action_107 (86) = happyShift action_42
action_107 (102) = happyShift action_43
action_107 (105) = happyShift action_44
action_107 (39) = happyGoto action_116
action_107 _ = happyFail

action_108 (55) = happyShift action_115
action_108 _ = happyFail

action_109 (55) = happyShift action_114
action_109 _ = happyFail

action_110 (90) = happyShift action_113
action_110 _ = happyFail

action_111 (48) = happyShift action_36
action_111 (50) = happyShift action_37
action_111 (106) = happyShift action_38
action_111 (15) = happyGoto action_112
action_111 _ = happyFail

action_112 _ = happyReduce_18

action_113 (45) = happyShift action_189
action_113 (51) = happyShift action_190
action_113 (59) = happyShift action_191
action_113 (61) = happyShift action_192
action_113 (63) = happyShift action_193
action_113 (64) = happyShift action_194
action_113 (70) = happyShift action_195
action_113 (73) = happyShift action_196
action_113 (76) = happyShift action_197
action_113 (84) = happyShift action_198
action_113 (102) = happyShift action_199
action_113 (16) = happyGoto action_186
action_113 (17) = happyGoto action_187
action_113 (23) = happyGoto action_188
action_113 _ = happyFail

action_114 (73) = happyShift action_40
action_114 (81) = happyShift action_41
action_114 (86) = happyShift action_42
action_114 (102) = happyShift action_43
action_114 (105) = happyShift action_44
action_114 (39) = happyGoto action_185
action_114 _ = happyFail

action_115 (73) = happyShift action_40
action_115 (81) = happyShift action_41
action_115 (86) = happyShift action_42
action_115 (102) = happyShift action_43
action_115 (105) = happyShift action_44
action_115 (39) = happyGoto action_184
action_115 _ = happyFail

action_116 (65) = happyShift action_103
action_116 (91) = happyShift action_104
action_116 (92) = happyShift action_105
action_116 (93) = happyShift action_106
action_116 _ = happyReduce_22

action_117 (91) = happyShift action_104
action_117 (92) = happyShift action_105
action_117 (93) = happyShift action_106
action_117 _ = happyReduce_142

action_118 (65) = happyShift action_103
action_118 (89) = happyShift action_183
action_118 (91) = happyShift action_104
action_118 (92) = happyShift action_105
action_118 (93) = happyShift action_106
action_118 _ = happyFail

action_119 (73) = happyShift action_40
action_119 (81) = happyShift action_41
action_119 (86) = happyShift action_42
action_119 (102) = happyShift action_43
action_119 (105) = happyShift action_44
action_119 (39) = happyGoto action_182
action_119 _ = happyFail

action_120 _ = happyReduce_143

action_121 (73) = happyShift action_40
action_121 (81) = happyShift action_41
action_121 (86) = happyShift action_42
action_121 (102) = happyShift action_43
action_121 (105) = happyShift action_44
action_121 (39) = happyGoto action_181
action_121 _ = happyFail

action_122 _ = happyReduce_139

action_123 _ = happyReduce_138

action_124 (65) = happyShift action_103
action_124 (89) = happyShift action_180
action_124 (91) = happyShift action_104
action_124 (92) = happyShift action_105
action_124 (93) = happyShift action_106
action_124 _ = happyFail

action_125 _ = happyReduce_10

action_126 _ = happyReduce_91

action_127 (97) = happyShift action_90
action_127 _ = happyReduce_106

action_128 _ = happyReduce_126

action_129 _ = happyReduce_121

action_130 (88) = happyShift action_86
action_130 (97) = happyShift action_90
action_130 (98) = happyShift action_91
action_130 _ = happyReduce_105

action_131 (89) = happyShift action_179
action_131 _ = happyFail

action_132 _ = happyReduce_95

action_133 _ = happyReduce_94

action_134 (88) = happyShift action_86
action_134 (97) = happyShift action_90
action_134 (98) = happyShift action_91
action_134 _ = happyReduce_89

action_135 (102) = happyShift action_178
action_135 _ = happyFail

action_136 (47) = happyShift action_49
action_136 (73) = happyShift action_50
action_136 (76) = happyShift action_51
action_136 (81) = happyShift action_52
action_136 (84) = happyShift action_53
action_136 (97) = happyShift action_54
action_136 (99) = happyShift action_55
action_136 (102) = happyShift action_56
action_136 (103) = happyShift action_57
action_136 (104) = happyShift action_58
action_136 (106) = happyShift action_59
action_136 (108) = happyShift action_60
action_136 (109) = happyShift action_61
action_136 (110) = happyShift action_62
action_136 (30) = happyGoto action_177
action_136 (34) = happyGoto action_47
action_136 (35) = happyGoto action_48
action_136 _ = happyFail

action_137 (97) = happyShift action_90
action_137 _ = happyReduce_125

action_138 _ = happyReduce_122

action_139 (89) = happyShift action_176
action_139 _ = happyFail

action_140 (47) = happyShift action_49
action_140 (73) = happyShift action_50
action_140 (76) = happyShift action_51
action_140 (81) = happyShift action_52
action_140 (84) = happyShift action_53
action_140 (97) = happyShift action_54
action_140 (99) = happyShift action_55
action_140 (102) = happyShift action_56
action_140 (103) = happyShift action_57
action_140 (104) = happyShift action_58
action_140 (106) = happyShift action_59
action_140 (108) = happyShift action_60
action_140 (109) = happyShift action_61
action_140 (110) = happyShift action_62
action_140 (30) = happyGoto action_175
action_140 (34) = happyGoto action_47
action_140 (35) = happyGoto action_48
action_140 _ = happyFail

action_141 (73) = happyShift action_40
action_141 (81) = happyShift action_41
action_141 (86) = happyShift action_42
action_141 (102) = happyShift action_43
action_141 (105) = happyShift action_44
action_141 (39) = happyGoto action_174
action_141 _ = happyFail

action_142 (73) = happyShift action_40
action_142 (81) = happyShift action_74
action_142 (86) = happyShift action_75
action_142 (102) = happyShift action_76
action_142 (105) = happyShift action_44
action_142 (106) = happyShift action_77
action_142 (36) = happyGoto action_172
action_142 (37) = happyGoto action_144
action_142 (38) = happyGoto action_72
action_142 (39) = happyGoto action_173
action_142 _ = happyFail

action_143 (87) = happyShift action_171
action_143 _ = happyFail

action_144 (94) = happyShift action_170
action_144 _ = happyReduce_128

action_145 (65) = happyShift action_103
action_145 (87) = happyShift action_120
action_145 (91) = happyShift action_104
action_145 (92) = happyShift action_105
action_145 (93) = happyShift action_106
action_145 (94) = happyShift action_169
action_145 _ = happyFail

action_146 (88) = happyShift action_168
action_146 _ = happyFail

action_147 (47) = happyShift action_49
action_147 (73) = happyShift action_50
action_147 (76) = happyShift action_51
action_147 (81) = happyShift action_52
action_147 (84) = happyShift action_53
action_147 (97) = happyShift action_54
action_147 (99) = happyShift action_55
action_147 (102) = happyShift action_56
action_147 (103) = happyShift action_57
action_147 (104) = happyShift action_58
action_147 (106) = happyShift action_59
action_147 (108) = happyShift action_60
action_147 (109) = happyShift action_61
action_147 (110) = happyShift action_62
action_147 (30) = happyGoto action_167
action_147 (34) = happyGoto action_47
action_147 (35) = happyGoto action_48
action_147 _ = happyFail

action_148 _ = happyReduce_84

action_149 (89) = happyShift action_166
action_149 _ = happyFail

action_150 (87) = happyShift action_165
action_150 (94) = happyShift action_96
action_150 _ = happyFail

action_151 _ = happyReduce_115

action_152 _ = happyReduce_116

action_153 (80) = happyShift action_163
action_153 (102) = happyShift action_156
action_153 (111) = happyShift action_164
action_153 (33) = happyGoto action_162
action_153 _ = happyFail

action_154 _ = happyReduce_100

action_155 _ = happyReduce_82

action_156 (90) = happyShift action_161
action_156 _ = happyFail

action_157 (47) = happyShift action_49
action_157 (73) = happyShift action_50
action_157 (76) = happyShift action_51
action_157 (79) = happyShift action_160
action_157 (81) = happyShift action_52
action_157 (84) = happyShift action_53
action_157 (97) = happyShift action_54
action_157 (99) = happyShift action_55
action_157 (102) = happyShift action_56
action_157 (103) = happyShift action_57
action_157 (104) = happyShift action_58
action_157 (106) = happyShift action_59
action_157 (108) = happyShift action_60
action_157 (109) = happyShift action_61
action_157 (110) = happyShift action_62
action_157 (29) = happyGoto action_158
action_157 (30) = happyGoto action_159
action_157 (34) = happyGoto action_47
action_157 (35) = happyGoto action_48
action_157 _ = happyFail

action_158 (47) = happyShift action_49
action_158 (73) = happyShift action_50
action_158 (76) = happyShift action_51
action_158 (79) = happyShift action_247
action_158 (81) = happyShift action_52
action_158 (84) = happyShift action_53
action_158 (97) = happyShift action_54
action_158 (99) = happyShift action_55
action_158 (102) = happyShift action_56
action_158 (103) = happyShift action_57
action_158 (104) = happyShift action_58
action_158 (106) = happyShift action_59
action_158 (108) = happyShift action_60
action_158 (109) = happyShift action_61
action_158 (110) = happyShift action_62
action_158 (30) = happyGoto action_246
action_158 (34) = happyGoto action_47
action_158 (35) = happyGoto action_48
action_158 _ = happyFail

action_159 _ = happyReduce_76

action_160 (102) = happyShift action_245
action_160 _ = happyFail

action_161 (47) = happyShift action_49
action_161 (73) = happyShift action_50
action_161 (76) = happyShift action_51
action_161 (81) = happyShift action_52
action_161 (84) = happyShift action_53
action_161 (97) = happyShift action_54
action_161 (99) = happyShift action_55
action_161 (102) = happyShift action_56
action_161 (103) = happyShift action_57
action_161 (104) = happyShift action_58
action_161 (106) = happyShift action_59
action_161 (108) = happyShift action_60
action_161 (109) = happyShift action_61
action_161 (110) = happyShift action_62
action_161 (30) = happyGoto action_244
action_161 (34) = happyGoto action_47
action_161 (35) = happyGoto action_48
action_161 _ = happyFail

action_162 _ = happyReduce_101

action_163 _ = happyReduce_83

action_164 (47) = happyShift action_49
action_164 (73) = happyShift action_50
action_164 (76) = happyShift action_51
action_164 (79) = happyShift action_243
action_164 (81) = happyShift action_52
action_164 (84) = happyShift action_53
action_164 (97) = happyShift action_54
action_164 (99) = happyShift action_55
action_164 (102) = happyShift action_56
action_164 (103) = happyShift action_57
action_164 (104) = happyShift action_58
action_164 (106) = happyShift action_59
action_164 (108) = happyShift action_60
action_164 (109) = happyShift action_61
action_164 (110) = happyShift action_62
action_164 (29) = happyGoto action_242
action_164 (30) = happyGoto action_159
action_164 (34) = happyGoto action_47
action_164 (35) = happyGoto action_48
action_164 _ = happyFail

action_165 _ = happyReduce_123

action_166 _ = happyReduce_107

action_167 (78) = happyShift action_241
action_167 _ = happyFail

action_168 (73) = happyShift action_40
action_168 (81) = happyShift action_41
action_168 (86) = happyShift action_42
action_168 (102) = happyShift action_43
action_168 (105) = happyShift action_44
action_168 (106) = happyShift action_77
action_168 (38) = happyGoto action_239
action_168 (39) = happyGoto action_240
action_168 _ = happyFail

action_169 (73) = happyShift action_40
action_169 (81) = happyShift action_74
action_169 (86) = happyShift action_75
action_169 (102) = happyShift action_76
action_169 (105) = happyShift action_44
action_169 (106) = happyShift action_77
action_169 (36) = happyGoto action_237
action_169 (37) = happyGoto action_144
action_169 (38) = happyGoto action_72
action_169 (39) = happyGoto action_238
action_169 _ = happyFail

action_170 (73) = happyShift action_40
action_170 (81) = happyShift action_74
action_170 (86) = happyShift action_75
action_170 (102) = happyShift action_76
action_170 (105) = happyShift action_44
action_170 (106) = happyShift action_77
action_170 (36) = happyGoto action_235
action_170 (37) = happyGoto action_144
action_170 (38) = happyGoto action_72
action_170 (39) = happyGoto action_236
action_170 _ = happyFail

action_171 _ = happyReduce_134

action_172 (89) = happyShift action_234
action_172 _ = happyFail

action_173 (65) = happyShift action_103
action_173 (89) = happyShift action_180
action_173 (91) = happyShift action_104
action_173 (92) = happyShift action_105
action_173 (93) = happyShift action_106
action_173 (94) = happyShift action_233
action_173 _ = happyFail

action_174 (65) = happyShift action_103
action_174 (91) = happyShift action_104
action_174 (92) = happyShift action_105
action_174 (93) = happyShift action_106
action_174 _ = happyReduce_135

action_175 (75) = happyShift action_232
action_175 _ = happyFail

action_176 _ = happyReduce_108

action_177 (107) = happyShift action_231
action_177 _ = happyFail

action_178 (86) = happyShift action_230
action_178 _ = happyReduce_119

action_179 _ = happyReduce_109

action_180 _ = happyReduce_146

action_181 (65) = happyShift action_103
action_181 (87) = happyShift action_229
action_181 (91) = happyShift action_104
action_181 (92) = happyShift action_105
action_181 (93) = happyShift action_106
action_181 _ = happyFail

action_182 (65) = happyShift action_103
action_182 (89) = happyShift action_228
action_182 (91) = happyShift action_104
action_182 (92) = happyShift action_105
action_182 (93) = happyShift action_106
action_182 _ = happyFail

action_183 _ = happyReduce_147

action_184 (65) = happyShift action_103
action_184 (91) = happyShift action_104
action_184 (92) = happyShift action_105
action_184 (93) = happyShift action_106
action_184 _ = happyReduce_20

action_185 (65) = happyShift action_103
action_185 (91) = happyShift action_104
action_185 (92) = happyShift action_105
action_185 (93) = happyShift action_106
action_185 _ = happyReduce_21

action_186 (96) = happyShift action_227
action_186 _ = happyReduce_16

action_187 _ = happyReduce_23

action_188 (72) = happyShift action_226
action_188 (20) = happyGoto action_224
action_188 (21) = happyGoto action_225
action_188 _ = happyReduce_36

action_189 (73) = happyShift action_211
action_189 (81) = happyShift action_213
action_189 (86) = happyShift action_75
action_189 (97) = happyShift action_54
action_189 (99) = happyShift action_55
action_189 (102) = happyShift action_214
action_189 (103) = happyShift action_57
action_189 (104) = happyShift action_58
action_189 (105) = happyShift action_44
action_189 (106) = happyShift action_215
action_189 (108) = happyShift action_60
action_189 (109) = happyShift action_61
action_189 (24) = happyGoto action_222
action_189 (34) = happyGoto action_223
action_189 (35) = happyGoto action_48
action_189 (37) = happyGoto action_210
action_189 (38) = happyGoto action_72
action_189 (39) = happyGoto action_73
action_189 _ = happyFail

action_190 (52) = happyShift action_219
action_190 (53) = happyShift action_220
action_190 (55) = happyShift action_221
action_190 _ = happyFail

action_191 (60) = happyShift action_218
action_191 (73) = happyShift action_211
action_191 (81) = happyShift action_213
action_191 (86) = happyShift action_75
action_191 (97) = happyShift action_54
action_191 (99) = happyShift action_55
action_191 (102) = happyShift action_214
action_191 (103) = happyShift action_57
action_191 (104) = happyShift action_58
action_191 (105) = happyShift action_44
action_191 (106) = happyShift action_215
action_191 (108) = happyShift action_60
action_191 (109) = happyShift action_61
action_191 (24) = happyGoto action_216
action_191 (34) = happyGoto action_217
action_191 (35) = happyGoto action_48
action_191 (37) = happyGoto action_210
action_191 (38) = happyGoto action_72
action_191 (39) = happyGoto action_73
action_191 _ = happyFail

action_192 (73) = happyShift action_211
action_192 (78) = happyShift action_212
action_192 (81) = happyShift action_213
action_192 (86) = happyShift action_75
action_192 (97) = happyShift action_54
action_192 (99) = happyShift action_55
action_192 (102) = happyShift action_214
action_192 (103) = happyShift action_57
action_192 (104) = happyShift action_58
action_192 (105) = happyShift action_44
action_192 (106) = happyShift action_215
action_192 (108) = happyShift action_60
action_192 (109) = happyShift action_61
action_192 (24) = happyGoto action_208
action_192 (34) = happyGoto action_209
action_192 (35) = happyGoto action_48
action_192 (37) = happyGoto action_210
action_192 (38) = happyGoto action_72
action_192 (39) = happyGoto action_73
action_192 _ = happyFail

action_193 (54) = happyShift action_207
action_193 _ = happyFail

action_194 (73) = happyShift action_68
action_194 (81) = happyShift action_52
action_194 (97) = happyShift action_54
action_194 (99) = happyShift action_55
action_194 (102) = happyShift action_56
action_194 (103) = happyShift action_57
action_194 (104) = happyShift action_58
action_194 (106) = happyShift action_59
action_194 (108) = happyShift action_60
action_194 (109) = happyShift action_61
action_194 (34) = happyGoto action_206
action_194 (35) = happyGoto action_48
action_194 _ = happyFail

action_195 (47) = happyShift action_49
action_195 (73) = happyShift action_50
action_195 (76) = happyShift action_51
action_195 (81) = happyShift action_52
action_195 (84) = happyShift action_53
action_195 (97) = happyShift action_54
action_195 (99) = happyShift action_55
action_195 (102) = happyShift action_56
action_195 (103) = happyShift action_57
action_195 (104) = happyShift action_58
action_195 (106) = happyShift action_59
action_195 (108) = happyShift action_60
action_195 (109) = happyShift action_61
action_195 (110) = happyShift action_62
action_195 (30) = happyGoto action_205
action_195 (34) = happyGoto action_47
action_195 (35) = happyGoto action_48
action_195 _ = happyFail

action_196 (47) = happyShift action_49
action_196 (73) = happyShift action_50
action_196 (76) = happyShift action_51
action_196 (81) = happyShift action_52
action_196 (84) = happyShift action_53
action_196 (97) = happyShift action_54
action_196 (99) = happyShift action_55
action_196 (102) = happyShift action_56
action_196 (103) = happyShift action_57
action_196 (104) = happyShift action_58
action_196 (106) = happyShift action_59
action_196 (108) = happyShift action_60
action_196 (109) = happyShift action_61
action_196 (110) = happyShift action_62
action_196 (22) = happyGoto action_203
action_196 (30) = happyGoto action_204
action_196 (34) = happyGoto action_47
action_196 (35) = happyGoto action_48
action_196 _ = happyFail

action_197 (73) = happyShift action_40
action_197 (81) = happyShift action_74
action_197 (86) = happyShift action_75
action_197 (102) = happyShift action_76
action_197 (105) = happyShift action_44
action_197 (106) = happyShift action_77
action_197 (37) = happyGoto action_202
action_197 (38) = happyGoto action_72
action_197 (39) = happyGoto action_73
action_197 _ = happyFail

action_198 (85) = happyShift action_201
action_198 _ = happyFail

action_199 (86) = happyShift action_200
action_199 _ = happyFail

action_200 (47) = happyShift action_49
action_200 (73) = happyShift action_50
action_200 (76) = happyShift action_51
action_200 (81) = happyShift action_52
action_200 (84) = happyShift action_53
action_200 (97) = happyShift action_54
action_200 (99) = happyShift action_55
action_200 (102) = happyShift action_56
action_200 (103) = happyShift action_57
action_200 (104) = happyShift action_58
action_200 (106) = happyShift action_59
action_200 (108) = happyShift action_60
action_200 (109) = happyShift action_61
action_200 (110) = happyShift action_62
action_200 (10) = happyGoto action_285
action_200 (30) = happyGoto action_46
action_200 (34) = happyGoto action_47
action_200 (35) = happyGoto action_48
action_200 _ = happyReduce_11

action_201 _ = happyReduce_25

action_202 (77) = happyShift action_284
action_202 _ = happyFail

action_203 (74) = happyShift action_283
action_203 _ = happyFail

action_204 _ = happyReduce_39

action_205 (71) = happyShift action_282
action_205 _ = happyFail

action_206 (88) = happyShift action_86
action_206 (97) = happyShift action_90
action_206 (98) = happyShift action_91
action_206 _ = happyReduce_62

action_207 (47) = happyShift action_49
action_207 (73) = happyShift action_50
action_207 (76) = happyShift action_51
action_207 (81) = happyShift action_52
action_207 (84) = happyShift action_53
action_207 (97) = happyShift action_54
action_207 (99) = happyShift action_55
action_207 (102) = happyShift action_56
action_207 (103) = happyShift action_57
action_207 (104) = happyShift action_58
action_207 (106) = happyShift action_59
action_207 (108) = happyShift action_60
action_207 (109) = happyShift action_61
action_207 (110) = happyShift action_62
action_207 (30) = happyGoto action_281
action_207 (34) = happyGoto action_47
action_207 (35) = happyGoto action_48
action_207 _ = happyFail

action_208 (73) = happyShift action_68
action_208 (81) = happyShift action_52
action_208 (97) = happyShift action_54
action_208 (99) = happyShift action_55
action_208 (102) = happyShift action_56
action_208 (103) = happyShift action_57
action_208 (104) = happyShift action_58
action_208 (106) = happyShift action_59
action_208 (108) = happyShift action_60
action_208 (109) = happyShift action_61
action_208 (34) = happyGoto action_280
action_208 (35) = happyGoto action_48
action_208 _ = happyFail

action_209 (62) = happyShift action_279
action_209 (88) = happyShift action_86
action_209 (97) = happyShift action_90
action_209 (98) = happyShift action_91
action_209 _ = happyFail

action_210 (78) = happyShift action_278
action_210 _ = happyFail

action_211 (88) = happyShift action_277
action_211 (98) = happyShift action_80
action_211 _ = happyFail

action_212 (73) = happyShift action_211
action_212 (81) = happyShift action_213
action_212 (86) = happyShift action_75
action_212 (97) = happyShift action_54
action_212 (99) = happyShift action_55
action_212 (102) = happyShift action_214
action_212 (103) = happyShift action_57
action_212 (104) = happyShift action_58
action_212 (105) = happyShift action_44
action_212 (106) = happyShift action_215
action_212 (108) = happyShift action_60
action_212 (109) = happyShift action_61
action_212 (24) = happyGoto action_275
action_212 (34) = happyGoto action_276
action_212 (35) = happyGoto action_48
action_212 (37) = happyGoto action_210
action_212 (38) = happyGoto action_72
action_212 (39) = happyGoto action_73
action_212 _ = happyFail

action_213 (102) = happyShift action_274
action_213 _ = happyFail

action_214 (86) = happyShift action_65
action_214 (88) = happyShift action_273
action_214 (95) = happyShift action_98
action_214 _ = happyReduce_124

action_215 (55) = happyShift action_141
action_215 (78) = happyReduce_136
action_215 (89) = happyReduce_136
action_215 (94) = happyReduce_136
action_215 _ = happyReduce_110

action_216 (73) = happyShift action_68
action_216 (81) = happyShift action_52
action_216 (97) = happyShift action_54
action_216 (99) = happyShift action_55
action_216 (102) = happyShift action_56
action_216 (103) = happyShift action_57
action_216 (104) = happyShift action_58
action_216 (106) = happyShift action_59
action_216 (108) = happyShift action_60
action_216 (109) = happyShift action_61
action_216 (34) = happyGoto action_272
action_216 (35) = happyGoto action_48
action_216 _ = happyFail

action_217 (88) = happyShift action_86
action_217 (97) = happyShift action_90
action_217 (98) = happyShift action_91
action_217 _ = happyReduce_49

action_218 (73) = happyShift action_211
action_218 (81) = happyShift action_213
action_218 (86) = happyShift action_75
action_218 (97) = happyShift action_54
action_218 (99) = happyShift action_55
action_218 (102) = happyShift action_214
action_218 (103) = happyShift action_57
action_218 (104) = happyShift action_58
action_218 (105) = happyShift action_44
action_218 (106) = happyShift action_215
action_218 (108) = happyShift action_60
action_218 (109) = happyShift action_61
action_218 (24) = happyGoto action_270
action_218 (34) = happyGoto action_271
action_218 (35) = happyGoto action_48
action_218 (37) = happyGoto action_210
action_218 (38) = happyGoto action_72
action_218 (39) = happyGoto action_73
action_218 _ = happyFail

action_219 (73) = happyShift action_211
action_219 (81) = happyShift action_213
action_219 (86) = happyShift action_75
action_219 (97) = happyShift action_54
action_219 (99) = happyShift action_55
action_219 (102) = happyShift action_214
action_219 (103) = happyShift action_57
action_219 (104) = happyShift action_58
action_219 (105) = happyShift action_44
action_219 (106) = happyShift action_215
action_219 (108) = happyShift action_60
action_219 (109) = happyShift action_61
action_219 (24) = happyGoto action_268
action_219 (34) = happyGoto action_269
action_219 (35) = happyGoto action_48
action_219 (37) = happyGoto action_210
action_219 (38) = happyGoto action_72
action_219 (39) = happyGoto action_73
action_219 _ = happyFail

action_220 (73) = happyShift action_211
action_220 (81) = happyShift action_213
action_220 (86) = happyShift action_75
action_220 (97) = happyShift action_54
action_220 (99) = happyShift action_55
action_220 (102) = happyShift action_214
action_220 (103) = happyShift action_57
action_220 (104) = happyShift action_58
action_220 (105) = happyShift action_44
action_220 (106) = happyShift action_215
action_220 (108) = happyShift action_60
action_220 (109) = happyShift action_61
action_220 (24) = happyGoto action_266
action_220 (34) = happyGoto action_267
action_220 (35) = happyGoto action_48
action_220 (37) = happyGoto action_210
action_220 (38) = happyGoto action_72
action_220 (39) = happyGoto action_73
action_220 _ = happyFail

action_221 (56) = happyShift action_264
action_221 (57) = happyShift action_265
action_221 _ = happyFail

action_222 (73) = happyShift action_68
action_222 (81) = happyShift action_52
action_222 (97) = happyShift action_54
action_222 (99) = happyShift action_55
action_222 (102) = happyShift action_56
action_222 (103) = happyShift action_57
action_222 (104) = happyShift action_58
action_222 (106) = happyShift action_59
action_222 (108) = happyShift action_60
action_222 (109) = happyShift action_61
action_222 (34) = happyGoto action_263
action_222 (35) = happyGoto action_48
action_222 _ = happyFail

action_223 (46) = happyShift action_262
action_223 (88) = happyShift action_86
action_223 (97) = happyShift action_90
action_223 (98) = happyShift action_91
action_223 _ = happyFail

action_224 (72) = happyShift action_226
action_224 (21) = happyGoto action_261
action_224 _ = happyReduce_26

action_225 _ = happyReduce_34

action_226 (47) = happyShift action_49
action_226 (73) = happyShift action_50
action_226 (76) = happyShift action_51
action_226 (81) = happyShift action_52
action_226 (84) = happyShift action_53
action_226 (97) = happyShift action_54
action_226 (99) = happyShift action_55
action_226 (102) = happyShift action_56
action_226 (103) = happyShift action_57
action_226 (104) = happyShift action_58
action_226 (106) = happyShift action_260
action_226 (108) = happyShift action_60
action_226 (109) = happyShift action_61
action_226 (110) = happyShift action_62
action_226 (22) = happyGoto action_259
action_226 (30) = happyGoto action_204
action_226 (34) = happyGoto action_47
action_226 (35) = happyGoto action_48
action_226 _ = happyFail

action_227 (45) = happyShift action_189
action_227 (51) = happyShift action_190
action_227 (59) = happyShift action_191
action_227 (61) = happyShift action_192
action_227 (63) = happyShift action_193
action_227 (64) = happyShift action_194
action_227 (70) = happyShift action_195
action_227 (73) = happyShift action_196
action_227 (76) = happyShift action_197
action_227 (102) = happyShift action_199
action_227 (17) = happyGoto action_258
action_227 (23) = happyGoto action_188
action_227 _ = happyFail

action_228 _ = happyReduce_148

action_229 _ = happyReduce_144

action_230 (87) = happyShift action_256
action_230 (103) = happyShift action_257
action_230 _ = happyFail

action_231 (47) = happyShift action_49
action_231 (73) = happyShift action_50
action_231 (76) = happyShift action_51
action_231 (81) = happyShift action_52
action_231 (84) = happyShift action_53
action_231 (97) = happyShift action_54
action_231 (99) = happyShift action_55
action_231 (102) = happyShift action_56
action_231 (103) = happyShift action_57
action_231 (104) = happyShift action_58
action_231 (106) = happyShift action_59
action_231 (108) = happyShift action_60
action_231 (109) = happyShift action_61
action_231 (110) = happyShift action_62
action_231 (30) = happyGoto action_255
action_231 (34) = happyGoto action_47
action_231 (35) = happyGoto action_48
action_231 _ = happyFail

action_232 (47) = happyShift action_49
action_232 (73) = happyShift action_50
action_232 (76) = happyShift action_51
action_232 (81) = happyShift action_52
action_232 (84) = happyShift action_53
action_232 (97) = happyShift action_54
action_232 (99) = happyShift action_55
action_232 (102) = happyShift action_56
action_232 (103) = happyShift action_57
action_232 (104) = happyShift action_58
action_232 (106) = happyShift action_59
action_232 (108) = happyShift action_60
action_232 (109) = happyShift action_61
action_232 (110) = happyShift action_62
action_232 (30) = happyGoto action_254
action_232 (34) = happyGoto action_47
action_232 (35) = happyGoto action_48
action_232 _ = happyFail

action_233 (73) = happyShift action_40
action_233 (81) = happyShift action_74
action_233 (86) = happyShift action_75
action_233 (102) = happyShift action_76
action_233 (105) = happyShift action_44
action_233 (106) = happyShift action_77
action_233 (36) = happyGoto action_237
action_233 (37) = happyGoto action_144
action_233 (38) = happyGoto action_72
action_233 (39) = happyGoto action_236
action_233 _ = happyFail

action_234 _ = happyReduce_131

action_235 _ = happyReduce_129

action_236 (65) = happyShift action_103
action_236 (91) = happyShift action_104
action_236 (92) = happyShift action_105
action_236 (93) = happyShift action_106
action_236 (94) = happyShift action_233
action_236 _ = happyReduce_137

action_237 _ = happyReduce_130

action_238 (65) = happyShift action_103
action_238 (87) = happyShift action_229
action_238 (91) = happyShift action_104
action_238 (92) = happyShift action_105
action_238 (93) = happyShift action_106
action_238 (94) = happyShift action_233
action_238 _ = happyFail

action_239 (89) = happyShift action_253
action_239 _ = happyFail

action_240 (65) = happyShift action_103
action_240 (89) = happyShift action_228
action_240 (91) = happyShift action_104
action_240 (92) = happyShift action_105
action_240 (93) = happyShift action_106
action_240 _ = happyFail

action_241 (47) = happyShift action_49
action_241 (73) = happyShift action_50
action_241 (76) = happyShift action_51
action_241 (81) = happyShift action_52
action_241 (84) = happyShift action_53
action_241 (97) = happyShift action_54
action_241 (99) = happyShift action_55
action_241 (102) = happyShift action_56
action_241 (103) = happyShift action_57
action_241 (104) = happyShift action_58
action_241 (106) = happyShift action_59
action_241 (108) = happyShift action_60
action_241 (109) = happyShift action_61
action_241 (110) = happyShift action_62
action_241 (30) = happyGoto action_252
action_241 (34) = happyGoto action_47
action_241 (35) = happyGoto action_48
action_241 _ = happyFail

action_242 (47) = happyShift action_49
action_242 (73) = happyShift action_50
action_242 (76) = happyShift action_51
action_242 (79) = happyShift action_251
action_242 (81) = happyShift action_52
action_242 (84) = happyShift action_53
action_242 (97) = happyShift action_54
action_242 (99) = happyShift action_55
action_242 (102) = happyShift action_56
action_242 (103) = happyShift action_57
action_242 (104) = happyShift action_58
action_242 (106) = happyShift action_59
action_242 (108) = happyShift action_60
action_242 (109) = happyShift action_61
action_242 (110) = happyShift action_62
action_242 (30) = happyGoto action_246
action_242 (34) = happyGoto action_47
action_242 (35) = happyGoto action_48
action_242 _ = happyFail

action_243 (102) = happyShift action_250
action_243 _ = happyFail

action_244 _ = happyReduce_102

action_245 (111) = happyShift action_249
action_245 _ = happyFail

action_246 _ = happyReduce_77

action_247 (102) = happyShift action_248
action_247 _ = happyFail

action_248 (111) = happyShift action_316
action_248 _ = happyFail

action_249 _ = happyReduce_81

action_250 (111) = happyShift action_315
action_250 _ = happyFail

action_251 (102) = happyShift action_314
action_251 _ = happyFail

action_252 _ = happyReduce_86

action_253 _ = happyReduce_132

action_254 _ = happyReduce_87

action_255 _ = happyReduce_88

action_256 _ = happyReduce_117

action_257 (87) = happyShift action_313
action_257 _ = happyFail

action_258 _ = happyReduce_24

action_259 _ = happyReduce_37

action_260 (77) = happyShift action_312
action_260 _ = happyReduce_110

action_261 _ = happyReduce_35

action_262 (45) = happyShift action_189
action_262 (51) = happyShift action_190
action_262 (59) = happyShift action_191
action_262 (61) = happyShift action_192
action_262 (63) = happyShift action_193
action_262 (64) = happyShift action_194
action_262 (66) = happyShift action_308
action_262 (67) = happyShift action_309
action_262 (68) = happyShift action_310
action_262 (70) = happyShift action_195
action_262 (73) = happyShift action_196
action_262 (76) = happyShift action_197
action_262 (84) = happyShift action_311
action_262 (102) = happyShift action_199
action_262 (16) = happyGoto action_305
action_262 (17) = happyGoto action_187
action_262 (23) = happyGoto action_188
action_262 (26) = happyGoto action_306
action_262 (27) = happyGoto action_307
action_262 _ = happyFail

action_263 (46) = happyShift action_304
action_263 (88) = happyShift action_86
action_263 (97) = happyShift action_90
action_263 (98) = happyShift action_91
action_263 _ = happyFail

action_264 (58) = happyShift action_303
action_264 _ = happyFail

action_265 (58) = happyShift action_302
action_265 _ = happyFail

action_266 (73) = happyShift action_68
action_266 (81) = happyShift action_52
action_266 (97) = happyShift action_54
action_266 (99) = happyShift action_55
action_266 (102) = happyShift action_56
action_266 (103) = happyShift action_57
action_266 (104) = happyShift action_58
action_266 (106) = happyShift action_59
action_266 (108) = happyShift action_60
action_266 (109) = happyShift action_61
action_266 (34) = happyGoto action_301
action_266 (35) = happyGoto action_48
action_266 _ = happyFail

action_267 (54) = happyShift action_300
action_267 (88) = happyShift action_86
action_267 (97) = happyShift action_90
action_267 (98) = happyShift action_91
action_267 _ = happyFail

action_268 (73) = happyShift action_68
action_268 (81) = happyShift action_52
action_268 (97) = happyShift action_54
action_268 (99) = happyShift action_55
action_268 (102) = happyShift action_56
action_268 (103) = happyShift action_57
action_268 (104) = happyShift action_58
action_268 (106) = happyShift action_59
action_268 (108) = happyShift action_60
action_268 (109) = happyShift action_61
action_268 (34) = happyGoto action_299
action_268 (35) = happyGoto action_48
action_268 _ = happyFail

action_269 (54) = happyShift action_298
action_269 (88) = happyShift action_86
action_269 (97) = happyShift action_90
action_269 (98) = happyShift action_91
action_269 _ = happyFail

action_270 (73) = happyShift action_68
action_270 (81) = happyShift action_52
action_270 (97) = happyShift action_54
action_270 (99) = happyShift action_55
action_270 (102) = happyShift action_56
action_270 (103) = happyShift action_57
action_270 (104) = happyShift action_58
action_270 (106) = happyShift action_59
action_270 (108) = happyShift action_60
action_270 (109) = happyShift action_61
action_270 (34) = happyGoto action_297
action_270 (35) = happyGoto action_48
action_270 _ = happyFail

action_271 (88) = happyShift action_86
action_271 (97) = happyShift action_90
action_271 (98) = happyShift action_91
action_271 _ = happyReduce_51

action_272 (88) = happyShift action_86
action_272 (97) = happyShift action_90
action_272 (98) = happyShift action_91
action_272 _ = happyReduce_48

action_273 (47) = happyShift action_49
action_273 (73) = happyShift action_292
action_273 (76) = happyShift action_51
action_273 (81) = happyShift action_213
action_273 (84) = happyShift action_53
action_273 (86) = happyShift action_75
action_273 (97) = happyShift action_54
action_273 (99) = happyShift action_55
action_273 (102) = happyShift action_214
action_273 (103) = happyShift action_57
action_273 (104) = happyShift action_58
action_273 (105) = happyShift action_44
action_273 (106) = happyShift action_215
action_273 (108) = happyShift action_60
action_273 (109) = happyShift action_61
action_273 (110) = happyShift action_62
action_273 (30) = happyGoto action_149
action_273 (34) = happyGoto action_47
action_273 (35) = happyGoto action_48
action_273 (36) = happyGoto action_172
action_273 (37) = happyGoto action_144
action_273 (38) = happyGoto action_72
action_273 (39) = happyGoto action_173
action_273 _ = happyFail

action_274 (88) = happyShift action_168
action_274 _ = happyReduce_120

action_275 (73) = happyShift action_68
action_275 (81) = happyShift action_52
action_275 (97) = happyShift action_54
action_275 (99) = happyShift action_55
action_275 (102) = happyShift action_56
action_275 (103) = happyShift action_57
action_275 (104) = happyShift action_58
action_275 (106) = happyShift action_59
action_275 (108) = happyShift action_60
action_275 (109) = happyShift action_61
action_275 (34) = happyGoto action_296
action_275 (35) = happyGoto action_48
action_275 _ = happyFail

action_276 (62) = happyShift action_295
action_276 (88) = happyShift action_86
action_276 (97) = happyShift action_90
action_276 (98) = happyShift action_91
action_276 _ = happyFail

action_277 (47) = happyShift action_49
action_277 (73) = happyShift action_292
action_277 (76) = happyShift action_51
action_277 (81) = happyShift action_293
action_277 (84) = happyShift action_53
action_277 (86) = happyShift action_42
action_277 (97) = happyShift action_54
action_277 (99) = happyShift action_55
action_277 (102) = happyShift action_294
action_277 (103) = happyShift action_57
action_277 (104) = happyShift action_58
action_277 (105) = happyShift action_44
action_277 (106) = happyShift action_59
action_277 (108) = happyShift action_60
action_277 (109) = happyShift action_61
action_277 (110) = happyShift action_62
action_277 (30) = happyGoto action_139
action_277 (34) = happyGoto action_47
action_277 (35) = happyGoto action_48
action_277 (39) = happyGoto action_118
action_277 _ = happyFail

action_278 _ = happyReduce_64

action_279 (47) = happyShift action_49
action_279 (73) = happyShift action_50
action_279 (76) = happyShift action_51
action_279 (81) = happyShift action_52
action_279 (84) = happyShift action_53
action_279 (97) = happyShift action_54
action_279 (99) = happyShift action_55
action_279 (102) = happyShift action_56
action_279 (103) = happyShift action_57
action_279 (104) = happyShift action_58
action_279 (106) = happyShift action_59
action_279 (108) = happyShift action_60
action_279 (109) = happyShift action_61
action_279 (110) = happyShift action_62
action_279 (30) = happyGoto action_291
action_279 (34) = happyGoto action_47
action_279 (35) = happyGoto action_48
action_279 _ = happyFail

action_280 (62) = happyShift action_290
action_280 (88) = happyShift action_86
action_280 (97) = happyShift action_90
action_280 (98) = happyShift action_91
action_280 _ = happyFail

action_281 _ = happyReduce_63

action_282 (84) = happyShift action_289
action_282 _ = happyFail

action_283 (45) = happyShift action_189
action_283 (51) = happyShift action_190
action_283 (59) = happyShift action_191
action_283 (61) = happyShift action_192
action_283 (63) = happyShift action_193
action_283 (64) = happyShift action_194
action_283 (70) = happyShift action_195
action_283 (73) = happyShift action_196
action_283 (76) = happyShift action_197
action_283 (84) = happyShift action_198
action_283 (102) = happyShift action_199
action_283 (16) = happyGoto action_288
action_283 (17) = happyGoto action_187
action_283 (23) = happyGoto action_188
action_283 _ = happyFail

action_284 (47) = happyShift action_49
action_284 (73) = happyShift action_50
action_284 (76) = happyShift action_51
action_284 (81) = happyShift action_52
action_284 (84) = happyShift action_53
action_284 (97) = happyShift action_54
action_284 (99) = happyShift action_55
action_284 (102) = happyShift action_56
action_284 (103) = happyShift action_57
action_284 (104) = happyShift action_58
action_284 (106) = happyShift action_59
action_284 (108) = happyShift action_60
action_284 (109) = happyShift action_61
action_284 (110) = happyShift action_62
action_284 (30) = happyGoto action_287
action_284 (34) = happyGoto action_47
action_284 (35) = happyGoto action_48
action_284 _ = happyFail

action_285 (87) = happyShift action_286
action_285 (94) = happyShift action_96
action_285 _ = happyFail

action_286 _ = happyReduce_29

action_287 (78) = happyShift action_345
action_287 _ = happyFail

action_288 (75) = happyShift action_344
action_288 (96) = happyShift action_227
action_288 _ = happyFail

action_289 (73) = happyShift action_40
action_289 (81) = happyShift action_74
action_289 (86) = happyShift action_75
action_289 (102) = happyShift action_76
action_289 (105) = happyShift action_44
action_289 (106) = happyShift action_77
action_289 (18) = happyGoto action_341
action_289 (19) = happyGoto action_342
action_289 (37) = happyGoto action_343
action_289 (38) = happyGoto action_72
action_289 (39) = happyGoto action_73
action_289 _ = happyFail

action_290 (47) = happyShift action_49
action_290 (73) = happyShift action_50
action_290 (76) = happyShift action_51
action_290 (81) = happyShift action_52
action_290 (84) = happyShift action_53
action_290 (97) = happyShift action_54
action_290 (99) = happyShift action_55
action_290 (102) = happyShift action_56
action_290 (103) = happyShift action_57
action_290 (104) = happyShift action_58
action_290 (106) = happyShift action_59
action_290 (108) = happyShift action_60
action_290 (109) = happyShift action_61
action_290 (110) = happyShift action_62
action_290 (30) = happyGoto action_340
action_290 (34) = happyGoto action_47
action_290 (35) = happyGoto action_48
action_290 _ = happyFail

action_291 _ = happyReduce_53

action_292 (47) = happyShift action_49
action_292 (73) = happyShift action_50
action_292 (76) = happyShift action_51
action_292 (81) = happyShift action_52
action_292 (84) = happyShift action_53
action_292 (88) = happyShift action_277
action_292 (97) = happyShift action_54
action_292 (98) = happyShift action_80
action_292 (99) = happyShift action_55
action_292 (102) = happyShift action_56
action_292 (103) = happyShift action_57
action_292 (104) = happyShift action_58
action_292 (106) = happyShift action_59
action_292 (108) = happyShift action_60
action_292 (109) = happyShift action_61
action_292 (110) = happyShift action_62
action_292 (30) = happyGoto action_78
action_292 (34) = happyGoto action_47
action_292 (35) = happyGoto action_48
action_292 _ = happyFail

action_293 (102) = happyShift action_339
action_293 _ = happyFail

action_294 (86) = happyShift action_65
action_294 (88) = happyShift action_338
action_294 (95) = happyShift action_98
action_294 _ = happyReduce_124

action_295 (47) = happyShift action_49
action_295 (73) = happyShift action_50
action_295 (76) = happyShift action_51
action_295 (81) = happyShift action_52
action_295 (84) = happyShift action_53
action_295 (97) = happyShift action_54
action_295 (99) = happyShift action_55
action_295 (102) = happyShift action_56
action_295 (103) = happyShift action_57
action_295 (104) = happyShift action_58
action_295 (106) = happyShift action_59
action_295 (108) = happyShift action_60
action_295 (109) = happyShift action_61
action_295 (110) = happyShift action_62
action_295 (30) = happyGoto action_337
action_295 (34) = happyGoto action_47
action_295 (35) = happyGoto action_48
action_295 _ = happyFail

action_296 (62) = happyShift action_336
action_296 (88) = happyShift action_86
action_296 (97) = happyShift action_90
action_296 (98) = happyShift action_91
action_296 _ = happyFail

action_297 (88) = happyShift action_86
action_297 (97) = happyShift action_90
action_297 (98) = happyShift action_91
action_297 _ = happyReduce_50

action_298 (47) = happyShift action_49
action_298 (73) = happyShift action_50
action_298 (76) = happyShift action_51
action_298 (81) = happyShift action_52
action_298 (84) = happyShift action_53
action_298 (97) = happyShift action_54
action_298 (99) = happyShift action_55
action_298 (102) = happyShift action_56
action_298 (103) = happyShift action_57
action_298 (104) = happyShift action_58
action_298 (106) = happyShift action_59
action_298 (108) = happyShift action_60
action_298 (109) = happyShift action_61
action_298 (110) = happyShift action_62
action_298 (30) = happyGoto action_335
action_298 (34) = happyGoto action_47
action_298 (35) = happyGoto action_48
action_298 _ = happyFail

action_299 (54) = happyShift action_334
action_299 (88) = happyShift action_86
action_299 (97) = happyShift action_90
action_299 (98) = happyShift action_91
action_299 _ = happyFail

action_300 (47) = happyShift action_49
action_300 (73) = happyShift action_50
action_300 (76) = happyShift action_51
action_300 (81) = happyShift action_52
action_300 (84) = happyShift action_53
action_300 (97) = happyShift action_54
action_300 (99) = happyShift action_55
action_300 (102) = happyShift action_56
action_300 (103) = happyShift action_57
action_300 (104) = happyShift action_58
action_300 (106) = happyShift action_59
action_300 (108) = happyShift action_60
action_300 (109) = happyShift action_61
action_300 (110) = happyShift action_62
action_300 (30) = happyGoto action_333
action_300 (34) = happyGoto action_47
action_300 (35) = happyGoto action_48
action_300 _ = happyFail

action_301 (54) = happyShift action_332
action_301 (88) = happyShift action_86
action_301 (97) = happyShift action_90
action_301 (98) = happyShift action_91
action_301 _ = happyFail

action_302 (73) = happyShift action_211
action_302 (81) = happyShift action_213
action_302 (86) = happyShift action_75
action_302 (97) = happyShift action_54
action_302 (99) = happyShift action_55
action_302 (102) = happyShift action_214
action_302 (103) = happyShift action_57
action_302 (104) = happyShift action_58
action_302 (105) = happyShift action_44
action_302 (106) = happyShift action_215
action_302 (108) = happyShift action_60
action_302 (109) = happyShift action_61
action_302 (24) = happyGoto action_330
action_302 (34) = happyGoto action_331
action_302 (35) = happyGoto action_48
action_302 (37) = happyGoto action_210
action_302 (38) = happyGoto action_72
action_302 (39) = happyGoto action_73
action_302 _ = happyFail

action_303 (73) = happyShift action_211
action_303 (81) = happyShift action_213
action_303 (86) = happyShift action_75
action_303 (97) = happyShift action_54
action_303 (99) = happyShift action_55
action_303 (102) = happyShift action_214
action_303 (103) = happyShift action_57
action_303 (104) = happyShift action_58
action_303 (105) = happyShift action_44
action_303 (106) = happyShift action_215
action_303 (108) = happyShift action_60
action_303 (109) = happyShift action_61
action_303 (24) = happyGoto action_328
action_303 (34) = happyGoto action_329
action_303 (35) = happyGoto action_48
action_303 (37) = happyGoto action_210
action_303 (38) = happyGoto action_72
action_303 (39) = happyGoto action_73
action_303 _ = happyFail

action_304 (45) = happyShift action_189
action_304 (51) = happyShift action_190
action_304 (59) = happyShift action_191
action_304 (61) = happyShift action_192
action_304 (63) = happyShift action_193
action_304 (64) = happyShift action_194
action_304 (66) = happyShift action_308
action_304 (67) = happyShift action_309
action_304 (68) = happyShift action_310
action_304 (70) = happyShift action_195
action_304 (73) = happyShift action_196
action_304 (76) = happyShift action_197
action_304 (84) = happyShift action_311
action_304 (102) = happyShift action_199
action_304 (16) = happyGoto action_326
action_304 (17) = happyGoto action_187
action_304 (23) = happyGoto action_188
action_304 (26) = happyGoto action_327
action_304 (27) = happyGoto action_307
action_304 _ = happyFail

action_305 (96) = happyShift action_227
action_305 _ = happyReduce_57

action_306 (47) = happyShift action_324
action_306 (65) = happyShift action_325
action_306 _ = happyFail

action_307 _ = happyReduce_67

action_308 (69) = happyShift action_323
action_308 _ = happyFail

action_309 (69) = happyShift action_322
action_309 _ = happyFail

action_310 (69) = happyShift action_321
action_310 _ = happyFail

action_311 (45) = happyShift action_189
action_311 (51) = happyShift action_190
action_311 (59) = happyShift action_191
action_311 (61) = happyShift action_192
action_311 (63) = happyShift action_193
action_311 (64) = happyShift action_194
action_311 (66) = happyShift action_308
action_311 (67) = happyShift action_309
action_311 (68) = happyShift action_310
action_311 (70) = happyShift action_195
action_311 (73) = happyShift action_196
action_311 (76) = happyShift action_197
action_311 (84) = happyShift action_311
action_311 (85) = happyShift action_201
action_311 (102) = happyShift action_199
action_311 (16) = happyGoto action_319
action_311 (17) = happyGoto action_187
action_311 (23) = happyGoto action_188
action_311 (26) = happyGoto action_320
action_311 (27) = happyGoto action_307
action_311 _ = happyFail

action_312 (47) = happyShift action_49
action_312 (73) = happyShift action_50
action_312 (76) = happyShift action_51
action_312 (81) = happyShift action_52
action_312 (84) = happyShift action_53
action_312 (97) = happyShift action_54
action_312 (99) = happyShift action_55
action_312 (102) = happyShift action_56
action_312 (103) = happyShift action_57
action_312 (104) = happyShift action_58
action_312 (106) = happyShift action_59
action_312 (108) = happyShift action_60
action_312 (109) = happyShift action_61
action_312 (110) = happyShift action_62
action_312 (30) = happyGoto action_318
action_312 (34) = happyGoto action_47
action_312 (35) = happyGoto action_48
action_312 _ = happyFail

action_313 _ = happyReduce_118

action_314 (111) = happyShift action_317
action_314 _ = happyFail

action_315 _ = happyReduce_80

action_316 _ = happyReduce_79

action_317 _ = happyReduce_78

action_318 _ = happyReduce_38

action_319 (85) = happyShift action_366
action_319 (96) = happyShift action_227
action_319 _ = happyFail

action_320 (65) = happyShift action_325
action_320 (85) = happyShift action_365
action_320 _ = happyFail

action_321 (45) = happyShift action_189
action_321 (51) = happyShift action_190
action_321 (59) = happyShift action_191
action_321 (61) = happyShift action_192
action_321 (63) = happyShift action_193
action_321 (64) = happyShift action_194
action_321 (70) = happyShift action_195
action_321 (73) = happyShift action_196
action_321 (76) = happyShift action_197
action_321 (84) = happyShift action_198
action_321 (102) = happyShift action_199
action_321 (16) = happyGoto action_364
action_321 (17) = happyGoto action_187
action_321 (23) = happyGoto action_188
action_321 _ = happyFail

action_322 (45) = happyShift action_189
action_322 (51) = happyShift action_190
action_322 (59) = happyShift action_191
action_322 (61) = happyShift action_192
action_322 (63) = happyShift action_193
action_322 (64) = happyShift action_194
action_322 (70) = happyShift action_195
action_322 (73) = happyShift action_196
action_322 (76) = happyShift action_197
action_322 (84) = happyShift action_198
action_322 (102) = happyShift action_199
action_322 (16) = happyGoto action_363
action_322 (17) = happyGoto action_187
action_322 (23) = happyGoto action_188
action_322 _ = happyFail

action_323 (45) = happyShift action_189
action_323 (51) = happyShift action_190
action_323 (59) = happyShift action_191
action_323 (61) = happyShift action_192
action_323 (63) = happyShift action_193
action_323 (64) = happyShift action_194
action_323 (70) = happyShift action_195
action_323 (73) = happyShift action_196
action_323 (76) = happyShift action_197
action_323 (84) = happyShift action_198
action_323 (102) = happyShift action_199
action_323 (16) = happyGoto action_362
action_323 (17) = happyGoto action_187
action_323 (23) = happyGoto action_188
action_323 _ = happyFail

action_324 (48) = happyShift action_361
action_324 _ = happyFail

action_325 (66) = happyShift action_308
action_325 (67) = happyShift action_309
action_325 (68) = happyShift action_310
action_325 (84) = happyShift action_360
action_325 (26) = happyGoto action_359
action_325 (27) = happyGoto action_307
action_325 _ = happyFail

action_326 (96) = happyShift action_227
action_326 _ = happyReduce_56

action_327 (47) = happyShift action_358
action_327 (65) = happyShift action_325
action_327 _ = happyFail

action_328 (73) = happyShift action_68
action_328 (81) = happyShift action_52
action_328 (97) = happyShift action_54
action_328 (99) = happyShift action_55
action_328 (102) = happyShift action_56
action_328 (103) = happyShift action_57
action_328 (104) = happyShift action_58
action_328 (106) = happyShift action_59
action_328 (108) = happyShift action_60
action_328 (109) = happyShift action_61
action_328 (34) = happyGoto action_357
action_328 (35) = happyGoto action_48
action_328 _ = happyFail

action_329 (54) = happyShift action_356
action_329 (88) = happyShift action_86
action_329 (97) = happyShift action_90
action_329 (98) = happyShift action_91
action_329 _ = happyFail

action_330 (73) = happyShift action_68
action_330 (81) = happyShift action_52
action_330 (97) = happyShift action_54
action_330 (99) = happyShift action_55
action_330 (102) = happyShift action_56
action_330 (103) = happyShift action_57
action_330 (104) = happyShift action_58
action_330 (106) = happyShift action_59
action_330 (108) = happyShift action_60
action_330 (109) = happyShift action_61
action_330 (34) = happyGoto action_355
action_330 (35) = happyGoto action_48
action_330 _ = happyFail

action_331 (54) = happyShift action_354
action_331 (88) = happyShift action_86
action_331 (97) = happyShift action_90
action_331 (98) = happyShift action_91
action_331 _ = happyFail

action_332 (47) = happyShift action_49
action_332 (73) = happyShift action_50
action_332 (76) = happyShift action_51
action_332 (81) = happyShift action_52
action_332 (84) = happyShift action_53
action_332 (97) = happyShift action_54
action_332 (99) = happyShift action_55
action_332 (102) = happyShift action_56
action_332 (103) = happyShift action_57
action_332 (104) = happyShift action_58
action_332 (106) = happyShift action_59
action_332 (108) = happyShift action_60
action_332 (109) = happyShift action_61
action_332 (110) = happyShift action_62
action_332 (30) = happyGoto action_353
action_332 (34) = happyGoto action_47
action_332 (35) = happyGoto action_48
action_332 _ = happyFail

action_333 _ = happyReduce_43

action_334 (47) = happyShift action_49
action_334 (73) = happyShift action_50
action_334 (76) = happyShift action_51
action_334 (81) = happyShift action_52
action_334 (84) = happyShift action_53
action_334 (97) = happyShift action_54
action_334 (99) = happyShift action_55
action_334 (102) = happyShift action_56
action_334 (103) = happyShift action_57
action_334 (104) = happyShift action_58
action_334 (106) = happyShift action_59
action_334 (108) = happyShift action_60
action_334 (109) = happyShift action_61
action_334 (110) = happyShift action_62
action_334 (30) = happyGoto action_352
action_334 (34) = happyGoto action_47
action_334 (35) = happyGoto action_48
action_334 _ = happyFail

action_335 _ = happyReduce_41

action_336 (47) = happyShift action_49
action_336 (73) = happyShift action_50
action_336 (76) = happyShift action_51
action_336 (81) = happyShift action_52
action_336 (84) = happyShift action_53
action_336 (97) = happyShift action_54
action_336 (99) = happyShift action_55
action_336 (102) = happyShift action_56
action_336 (103) = happyShift action_57
action_336 (104) = happyShift action_58
action_336 (106) = happyShift action_59
action_336 (108) = happyShift action_60
action_336 (109) = happyShift action_61
action_336 (110) = happyShift action_62
action_336 (30) = happyGoto action_351
action_336 (34) = happyGoto action_47
action_336 (35) = happyGoto action_48
action_336 _ = happyFail

action_337 _ = happyReduce_55

action_338 (47) = happyShift action_49
action_338 (73) = happyShift action_292
action_338 (76) = happyShift action_51
action_338 (81) = happyShift action_293
action_338 (84) = happyShift action_53
action_338 (86) = happyShift action_42
action_338 (97) = happyShift action_54
action_338 (99) = happyShift action_55
action_338 (102) = happyShift action_294
action_338 (103) = happyShift action_57
action_338 (104) = happyShift action_58
action_338 (105) = happyShift action_44
action_338 (106) = happyShift action_59
action_338 (108) = happyShift action_60
action_338 (109) = happyShift action_61
action_338 (110) = happyShift action_62
action_338 (30) = happyGoto action_149
action_338 (34) = happyGoto action_47
action_338 (35) = happyGoto action_48
action_338 (39) = happyGoto action_124
action_338 _ = happyFail

action_339 (88) = happyShift action_119
action_339 _ = happyReduce_120

action_340 _ = happyReduce_52

action_341 (65) = happyShift action_349
action_341 (85) = happyShift action_350
action_341 _ = happyFail

action_342 _ = happyReduce_31

action_343 (69) = happyShift action_348
action_343 _ = happyFail

action_344 (45) = happyShift action_189
action_344 (51) = happyShift action_190
action_344 (59) = happyShift action_191
action_344 (61) = happyShift action_192
action_344 (63) = happyShift action_193
action_344 (64) = happyShift action_194
action_344 (70) = happyShift action_195
action_344 (73) = happyShift action_196
action_344 (76) = happyShift action_197
action_344 (84) = happyShift action_198
action_344 (102) = happyShift action_199
action_344 (16) = happyGoto action_347
action_344 (17) = happyGoto action_187
action_344 (23) = happyGoto action_188
action_344 _ = happyFail

action_345 (45) = happyShift action_189
action_345 (51) = happyShift action_190
action_345 (59) = happyShift action_191
action_345 (61) = happyShift action_192
action_345 (63) = happyShift action_193
action_345 (64) = happyShift action_194
action_345 (70) = happyShift action_195
action_345 (73) = happyShift action_196
action_345 (76) = happyShift action_197
action_345 (84) = happyShift action_198
action_345 (102) = happyShift action_199
action_345 (16) = happyGoto action_346
action_345 (17) = happyGoto action_187
action_345 (23) = happyGoto action_188
action_345 _ = happyFail

action_346 _ = happyReduce_28

action_347 _ = happyReduce_27

action_348 (45) = happyShift action_189
action_348 (51) = happyShift action_190
action_348 (59) = happyShift action_191
action_348 (61) = happyShift action_192
action_348 (63) = happyShift action_193
action_348 (64) = happyShift action_194
action_348 (70) = happyShift action_195
action_348 (73) = happyShift action_196
action_348 (76) = happyShift action_197
action_348 (84) = happyShift action_198
action_348 (102) = happyShift action_199
action_348 (16) = happyGoto action_375
action_348 (17) = happyGoto action_187
action_348 (23) = happyGoto action_188
action_348 _ = happyFail

action_349 (73) = happyShift action_40
action_349 (81) = happyShift action_74
action_349 (86) = happyShift action_75
action_349 (102) = happyShift action_76
action_349 (105) = happyShift action_44
action_349 (106) = happyShift action_77
action_349 (19) = happyGoto action_374
action_349 (37) = happyGoto action_343
action_349 (38) = happyGoto action_72
action_349 (39) = happyGoto action_73
action_349 _ = happyFail

action_350 _ = happyReduce_30

action_351 _ = happyReduce_54

action_352 _ = happyReduce_40

action_353 _ = happyReduce_42

action_354 (47) = happyShift action_49
action_354 (73) = happyShift action_50
action_354 (76) = happyShift action_51
action_354 (81) = happyShift action_52
action_354 (84) = happyShift action_53
action_354 (97) = happyShift action_54
action_354 (99) = happyShift action_55
action_354 (102) = happyShift action_56
action_354 (103) = happyShift action_57
action_354 (104) = happyShift action_58
action_354 (106) = happyShift action_59
action_354 (108) = happyShift action_60
action_354 (109) = happyShift action_61
action_354 (110) = happyShift action_62
action_354 (30) = happyGoto action_373
action_354 (34) = happyGoto action_47
action_354 (35) = happyGoto action_48
action_354 _ = happyFail

action_355 (54) = happyShift action_372
action_355 (88) = happyShift action_86
action_355 (97) = happyShift action_90
action_355 (98) = happyShift action_91
action_355 _ = happyFail

action_356 (47) = happyShift action_49
action_356 (73) = happyShift action_50
action_356 (76) = happyShift action_51
action_356 (81) = happyShift action_52
action_356 (84) = happyShift action_53
action_356 (97) = happyShift action_54
action_356 (99) = happyShift action_55
action_356 (102) = happyShift action_56
action_356 (103) = happyShift action_57
action_356 (104) = happyShift action_58
action_356 (106) = happyShift action_59
action_356 (108) = happyShift action_60
action_356 (109) = happyShift action_61
action_356 (110) = happyShift action_62
action_356 (30) = happyGoto action_371
action_356 (34) = happyGoto action_47
action_356 (35) = happyGoto action_48
action_356 _ = happyFail

action_357 (54) = happyShift action_370
action_357 (88) = happyShift action_86
action_357 (97) = happyShift action_90
action_357 (98) = happyShift action_91
action_357 _ = happyFail

action_358 (48) = happyShift action_369
action_358 _ = happyFail

action_359 _ = happyReduce_68

action_360 (45) = happyShift action_189
action_360 (51) = happyShift action_190
action_360 (59) = happyShift action_191
action_360 (61) = happyShift action_192
action_360 (63) = happyShift action_193
action_360 (64) = happyShift action_194
action_360 (66) = happyShift action_308
action_360 (67) = happyShift action_309
action_360 (68) = happyShift action_310
action_360 (70) = happyShift action_195
action_360 (73) = happyShift action_196
action_360 (76) = happyShift action_197
action_360 (84) = happyShift action_311
action_360 (102) = happyShift action_199
action_360 (16) = happyGoto action_319
action_360 (17) = happyGoto action_187
action_360 (23) = happyGoto action_188
action_360 (26) = happyGoto action_320
action_360 (27) = happyGoto action_307
action_360 _ = happyFail

action_361 (73) = happyShift action_211
action_361 (81) = happyShift action_213
action_361 (86) = happyShift action_75
action_361 (97) = happyShift action_54
action_361 (99) = happyShift action_55
action_361 (102) = happyShift action_214
action_361 (103) = happyShift action_57
action_361 (104) = happyShift action_58
action_361 (105) = happyShift action_44
action_361 (106) = happyShift action_215
action_361 (108) = happyShift action_60
action_361 (109) = happyShift action_61
action_361 (24) = happyGoto action_367
action_361 (34) = happyGoto action_368
action_361 (35) = happyGoto action_48
action_361 (37) = happyGoto action_210
action_361 (38) = happyGoto action_72
action_361 (39) = happyGoto action_73
action_361 _ = happyFail

action_362 (96) = happyShift action_227
action_362 _ = happyReduce_70

action_363 (96) = happyShift action_227
action_363 _ = happyReduce_71

action_364 (96) = happyShift action_227
action_364 _ = happyReduce_72

action_365 _ = happyReduce_69

action_366 _ = happyReduce_73

action_367 (73) = happyShift action_68
action_367 (81) = happyShift action_52
action_367 (97) = happyShift action_54
action_367 (99) = happyShift action_55
action_367 (102) = happyShift action_56
action_367 (103) = happyShift action_57
action_367 (104) = happyShift action_58
action_367 (106) = happyShift action_59
action_367 (108) = happyShift action_60
action_367 (109) = happyShift action_61
action_367 (34) = happyGoto action_383
action_367 (35) = happyGoto action_48
action_367 _ = happyFail

action_368 (49) = happyShift action_382
action_368 (88) = happyShift action_86
action_368 (97) = happyShift action_90
action_368 (98) = happyShift action_91
action_368 (25) = happyGoto action_380
action_368 (28) = happyGoto action_381
action_368 _ = happyReduce_66

action_369 (73) = happyShift action_211
action_369 (81) = happyShift action_213
action_369 (86) = happyShift action_75
action_369 (97) = happyShift action_54
action_369 (99) = happyShift action_55
action_369 (102) = happyShift action_214
action_369 (103) = happyShift action_57
action_369 (104) = happyShift action_58
action_369 (105) = happyShift action_44
action_369 (106) = happyShift action_215
action_369 (108) = happyShift action_60
action_369 (109) = happyShift action_61
action_369 (24) = happyGoto action_378
action_369 (34) = happyGoto action_379
action_369 (35) = happyGoto action_48
action_369 (37) = happyGoto action_210
action_369 (38) = happyGoto action_72
action_369 (39) = happyGoto action_73
action_369 _ = happyFail

action_370 (47) = happyShift action_49
action_370 (73) = happyShift action_50
action_370 (76) = happyShift action_51
action_370 (81) = happyShift action_52
action_370 (84) = happyShift action_53
action_370 (97) = happyShift action_54
action_370 (99) = happyShift action_55
action_370 (102) = happyShift action_56
action_370 (103) = happyShift action_57
action_370 (104) = happyShift action_58
action_370 (106) = happyShift action_59
action_370 (108) = happyShift action_60
action_370 (109) = happyShift action_61
action_370 (110) = happyShift action_62
action_370 (30) = happyGoto action_377
action_370 (34) = happyGoto action_47
action_370 (35) = happyGoto action_48
action_370 _ = happyFail

action_371 _ = happyReduce_47

action_372 (47) = happyShift action_49
action_372 (73) = happyShift action_50
action_372 (76) = happyShift action_51
action_372 (81) = happyShift action_52
action_372 (84) = happyShift action_53
action_372 (97) = happyShift action_54
action_372 (99) = happyShift action_55
action_372 (102) = happyShift action_56
action_372 (103) = happyShift action_57
action_372 (104) = happyShift action_58
action_372 (106) = happyShift action_59
action_372 (108) = happyShift action_60
action_372 (109) = happyShift action_61
action_372 (110) = happyShift action_62
action_372 (30) = happyGoto action_376
action_372 (34) = happyGoto action_47
action_372 (35) = happyGoto action_48
action_372 _ = happyFail

action_373 _ = happyReduce_45

action_374 _ = happyReduce_32

action_375 (96) = happyShift action_227
action_375 _ = happyReduce_33

action_376 _ = happyReduce_44

action_377 _ = happyReduce_46

action_378 (73) = happyShift action_68
action_378 (81) = happyShift action_52
action_378 (97) = happyShift action_54
action_378 (99) = happyShift action_55
action_378 (102) = happyShift action_56
action_378 (103) = happyShift action_57
action_378 (104) = happyShift action_58
action_378 (106) = happyShift action_59
action_378 (108) = happyShift action_60
action_378 (109) = happyShift action_61
action_378 (34) = happyGoto action_388
action_378 (35) = happyGoto action_48
action_378 _ = happyFail

action_379 (49) = happyShift action_382
action_379 (88) = happyShift action_86
action_379 (97) = happyShift action_90
action_379 (98) = happyShift action_91
action_379 (25) = happyGoto action_387
action_379 (28) = happyGoto action_381
action_379 _ = happyReduce_66

action_380 _ = happyReduce_60

action_381 _ = happyReduce_65

action_382 (46) = happyShift action_385
action_382 (50) = happyShift action_386
action_382 _ = happyFail

action_383 (49) = happyShift action_382
action_383 (88) = happyShift action_86
action_383 (97) = happyShift action_90
action_383 (98) = happyShift action_91
action_383 (25) = happyGoto action_384
action_383 (28) = happyGoto action_381
action_383 _ = happyReduce_66

action_384 _ = happyReduce_59

action_385 (73) = happyShift action_68
action_385 (81) = happyShift action_52
action_385 (97) = happyShift action_54
action_385 (99) = happyShift action_55
action_385 (102) = happyShift action_56
action_385 (103) = happyShift action_57
action_385 (104) = happyShift action_58
action_385 (106) = happyShift action_59
action_385 (108) = happyShift action_60
action_385 (109) = happyShift action_61
action_385 (34) = happyGoto action_391
action_385 (35) = happyGoto action_48
action_385 _ = happyFail

action_386 (46) = happyShift action_390
action_386 _ = happyFail

action_387 _ = happyReduce_61

action_388 (49) = happyShift action_382
action_388 (88) = happyShift action_86
action_388 (97) = happyShift action_90
action_388 (98) = happyShift action_91
action_388 (25) = happyGoto action_389
action_388 (28) = happyGoto action_381
action_388 _ = happyReduce_66

action_389 _ = happyReduce_58

action_390 (73) = happyShift action_68
action_390 (81) = happyShift action_52
action_390 (97) = happyShift action_54
action_390 (99) = happyShift action_55
action_390 (102) = happyShift action_56
action_390 (103) = happyShift action_57
action_390 (104) = happyShift action_58
action_390 (106) = happyShift action_59
action_390 (108) = happyShift action_60
action_390 (109) = happyShift action_61
action_390 (34) = happyGoto action_392
action_390 (35) = happyGoto action_48
action_390 _ = happyFail

action_391 (88) = happyShift action_86
action_391 (97) = happyShift action_90
action_391 (98) = happyShift action_91
action_391 _ = happyReduce_74

action_392 (48) = happyShift action_393
action_392 (88) = happyShift action_86
action_392 (97) = happyShift action_90
action_392 (98) = happyShift action_91
action_392 _ = happyFail

action_393 (46) = happyShift action_394
action_393 _ = happyFail

action_394 (73) = happyShift action_68
action_394 (81) = happyShift action_52
action_394 (97) = happyShift action_54
action_394 (99) = happyShift action_55
action_394 (102) = happyShift action_56
action_394 (103) = happyShift action_57
action_394 (104) = happyShift action_58
action_394 (106) = happyShift action_59
action_394 (108) = happyShift action_60
action_394 (109) = happyShift action_61
action_394 (34) = happyGoto action_395
action_394 (35) = happyGoto action_48
action_394 _ = happyFail

action_395 (88) = happyShift action_86
action_395 (97) = happyShift action_90
action_395 (98) = happyShift action_91
action_395 _ = happyReduce_75

happyReduce_1 = happyReduce 4 4 happyReduction_1
happyReduction_1 ((HappyAbsSyn11  happy_var_4) `HappyStk`
	(HappyAbsSyn9  happy_var_3) `HappyStk`
	(HappyAbsSyn7  happy_var_2) `HappyStk`
	(HappyAbsSyn5  happy_var_1) `HappyStk`
	happyRest)
	 = HappyAbsSyn4
		 (Program happy_var_1 happy_var_2 happy_var_3 happy_var_4
	) `HappyStk` happyRest

happyReduce_2 = happySpecReduce_1  5 happyReduction_2
happyReduction_2 (HappyAbsSyn6  happy_var_1)
	 =  HappyAbsSyn5
		 ([happy_var_1]
	)
happyReduction_2 _  = notHappyAtAll 

happyReduce_3 = happySpecReduce_2  5 happyReduction_3
happyReduction_3 (HappyAbsSyn6  happy_var_2)
	(HappyAbsSyn5  happy_var_1)
	 =  HappyAbsSyn5
		 (happy_var_1 ++ [happy_var_2]
	)
happyReduction_3 _ _  = notHappyAtAll 

happyReduce_4 = happyReduce 4 6 happyReduction_4
happyReduction_4 ((HappyTerminal (QName happy_var_4)) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn6
		 (Import happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_5 = happySpecReduce_1  7 happyReduction_5
happyReduction_5 (HappyAbsSyn8  happy_var_1)
	 =  HappyAbsSyn7
		 ([happy_var_1]
	)
happyReduction_5 _  = notHappyAtAll 

happyReduce_6 = happySpecReduce_2  7 happyReduction_6
happyReduction_6 (HappyAbsSyn8  happy_var_2)
	(HappyAbsSyn7  happy_var_1)
	 =  HappyAbsSyn7
		 (happy_var_1 ++ [happy_var_2]
	)
happyReduction_6 _ _  = notHappyAtAll 

happyReduce_7 = happyReduce 6 8 happyReduction_7
happyReduction_7 (_ `HappyStk`
	(HappyTerminal (QString happy_var_5)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QVar happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn8
		 (VarBind happy_var_1 happy_var_5
	) `HappyStk` happyRest

happyReduce_8 = happyReduce 6 9 happyReduction_8
happyReduction_8 (_ `HappyStk`
	(HappyAbsSyn10  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_3)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn9
		 (Start happy_var_3  happy_var_5
	) `HappyStk` happyRest

happyReduce_9 = happySpecReduce_1  10 happyReduction_9
happyReduction_9 (HappyAbsSyn29  happy_var_1)
	 =  HappyAbsSyn10
		 ([ happy_var_1]
	)
happyReduction_9 _  = notHappyAtAll 

happyReduce_10 = happySpecReduce_3  10 happyReduction_10
happyReduction_10 (HappyAbsSyn29  happy_var_3)
	_
	(HappyAbsSyn10  happy_var_1)
	 =  HappyAbsSyn10
		 (happy_var_1 ++ [happy_var_3]
	)
happyReduction_10 _ _ _  = notHappyAtAll 

happyReduce_11 = happySpecReduce_0  10 happyReduction_11
happyReduction_11  =  HappyAbsSyn10
		 ([]
	)

happyReduce_12 = happySpecReduce_1  11 happyReduction_12
happyReduction_12 (HappyAbsSyn12  happy_var_1)
	 =  HappyAbsSyn11
		 ([happy_var_1]
	)
happyReduction_12 _  = notHappyAtAll 

happyReduce_13 = happySpecReduce_2  11 happyReduction_13
happyReduction_13 (HappyAbsSyn12  happy_var_2)
	(HappyAbsSyn11  happy_var_1)
	 =  HappyAbsSyn11
		 (happy_var_1 ++ [happy_var_2]
	)
happyReduction_13 _ _  = notHappyAtAll 

happyReduce_14 = happySpecReduce_1  12 happyReduction_14
happyReduction_14 (HappyAbsSyn13  happy_var_1)
	 =  HappyAbsSyn12
		 (ProcedureDecl happy_var_1
	)
happyReduction_14 _  = notHappyAtAll 

happyReduce_15 = happyReduce 4 12 happyReduction_15
happyReduction_15 ((HappyAbsSyn39  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QTName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn12
		 (TypeDecl happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_16 = happyReduce 7 13 happyReduction_16
happyReduction_16 ((HappyAbsSyn16  happy_var_7) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn14  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn13
		 (Procedure happy_var_2 happy_var_4 happy_var_7
	) `HappyStk` happyRest

happyReduce_17 = happySpecReduce_1  14 happyReduction_17
happyReduction_17 (HappyAbsSyn15  happy_var_1)
	 =  HappyAbsSyn14
		 ([happy_var_1]
	)
happyReduction_17 _  = notHappyAtAll 

happyReduce_18 = happySpecReduce_3  14 happyReduction_18
happyReduction_18 (HappyAbsSyn15  happy_var_3)
	_
	(HappyAbsSyn14  happy_var_1)
	 =  HappyAbsSyn14
		 (happy_var_1 ++ [happy_var_3]
	)
happyReduction_18 _ _ _  = notHappyAtAll 

happyReduce_19 = happySpecReduce_0  14 happyReduction_19
happyReduction_19  =  HappyAbsSyn14
		 ([]
	)

happyReduce_20 = happyReduce 4 15 happyReduction_20
happyReduction_20 ((HappyAbsSyn39  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QVar happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn15
		 ((ProcSVar happy_var_2, happy_var_4)
	) `HappyStk` happyRest

happyReduce_21 = happyReduce 4 15 happyReduction_21
happyReduction_21 ((HappyAbsSyn39  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QVar happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn15
		 ((ProcVVar happy_var_2, happy_var_4)
	) `HappyStk` happyRest

happyReduce_22 = happySpecReduce_3  15 happyReduction_22
happyReduction_22 (HappyAbsSyn39  happy_var_3)
	_
	(HappyTerminal (QVar happy_var_1))
	 =  HappyAbsSyn15
		 ((ProcEVar happy_var_1, happy_var_3)
	)
happyReduction_22 _ _ _  = notHappyAtAll 

happyReduce_23 = happySpecReduce_1  16 happyReduction_23
happyReduction_23 (HappyAbsSyn17  happy_var_1)
	 =  HappyAbsSyn16
		 ([happy_var_1]
	)
happyReduction_23 _  = notHappyAtAll 

happyReduce_24 = happySpecReduce_3  16 happyReduction_24
happyReduction_24 (HappyAbsSyn17  happy_var_3)
	_
	(HappyAbsSyn16  happy_var_1)
	 =  HappyAbsSyn16
		 (happy_var_1 ++ [happy_var_3]
	)
happyReduction_24 _ _ _  = notHappyAtAll 

happyReduce_25 = happySpecReduce_2  16 happyReduction_25
happyReduction_25 _
	_
	 =  HappyAbsSyn16
		 ([]
	)

happyReduce_26 = happySpecReduce_2  17 happyReduction_26
happyReduction_26 (HappyAbsSyn20  happy_var_2)
	(HappyAbsSyn23  happy_var_1)
	 =  HappyAbsSyn17
		 (StmtUpd happy_var_1 happy_var_2
	)
happyReduction_26 _ _  = notHappyAtAll 

happyReduce_27 = happyReduce 6 17 happyReduction_27
happyReduction_27 ((HappyAbsSyn16  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn16  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn22  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn17
		 (StmtIF  happy_var_2 happy_var_4  happy_var_6
	) `HappyStk` happyRest

happyReduce_28 = happyReduce 6 17 happyReduction_28
happyReduction_28 ((HappyAbsSyn16  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn29  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn37  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn17
		 (StmtLet happy_var_2 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_29 = happyReduce 4 17 happyReduction_29
happyReduction_29 (_ `HappyStk`
	(HappyAbsSyn10  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn17
		 (StmtP   happy_var_1 happy_var_3
	) `HappyStk` happyRest

happyReduce_30 = happyReduce 6 17 happyReduction_30
happyReduction_30 (_ `HappyStk`
	(HappyAbsSyn18  happy_var_5) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn29  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn17
		 (StmtCase happy_var_2 happy_var_5
	) `HappyStk` happyRest

happyReduce_31 = happySpecReduce_1  18 happyReduction_31
happyReduction_31 (HappyAbsSyn19  happy_var_1)
	 =  HappyAbsSyn18
		 ([happy_var_1]
	)
happyReduction_31 _  = notHappyAtAll 

happyReduce_32 = happySpecReduce_3  18 happyReduction_32
happyReduction_32 (HappyAbsSyn19  happy_var_3)
	_
	(HappyAbsSyn18  happy_var_1)
	 =  HappyAbsSyn18
		 (happy_var_1 ++ [happy_var_3]
	)
happyReduction_32 _ _ _  = notHappyAtAll 

happyReduce_33 = happySpecReduce_3  19 happyReduction_33
happyReduction_33 (HappyAbsSyn16  happy_var_3)
	_
	(HappyAbsSyn37  happy_var_1)
	 =  HappyAbsSyn19
		 ((happy_var_1, happy_var_3)
	)
happyReduction_33 _ _ _  = notHappyAtAll 

happyReduce_34 = happySpecReduce_1  20 happyReduction_34
happyReduction_34 (HappyAbsSyn21  happy_var_1)
	 =  HappyAbsSyn20
		 ([happy_var_1]
	)
happyReduction_34 _  = notHappyAtAll 

happyReduce_35 = happySpecReduce_2  20 happyReduction_35
happyReduction_35 (HappyAbsSyn21  happy_var_2)
	(HappyAbsSyn20  happy_var_1)
	 =  HappyAbsSyn20
		 (happy_var_1 ++ [happy_var_2]
	)
happyReduction_35 _ _  = notHappyAtAll 

happyReduce_36 = happySpecReduce_0  20 happyReduction_36
happyReduction_36  =  HappyAbsSyn20
		 ([]
	)

happyReduce_37 = happySpecReduce_2  21 happyReduction_37
happyReduction_37 (HappyAbsSyn22  happy_var_2)
	_
	 =  HappyAbsSyn21
		 (WhereBool happy_var_2
	)
happyReduction_37 _ _  = notHappyAtAll 

happyReduce_38 = happyReduce 4 21 happyReduction_38
happyReduction_38 ((HappyAbsSyn29  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QVar happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn21
		 (WhereBind happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_39 = happySpecReduce_1  22 happyReduction_39
happyReduction_39 (HappyAbsSyn29  happy_var_1)
	 =  HappyAbsSyn22
		 (happy_var_1
	)
happyReduction_39 _  = notHappyAtAll 

happyReduce_40 = happyReduce 6 23 happyReduction_40
happyReduction_40 ((HappyAbsSyn29  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_4) `HappyStk`
	(HappyAbsSyn24  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (SingleInsertion UBEFORE happy_var_3 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_41 = happyReduce 5 23 happyReduction_41
happyReduction_41 ((HappyAbsSyn29  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (SingleInsertion UBEFORE Nothing happy_var_3 happy_var_5
	) `HappyStk` happyRest

happyReduce_42 = happyReduce 6 23 happyReduction_42
happyReduction_42 ((HappyAbsSyn29  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_4) `HappyStk`
	(HappyAbsSyn24  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (SingleInsertion UAFTER  happy_var_3 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_43 = happyReduce 5 23 happyReduction_43
happyReduction_43 ((HappyAbsSyn29  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (SingleInsertion UAFTER  Nothing happy_var_3 happy_var_5
	) `HappyStk` happyRest

happyReduce_44 = happyReduce 8 23 happyReduction_44
happyReduction_44 ((HappyAbsSyn29  happy_var_8) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_6) `HappyStk`
	(HappyAbsSyn24  happy_var_5) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (PluralInsertion UFIRST  happy_var_5 happy_var_6 happy_var_8
	) `HappyStk` happyRest

happyReduce_45 = happyReduce 7 23 happyReduction_45
happyReduction_45 ((HappyAbsSyn29  happy_var_7) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_5) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (PluralInsertion UFIRST  Nothing happy_var_5 happy_var_7
	) `HappyStk` happyRest

happyReduce_46 = happyReduce 8 23 happyReduction_46
happyReduction_46 ((HappyAbsSyn29  happy_var_8) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_6) `HappyStk`
	(HappyAbsSyn24  happy_var_5) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (PluralInsertion ULAST   happy_var_5 happy_var_6 happy_var_8
	) `HappyStk` happyRest

happyReduce_47 = happyReduce 7 23 happyReduction_47
happyReduction_47 ((HappyAbsSyn29  happy_var_7) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_5) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (PluralInsertion ULAST   Nothing happy_var_5 happy_var_7
	) `HappyStk` happyRest

happyReduce_48 = happySpecReduce_3  23 happyReduction_48
happyReduction_48 (HappyAbsSyn34  happy_var_3)
	(HappyAbsSyn24  happy_var_2)
	_
	 =  HappyAbsSyn23
		 (SingleDeletion          happy_var_2 happy_var_3
	)
happyReduction_48 _ _ _  = notHappyAtAll 

happyReduce_49 = happySpecReduce_2  23 happyReduction_49
happyReduction_49 (HappyAbsSyn34  happy_var_2)
	_
	 =  HappyAbsSyn23
		 (SingleDeletion          Nothing happy_var_2
	)
happyReduction_49 _ _  = notHappyAtAll 

happyReduce_50 = happyReduce 4 23 happyReduction_50
happyReduction_50 ((HappyAbsSyn34  happy_var_4) `HappyStk`
	(HappyAbsSyn24  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (PluralDeletion          happy_var_3 happy_var_4
	) `HappyStk` happyRest

happyReduce_51 = happySpecReduce_3  23 happyReduction_51
happyReduction_51 (HappyAbsSyn34  happy_var_3)
	_
	_
	 =  HappyAbsSyn23
		 (PluralDeletion          Nothing  happy_var_3
	)
happyReduction_51 _ _ _  = notHappyAtAll 

happyReduce_52 = happyReduce 5 23 happyReduction_52
happyReduction_52 ((HappyAbsSyn29  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_3) `HappyStk`
	(HappyAbsSyn24  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (SingleReplace           happy_var_2 happy_var_3 happy_var_5
	) `HappyStk` happyRest

happyReduce_53 = happyReduce 4 23 happyReduction_53
happyReduction_53 ((HappyAbsSyn29  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (SingleReplace           Nothing happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_54 = happyReduce 6 23 happyReduction_54
happyReduction_54 ((HappyAbsSyn29  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_4) `HappyStk`
	(HappyAbsSyn24  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (PluralReplace           happy_var_3 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_55 = happyReduce 5 23 happyReduction_55
happyReduction_55 ((HappyAbsSyn29  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (PluralReplace           Nothing happy_var_3 happy_var_5
	) `HappyStk` happyRest

happyReduce_56 = happyReduce 5 23 happyReduction_56
happyReduction_56 ((HappyAbsSyn16  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_3) `HappyStk`
	(HappyAbsSyn24  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (UpdateSource        happy_var_2 happy_var_3 happy_var_5
	) `HappyStk` happyRest

happyReduce_57 = happyReduce 4 23 happyReduction_57
happyReduction_57 ((HappyAbsSyn16  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (UpdateSource        Nothing happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_58 = happyReduce 10 23 happyReduction_58
happyReduction_58 ((HappyAbsSyn25  happy_var_10) `HappyStk`
	(HappyAbsSyn34  happy_var_9) `HappyStk`
	(HappyAbsSyn24  happy_var_8) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn26  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_3) `HappyStk`
	(HappyAbsSyn24  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (UpdateView happy_var_2 happy_var_3 happy_var_5 happy_var_8 happy_var_9 happy_var_10
	) `HappyStk` happyRest

happyReduce_59 = happyReduce 9 23 happyReduction_59
happyReduction_59 ((HappyAbsSyn25  happy_var_9) `HappyStk`
	(HappyAbsSyn34  happy_var_8) `HappyStk`
	(HappyAbsSyn24  happy_var_7) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn26  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (UpdateView Nothing happy_var_2 happy_var_4 happy_var_7 happy_var_8 happy_var_9
	) `HappyStk` happyRest

happyReduce_60 = happyReduce 8 23 happyReduction_60
happyReduction_60 ((HappyAbsSyn25  happy_var_8) `HappyStk`
	(HappyAbsSyn34  happy_var_7) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn26  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (UpdateView Nothing happy_var_2 happy_var_4 Nothing happy_var_7 happy_var_8
	) `HappyStk` happyRest

happyReduce_61 = happyReduce 9 23 happyReduction_61
happyReduction_61 ((HappyAbsSyn25  happy_var_9) `HappyStk`
	(HappyAbsSyn34  happy_var_8) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn26  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_3) `HappyStk`
	(HappyAbsSyn24  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn23
		 (UpdateView happy_var_2 happy_var_3 happy_var_5 Nothing happy_var_8 happy_var_9
	) `HappyStk` happyRest

happyReduce_62 = happySpecReduce_2  23 happyReduction_62
happyReduction_62 (HappyAbsSyn34  happy_var_2)
	_
	 =  HappyAbsSyn23
		 (UpdateKeep                happy_var_2
	)
happyReduction_62 _ _  = notHappyAtAll 

happyReduce_63 = happySpecReduce_3  23 happyReduction_63
happyReduction_63 (HappyAbsSyn29  happy_var_3)
	_
	_
	 =  HappyAbsSyn23
		 (UpdateCreate              happy_var_3
	)
happyReduction_63 _ _ _  = notHappyAtAll 

happyReduce_64 = happySpecReduce_2  24 happyReduction_64
happyReduction_64 _
	(HappyAbsSyn37  happy_var_1)
	 =  HappyAbsSyn24
		 (Just happy_var_1
	)
happyReduction_64 _ _  = notHappyAtAll 

happyReduce_65 = happySpecReduce_1  25 happyReduction_65
happyReduction_65 (HappyAbsSyn28  happy_var_1)
	 =  HappyAbsSyn25
		 (Just happy_var_1
	)
happyReduction_65 _  = notHappyAtAll 

happyReduce_66 = happySpecReduce_0  25 happyReduction_66
happyReduction_66  =  HappyAbsSyn25
		 (Nothing
	)

happyReduce_67 = happySpecReduce_1  26 happyReduction_67
happyReduction_67 (HappyAbsSyn27  happy_var_1)
	 =  HappyAbsSyn26
		 ([happy_var_1]
	)
happyReduction_67 _  = notHappyAtAll 

happyReduce_68 = happySpecReduce_3  26 happyReduction_68
happyReduction_68 (HappyAbsSyn26  happy_var_3)
	_
	(HappyAbsSyn26  happy_var_1)
	 =  HappyAbsSyn26
		 (happy_var_1 ++ happy_var_3
	)
happyReduction_68 _ _ _  = notHappyAtAll 

happyReduce_69 = happySpecReduce_3  26 happyReduction_69
happyReduction_69 _
	(HappyAbsSyn26  happy_var_2)
	_
	 =  HappyAbsSyn26
		 (happy_var_2
	)
happyReduction_69 _ _ _  = notHappyAtAll 

happyReduce_70 = happySpecReduce_3  27 happyReduction_70
happyReduction_70 (HappyAbsSyn16  happy_var_3)
	_
	_
	 =  HappyAbsSyn27
		 (ViewStmtMatch happy_var_3
	)
happyReduction_70 _ _ _  = notHappyAtAll 

happyReduce_71 = happySpecReduce_3  27 happyReduction_71
happyReduction_71 (HappyAbsSyn16  happy_var_3)
	_
	_
	 =  HappyAbsSyn27
		 (ViewStmtUMV   happy_var_3
	)
happyReduction_71 _ _ _  = notHappyAtAll 

happyReduce_72 = happySpecReduce_3  27 happyReduction_72
happyReduction_72 (HappyAbsSyn16  happy_var_3)
	_
	_
	 =  HappyAbsSyn27
		 (ViewStmtUMS   happy_var_3
	)
happyReduction_72 _ _ _  = notHappyAtAll 

happyReduce_73 = happySpecReduce_3  27 happyReduction_73
happyReduction_73 _
	(HappyAbsSyn16  happy_var_2)
	_
	 =  HappyAbsSyn27
		 (ViewStmtMatch happy_var_2
	)
happyReduction_73 _ _ _  = notHappyAtAll 

happyReduce_74 = happySpecReduce_3  28 happyReduction_74
happyReduction_74 (HappyAbsSyn34  happy_var_3)
	_
	_
	 =  HappyAbsSyn28
		 (MatchBY happy_var_3
	)
happyReduction_74 _ _ _  = notHappyAtAll 

happyReduce_75 = happyReduce 7 28 happyReduction_75
happyReduction_75 ((HappyAbsSyn34  happy_var_7) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_4) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn28
		 (MatchSV happy_var_4 happy_var_7
	) `HappyStk` happyRest

happyReduce_76 = happySpecReduce_1  29 happyReduction_76
happyReduction_76 (HappyAbsSyn29  happy_var_1)
	 =  HappyAbsSyn29
		 (happy_var_1
	)
happyReduction_76 _  = notHappyAtAll 

happyReduce_77 = happySpecReduce_2  29 happyReduction_77
happyReduction_77 (HappyAbsSyn29  happy_var_2)
	(HappyAbsSyn29  happy_var_1)
	 =  HappyAbsSyn29
		 (XQProd happy_var_1 happy_var_2
	)
happyReduction_77 _ _  = notHappyAtAll 

happyReduce_78 = happyReduce 8 30 happyReduction_78
happyReduction_78 (_ `HappyStk`
	(HappyTerminal (QName happy_var_7)) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn29  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn29  happy_var_3) `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn29
		 (if happy_var_2 == happy_var_7 
 							      then XQElem happy_var_2  (XQProd happy_var_3 happy_var_5)
                                                              else parseError [(QError("Element: unmatched tag name"))]
	) `HappyStk` happyRest

happyReduce_79 = happyReduce 7 30 happyReduction_79
happyReduction_79 (_ `HappyStk`
	(HappyTerminal (QName happy_var_6)) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn29  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn29
		 (if happy_var_2 == happy_var_6 
 							      then XQElem happy_var_2 happy_var_4
                                                              else parseError [(QError("Element: unmatched tag name"))]
	) `HappyStk` happyRest

happyReduce_80 = happyReduce 7 30 happyReduction_80
happyReduction_80 (_ `HappyStk`
	(HappyTerminal (QName happy_var_6)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn29  happy_var_3) `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn29
		 (if happy_var_2 == happy_var_6 
 							      then XQElem happy_var_2  happy_var_3
                                                              else parseError [(QError("Element: unmatched tag name"))]
	) `HappyStk` happyRest

happyReduce_81 = happyReduce 6 30 happyReduction_81
happyReduction_81 (_ `HappyStk`
	(HappyTerminal (QName happy_var_5)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn29
		 (if happy_var_2 == happy_var_5
							      then XQElem happy_var_2 XQEmpty	      
                                                              else parseError [(QError("Element: unmatched tag name"))]
	) `HappyStk` happyRest

happyReduce_82 = happySpecReduce_3  30 happyReduction_82
happyReduction_82 _
	(HappyTerminal (QName happy_var_2))
	_
	 =  HappyAbsSyn29
		 (XQElem happy_var_2 XQEmpty
	)
happyReduction_82 _ _ _  = notHappyAtAll 

happyReduce_83 = happyReduce 4 30 happyReduction_83
happyReduction_83 (_ `HappyStk`
	(HappyAbsSyn29  happy_var_3) `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn29
		 (XQElem happy_var_2 happy_var_3
	) `HappyStk` happyRest

happyReduce_84 = happySpecReduce_3  30 happyReduction_84
happyReduction_84 _
	(HappyAbsSyn34  happy_var_2)
	_
	 =  HappyAbsSyn29
		 (XQPath   happy_var_2
	)
happyReduction_84 _ _ _  = notHappyAtAll 

happyReduce_85 = happySpecReduce_1  30 happyReduction_85
happyReduction_85 (HappyAbsSyn34  happy_var_1)
	 =  HappyAbsSyn29
		 (XQPath happy_var_1
	)
happyReduction_85 _  = notHappyAtAll 

happyReduce_86 = happyReduce 6 30 happyReduction_86
happyReduction_86 ((HappyAbsSyn29  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn29  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn37  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn29
		 (XQLet happy_var_2 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_87 = happyReduce 6 30 happyReduction_87
happyReduction_87 ((HappyAbsSyn29  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn29  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn29  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn29
		 (XQIf happy_var_2 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_88 = happyReduce 6 30 happyReduction_88
happyReduction_88 ((HappyAbsSyn29  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn29  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QVar happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn29
		 (XQFor happy_var_2 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_89 = happySpecReduce_3  30 happyReduction_89
happyReduction_89 (HappyAbsSyn34  happy_var_3)
	(HappyAbsSyn31  happy_var_2)
	(HappyAbsSyn34  happy_var_1)
	 =  HappyAbsSyn29
		 (XQBinOp happy_var_2 (XQPath happy_var_1) (XQPath happy_var_3)
	)
happyReduction_89 _ _ _  = notHappyAtAll 

happyReduce_90 = happySpecReduce_1  31 happyReduction_90
happyReduction_90 _
	 =  HappyAbsSyn31
		 (XPath.Eq
	)

happyReduce_91 = happySpecReduce_2  31 happyReduction_91
happyReduction_91 _
	_
	 =  HappyAbsSyn31
		 (XPath.NEq
	)

happyReduce_92 = happySpecReduce_1  31 happyReduction_92
happyReduction_92 _
	 =  HappyAbsSyn31
		 (XPath.Less
	)

happyReduce_93 = happySpecReduce_1  31 happyReduction_93
happyReduction_93 _
	 =  HappyAbsSyn31
		 (XPath.Greater
	)

happyReduce_94 = happySpecReduce_2  31 happyReduction_94
happyReduction_94 _
	_
	 =  HappyAbsSyn31
		 (XPath.LessEq
	)

happyReduce_95 = happySpecReduce_2  31 happyReduction_95
happyReduction_95 _
	_
	 =  HappyAbsSyn31
		 (XPath.GreaterEq
	)

happyReduce_96 = happySpecReduce_1  31 happyReduction_96
happyReduction_96 _
	 =  HappyAbsSyn31
		 (XPath.Plus
	)

happyReduce_97 = happySpecReduce_1  31 happyReduction_97
happyReduction_97 _
	 =  HappyAbsSyn31
		 (XPath.Minus
	)

happyReduce_98 = happySpecReduce_1  31 happyReduction_98
happyReduction_98 _
	 =  HappyAbsSyn31
		 (XPath.Mult
	)

happyReduce_99 = happySpecReduce_1  31 happyReduction_99
happyReduction_99 (HappyTerminal (QName happy_var_1))
	 =  HappyAbsSyn31
		 (if happy_var_1 == "and" then XPath.And
                                                           else if happy_var_1 == "or" then XPath.Or
							     else if happy_var_1 == "mod"  then XPath.Mod
							       else if happy_var_1 == "div" then XPath.Div
								 else parseError [(QError("Binary Operator wrong"))]
	)
happyReduction_99 _  = notHappyAtAll 

happyReduce_100 = happySpecReduce_1  32 happyReduction_100
happyReduction_100 (HappyAbsSyn29  happy_var_1)
	 =  HappyAbsSyn29
		 (happy_var_1
	)
happyReduction_100 _  = notHappyAtAll 

happyReduce_101 = happySpecReduce_2  32 happyReduction_101
happyReduction_101 (HappyAbsSyn29  happy_var_2)
	(HappyAbsSyn29  happy_var_1)
	 =  HappyAbsSyn29
		 (XQProd happy_var_1 happy_var_2
	)
happyReduction_101 _ _  = notHappyAtAll 

happyReduce_102 = happySpecReduce_3  33 happyReduction_102
happyReduction_102 (HappyAbsSyn29  happy_var_3)
	_
	(HappyTerminal (QName happy_var_1))
	 =  HappyAbsSyn29
		 (XQAttr happy_var_1 happy_var_3
	)
happyReduction_102 _ _ _  = notHappyAtAll 

happyReduce_103 = happySpecReduce_1  34 happyReduction_103
happyReduction_103 _
	 =  HappyAbsSyn34
		 (CPathSelf
	)

happyReduce_104 = happySpecReduce_2  34 happyReduction_104
happyReduction_104 (HappyAbsSyn34  happy_var_2)
	_
	 =  HappyAbsSyn34
		 (CPathSlash CPathDoS happy_var_2
	)
happyReduction_104 _ _  = notHappyAtAll 

happyReduce_105 = happySpecReduce_3  34 happyReduction_105
happyReduction_105 (HappyAbsSyn34  happy_var_3)
	_
	(HappyAbsSyn34  happy_var_1)
	 =  HappyAbsSyn34
		 (CPathSlash happy_var_1  (CPathSlash CPathDoS happy_var_3)
	)
happyReduction_105 _ _ _  = notHappyAtAll 

happyReduce_106 = happySpecReduce_3  34 happyReduction_106
happyReduction_106 (HappyAbsSyn34  happy_var_3)
	_
	(HappyAbsSyn34  happy_var_1)
	 =  HappyAbsSyn34
		 (CPathSlash happy_var_1 happy_var_3
	)
happyReduction_106 _ _ _  = notHappyAtAll 

happyReduce_107 = happyReduce 4 34 happyReduction_107
happyReduction_107 (_ `HappyStk`
	(HappyAbsSyn29  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn34
		 (CPathSlash (CPathSlash CPathChild (CPathNodeTest (XPath.NameTest (HXTQN.mkName happy_var_1)))) (CPathFilter happy_var_3)
	) `HappyStk` happyRest

happyReduce_108 = happyReduce 4 34 happyReduction_108
happyReduction_108 (_ `HappyStk`
	(HappyAbsSyn29  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn34
		 (CPathSlash (CPathSlash CPathChild (CPathNodeTest (XPath.NameTest (HXTQN.mkName "if")))) (CPathFilter happy_var_3)
	) `HappyStk` happyRest

happyReduce_109 = happyReduce 4 34 happyReduction_109
happyReduction_109 (_ `HappyStk`
	(HappyAbsSyn29  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_1) `HappyStk`
	happyRest)
	 = HappyAbsSyn34
		 (CPathSlash happy_var_1 (CPathFilter happy_var_3)
	) `HappyStk` happyRest

happyReduce_110 = happySpecReduce_1  34 happyReduction_110
happyReduction_110 (HappyTerminal (QVar happy_var_1))
	 =  HappyAbsSyn34
		 (CPathVar happy_var_1
	)
happyReduction_110 _  = notHappyAtAll 

happyReduce_111 = happySpecReduce_1  34 happyReduction_111
happyReduction_111 (HappyTerminal (QString happy_var_1))
	 =  HappyAbsSyn34
		 (CPathString happy_var_1
	)
happyReduction_111 _  = notHappyAtAll 

happyReduce_112 = happySpecReduce_1  34 happyReduction_112
happyReduction_112 (HappyTerminal (QXmlText happy_var_1))
	 =  HappyAbsSyn34
		 (CPathString happy_var_1
	)
happyReduction_112 _  = notHappyAtAll 

happyReduce_113 = happySpecReduce_1  34 happyReduction_113
happyReduction_113 _
	 =  HappyAbsSyn34
		 (CPathBool True
	)

happyReduce_114 = happySpecReduce_1  34 happyReduction_114
happyReduction_114 _
	 =  HappyAbsSyn34
		 (CPathBool False
	)

happyReduce_115 = happySpecReduce_3  34 happyReduction_115
happyReduction_115 _
	_
	(HappyTerminal (QName happy_var_1))
	 =  HappyAbsSyn34
		 (if happy_var_1 == "node" then (CPathSlash (CPathSlash CPathSelf CPathChild) (CPathNodeTest (XPath.TypeTest XPath.XPNode))) 
                                               else if happy_var_1 == "comment" then (CPathSlash (CPathSlash CPathSelf CPathChild) (CPathNodeTest (XPath.TypeTest XPath.XPCommentNode))) 
						    else if happy_var_1 == "text" then (CPathSlash (CPathSlash CPathSelf CPathChild) (CPathNodeTest (XPath.TypeTest XPath.XPTextNode))) 
						         else if happy_var_1 == "processing-instruction" then (CPathSlash (CPathSlash CPathSelf CPathChild) (CPathNodeTest (XPath.TypeTest XPath.XPPINode))) 
							   else  if happy_var_1 == "string" then (CPathSlash (CPathSlash CPathSelf CPathChild) (CPathNodeTest (XPath.TypeTest XPString))) 
							     else parseError [(QError("XPath NodeTest wrong name()."))]
	)
happyReduction_115 _ _ _  = notHappyAtAll 

happyReduce_116 = happySpecReduce_3  34 happyReduction_116
happyReduction_116 _
	_
	_
	 =  HappyAbsSyn34
		 ((CPathSlash (CPathSlash CPathSelf CPathChild) (CPathNodeTest (XPath.TypeTest XPath.XPString)))
	)

happyReduce_117 = happyReduce 6 34 happyReduction_117
happyReduction_117 (_ `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_4)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_1) `HappyStk`
	happyRest)
	 = HappyAbsSyn34
		 (if happy_var_4 == "node" then CPathSlash happy_var_1 (CPathNodeTest (XPath.TypeTest XPath.XPNode))
                                                 else if happy_var_4 == "comment" then CPathSlash happy_var_1 (CPathNodeTest (XPath.TypeTest XPath.XPCommentNode))
						   else if happy_var_4 == "text" then CPathSlash happy_var_1 (CPathNodeTest (XPath.TypeTest XPath.XPTextNode)) 
						     else if happy_var_4 == "processing-instruction" then CPathSlash happy_var_1 (CPathNodeTest (XPath.TypeTest XPath.XPPINode))
                                                       else if happy_var_4 == "string" then CPathSlash happy_var_1 (CPathNodeTest (XPath.TypeTest XPString)) 
							     else parseError [(QError("XPath NodeTest wrong name()."))]
	) `HappyStk` happyRest

happyReduce_118 = happyReduce 7 34 happyReduction_118
happyReduction_118 (_ `HappyStk`
	(HappyTerminal (QString happy_var_6)) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_4)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_1) `HappyStk`
	happyRest)
	 = HappyAbsSyn34
		 (if happy_var_4 == "processing-instruction" then CPathSlash happy_var_1 (CPathNodeTest (XPath.PI happy_var_6))
                                                   else parseError [(QError("XPath NodeTest wrong processing-instruction(str)."))]
	) `HappyStk` happyRest

happyReduce_119 = happyReduce 4 34 happyReduction_119
happyReduction_119 ((HappyTerminal (QName happy_var_4)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn34  happy_var_1) `HappyStk`
	happyRest)
	 = HappyAbsSyn34
		 (CPathSlash happy_var_1 ((CPathNodeTest (XPath.NameTest (HXTQN.mkName happy_var_4))))
	) `HappyStk` happyRest

happyReduce_120 = happySpecReduce_2  34 happyReduction_120
happyReduction_120 (HappyTerminal (QName happy_var_2))
	_
	 =  HappyAbsSyn34
		 (CPathSlash (CPathSlash CPathSelf CPathAttribute) (CPathNodeTest (XPath.NameTest (HXTQN.mkName happy_var_2)))
	)
happyReduction_120 _ _  = notHappyAtAll 

happyReduce_121 = happySpecReduce_3  34 happyReduction_121
happyReduction_121 _
	_
	(HappyAbsSyn34  happy_var_1)
	 =  HappyAbsSyn34
		 (CPathSlash happy_var_1 (CPathSlash CPathChild (CPathNodeTest (XPath.TypeTest XPath.XPNode)))
	)
happyReduction_121 _ _ _  = notHappyAtAll 

happyReduce_122 = happySpecReduce_3  34 happyReduction_122
happyReduction_122 _
	_
	_
	 =  HappyAbsSyn34
		 (CPathSlash (CPathSlash CPathChild (CPathNodeTest (XPath.NameTest (HXTQN.mkName "if")))) (CPathSlash CPathChild (CPathNodeTest (XPath.TypeTest XPath.XPNode)))
	)

happyReduce_123 = happyReduce 4 34 happyReduction_123
happyReduction_123 (_ `HappyStk`
	(HappyAbsSyn10  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn34
		 (CPathFct happy_var_1 happy_var_3
	) `HappyStk` happyRest

happyReduce_124 = happySpecReduce_1  34 happyReduction_124
happyReduction_124 (HappyTerminal (QName happy_var_1))
	 =  HappyAbsSyn34
		 (CPathSlash (CPathSlash CPathSelf CPathChild) (CPathNodeTest (XPath.NameTest (HXTQN.mkName happy_var_1)))
	)
happyReduction_124 _  = notHappyAtAll 

happyReduce_125 = happySpecReduce_3  34 happyReduction_125
happyReduction_125 (HappyAbsSyn34  happy_var_3)
	_
	_
	 =  HappyAbsSyn34
		 (CPathSlash (CPathSlash CPathChild ((CPathNodeTest (XPath.NameTest (HXTQN.mkName "if"))))) happy_var_3
	)
happyReduction_125 _ _ _  = notHappyAtAll 

happyReduce_126 = happySpecReduce_3  34 happyReduction_126
happyReduction_126 _
	_
	(HappyAbsSyn34  happy_var_1)
	 =  HappyAbsSyn34
		 (CPathSlash  happy_var_1 (CPathSlash CPathChild (CPathNodeTest (XPath.NameTest (HXTQN.mkName "if"))))
	)
happyReduction_126 _ _ _  = notHappyAtAll 

happyReduce_127 = happySpecReduce_1  35 happyReduction_127
happyReduction_127 (HappyTerminal (QName happy_var_1))
	 =  HappyAbsSyn34
		 (if happy_var_1 == "self" then CPathSelf
                                                  else if happy_var_1 == "child" then CPathSlash CPathSelf CPathChild
						    else if happy_var_1 == "attribute" then (CPathSlash CPathSelf CPathAttribute)
                                                      else if happy_var_1 == "descendant-or-self" then CPathDoS
							else parseError [(QError("unsupported xpath axis."))]
	)
happyReduction_127 _  = notHappyAtAll 

happyReduce_128 = happySpecReduce_1  36 happyReduction_128
happyReduction_128 (HappyAbsSyn37  happy_var_1)
	 =  HappyAbsSyn36
		 ([happy_var_1]
	)
happyReduction_128 _  = notHappyAtAll 

happyReduce_129 = happySpecReduce_3  36 happyReduction_129
happyReduction_129 (HappyAbsSyn36  happy_var_3)
	_
	(HappyAbsSyn37  happy_var_1)
	 =  HappyAbsSyn36
		 ([happy_var_1] ++ happy_var_3
	)
happyReduction_129 _ _ _  = notHappyAtAll 

happyReduce_130 = happySpecReduce_3  36 happyReduction_130
happyReduction_130 (HappyAbsSyn36  happy_var_3)
	_
	(HappyAbsSyn39  happy_var_1)
	 =  HappyAbsSyn36
		 ([VarPat (VarTP happy_var_1)] ++ happy_var_3
	)
happyReduction_130 _ _ _  = notHappyAtAll 

happyReduce_131 = happyReduce 4 37 happyReduction_131
happyReduction_131 (_ `HappyStk`
	(HappyAbsSyn36  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn37
		 (ElementPat happy_var_1  happy_var_3
	) `HappyStk` happyRest

happyReduce_132 = happyReduce 5 37 happyReduction_132
happyReduction_132 (_ `HappyStk`
	(HappyAbsSyn38  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn37
		 (AttributePat happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_133 = happySpecReduce_1  37 happyReduction_133
happyReduction_133 (HappyAbsSyn38  happy_var_1)
	 =  HappyAbsSyn37
		 (VarPat     happy_var_1
	)
happyReduction_133 _  = notHappyAtAll 

happyReduce_134 = happySpecReduce_3  37 happyReduction_134
happyReduction_134 _
	(HappyAbsSyn36  happy_var_2)
	_
	 =  HappyAbsSyn37
		 (SequencePat happy_var_2
	)
happyReduction_134 _ _ _  = notHappyAtAll 

happyReduce_135 = happySpecReduce_3  38 happyReduction_135
happyReduction_135 (HappyAbsSyn39  happy_var_3)
	_
	(HappyTerminal (QVar happy_var_1))
	 =  HappyAbsSyn38
		 (VarT happy_var_1 happy_var_3
	)
happyReduction_135 _ _ _  = notHappyAtAll 

happyReduce_136 = happySpecReduce_1  38 happyReduction_136
happyReduction_136 (HappyTerminal (QVar happy_var_1))
	 =  HappyAbsSyn38
		 (VarV happy_var_1
	)
happyReduction_136 _  = notHappyAtAll 

happyReduce_137 = happySpecReduce_1  38 happyReduction_137
happyReduction_137 (HappyAbsSyn39  happy_var_1)
	 =  HappyAbsSyn38
		 (VarTP happy_var_1
	)
happyReduction_137 _  = notHappyAtAll 

happyReduce_138 = happySpecReduce_3  39 happyReduction_138
happyReduction_138 (HappyTerminal (QName happy_var_3))
	_
	(HappyTerminal (QName happy_var_1))
	 =  HappyAbsSyn39
		 (NameT (happy_var_1 ++ ":" ++ happy_var_3)
	)
happyReduction_138 _ _ _  = notHappyAtAll 

happyReduce_139 = happySpecReduce_3  39 happyReduction_139
happyReduction_139 _
	_
	(HappyTerminal (QName happy_var_1))
	 =  HappyAbsSyn39
		 (NameT (happy_var_1 ++ ":if"  )
	)
happyReduction_139 _ _ _  = notHappyAtAll 

happyReduce_140 = happySpecReduce_1  39 happyReduction_140
happyReduction_140 (HappyTerminal (QTName happy_var_1))
	 =  HappyAbsSyn39
		 (if happy_var_1 == "String" then StringT else NameT happy_var_1
	)
happyReduction_140 _  = notHappyAtAll 

happyReduce_141 = happySpecReduce_2  39 happyReduction_141
happyReduction_141 _
	(HappyAbsSyn39  happy_var_1)
	 =  HappyAbsSyn39
		 (StarT happy_var_1
	)
happyReduction_141 _ _  = notHappyAtAll 

happyReduce_142 = happySpecReduce_3  39 happyReduction_142
happyReduction_142 (HappyAbsSyn39  happy_var_3)
	_
	(HappyAbsSyn39  happy_var_1)
	 =  HappyAbsSyn39
		 (ChoiceT happy_var_1 happy_var_3
	)
happyReduction_142 _ _ _  = notHappyAtAll 

happyReduce_143 = happySpecReduce_3  39 happyReduction_143
happyReduction_143 _
	(HappyAbsSyn39  happy_var_2)
	_
	 =  HappyAbsSyn39
		 (happy_var_2
	)
happyReduction_143 _ _ _  = notHappyAtAll 

happyReduce_144 = happyReduce 5 39 happyReduction_144
happyReduction_144 (_ `HappyStk`
	(HappyAbsSyn39  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn39  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn39
		 (SequenceT happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_145 = happySpecReduce_2  39 happyReduction_145
happyReduction_145 _
	_
	 =  HappyAbsSyn39
		 (EmptyT
	)

happyReduce_146 = happyReduce 4 39 happyReduction_146
happyReduction_146 (_ `HappyStk`
	(HappyAbsSyn39  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn39
		 (ElementT happy_var_1 happy_var_3
	) `HappyStk` happyRest

happyReduce_147 = happyReduce 4 39 happyReduction_147
happyReduction_147 (_ `HappyStk`
	(HappyAbsSyn39  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn39
		 (ElementT "if" happy_var_3
	) `HappyStk` happyRest

happyReduce_148 = happyReduce 5 39 happyReduction_148
happyReduction_148 (_ `HappyStk`
	(HappyAbsSyn39  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn39
		 (AttributeT happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_149 = happySpecReduce_2  39 happyReduction_149
happyReduction_149 _
	(HappyAbsSyn39  happy_var_1)
	 =  HappyAbsSyn39
		 (ChoiceT happy_var_1 EmptyT
	)
happyReduction_149 _ _  = notHappyAtAll 

happyReduce_150 = happySpecReduce_2  39 happyReduction_150
happyReduction_150 _
	(HappyAbsSyn39  happy_var_1)
	 =  HappyAbsSyn39
		 (SequenceT happy_var_1 (StarT happy_var_1)
	)
happyReduction_150 _ _  = notHappyAtAll 

happyNewToken action sts stk [] =
	action 112 112 notHappyAtAll (HappyState action) sts stk []

happyNewToken action sts stk (tk:tks) =
	let cont i = action i i tk (HappyState action) sts stk tks in
	case tk of {
	IMPORT -> cont 40;
	TYPE -> cont 41;
	START -> cont 42;
	DOC -> cont 43;
	PROCEDURE -> cont 44;
	UPDATE -> cont 45;
	BY -> cont 46;
	FOR -> cont 47;
	VIEW -> cont 48;
	MATCHING -> cont 49;
	SOURCE -> cont 50;
	INSERT -> cont 51;
	BEFORE -> cont 52;
	AFTER -> cont 53;
	VALUE -> cont 54;
	AS -> cont 55;
	LAST -> cont 56;
	FIRST -> cont 57;
	INTO -> cont 58;
	DELETE -> cont 59;
	FROM -> cont 60;
	REPLACE -> cont 61;
	WITH -> cont 62;
	CREATE -> cont 63;
	KEEP -> cont 64;
	EITHER -> cont 65;
	MATCH -> cont 66;
	UNMATCHV -> cont 67;
	UNMATCHS -> cont 68;
	ARROW -> cont 69;
	CASE -> cont 70;
	OF -> cont 71;
	WHERE -> cont 72;
	IF -> cont 73;
	THEN -> cont 74;
	ELSE -> cont 75;
	LET -> cont 76;
	ASSIGN -> cont 77;
	IN -> cont 78;
	STAG -> cont 79;
	ETAG -> cont 80;
	ATSIGN -> cont 81;
	TLT -> cont 82;
	TGT -> cont 83;
	LSB -> cont 84;
	RSB -> cont 85;
	LP -> cont 86;
	RP -> cont 87;
	LB -> cont 88;
	RB -> cont 89;
	QEQ -> cont 90;
	STAR -> cont 91;
	OPT -> cont 92;
	PLUS -> cont 93;
	COMMA -> cont 94;
	COLON -> cont 95;
	SEMI -> cont 96;
	QDSLASH -> cont 97;
	QSLASH -> cont 98;
	QDOT -> cont 99;
	QEMark -> cont 100;
	QMinus -> cont 101;
	QName happy_dollar_dollar -> cont 102;
	QString happy_dollar_dollar -> cont 103;
	QXmlText happy_dollar_dollar -> cont 104;
	QTName happy_dollar_dollar -> cont 105;
	QVar happy_dollar_dollar -> cont 106;
	QReturn -> cont 107;
	QTrue -> cont 108;
	QFalse -> cont 109;
	TST -> cont 110;
	TET -> cont 111;
	_ -> happyError' (tk:tks)
	}

happyError_ 112 tk tks = happyError' tks
happyError_ _ tk tks = happyError' (tk:tks)

newtype HappyIdentity a = HappyIdentity a
happyIdentity = HappyIdentity
happyRunIdentity (HappyIdentity a) = a

instance Monad HappyIdentity where
    return = HappyIdentity
    (HappyIdentity p) >>= q = q p

happyThen :: () => HappyIdentity a -> (a -> HappyIdentity b) -> HappyIdentity b
happyThen = (>>=)
happyReturn :: () => a -> HappyIdentity a
happyReturn = (return)
happyThen1 m k tks = (>>=) m (\a -> k a tks)
happyReturn1 :: () => a -> b -> HappyIdentity a
happyReturn1 = \a tks -> (return) a
happyError' :: () => [(Token)] -> HappyIdentity a
happyError' = HappyIdentity . parseError

nParser tks = happyRunIdentity happySomeParser where
  happySomeParser = happyThen (happyParse action_0 tks) (\x -> case x of {HappyAbsSyn4 z -> happyReturn z; _other -> notHappyAtAll })

happySeq = happyDontSeq


parseError tk = error(
 case tk of
  ((QError s) : _) -> "Parse error: " ++ s
  (TokenEOF: _)    -> "Parse error:  Unexpected end of file"
  _                -> "Parse error: " ++ (foldr (\a r -> (show a)++ " "  ++ r ) "" (take 10 tk))

		      )
{-# LINE 1 "templates/GenericTemplate.hs" #-}
{-# LINE 1 "templates/GenericTemplate.hs" #-}
{-# LINE 1 "<command-line>" #-}
{-# LINE 1 "templates/GenericTemplate.hs" #-}
-- Id: GenericTemplate.hs,v 1.26 2005/01/14 14:47:22 simonmar Exp 

{-# LINE 30 "templates/GenericTemplate.hs" #-}








{-# LINE 51 "templates/GenericTemplate.hs" #-}

{-# LINE 61 "templates/GenericTemplate.hs" #-}

{-# LINE 70 "templates/GenericTemplate.hs" #-}

infixr 9 `HappyStk`
data HappyStk a = HappyStk a (HappyStk a)

-----------------------------------------------------------------------------
-- starting the parse

happyParse start_state = happyNewToken start_state notHappyAtAll notHappyAtAll

-----------------------------------------------------------------------------
-- Accepting the parse

-- If the current token is (1), it means we've just accepted a partial
-- parse (a %partial parser).  We must ignore the saved token on the top of
-- the stack in this case.
happyAccept (1) tk st sts (_ `HappyStk` ans `HappyStk` _) =
	happyReturn1 ans
happyAccept j tk st sts (HappyStk ans _) = 
	 (happyReturn1 ans)

-----------------------------------------------------------------------------
-- Arrays only: do the next action

{-# LINE 148 "templates/GenericTemplate.hs" #-}

-----------------------------------------------------------------------------
-- HappyState data type (not arrays)



newtype HappyState b c = HappyState
        (Int ->                    -- token number
         Int ->                    -- token number (yes, again)
         b ->                           -- token semantic value
         HappyState b c ->              -- current state
         [HappyState b c] ->            -- state stack
         c)



-----------------------------------------------------------------------------
-- Shifting a token

happyShift new_state (1) tk st sts stk@(x `HappyStk` _) =
     let (i) = (case x of { HappyErrorToken (i) -> i }) in
--     trace "shifting the error token" $
     new_state i i tk (HappyState (new_state)) ((st):(sts)) (stk)

happyShift new_state i tk st sts stk =
     happyNewToken new_state ((st):(sts)) ((HappyTerminal (tk))`HappyStk`stk)

-- happyReduce is specialised for the common cases.

happySpecReduce_0 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_0 nt fn j tk st@((HappyState (action))) sts stk
     = action nt j tk st ((st):(sts)) (fn `HappyStk` stk)

happySpecReduce_1 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_1 nt fn j tk _ sts@(((st@(HappyState (action))):(_))) (v1`HappyStk`stk')
     = let r = fn v1 in
       happySeq r (action nt j tk st sts (r `HappyStk` stk'))

happySpecReduce_2 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_2 nt fn j tk _ ((_):(sts@(((st@(HappyState (action))):(_))))) (v1`HappyStk`v2`HappyStk`stk')
     = let r = fn v1 v2 in
       happySeq r (action nt j tk st sts (r `HappyStk` stk'))

happySpecReduce_3 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_3 nt fn j tk _ ((_):(((_):(sts@(((st@(HappyState (action))):(_))))))) (v1`HappyStk`v2`HappyStk`v3`HappyStk`stk')
     = let r = fn v1 v2 v3 in
       happySeq r (action nt j tk st sts (r `HappyStk` stk'))

happyReduce k i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happyReduce k nt fn j tk st sts stk
     = case happyDrop (k - ((1) :: Int)) sts of
	 sts1@(((st1@(HappyState (action))):(_))) ->
        	let r = fn stk in  -- it doesn't hurt to always seq here...
       		happyDoSeq r (action nt j tk st1 sts1 r)

happyMonadReduce k nt fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happyMonadReduce k nt fn j tk st sts stk =
        happyThen1 (fn stk tk) (\r -> action nt j tk st1 sts1 (r `HappyStk` drop_stk))
       where (sts1@(((st1@(HappyState (action))):(_)))) = happyDrop k ((st):(sts))
             drop_stk = happyDropStk k stk

happyMonad2Reduce k nt fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happyMonad2Reduce k nt fn j tk st sts stk =
       happyThen1 (fn stk tk) (\r -> happyNewToken new_state sts1 (r `HappyStk` drop_stk))
       where (sts1@(((st1@(HappyState (action))):(_)))) = happyDrop k ((st):(sts))
             drop_stk = happyDropStk k stk





             new_state = action


happyDrop (0) l = l
happyDrop n ((_):(t)) = happyDrop (n - ((1) :: Int)) t

happyDropStk (0) l = l
happyDropStk n (x `HappyStk` xs) = happyDropStk (n - ((1)::Int)) xs

-----------------------------------------------------------------------------
-- Moving to a new state after a reduction

{-# LINE 246 "templates/GenericTemplate.hs" #-}
happyGoto action j tk st = action j j tk (HappyState action)


-----------------------------------------------------------------------------
-- Error recovery ((1) is the error token)

-- parse error if we are in recovery and we fail again
happyFail (1) tk old_st _ stk@(x `HappyStk` _) =
     let (i) = (case x of { HappyErrorToken (i) -> i }) in
--	trace "failing" $ 
        happyError_ i tk

{-  We don't need state discarding for our restricted implementation of
    "error".  In fact, it can cause some bogus parses, so I've disabled it
    for now --SDM

-- discard a state
happyFail  (1) tk old_st (((HappyState (action))):(sts)) 
						(saved_tok `HappyStk` _ `HappyStk` stk) =
--	trace ("discarding state, depth " ++ show (length stk))  $
	action (1) (1) tk (HappyState (action)) sts ((saved_tok`HappyStk`stk))
-}

-- Enter error recovery: generate an error token,
--                       save the old token and carry on.
happyFail  i tk (HappyState (action)) sts stk =
--      trace "entering error recovery" $
	action (1) (1) tk (HappyState (action)) sts ( (HappyErrorToken (i)) `HappyStk` stk)

-- Internal happy errors:

notHappyAtAll :: a
notHappyAtAll = error "Internal Happy error\n"

-----------------------------------------------------------------------------
-- Hack to get the typechecker to accept our action functions







-----------------------------------------------------------------------------
-- Seq-ing.  If the --strict flag is given, then Happy emits 
--	happySeq = happyDoSeq
-- otherwise it emits
-- 	happySeq = happyDontSeq

happyDoSeq, happyDontSeq :: a -> b -> b
happyDoSeq   a b = a `seq` b
happyDontSeq a b = b

-----------------------------------------------------------------------------
-- Don't inline any functions from the template.  GHC has a nasty habit
-- of deciding to inline happyGoto everywhere, which increases the size of
-- the generated parser quite a bit.

{-# LINE 312 "templates/GenericTemplate.hs" #-}
{-# NOINLINE happyShift #-}
{-# NOINLINE happySpecReduce_0 #-}
{-# NOINLINE happySpecReduce_1 #-}
{-# NOINLINE happySpecReduce_2 #-}
{-# NOINLINE happySpecReduce_3 #-}
{-# NOINLINE happyReduce #-}
{-# NOINLINE happyMonadReduce #-}
{-# NOINLINE happyGoto #-}
{-# NOINLINE happyFail #-}

-- end of Happy Template.
