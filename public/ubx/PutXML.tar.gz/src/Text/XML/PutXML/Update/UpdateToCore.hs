module Text.XML.PutXML.Update.UpdateToCore where

import Text.XML.PutXML.Update.AST
import Text.XML.PutXML.Update.CoreAST
import Data.Set (Set(..))
import qualified Data.Set as Set
import Data.Map (Map(..))
import Data.List as List
import qualified Data.Map as Map
import Control.Monad
import Control.Monad.State (State,MonadState,StateT)
import qualified Control.Monad.State as State
import Control.Monad.Identity
import Control.Monad.Reader (Reader(..),MonadReader(..),ReaderT(..))
import qualified Control.Monad.Reader as Reader
import Control.Monad.Trans
import Text.XML.PutXML.XQuery.UXQ
import Text.XML.PutXML.DTD.Type
import Safe
import Data.Maybe
import Text.XML.PutXML.Update.Patterns

import Debug.Trace

type ProcsVars = Map String [ProcVar] -- procedure arguments to use in procedure calls

type ThreeVars = (Set Var,Set Var,Set Var) -- (source variables,view variables,environment variables)
type CoreM m = ReaderT TypeEnv (StateT ProcsVars (ReaderT ThreeVars m))

type RuleM m = ReaderT TypeEnv (StateT ProcsVars (ReaderT (Set Var) m))

program2core :: MonadPlus m => TypeEnv -> Program -> m CProgram
program2core tenv (Program _ _ (Start startname startargs) decls) = do
	let procsvars = Map.fromList (map procedureArgVars procedures)
	    env = (Set.singleton "source",Set.singleton "view",Set.fromList ["source","view"])
	Reader.runReaderT (State.evalStateT (Reader.runReaderT aux tenv) procsvars) env
  where aux = do
			CStmtProc name sargs vargs eargs <- procedureCall2core startname startargs
			cprocedures <- mapM procedure2core procedures
			return $ CProgram (CStart name sargs vargs eargs) cprocedures
        procedures = procedureDecls decls

procedure2core :: MonadPlus m => Procedure -> CoreM m CProcedure
procedure2core (Procedure name args stmts) = resetViewFocus $ delViewFocus (Set.singleton ".") $ resetSourceFocus $ addSourceEnvFocus snames $ addViewEnvFocus vnames $ addEnvFocus enames $ do
	if not (stmtsRelativeSourcePaths stmts)
		then do
			cstmt <- stmts2core stmts
			tenv <- ask
			svars <- liftM prodVariables $ mapM (\(v,t) -> inferAstType tenv t >>= \dt -> return (v,dt)) sargs
			vvars <- liftM prodVariables $ mapM (\(v,t) -> inferAstType tenv t >>= \dt -> return (v,dt)) vargs
			evars <- mapM (\(v,t) -> inferAstType tenv t >>= \dt -> return (v,dt)) eargs
			return $ CProcedure name svars vvars evars cstmt
		else error "cannot use relative source paths in procedures (all top-level updates)"
  where (sargs,vargs,eargs) = splitProcVars args
        (snames,vnames,enames) = (Set.fromList $ map fst sargs,Set.fromList $ map fst vargs,Set.fromList $ map fst eargs)

stmts2core :: MonadPlus m => [Stmt] -> CoreM m CStmt
stmts2core [] = emptyView >>= \b -> if b
	then return CStmtSkip
	else do
		(svars,vvars,evars) <- lift ask
		error $ "view variables " ++ show vvars ++ " unused"
stmts2core [stmt] = stmt2core stmt
stmts2core (stmt:stmts) = do
	(svars,vvars,evars) <- lift ask
	let vs1 = Set.intersection vvars (stmtVars stmt)
	    vs2 = Set.intersection vvars (stmtsVars stmts)
	cstmt1 <- changeViewFocus vs1 (stmt2core stmt)
	cstmt2 <- changeViewFocus vs2 (stmts2core stmts)
	return $ CStmtComp cstmt1 vs1 cstmt2 vs2

splitWhereConds :: MonadPlus m => [WhereCond] -> CoreM m (Maybe BoolExpr,Maybe BoolExpr,[(Var,XQExpr)])
splitWhereConds conds = lift ask >>= \(svars,vvars,evars) -> do
	let (wheres,binds) = splitWheres conds
	    (sconds,conds') = partition (\c -> uXQVars c `Set.isSubsetOf` svars) wheres
	    (vconds,rest) = partition (\c -> not (isRelativeExpr c) && uXQVars c `Set.isSubsetOf` vvars) conds'
	    (vbinds,rest2) = partition (\(v,e) -> not (isRelativeExpr e) && Set.insert v (uXQVars e) `Set.isSubsetOf` vvars) binds
	if null rest && null rest2
		then return (mbConds sconds,mbConds vconds,vbinds)
		else error $ "unsupported conditions: " ++ show rest ++ "\n" ++ show rest2 ++ "\n"++show vvars

mbConds :: [BoolExpr] -> Maybe BoolExpr
mbConds [] = Nothing
mbConds xs = Just (andExpr xs)

stmt2core :: MonadPlus m => Stmt -> CoreM m CStmt
stmt2core (StmtUpd upd conds) = upd2core upd conds
	--splitWhereConds conds >>= \(wheres,wherev,bindv) -> upd2core upd (andExpr wheres) (andExpr wherev) bindv
stmt2core (StmtIF cond stmt1 stmt2) = if2core cond stmt1 stmt2
stmt2core (StmtLet pat expr stmts) = let2core pat expr stmts
stmt2core (StmtP name args) = procedureCall2core name args
stmt2core (StmtCase expr cs) = case2core expr cs

-- we need to keep resetting the source environment as the updates (like replace,update) change the focus
upd2core :: MonadPlus m => Upd -> [WhereCond] -> CoreM m CStmt
upd2core u@(SingleInsertion loc pat path expr) conds = error "insertion not supported as a bidirectional statement"
upd2core u@(PluralInsertion loc pat path expr) conds = error "insertion not supported as a bidirectional statement"
upd2core u@(SingleDeletion pat path) conds = guardEmptyView $ do
	(ps,cstmt) <- resetSourceFocus $ updSourcePat pat rule
	return $ CStmtPathS (updSourceWhere path pat ps) cstmt
  where rule :: MonadPlus m => CoreM m (Maybe XQExpr,CStmt)
        rule = do
        	(ps,pv,bv) <- splitWhereConds conds
        	cstmt <- return CStmtReplace
        	return (ps,cstmt)     
upd2core u@(PluralDeletion pat path) conds = guardEmptyView $ do
	(ps,cstmt) <- resetSourceFocus $ updSourcePat pat rule
	return $ CStmtPathS (updSourceWhere path pat ps) cstmt
  where rule :: MonadPlus m => CoreM m (Maybe XQExpr,CStmt)
        rule = do
        	(ps,pv,bv) <- splitWhereConds conds
        	cstmt <- return $ CStmtPathS CPathChild CStmtReplace
        	return (ps,cstmt)     
upd2core u@(SingleReplace pat path expr) conds = do
	(ps,cstmt) <- resetSourceFocus $ updSourcePat pat rule
	return $ CStmtPathS (updSourceWhere path pat ps) $ CStmtIter cstmt
  where rule :: MonadPlus m => CoreM m (Maybe XQExpr,CStmt)
        rule = do
        	(ps,pv,bv) <- splitWhereConds conds
        	cstmt <- updViewWhere pv $ updViewBind bv $ return $ CStmtExprV expr CStmtReplace
        	return (ps,cstmt)      	
upd2core u@(PluralReplace pat path expr) conds = do
	(ps,cstmt) <- resetSourceFocus $ updSourcePat pat rule
	return $ CStmtPathS (updSourceWhere path pat ps) $ CStmtIter cstmt
  where rule :: MonadPlus m => CoreM m (Maybe XQExpr,CStmt)
        rule = do
        	(ps,pv,bv) <- splitWhereConds conds
        	cstmt <- updViewWhere pv $ updViewBind bv $ return $ CStmtPathS CPathChild $ CStmtExprV expr CStmtReplace
        	return (ps,cstmt)
upd2core u@(UpdateSource pat path stmts) conds = do
	(ps,cstmt) <- resetSourceFocus $ updSourcePat pat rule
	return $ CStmtPathS (updSourceWhere path pat ps) $ CStmtIter cstmt
  where rule :: MonadPlus m => CoreM m (Maybe XQExpr,CStmt)
        rule = do
        	(ps,pv,bv) <- splitWhereConds conds
        	cstmt <- updViewWhere pv $ updViewBind bv $ stmts2core stmts
        	return (ps,cstmt)
upd2core (UpdateView spat spath vstmts vpat vpath Nothing) conds = do
	let (msv,umv,ums) = updViewStmts vstmts
	crule <- updCreate2core vpat umv
	crecover <- updRecover2core spat ums
	(ps,cstmt) <- resetViewFocus $ resetSourceFocus $ updSourcePat spat $ updViewPat vpat $ rule msv
	return $ CStmtPathS spath $ CStmtExprV (XQPath vpath) $ CStmtAlign (sourceExpr spat ps) Nothing cstmt crule crecover
  where rule :: MonadPlus m => Stmts -> CoreM m (Maybe XQExpr,CStmt)
        rule msv = do
        	(ps,pv,bv) <- splitWhereConds conds
        	cstmt <- updViewWhere pv $ updViewBind bv $ stmts2core msv
        	return (ps,cstmt)
upd2core (UpdateView spat spath vstmts vpat vpath (Just matchcond)) conds = do
	let (msv,umv,ums) = updViewStmts vstmts
	    (matchs,matchv) = matchcondPaths matchcond
	patmatchs <- matchexpr2core spat matchs
	patmatchv <- matchexpr2core vpat matchv
	crule <- updCreate2core vpat umv
	crecover <- updRecover2core spat ums
	(ps,cstmt) <- resetViewFocus $ resetSourceFocus $ updSourcePat spat $ updViewPat vpat $ rule msv matchs matchv
	return $ CStmtPathS spath $ CStmtExprV (XQPath vpath) $ CStmtAlign (sourceExpr spat ps) (Just (patmatchs,patmatchv)) cstmt crule crecover
  where rule :: MonadPlus m => Stmts -> CPath -> CPath -> CoreM m (Maybe XQExpr,CStmt)
        rule msv matchs matchv = do
        	(ps,pv,bv) <- splitWhereConds conds
        	cstmt <- updViewWhere pv $ updViewBind bv $ matchReplace matchs matchv msv
        	return (ps,cstmt)
upd2core (UpdateKeep path) conds = error "keep not supported outside unmatchs"
upd2core (UpdateCreate expr) conds = error "create not supported outside unmatchv"

sourceExpr :: Maybe Pat -> Maybe XQExpr -> XQExpr
sourceExpr pat Nothing = andExpr []
sourceExpr Nothing (Just expr) = expr
sourceExpr (Just pat) (Just expr) = XQLet pat (XQPath CPathSelf) expr

matchcondPaths :: MatchCond -> (CPath,CPath)
matchcondPaths (MatchBY path) = (path,path)
matchcondPaths (MatchSV spath vpath) = (spath,vpath)

-- if the update will fail because it does not embed all view variables, add a default replace using the match conditions (what may also fail anyway)
matchReplace :: MonadPlus m => CPath -> CPath -> Stmts -> CoreM m CStmt
matchReplace spath vpath stmts = lift ask >>= \(svars,vvars,evars) -> do
	if vvars `Set.isSubsetOf` stmtsVars stmts
		then stmts2core stmts -- if all variables are embedded, do nothing
		else do
			let vpath' = relativeToRootedPath (Set.toList vvars) vpath
			(delViewFocus (cpathVars vpath') $ stmts2core stmts) >>= \cstmt -> return $ CStmtComp cstmt (stmtsVars stmts) (CStmtPathS spath $ CStmtExprV (XQPath vpath') CStmtReplace) (vvars `Set.difference` stmtsVars stmts)

relativeToRootedPath :: [Var] -> CPath -> CPath
relativeToRootedPath [var] path@(isRelativeCPath -> True) = rootCPath var path
relativeToRootedPath vars path@(isRelativeCPath -> True) = error "multiple view variables"
relativeToRootedPath vars path@(isRelativeCPath -> False) = path

matchexpr2core :: MonadPlus m => Maybe Pat -> CPath -> CoreM m CPath
matchexpr2core Nothing path = return path
matchexpr2core (Just pat) path = return $ CPathSnapshot pat path

updCreate2core :: MonadPlus m => Maybe Pat -> Maybe Stmts -> CoreM m (Maybe CRule)
updCreate2core vpat Nothing = return Nothing
updCreate2core vpat (Just stmts) = liftM (Just . CRuleComp CRuleDelete) $ createViewPat vpat $ runRuleM $ updCreate2rule stmts

-- for unmathcv statements, create must appear at the head (create start from an empty input, therefore insert)
updCreate2rule :: MonadPlus m => Stmts -> RuleM m CRule
updCreate2rule [StmtIF cond stmt1 stmt2] = if2rule cond (updCreate2rule stmt1) (updCreate2rule stmt2)
updCreate2rule [StmtLet pat expr stmt] = let2rule pat expr (updCreate2rule stmt)
updCreate2rule [StmtCase expr cs] = case2rule expr $ map (\(pat,stmt) -> (pat,updCreate2rule stmt)) cs
updCreate2rule (StmtUpd (UpdateCreate expr) []:stmts) = liftM (CRuleComp (CRuleInsert expr)) (stmts2rule stmts)
updCreate2rule _ = error "unmatchv structure must start with a create (without where conditions)"

createViewPat :: MonadPlus m => Maybe Pat -> CoreM m CRule -> CoreM m CRule
createViewPat Nothing m = m
createViewPat (Just pat) m = m >>= \crule -> return $ CRuleCase (XQPath $ CPathVar ".") [(pat,crule)]

updRecover2core :: MonadPlus m => Maybe Pat -> Maybe Stmts -> CoreM m CRecover
updRecover2core spat Nothing = return CRecoverDeleteSource -- the default option when no recover is declared
updRecover2core spat (Just stmts) = recoverSourcePat spat $ runRuleM $ recover2rule stmts

recover2rule :: MonadPlus m => Stmts -> RuleM m CRecover
recover2rule [StmtIF cond stmt1 stmt2] = do
	crv1 <- recover2rule stmt1
	crv2 <- recover2rule stmt2
	return $ CRecoverIf cond crv1 crv2
recover2rule [StmtLet pat expr stmt] = recover2rule [StmtCase expr [(pat,stmt)]]
recover2rule [StmtCase expr cs] = liftM (CRecoverCase expr) (mapM (\(pat,stmt) -> recover2rule stmt >>= \cr -> return (pat,cr)) cs)
recover2rule (StmtUpd (UpdateKeep CPathSelf) []:stmts) = do
	crule <- stmts2rule stmts
	return $ CRecoverKeepSource crule
recover2rule [StmtUpd (SingleDeletion Nothing CPathSelf) []] = return CRecoverDeleteSource
recover2rule _ = error "unmatchs structure must start with keep/delete . (without where conditions)"

recoverSourcePat :: MonadPlus m => Maybe Pat -> CoreM m CRecover -> CoreM m CRecover
recoverSourcePat Nothing m = m
recoverSourcePat (Just pat) m = m >>= \crecover -> return $ CRecoverCase (XQPath CPathSelf) [(pat,crecover)]

-- generates (match,unmatchv,unmatchs) statements from a list of view statements
updViewStmts :: ViewStmts -> (Stmts,Maybe Stmts,Maybe Stmts)
updViewStmts vstmts = (msv,umv,ums)
	where (msvs,umvs,umss) = splitViewStmts vstmts
	      msv = if length msvs > 1 then error "multiple match conditions" else maybe [] id (headMay msvs)
	      umv = if length umvs > 1 then error "multiple unmatchv conditions" else headMay umvs
	      ums = if length umss > 1 then error "multiple unmatchs conditions" else headMay umss
			
updSourceWhere :: CPath -> Maybe Pat -> Maybe BoolExpr -> CPath
updSourceWhere cpath _ Nothing = cpath
updSourceWhere cpath Nothing (Just ps) = CPathSlash cpath $ CPathFilter ps
updSourceWhere cpath (Just pat) (Just ps) = CPathSlash cpath $ CPathSnapshot pat $ CPathFilter ps

updSourcePat :: MonadPlus m => Maybe Pat -> CoreM m (a,CStmt) -> CoreM m (a,CStmt)
updSourcePat Nothing m = m
updSourcePat (Just pat) m = addSourceEnvFocus (patVars pat) $ m >>= \(a,cstmt) -> return (a,CStmtCaseS CPathSelf [(pat,cstmt)])

updViewWhere :: MonadPlus m => Maybe BoolExpr -> CoreM m CStmt -> CoreM m CStmt
updViewWhere Nothing m = m
updViewWhere (Just pv) m = m >>= \cstmt -> return $ CStmtIfV pv cstmt CStmtFail

updViewPat :: MonadPlus m => Maybe Pat -> CoreM m (a,CStmt) -> CoreM m (a,CStmt)
updViewPat Nothing m = m
updViewPat (Just pat) m = delViewFocus (Set.singleton ".") $ addViewEnvFocus (patVars pat) $ m >>= \(a,cstmt) -> return (a,CStmtCaseV (XQPath $ CPathVar ".") [(pat,cstmt)])

updViewBind :: MonadPlus m => [(Var,XQExpr)] -> CoreM m CStmt -> CoreM m CStmt
updViewBind [] m = m
updViewBind ((v,e):bs) m = delViewFocus (Set.singleton v) $ updViewBind bs m >>= \stmt -> return $ CStmtBindV v e stmt

if2core :: MonadPlus m => XQExpr -> Stmts -> Stmts -> CoreM m CStmt
if2core e stmt1 stmt2 = lift ask >>= \(svars,vvars,evars) -> do
	cstmt1 <- stmts2core stmt1
	cstmt2 <- stmts2core stmt2
	if (uXQVars e `Set.isSubsetOf` svars)
		then return (CStmtIfS e cstmt1 cstmt2)
		else if (not (isRelativeExpr e) && uXQVars e `Set.isSubsetOf` vvars)
			then return (CStmtIfV e cstmt1 cstmt2)
			else if (uXQVars e `Set.isSubsetOf` evars)
				then return (CStmtIf e cstmt1 cstmt2)
				else error "not defined variables for if expression"
	
let2core :: MonadPlus m => Pat -> XQExpr -> Stmts -> CoreM m CStmt
let2core pat expr stmts = case2core expr [(pat,stmts)]

procedureCall2core :: MonadPlus m => Name -> [XQExpr] -> CoreM m CStmt
procedureCall2core name args = do
	procs <- State.get
	case Map.lookup name procs of
		Just pvars -> do
			if (length pvars == length args)
				then do
					let (sargs,vargs,eargs) = splitProcVars (zip pvars args)
					sargs' <- mapM (procedureCallSource2core . snd) sargs
					vargs' <- mapM (procedureCallView2core . snd) vargs
					eargs' <- mapM (procedureCallEnv2core . snd) eargs
					return $ CStmtProc name sargs' vargs' eargs'
				else error "procedure call with wrong number of elements"
		Nothing -> error $ "procedure not found " ++ name

procedureCallSource2core :: MonadPlus m => XQExpr -> CoreM m CPath
procedureCallSource2core (XQPath path) = lift ask >>= \(svars,vvars,evars) -> do
	if (cpathVars path `Set.isSubsetOf` svars)
		then return path
		else error "path not a source path"
procedureCallSource2core e = error "expression not a source path"

procedureCallView2core :: MonadPlus m => XQExpr -> CoreM m XQExpr
procedureCallView2core expr = lift ask >>= \(svars,vvars,evars) -> do
	if (not (isRelativeExpr expr) && uXQVars expr `Set.isSubsetOf` vvars)
		then return expr
		else error "expression not a view expression"

procedureCallEnv2core :: MonadPlus m => XQExpr -> CoreM m XQExpr
procedureCallEnv2core expr = lift ask >>= \(svars,vvars,evars) -> do
	if (uXQVars expr `Set.isSubsetOf` evars)
		then return expr
		else error "expression not an environment expression"

case2core :: MonadPlus m => XQExpr -> [(Pat,Stmts)] -> CoreM m CStmt
case2core expr@(isPathExpr -> Just path) cs = lift ask >>= \(svars,vvars,evars) -> do
	if cpathVars path `Set.isSubsetOf` svars
		then caseS2core path cs
	else if not (isRelativeExpr expr) && uXQVars expr `Set.isSubsetOf` vvars
		then caseV2core expr cs
		else if uXQVars expr `Set.isSubsetOf` evars
			then caseE2core expr cs
			else error "not defined variables for case expression"
case2core expr cs = lift ask >>= \(svars,vvars,evars) -> do
	if not (isRelativeExpr expr) && uXQVars expr `Set.isSubsetOf` vvars
		then caseV2core expr cs
		else if uXQVars expr `Set.isSubsetOf` evars
			then caseE2core expr cs
			else error "not defined variables for case expression"

caseS2core :: MonadPlus m => CPath -> [(Pat,Stmts)] -> CoreM m CStmt
caseS2core path cs = liftM (CStmtCaseS path) (mapM caseSStmt2core cs)

caseSStmt2core :: MonadPlus m => (Pat,Stmts) -> CoreM m (Pat,CStmt)
caseSStmt2core (pat,stmts) = addSourceEnvFocus (patVars pat) (stmts2core stmts >>= \cstmt -> return (pat,cstmt))

caseV2core :: MonadPlus m => XQExpr -> [(Pat,Stmts)] -> CoreM m CStmt
caseV2core expr cs = delViewFocus (Set.insert "." $ uXQVars expr) $ liftM (CStmtCaseV expr) (mapM caseVStmt2core cs)

caseVStmt2core :: MonadPlus m => (Pat,Stmts) -> CoreM m (Pat,CStmt)
caseVStmt2core (pat,stmts) = addViewEnvFocus (patVars pat) (stmts2core stmts >>= \cstmt -> return (pat,cstmt))

caseE2core :: MonadPlus m => XQExpr -> [(Pat,Stmts)] -> CoreM m CStmt
caseE2core expr cs = liftM (CStmtCase expr) (mapM caseEStmt2core cs)

caseEStmt2core :: MonadPlus m => (Pat,Stmts) -> CoreM m (Pat,CStmt)
caseEStmt2core (pat,stmts) = addEnvFocus (patVars pat) (stmts2core stmts >>= \cstmt -> return (pat,cstmt))

stmts2rule :: MonadPlus m => Stmts -> RuleM m CRule
stmts2rule [] = return CRuleSkip
stmts2rule [stmt] = stmt2rule stmt
stmts2rule (stmt:stmts) = do
	crule1 <- stmt2rule stmt
	crule2 <- stmts2rule stmts
	return $ CRuleComp crule1 crule2

stmt2rule :: MonadPlus m => Stmt -> RuleM m CRule
stmt2rule (StmtUpd upd conds) = upd2rule upd (whereConds conds)
stmt2rule (StmtIF cond stmt1 stmt2) = if2rule cond (stmts2rule stmt1) (stmts2rule stmt2)
stmt2rule (StmtLet pat expr stmt) = let2rule pat expr (stmts2rule stmt)
stmt2rule (StmtP name args) = error "procedures unsupported as rewrite rules"
stmt2rule (StmtCase expr cs) = case2rule expr $ map (\(pat,stmt) -> (pat,stmts2rule stmt)) cs

if2rule :: MonadPlus m => XQExpr -> RuleM m CRule -> RuleM m CRule -> RuleM m CRule
if2rule cond stmt1 stmt2 = do
	crule1 <- stmt1
	crule2 <- stmt2
	return $ CRuleIf cond crule1 crule2

let2rule :: MonadPlus m => Pat -> XQExpr -> RuleM m CRule -> RuleM m CRule
let2rule pat expr stmt1 = case2rule expr [(pat,stmt1)]

case2rule :: MonadPlus m => XQExpr -> [(Pat,RuleM m CRule)] -> RuleM m CRule
case2rule expr cs = liftM (CRuleCase expr) (mapM caseStmt2rule cs)

caseStmt2rule :: MonadPlus m => (Pat,RuleM m CRule) -> RuleM m (Pat,CRule)
caseStmt2rule (pat,stmt1) = liftM (\crule -> (pat,crule)) stmt1

upd2rule :: MonadPlus m => Upd -> BoolExpr -> RuleM m CRule
upd2rule (SingleInsertion loc pat path expr) cond = do
	let lr = case loc of { UBEFORE -> CRuleLeft; UAFTER -> CRuleRight }
	    spath = case pat of { Just p -> CPathSnapshot p ; Nothing -> id }
	return $ CRulePath (CPathSlash path $ spath $ CPathFilter cond) $ lr $ CRuleInsert expr
upd2rule (PluralInsertion loc pat path expr) cond = do
	let lr = case loc of { UFIRST -> CRuleLeft; ULAST -> CRuleRight }
	    spath = case pat of { Just p -> CPathSnapshot p ; Nothing -> id }
	return $ CRulePath (CPathSlash path $ spath $ CPathFilter cond) $ CRuleChildren $ lr $ CRuleInsert expr
upd2rule (SingleDeletion pat path) cond = do
	let spath = case pat of { Just p -> CPathSnapshot p ; Nothing -> id }
	return $ CRulePath (CPathSlash path $ spath $ CPathFilter cond) CRuleDelete
upd2rule (PluralDeletion pat path) cond = do
	let spath = case pat of { Just p -> CPathSnapshot p ; Nothing -> id }
	return $ CRulePath (CPathSlash path $ spath $ CPathFilter cond) $ CRuleChildren CRuleDelete
upd2rule (SingleReplace pat path expr) cond = do
	let spath = case pat of { Just p -> CPathSnapshot p ; Nothing -> id }
	return $ CRulePath (CPathSlash path $ spath $ CPathFilter cond) $ CRuleComp CRuleDelete $ CRuleInsert expr
upd2rule (PluralReplace pat path expr) cond = do
	let spath = case pat of { Just p -> CPathSnapshot p ; Nothing -> id }
	return $ CRulePath (CPathSlash path $ spath $ CPathFilter cond) $ CRuleChildren $ CRuleComp CRuleDelete $ CRuleInsert expr
upd2rule (UpdateSource pat path stmts) cond = do
	let spath = case pat of { Just p -> CPathSnapshot p ; Nothing -> id }
	crule <- stmts2rule stmts
	return $ CRulePath (CPathSlash path $ spath $ CPathFilter cond) crule
upd2rule (UpdateView _ _ _ _ _ _) cond = error "updateView is not a rewrite rule"
upd2rule (UpdateKeep _) cond = error "keep is not a rewrite rule"
upd2rule (UpdateCreate _) cond = error "create is not a rewrite rule"

runRuleM :: MonadPlus m => RuleM m a -> CoreM m a
runRuleM m = Reader.mapReaderT (State.mapStateT (\m -> ask >>= \(svars,vvars,evars) -> lift $ Reader.runReaderT m evars)) m

emptyView :: MonadPlus m => CoreM m Bool
emptyView = lift ask >>= \(svars,vvars,evars) -> return (Set.null vvars)

-- new set of source variables
changeSourceFocus :: MonadPlus m => Set Var -> CoreM m a -> CoreM m a
changeSourceFocus svars' m = Reader.mapReaderT (local (\(svars,vvars,evars) -> (svars',vvars,evars))) m

-- new set of view variables
changeViewFocus :: MonadPlus m => Set Var -> CoreM m a -> CoreM m a
changeViewFocus vvars' = Reader.mapReaderT (local (\(svars,vvars,evars) -> (svars,vvars',evars)))

-- new set of regular variables
changeEnvFocus :: MonadPlus m => Set Var -> CoreM m a -> CoreM m a
changeEnvFocus evars' m = Reader.mapReaderT (local (\(svars,vvars,evars) -> (svars,vvars,evars'))) m

addEnvFocus :: MonadPlus m => Set Var -> CoreM m a -> CoreM m a
addEnvFocus evars' m = lift ask >>= \(svars,vvars,evars) -> changeEnvFocus (evars `Set.union` evars') m

addSourceEnvFocus :: MonadPlus m => Set Var -> CoreM m a -> CoreM m a
addSourceEnvFocus svars' m = lift ask >>= \(svars,vvars,evars) -> changeSourceFocus (svars `Set.union` svars') (changeEnvFocus (evars `Set.union` svars') m)

delViewFocus :: MonadPlus m => Set Var -> CoreM m a -> CoreM m a
delViewFocus vvars' m = lift ask >>= \(svars,vvars,evars) -> changeViewFocus (vvars `Set.difference` vvars') m

addViewEnvFocus :: MonadPlus m => Set Var -> CoreM m a -> CoreM m a
addViewEnvFocus vvars' m = lift ask >>= \(svars,vvars,evars) -> changeViewFocus (vvars `Set.union` vvars') (changeEnvFocus (evars `Set.union` vvars') m)

guardEmptyView :: MonadPlus m => CoreM m a -> CoreM m a
guardEmptyView m = emptyView >>= \b -> if b then m else error "view not empty"

resetSourceFocus :: MonadPlus m => CoreM m a -> CoreM m a
resetSourceFocus = changeSourceFocus Set.empty

-- the view always has a variable
resetViewFocus :: MonadPlus m => CoreM m a -> CoreM m a
resetViewFocus = changeViewFocus (Set.singleton ".")
