module Text.XML.PutXML.Update.CoreToLenses where

import Text.XML.PutXML.DTD.SubType
import Text.XML.PutXML.Lenses.Lib
import Text.XML.PutXML.Generic.Rewrite
import Text.XML.PutXML.Update.AST
import Text.XML.PutXML.Update.CoreAST
import Text.XML.PutXML.Lenses.Pf
import Text.XML.PutXML.DTD.Type as Type
import Text.XML.PutXML.Lenses.View
import Text.XML.PutXML.Lenses.ViewPf
import Generics.Putlenses.Language
import Generics.Putlenses.Putlens hiding (Create(..))
import Generics.Putlenses.Examples.Examples
import Data.Map (Map(..))
import qualified Data.Map as Map
import Data.Set (Set(..))
import qualified Data.Set as Set
import Control.Monad
import Control.Monad.State (State,MonadState,StateT)
import qualified Control.Monad.State as State
import Control.Monad.Identity
import Control.Monad.Reader (Reader(..),MonadReader(..),ReaderT(..))
import qualified Control.Monad.Reader as Reader
import Control.Monad.Trans
import Text.XML.PutXML.XQuery.UXQ
import Text.XML.PutXML.XQuery.UXQToVal
import Text.XML.PutXML.XQuery.CPathToLens
import Text.XML.PutXML.Update.Patterns
import Text.XML.PutXML.XQuery.UXQToRef
import Text.XML.PutXML.XQuery.CPathToRef
import Text.XML.PutXML.XQuery.CPathToRewrite
import Text.XML.PutXML.Update.UpdateToCore
import Text.XML.PutXML.DTD.Normalize
import Data.Maybe

import Debug.Trace

type ProcArgs = (DynType,DynType,[(Var,DynType)]) -- source type, view type, environment variables
type ProcsArgs = Map String ProcArgs -- procedure arguments to use in procedure calls

type EnvVars s = (EnvT,ViewVars s) -- variables in the lens environment and current variables from the original source as lenses
type ViewVars s = Map String (EnvViewPf s)

type EnvView s = View (EnvM) s
type EnvViewPf s = ViewPf (EnvM) s

type EnvRef v = Ref ((State Env)) v
type EnvRefPf v = RefPf ((State Env)) v

type UpdateM m s = StateT Prevs (ReaderT TypeEnv (StateT (EnvVars s,ProcsArgs) m)) -- Prevs = explicit point-free representations, EnvVars = environment with variable types, ProcsArgs = procedure type arguments

type UpdRulePf m e s v = Type s -> Type v -> UpdateM m e (Pf (EnvPutlensM s v))
type UpdRulePfT m = forall s v . (Eq s,Eq v) => UpdRulePf m s s v

type UpdRefRulePfT m e = RefRulePfT m (ReaderT e (State Env))

evalcprogram :: (Eq s,Eq v,MonadPlus m) => CProgram -> TypeEnv -> Type s -> Type v -> m (Lens s v)
evalcprogram program tenv s v = liftM (put2lensErr "evalcprogram" . runStatePut (\s v -> return Map.empty)) (evalcprogramput program tenv s v)

evalcprogramput :: (Eq s,Eq v,MonadPlus m) => CProgram -> TypeEnv -> Type s -> Type v -> m (EnvPutlensM s v)
evalcprogramput prog tenv s v = cprogram2lens prog tenv s v >>= \(PfWithDecls lns decls) -> return $ evalPutlnsM decls envM s v lns

cprogram2lens :: (Eq s,Eq v,MonadPlus m) => CProgram -> TypeEnv -> Type s -> Type v -> m (PfWithDecls (EnvPutlensM s v))
cprogram2lens (CProgram (CStart name sargs vargs eargs) procedures) tenv s v = do
	let procsargs = foldr (\(CProcedure n s v e stmt) m -> Map.insert n (s,v,e) m) Map.empty procedures
	    prevs = ([],Map.empty)
	    envs = (Map.empty,Map.empty)
	    m = mapM (cprocedure2lens procsargs) procedures >> start2lens name sargs vargs eargs s v
	(lns,(_,decls)) <- State.evalStateT (Reader.runReaderT (State.runStateT m prevs) tenv) (envs,procsargs)
	return $ PfWithDecls lns decls

start2lens :: MonadPlus m => Name -> [CPath] -> [XQExpr] -> [XQExpr] -> UpdRulePfT m
start2lens name sargs vargs eargs s v = do
	rootS <- addSrcVar "source" s (Tag "#sroot" s) IdPut
	rootV <- addViewVar "view" (Tag "#vroot" v) id (Tag "#vroot" v)
	lns <- procedureCall2lens name sargs vargs eargs (Tag "#sroot" s) (Tag "$view" $ Tag "#vroot" v) -- the view must be a variable
	return $ ModifySt (\(Just s) v env -> return $ rootV (rootS env s) v) lns

cprocedure2lens :: MonadPlus m => ProcsArgs -> CProcedure -> StateT Prevs (ReaderT TypeEnv m) ()
cprocedure2lens procs (CProcedure name (DynT sVars) (DynT vVars) envVars stmt) = do
	lns <- runUpdateM (cprocedureStmt2lens sVars vVars envVars stmt (removeProdVariables sVars) vVars) (Map.fromList envVars,Map.empty) procs
	writeProcedure ("proc"++name) sVars vVars lns

cprocedureStmt2lens :: (Eq s,Eq v,MonadPlus m) => Type svars -> Type vvars -> [(Var,DynType)] -> CStmt -> Type s -> Type v -> UpdateM m s (Pf (EnvPutlensM s v))
cprocedureStmt2lens sVars vVars envVars stmt s v = do
	Type.Eq <- teq (removeProdVariables sVars) s -- this should be always true
	envS <- listPatVariablesPf envM sVars >>= \sview -> addSrcVars s sVars sview IdPut 	-- add source variables to the environment
	Type.Eq <- teq v vVars -- this should be always true
	envV <- listPatVariables envM vVars >>= \vview -> addViewVars vview id v -- add view variables to the environment
	lns <- cstmt2lens stmt s v
	return $ ModifySt (\(Just s) v env -> return $ envV (envS env s) v) lns

cstmt2lens :: MonadPlus m => CStmt -> UpdRulePfT m
cstmt2lens CStmtFail = fail2lens
cstmt2lens CStmtSkip = skip2lens
cstmt2lens (CStmtComp stmt1 vars1 stmt2 vars2) = comp2lens stmt1 vars1 stmt2 vars2
cstmt2lens (CStmtBindV var expr stmt) = bindv2lens var expr stmt
cstmt2lens (CStmtIf cond stmt1 stmt2) = if2lens cond stmt1 stmt2
cstmt2lens (CStmtIfS cond stmt1 stmt2) = ifS2lens cond stmt1 stmt2
cstmt2lens (CStmtIfV cond stmt1 stmt2) = ifV2lens cond stmt1 stmt2
cstmt2lens (CStmtReplace) = replace2lens
cstmt2lens (CStmtPathS spath stmt) = pathS2lens spath stmt
cstmt2lens (CStmtExprV vexpr stmt) = exprV2lens vexpr stmt
cstmt2lens (CStmtIter stmt) = iter2lens stmt
cstmt2lens (CStmtAlign scond matchsv stmt create rcv) = align2lens scond matchsv stmt create rcv
cstmt2lens (CStmtProc n sargs vargs eargs) = procedureCall2lens n sargs vargs eargs
cstmt2lens (CStmtCase e cs) = case2lens e cs
cstmt2lens (CStmtCaseS p cs) = caseS2lens p cs
cstmt2lens (CStmtCaseV e cs) = caseV2lens e cs
--cstmt2lens (CStmtRule rule) = rule2lens rule

procedureCall2lens :: MonadPlus m => Name -> [CPath] -> [XQExpr] -> [XQExpr] -> UpdRulePfT m
procedureCall2lens name sargs vargs eargs s v = freezeTEnv $ do -- procedures have their own fresh environment
	(DynT sVars,DynT vVars,envVars) <- getProcedureArgs name -- fetches the procedure declaration (source type,view type, environment variables)
	connectS <- procedureCallSources sVars sargs s
	connectV <- procedureCallViews vVars vargs s v
	(newEnvT,connectE) <- procedureCallEnvs envVars eargs s
	writeEnvT newEnvT
	let lnsCall = Variable ("proc"++name) (PutlnsM (envM) sVars vVars)
	return $ CompPut vVars (newEnv connectE $ CompPut sVars connectS lnsCall) connectV

procedureCallSources :: (Eq s,MonadPlus m) => Type svars -> [CPath] -> Type s -> UpdateM m s (Pf (EnvPutlensM s svars))
procedureCallSources sVars sargs s = do
	views <- listPatVariableTypes Type.Identity sVars
	ViewPf f s' <- liftM prodViews $ mapM (\x -> procedureCallSource x s) (zip views sargs)
	case teq s' (removeProdVariables sVars) of
		Just Type.Eq -> return f
		Nothing -> error "procedureCallSources panic!"

procedureCallSource :: (Eq s,MonadPlus m) => ((Var,DynType),CPath) -> Type s -> UpdateM m s (EnvViewPf s)
procedureCallSource ((n,DynT t),path) s = do
	ViewPf f a <- sourcepath2lens path s
	sub <- subtypeputNormWithDecls envM t a -- the variable type in the procedure must be a subtype of the actual variable type
	return $ ViewPf (CompPut a f sub) t

procedureCallViews :: (Eq s,Eq v,MonadPlus m) => Type vvars -> [XQExpr] -> Type s -> Type v -> UpdateM m s (Pf (EnvPutlensM vvars v))
procedureCallViews vVars vargs s v = do
	views <- listPatVariableTypes Type.Identity vVars
	let vars = map uXQVars vargs
	RefPf f v' <- procedureCallViews' (zip views vargs) (map uXQVars vargs) s v
	case teq v' vVars of
		Just Type.Eq -> return f
		Nothing -> error "procedureCallViews panic!"

procedureCallViews' :: (Eq s,Eq v,MonadPlus m) => [((Var,DynType),XQExpr)] -> [Set Var] -> Type s -> Type v -> UpdateM m s (EnvRefPf v)
procedureCallViews' [] [] s One = return $ RefPf IdPut One
procedureCallViews' [t] [tvars] s v = procedureCallView t tvars [] s v
procedureCallViews' (t:ts) (tvars:tsvars) s v = do
	RefPf f p@(Prod x v') <- procedureCallView t tvars tsvars s v
	RefPf g v'' <- procedureCallViews' ts tsvars s v'
	return $ RefPf (CompPut p (IdPut `ProdPut` g) f) (Prod x v'')
	
procedureCallView :: (Eq s,Eq v,MonadPlus m) => ((Var,DynType),XQExpr) -> Set Var -> [Set Var] -> Type s -> Type v -> UpdateM m s (EnvRefPf v)
procedureCallView ((n,DynT t),expr) x [] s v = do
	RefPf f p@(Prod v1 One) <- splitView envM x Set.empty v
	RefPf g b <- viewexpr2ref s expr v1
	sub <- subtypeputNormWithDecls envM b t -- the variable type in the procedure must be a supertype of the actual variable type
	return $ RefPf (CompPut b sub $ CompPut v1 g $ CompPut p RemsndOnePut f) (Tag (mkVar n) t)
procedureCallView ((n,DynT t),expr) x xs s v = do
	RefPf f p@(Prod v1 v2) <- splitView envM x (unionVars xs) v
	RefPf g b <- viewexpr2ref s expr v1
	sub <- subtypeputNormWithDecls envM b t -- the variable type in the procedure must be a supertype of the actual variable type
	return $ RefPf (CompPut p ((CompPut b sub g) `ProdPut` IdPut) f) (Prod (Tag (mkVar n) t) v2)

-- replaces the current environment by the procedure environment variables
procedureCallEnvs :: (Eq s,MonadPlus m) => [(Var,DynType)] -> [XQExpr] -> Type s -> UpdateM m s (EnvT,Env -> s -> Env)
procedureCallEnvs ts es s = foldM aux (Map.empty,\env x -> Map.empty) (zip ts es)
	where aux (envT,f) p = procedureCallEnv p s >>= \(envT',f') -> return (envT `Map.union` envT',\env x -> f env x `Map.union` f' env x)

procedureCallEnv :: (Eq s,MonadPlus m) => ((Var,DynType),XQExpr) -> Type s -> UpdateM m s (EnvT,Env -> s -> Env)
procedureCallEnv ((n,DynT t),expr) s = do
	((envT,svars),_) <- lift State.get
	Rewrite f a <- runQuery (uXQ2valWithRoot expr s)
	sub <- evalsubtype a t -- the variable type in the procedure must be a supertype of the actual variable type
	return $ (Map.singleton n (DynT t),\env x -> Map.singleton n $ Dyn t $ simplecreate sub $ Reader.runReader f env x)

fail2lens :: MonadPlus m => UpdRulePfT m
fail2lens s v = return BotPut

skip2lens :: MonadPlus m => UpdRulePfT m
skip2lens s One = return KeepDefPut

comp2lens :: MonadPlus m => CStmt -> Set Var -> CStmt -> Set Var -> UpdRulePfT m
comp2lens stmt1 vars1 stmt2 vars2 s v = do
	RefPf f (Prod v1 v2) <- splitView envM vars1 vars2 v
	g1 <- cstmt2lens stmt1 s v1
	g2 <- cstmt2lens stmt2 s v2
	return $ CompPut (Prod v1 v2) (g1 `UnforkPut` g2) f

bindv2lens :: MonadPlus m => Var -> XQExpr -> CStmt -> UpdRulePfT m
bindv2lens var expr stmt s v = trace ("bind") $ do
	RefPf f p@(Prod (Tag _ v1) v') <- splitView envM (Set.singleton var) (Set.delete var $ viewvars v) v
	vdep <- runViewQueryRes (uXQ2val expr) v' v1
	lns <- cstmt2lens stmt s v'
	return $ CompPut v' lns $ CompPut p (RemfstPut vdep) f

if2lens :: MonadPlus m => XQExpr -> CStmt -> CStmt -> UpdRulePfT m
if2lens cond stmt1 stmt2 s v = trace "if" $ do
	p <- runQuery (uXQ2boolWithRoot cond s)
	f <- cstmt2lens stmt1 s v
	g <- cstmt2lens stmt2 s v
	return $ IfthenelsePut (\(Just x) y -> State.get >>= \env -> return $ Reader.runReader p env x) f g
	
ifS2lens :: MonadPlus m => XQExpr -> CStmt -> CStmt -> UpdRulePfT m
ifS2lens cond stmt1 stmt2 s v = trace "ifS" $ do
	p <- runSourceQuery (uXQ2boolWithRoot cond s) s -- the current source is the root
	f <- cstmt2lens stmt1 s v
	g <- cstmt2lens stmt2 s v
	return $ IfSthenelsePut p f g
	
ifV2lens :: MonadPlus m => XQExpr -> CStmt -> CStmt -> UpdRulePfT m
ifV2lens cond stmt1 stmt2 s v = trace "ifV" $ do
	p <- runViewQuery (uXQ2bool cond) v -- we cannot have relative view paths, therefore no root
	f <- cstmt2lens stmt1 s v
	g <- cstmt2lens stmt2 s v
	return $ IfVthenelsePut p f g

--children2lens :: MonadPlus m => CStmt -> UpdRulePfT m
--children2lens stmt s@(getVPfAttEl -> Just (_,ViewPf out fs)) v = do -- only for elements
--	f <- changeFocus fs $ cstmt2lens stmt fs v
--	return $ CompPut fs out (WithS f)
--children2lens stmt s v = error "children can only be applied to elements"

replace2lens :: MonadPlus m =>  UpdRulePfT m
replace2lens s v = trace ("replace " ++ show s ++ "\n" ++ show (removeProdVariables v)) $ subtypeputOneNormWithDecls envM (removeProdVariables v) s -- subtyping extended with a rule () <: String because of ambiguity for inferred XML types

pathS2lens :: MonadPlus m => CPath -> CStmt -> UpdRulePfT m
pathS2lens spath stmt s v = trace "pathS" $ do
	ViewPf f a <- sourcepath2lens spath s
	lns <- changeFocus a $ cstmt2lens stmt a v
	return $ CompPut a f lns

exprV2lens :: MonadPlus m => XQExpr -> CStmt -> UpdRulePfT m
exprV2lens vexpr stmt s v = trace "exprV" $ do
	RefPf f b <- viewexpr2ref s vexpr v
	updViewRoot <- addViewVar "." b id (Tag "$." b) -- add the "temporary" view root variable to the environment
	lns <- cstmt2lens stmt s (Tag "$." b)
	return $ CompPut b (ModifySt (\s v env -> return $ updViewRoot env v) lns) f

iter2lens :: MonadPlus m => CStmt -> UpdRulePfT m
iter2lens stmt s v = trace "iter" $ do
	ListifyS lx x <- listifySource envM s
	l <- changeFocus x $ cstmt2lens stmt x v
	return $ CompPut (List x) lx $ CompPut (List v) (MapPut l) ListEqPut

-- when no filtering, can we have a general mapping lens? with the same element type (because of matching conditons perhaps)
align2lens :: MonadPlus m => XQExpr -> Maybe (CPath,CPath) -> CStmt -> Maybe CRule -> CRecover -> UpdRulePfT m
align2lens scond Nothing stmt create recover s (Tag _ v) = trace ("entered alignpos\ns: " ++ show s ++ "\nv: "++show v) $ do
	-- source processing
	ListifyS lx x <- listifySource envM s
	-- view processing
	ListifyV ly y <- listifyView envM v
	-- statement processing
	(lns,p,crt,rcv) <- rule scond stmt x (Tag "$." y) -- the view needs a tag
	return $ CompPut (List x) lx $ CompPut (List y) (AlignPosPut p rcv crt lns) ly -- this unsafe is fine because we just use a canonizer
  where -- rule used for processing inner elements
	rule :: (MonadPlus m,Eq s,Eq v) => XQExpr -> CStmt -> Type s -> Type v -> UpdateM m e (Pf (EnvPutlensM s v),s -> Bool,Maybe (Create s v),Recover s)
	rule scond stmt s v@(Tag "$." vt) = changeFocus s $ do
		p <- runSourceQuery (uXQ2boolWithRoot scond s) s
		crt <- runRewriteM (create2rule s v create)
		rcv <- runRewriteM (recover2fun recover s)
		updViewRoot <- addViewVar "." vt id v -- add the "temporary" view root variable to the environment
		f <- cstmt2lens stmt s v
		return (ModifySt (\s v env -> return $ updViewRoot env v) f,p,crt,rcv)
align2lens scond (Just (ps,pv)) stmt create recover s (Tag _ v) = trace ("entered alignkey\ns: " ++ show s ++ "\nv: "++show v) $ do
	-- source processing
	ListifyS lx x <- listifySource envM s
	-- view processing
	ListifyV ly y <- listifyView envM v
	-- statement processing
	(lns,p,crt,rcv,Match ks kv ms mv) <- rule scond ps pv stmt x (Tag "$." y) -- the view needs a tag
	return $ CompPut (List x) lx $ CompPut (List y) (AlignKeyPut ms mv (tcompare EQ ks kv) p rcv crt lns) ly
  where -- rule used for processing inner elements
	rule :: (MonadPlus m,Eq s,Eq v) => XQExpr -> CPath -> CPath -> CStmt -> Type s -> Type v -> UpdateM m e (Pf (EnvPutlensM s v),s -> Bool,Maybe (Create s v),Recover s,Match s v)
	rule scond ps pv stmt s v@(Tag "$." vt) = changeFocus s $ do
		p <- runSourceQuery (uXQ2boolWithRoot scond s) s
		Rewrite ms ks <- trace "ps" $ runQuery (uXQ2valWithRoot (XQPath ps) s) -- may use the environment, so its not a source query
		Rewrite mv kv <- trace "pv" $ runQuery (uXQ2valWithRoot (XQPath pv) vt) -- we can have a view focus, since it always has exactly one variable
		crt <- trace "create" $ runRewriteM (create2rule s v create)
		rcv <- trace "recv" $ runRewriteM (recover2fun recover s)
		updViewRoot <- addViewVar "." vt id v -- add the "temporary" view root variable to the environment
		f <- cstmt2lens stmt s v
		return (ModifySt (\s v env -> return $ updViewRoot env v) f,p,crt,rcv,Match ks kv (Reader.runReader ms) (Reader.runReader mv))

data ListifyS m a where
	ListifyS :: (Monad m,Eq b) => Pf (PutlensM m a [b]) -> Type b -> ListifyS m a

listifySource :: (Eq s,MonadPlus m,Monad lensm) => TypeM lensm -> Type s -> UpdateM m e (ListifyS lensm s)
listifySource lensm s = do
	ViewPf l t' <- normalizePfT lensm s
	DynT t <- eitherType (Set.toList $ elemsType t')
	guard (isUnambiguous t)
	c <- subtypeputWithDecls Type.Identity t' (List t)
	return $ ListifyS (CompPut t' l $ (UnsafeInvPut "listifySource" c)) t

data ListifyV m a where
	ListifyV :: (Monad m,Eq b) => Pf (PutlensM m [b] a) -> Type b -> ListifyV m a

listifyView :: (Eq v,MonadPlus m,Monad lensm) => TypeM lensm -> Type v -> UpdateM m e (ListifyV lensm v)
listifyView lensm v = do
	RefPf l t' <- normalizeViewPfT lensm v
	DynT t <- eitherType (Set.toList $ elemsType t')
	guard (isUnambiguous t)
	c <- subtypeputWithDecls lensm t' (List t)
	return $ ListifyV (CompPut t' c l) t

data Match s v where
	Match :: Type k1 -> Type k2 -> (Env -> s -> k1) -> (Env -> v -> k2) -> Match s v

type Create s v = Env -> v -> s

create2rule :: (Eq s,MonadPlus m) => Type s -> Type v -> Maybe CRule -> RewriteM m (Maybe (Create s v))
create2rule s (Tag "$." v) Nothing = return Nothing
create2rule s (Tag "$." v) (Just create) = trace ("create2rule " ++ show create) $ do
	updEnv <- addRewriteEnvVar "." v (\env y -> y)
	Rewrite f t <- crule2rewrite create v
	g <- trace ("sub " ++ show t ++ "\n"++show s) $ evalsubtypeOne t s `mplus` error "sbutyping failed"-- subtyping extended with a rule () <: String because of ambiguity for inferred XML types
	return $ Just $ \env y -> simplecreate g (Reader.runReader f (updEnv env y) y)

case2lens :: MonadPlus m => XQExpr -> [(Pat,CStmt)] -> UpdRulePfT m
case2lens expr cs s v = trace "case" $ do
	Rewrite f a <- runQuery (uXQ2valWithRoot expr s)	
	Rewrite g pats <- evalcase (map fst cs) a
	caseStmts2lens (map snd cs) pats (liftM (runIdentity g .) f) s v

caseStmts2lens :: (MonadPlus m,Eq s,Eq v) => [CStmt] -> Type pats -> (Reader Env (s -> pats)) -> UpdRulePf m s s v
caseStmts2lens [stmt] pat fun s v = caseStmt2lens stmt pat fun s v
caseStmts2lens (stmt:stmts) (Either pat pats) fun s v = do
	f <- freezeTEnv $ caseStmt2lens stmt pat (liftM (uninjl .) fun) s v
	g <- freezeTEnv $ caseStmts2lens stmts pats (liftM (uninjr .) fun) s v
	let p (Just s) v = State.get >>= \env -> return $ isLeft (Reader.runReader fun env s)
	return $ IfthenelsePut p f g

caseStmt2lens :: (MonadPlus m,Eq s,Eq v) => CStmt -> Type pat -> (Reader Env (s -> pat)) -> UpdRulePf m s s v
caseStmt2lens stmt pat fun s v = do
	vars <- listPatVariables (envM) pat
	updEnv <- addEnvVars vars (Reader.runReader fun)
	lns <- cstmt2lens stmt s v
	return $ ModifySt (\(Just s) v env -> return $ updEnv env s) lns

-- TODO: reformulate to match the current semantics
caseS2lens :: MonadPlus m => CPath -> [(Pat,CStmt)] -> UpdRulePfT m
caseS2lens path cs s v = trace "caseS" $ do
	ViewPf f a <- sourcepath2lens path s
	ViewPf g pats <- casesourceputWithDecls (envM) (map fst cs) a
	caseSStmts2lens (map snd cs) pats (CompPut a f g) s v

caseSStmts2lens :: (MonadPlus m,Eq s,Eq v,Eq pats) => [CStmt] -> Type pats -> Pf (EnvPutlensM s pats) -> UpdRulePf m s s v
caseSStmts2lens [stmt] pat lns s v = caseSStmt2lens stmt pat lns s v
caseSStmts2lens (stmt:stmts) paats@(Either pat pats) lns s v = do
	f <- freezeTEnv $ caseSStmt2lens stmt pat (CompPut paats lns InjlPut) s v
	g <- freezeTEnv $ caseSStmts2lens stmts pats (CompPut paats lns InjrPut) s v
	l <- evalUpdPutlnsM (envM) s paats lns
	return $ IfSthenelsePut (isLeft . get' l) f g

caseSStmt2lens :: (MonadPlus m,Eq s,Eq v,Eq pat) => CStmt -> Type pat -> Pf (EnvPutlensM s pat) -> UpdRulePf m s s v
caseSStmt2lens stmt pat lns s v = do
	vars <- listPatVariablesPf (envM) pat
	updEnv <- addSrcVars s pat vars lns
	lns <- cstmt2lens stmt s v
	return $ ModifySt (\(Just s) v env -> return $ updEnv env s) lns

caseV2lens :: MonadPlus m => XQExpr -> [(Pat,CStmt)] -> UpdRulePfT m
caseV2lens expr cs s v = trace "caseV" $ do
	RefPf f (Prod v1 v2) <- splitView (envM) (uXQVars expr) (viewvars v `Set.difference` uXQVars expr) v
	RefPf g a <- viewexpr2ref s expr v1
	RefPf h pats <- caseviewputWithDecls (envM) (map fst cs) a
	RefPf i pats2 <- distributeViewPatterns pats v2 -- creates a sum of products with pattern variables to the left and other variables to the right
	lns <- caseVStmts2lens (map snd cs) s pats2
	return $ CompPut pats2 lns $ CompPut (Prod pats v2) i $ CompPut (Prod v1 v2) (CompPut a h g `ProdPut` IdPut) f

caseVStmts2lens :: (MonadPlus m,Eq s,Eq v) => [CStmt] -> UpdRulePf m s s v
caseVStmts2lens [stmt] s v = caseVStmt2lens stmt s v
caseVStmts2lens (stmt:stmts) s (Either v vs) = do
	f <- freezeTEnv $ caseVStmt2lens stmt s v
	g <- freezeTEnv $ caseVStmts2lens stmts s vs
	return $ EitherLPut f g

caseVStmt2lens :: (MonadPlus m,Eq s,Eq v) => CStmt -> UpdRulePf m s s v
caseVStmt2lens stmt s v@(Prod pat vs) = do -- view is a product of pattern variables and remaining variables
	vars <- listPatVariables (envM) pat
	updEnv <- addViewVars vars fst v
	lns <- cstmt2lens stmt s v
	return $ ModifySt (\s v env -> return $ updEnv env v) lns

--rule2lens :: MonadPlus m => CRule -> UpdRulePfT m
--rule2lens rule s One = trace ("rule") $ do
--	Rewrite f t <- crule2rewritelens rule s
--	g <- evalsubtypeputOne Type.Identity t s
--	return $ PhiSourcePut (\s -> isJust (getM g s)) (PntPut $ \(Just x) -> trace ("rule: "++show rule++"\nVALUE!!!! "++gshow s x) $ do { y <- f; return $ trace ("changed: "++gshow t (y x)) $ (simplecreate (put2lensErr "rule2lens" g) $ y x) })

type RewriteM m = StateT Prevs (ReaderT TypeEnv (StateT EnvT m))

-- uses the current environment to run a rewrite rule
crule2rewritelens :: MonadPlus m => CRule -> RRuleT (UpdateM m e) (EnvM)
crule2rewritelens rule s = do
	Rewrite f t <- runRewriteM (crule2rewrite rule s)
	return $ Rewrite (State.get >>= \env -> return $ Reader.runReader f env) t

crulepath2rewrite :: MonadPlus m => CPath -> CRule -> RRuleT (RewriteM m) (Reader Env)
--crulepath2rewrite (isRootedCPath -> Just (var,path)) rule = do
--	((envT,svars),_) <- lift State.get
--	case Map.lookup var svars of
--		Just (ViewPf f b) -> crule2rewrite r `seqR` cpath2rewrite path (crule2rewrite rule)
--		Nothing -> error "variable not found in rule environment"
crulepath2rewrite path rule = cpath2rewrite path (crule2rewrite rule)

crule2rewrite :: MonadPlus m => CRule -> RRuleT (RewriteM m) (Reader Env)
crule2rewrite (CRulePath path rule) a = crulepath2rewrite path rule a
crule2rewrite (CRuleLeft rule) a = do
	Rewrite f b <- crule2rewrite rule One
	return $ Rewrite (Reader.reader $ \env x -> (Reader.runReader f env (),x)) (Prod b a)
crule2rewrite (CRuleRight rule) a = do
	Rewrite f b <- crule2rewrite rule One
	return $ Rewrite (Reader.reader $ \env x -> (x,Reader.runReader f env ())) (Prod a b)
crule2rewrite (CRuleChildren rule) a = childrenR (crule2rewrite rule) a
crule2rewrite (CRuleInsert expr) a = insert2rewrite expr a
crule2rewrite CRuleDelete a = delete2rewrite a
crule2rewrite (CRuleComp r1 r2) a = (crule2rewrite r1 `seqR` crule2rewrite r2) a
crule2rewrite CRuleSkip a = nopR a
crule2rewrite (CRuleIf cond r1 r2) a = if2rewrite cond (crule2rewrite r1) (crule2rewrite r2) a
crule2rewrite (CRuleCase expr cs) a = case2rewrite expr (map (\(pat,r) -> (pat,crule2rewrite r)) cs) a
--crule2rewrite (CRuleFirst rule) (Prod a b) = do
--	Rewrite f a' <- crule2rewrite rule a
--	return $ Rewrite (Reader.reader $ \env (x,y) -> (Reader.runReader f env x,y)) (Prod a' b)
--crule2rewrite (CRuleSecond rule) (Prod a b) = do
--	Rewrite g b' <- crule2rewrite rule b
--	return $ Rewrite (Reader.reader $ \env (x,y) -> (x,Reader.runReader g env y)) (Prod a b')
--crule2rewrite (CRuleFun (Type.DynFun x y f)) a = do
--	lns <- evalsubtype a x
--	Just Type.Eq -> return $ Rewrite (Reader.reader $ \env v -> f $ simplecreate lns v) y
--	Nothing -> error $ "crule2rewrite function type mismatch"
	
insert2rewrite :: MonadPlus m => XQExpr -> RRuleT (RewriteM m) (Reader Env)
insert2rewrite expr One = do
	ViewXQ f b <- runRewriteQuery (uXQ2val expr)
	return $ Rewrite (Reader.reader $ \env () -> Reader.runReader f env) b

delete2rewrite :: MonadPlus m => RRuleT (RewriteM m) (Reader Env)
delete2rewrite a = return $ Rewrite (Reader.reader $ \env x -> ()) One

if2rewrite :: MonadPlus m => XQExpr -> RRuleT (RewriteM m) (Reader Env) -> RRuleT (RewriteM m) (Reader Env) -> RRuleT (RewriteM m) (Reader Env)
if2rewrite cond r1 r2 a = do
	p <- runRewriteQuery (uXQ2boolWithRoot cond a)
	Rewrite f b <- freezeRewriteTEnv $ r1 a
	Rewrite g c <- freezeRewriteTEnv $ r2 a
	let fun = Reader.reader $ \env x -> if (Reader.runReader p env x) then Left (Reader.runReader f env x) else Right (Reader.runReader g env x)
	return $ Rewrite fun (Either b c)

case2rewrite :: MonadPlus m => XQExpr -> [(Pat,RRuleT (RewriteM m) (Reader Env))] -> RRuleT (RewriteM m) (Reader Env)
case2rewrite expr cs a = do
	Rewrite f b <- runRewriteQuery (uXQ2valWithRoot expr a)
	Rewrite g pats <- evalcase (map fst cs) b
	caseStmts2rewrite (map snd cs) pats (liftM (runIdentity g .) f) a

caseStmts2rewrite :: (MonadPlus m,Eq s) => [RRuleT (RewriteM m) (Reader Env)] -> Type pats -> (Reader Env (s -> pats)) -> RRule (RewriteM m) (Reader Env) s
caseStmts2rewrite [rule] pat fun s = caseStmt2rewrite rule pat fun s
caseStmts2rewrite (rule:rules) (Either pat pats) fun s = do
	Rewrite f a <- freezeRewriteTEnv $ caseStmt2rewrite rule pat (liftM (uninjl .) fun) s
	Rewrite g b <- freezeRewriteTEnv $ caseStmts2rewrite rules pats (liftM (uninjr .) fun) s
	let gun = Reader.reader $ \env x -> if isLeft (Reader.runReader fun env x) then Left (Reader.runReader f env x) else Right (Reader.runReader g env x)
	return $ Rewrite gun (Either a b)

caseStmt2rewrite :: (MonadPlus m,Eq s) => RRuleT (RewriteM m) (Reader Env) -> Type pat -> (Reader Env (s -> pat)) -> RRule (RewriteM m) (Reader Env) s
caseStmt2rewrite rule pat fun s = do
	vars <- listPatVariables envM pat
	updEnv <- addRewriteEnvVars vars (Reader.runReader fun)
	Rewrite f b <- rule s
	return $ Rewrite (Reader.reader $ \env x -> Reader.runReader f (updEnv env x) x) b

type RecoverRule m s = Type s -> RewriteM m (Recover s)
type RecoverRuleT m = forall s. Eq s => RecoverRule m s
type Recover s = Env -> s -> Maybe s

recover2fun :: MonadPlus m => CRecover -> RecoverRuleT m
recover2fun (CRecoverIf cond rcv1 rcv2) s = do
	p <- runRewriteQuery (uXQ2boolWithRoot cond s)
	f <- freezeRewriteTEnv $ recover2fun rcv1 s
	g <- freezeRewriteTEnv $ recover2fun rcv2 s
	return $ \env s -> if Reader.runReader p env s then f env s else g env s
recover2fun (CRecoverCase expr cs) s = do
	Rewrite f a <- runRewriteQuery (uXQ2valWithRoot expr s)
	Rewrite g pats <- evalcase (map fst cs) a
	recoverStmts2fun (map snd cs) pats (liftM (runIdentity g .) f) s
recover2fun (CRecoverKeepSource rule) s = do
	Rewrite f t <- crule2rewrite rule s
	lns <- evalsubtype t s
	return $ \env s -> Just $ simplecreate lns $ Reader.runReader f env s
recover2fun CRecoverDeleteSource s = return $ \env s -> Nothing

recoverStmts2fun :: (MonadPlus m,Eq s) => [CRecover] -> Type pats -> (Reader Env (s -> pats)) -> RecoverRule m s
recoverStmts2fun [crv] pat fun s = recoverStmt2fun crv pat fun s
recoverStmts2fun (crv:crvs) (Either pat pats) fun s = do
	f <- recoverStmt2fun crv pat (liftM (uninjl .) fun) s
	g <- recoverStmts2fun crvs pats (liftM (uninjr .) fun) s
	return $ \env x -> if isLeft (Reader.runReader fun env x) then f env x else g env x

recoverStmt2fun :: (MonadPlus m,Eq s) => CRecover -> Type pat -> (Reader Env (s -> pat)) -> RecoverRule m s
recoverStmt2fun rcv pat fun s = do
	vars <- listPatVariables Type.Identity pat
	updEnv <- addRewriteEnvVars vars (Reader.runReader fun)
	h <- recover2fun rcv s
	return $ \env x -> h (updEnv env x) x

-- evaluates a query with the type environment
runQuery :: MonadPlus m => QueryM m a -> UpdateM m e a
runQuery m = lift State.get >>= \((envT,_),_) -> runQueryWith m Nothing envT

-- evaluates a query given a particular environment
runQueryWith :: (MonadPlus m,MonadTrans t,Monad (t m)) => QueryM m a -> Maybe String -> EnvT -> StateT Prevs (ReaderT TypeEnv (t m)) a
runQueryWith m root envT = Reader.ask >>= \tenv -> lift $ lift $ lift $ runXQ tenv root envT m

-- collects the source variables in the environment (type and value)
sourceEnv :: (MonadPlus m,Eq e) => Type e -> UpdateM m e (EnvT,e -> Env)	
sourceEnv e = do
	((_,svars),_) <- lift State.get
	liftM (\(envT,updEnv) -> (envT,updEnv Map.empty)) (readLensVars (envM) e (Map.toList svars))

-- restricted sourceEnv
sourceEnvVars :: (MonadPlus m,Eq e) => Set Var -> Type e -> UpdateM m e (EnvT,e -> Env)	
sourceEnvVars set e = do
	((_,svars),_) <- lift State.get
	let svarsset = Map.filterWithKey (\k a -> Set.member k set) svars
	liftM (\(envT,updEnv) -> (envT,updEnv Map.empty)) (readLensVars (envM) e (Map.toList svarsset))

-- reads a set of variables from a list of lenses
readLensVars :: (MonadPlus m,Eq e,MonadState Prevs m,Monad lensm) => TypeM lensm -> Type e -> [(String,ViewPf lensm e)] -> m (EnvT,Env -> e -> Env)
readLensVars lensm e [] = return $ (Map.empty,\env x -> env)
readLensVars lensm e ((n,ViewPf f b):vs) = do
	lns <- evalUpdPutlnsM lensm e b f
	(envT,updEnv) <- readLensVars lensm e vs
	return $ (Map.insert n (DynT b) envT,\env x -> Map.insert n (Dyn b $ get' lns x) (updEnv env x))

-- evaluates a query over the source (under a particular source environment)
runSourceQuery :: (MonadPlus m,Eq s) => QueryM m (Reader Env (s -> r)) -> Type s -> UpdateM m s (s -> r)
runSourceQuery m s = do
	(sEnvT,sEnv) <- sourceEnv s -- collect the source variables
	p <- runQueryWith m Nothing sEnvT -- runs the query but only with the source environment
	return $ \x -> Reader.runReader p (sEnv x) x

-- collects the view variables in the environment
viewEnv :: (MonadPlus m,Eq v,MonadState Prevs m) => Type v -> m (EnvT,v -> Env)
viewEnv v = do
	vars <- listPatVariablesPf Type.Identity v
	let vars' = map (\(ViewPf f (Tag (varName -> n) x)) -> (n,ViewPf f x)) vars
	liftM (\(envT,updEnv) -> (envT,updEnv Map.empty)) (readLensVars Type.Identity v vars')

-- evaluates a query over the view (under a particular view environment)
runViewQuery :: (MonadPlus m,Eq v,MonadTrans t,MonadPlus (t m)) => QueryM m (Reader Env r) -> Type v ->  StateT Prevs (ReaderT TypeEnv (t m)) (v -> r)
runViewQuery m v = do
	(vEnvT,vEnv) <- viewEnv v -- -- collect the view variables
	p <- runQueryWith m Nothing vEnvT -- -- runs the query but only with the view environment
	return $ \y -> Reader.runReader p (vEnv y)

runViewQueryRes :: (MonadPlus m,Eq r,Eq v,MonadTrans t,MonadPlus (t m)) => QueryM m ViewXQ -> Type v -> Type r -> StateT Prevs (ReaderT TypeEnv (t m)) (v -> r)
runViewQueryRes m v r = do
	(vEnvT,vEnv) <- viewEnv v -- -- collect the view variables
	ViewXQ p t <- runQueryWith m Nothing vEnvT -- -- runs the query but only with the view environment
	sub <- evalsubtype t r
	return $ \y -> simplecreate sub $ Reader.runReader p (vEnv y)

-- changes the focus (current source), forgetting all lenses from the current source (they remain as constants constants in the environment)
changeFocus :: MonadPlus m => Type s' -> UpdateM m s' r -> UpdateM m s r
changeFocus s' = State.mapStateT $ Reader.mapReaderT (\m -> State.get >>= \((evars,svars),procs) -> lift $ State.evalStateT m ((evars,Map.empty),procs))

-- TODO: forcing all variables to be constant does not work!!
-- evaluates a path as a lens from the source
sourcepath2lens :: (MonadPlus m,Eq s) => CPath -> Type s -> UpdateM m s (EnvViewPf s)
sourcepath2lens (isRootedCPath -> Just (var,path)) s = do
	((evars,svars),procs) <- lift State.get
	case Map.lookup var svars of
		Just (ViewPf l1 a) -> do
			(sEnvT,sEnv) <- trace ("sourcepathWithRoot " ++ show var ++ " "++show path) $ sourceEnvVars (cpathVars path) s
			ViewEnvPf lns b <- runCPath sEnvT (cpath2lens path a)
			return $ ViewPf (CompPut (Prod Env s) (RemfstPut sEnv) $ CompPut (Prod Env a) (IdPut `ProdPut` l1) (ParamfstGet (\v -> return Map.empty) $ Reader.runReader lns)) b
		Nothing -> error $ "source variable " ++ show var ++ " not found in "
sourcepath2lens path s = do
	(sEnvT,sEnv) <- trace ("sourcepathWithoutRoot " ++ show path ++"\n"++ show s) $ sourceEnvVars (cpathVars path) s
	ViewEnvPf lns b <- runCPath sEnvT (cpath2lens path s)
	return $ trace ("path result " ++ show b) $ ViewPf (CompPut (Prod Env s) (RemfstPut sEnv) (ParamfstGet (\v -> return Map.empty) $ Reader.runReader lns)) b -- environment variables should be kept constant

runCPath :: MonadPlus m => EnvT -> CPathM m a -> UpdateM m s a
runCPath env m = State.mapStateT (Reader.mapReaderT (\m -> lift $ State.evalStateT m env)) m

-- no need to freeze the lens environment, since path2ref does not create variables (no snapshot)
--viewexpr2ref :: (Eq s,MonadPlus m,Eq v) => Type s -> XQExpr -> Type v -> UpdateM m s (RefPf (EnvM) v)
--viewexpr2ref s path v = runXQM (uXQ2ref s path v)

viewexpr2ref :: (Eq s,MonadPlus m,Eq v) => Type s -> XQExpr -> Type v -> UpdateM m s (RefPf (EnvM) v)
viewexpr2ref s expr v = freezeTEnv $ do
	RefPf f b <- runXQM (uXQ2ref s expr v)
	return $ RefPf (freezeEnv f) b

runXQM :: MonadPlus m => XQM m a -> UpdateM m s a
runXQM = State.mapStateT $ Reader.mapReaderT (\m -> State.get >>= \((evars,svars),_) -> lift $ State.evalStateT m evars)

addEnvVar :: (Eq a,MonadPlus m) => String -> Type a -> (Env -> e -> a) -> UpdateM m e (Env -> e -> Env)
addEnvVar n a f = do
	((evars,svars),procs) <- lift State.get
	lift $ State.put ((Map.insert n (DynT a) evars,svars),procs)
	return $ \env e -> Map.insert n (Dyn a $ f env e) env

addEnvVars :: MonadPlus m => [EnvView vars] -> (Env -> e -> vars) -> UpdateM m e (Env -> e -> Env)
addEnvVars [] f = return $ \env x -> env
addEnvVars (View g (Tag (varName -> n) x):xs) f = do
	fenv <- addEnvVar n x (\env x -> get' g $ f env x)
	fenvs <- addEnvVars xs f
	return $ \env x -> fenvs (fenv env x) x

addSrcVar :: (Eq a,Eq e,MonadPlus m) => String -> Type e -> Type a -> Pf (EnvPutlensM e a) -> UpdateM m e (Env -> e -> Env)
addSrcVar n e a f = do
	((evars,svars),procs) <- lift State.get
	lift $ State.put ((Map.insert n (DynT a) evars,Map.insert n (ViewPf f a) svars),procs)
	lns <- evalUpdPutlnsM (envM) e a f
	return $ \env x -> Map.insert n (Dyn a $ get' lns x) env

addSrcVars :: (MonadPlus m,Eq vars,Eq e) => Type e -> Type vars -> [(EnvViewPf vars)] -> Pf (EnvPutlensM e vars) -> UpdateM m e (Env -> e -> Env)
addSrcVars e vars [] slns = return $ \env x -> env
addSrcVars e vars (ViewPf f (Tag (varName -> n) x):xs) slns = do
	fenv <- addSrcVar n e x (CompPut vars slns f)
	fenvs <- addSrcVars e vars xs slns
	return $ \env x -> fenvs (fenv env x) x

addViewVar :: (Eq a,MonadPlus m) => String -> Type a -> (v -> a) -> Type v -> UpdateM m e (Env -> v -> Env)
addViewVar n a f v = do
	((evars,svars),procs) <- lift State.get
	lift $ State.put ((Map.insert n (DynT a) evars,svars),procs)
	return $ \env v1 -> Map.insert n (Dyn a $ f v1) env

addViewVars :: MonadPlus m => [EnvView vars] -> (v -> vars) -> Type v -> UpdateM m e (Env -> v -> Env)
addViewVars [] f v = return $ \env x -> env
addViewVars (View g (Tag (varName -> n) y):ys) f v = do
	fenv <- addViewVar n y (get' g . f) v
	fenvs <- addViewVars ys f v
	return $ \env x -> fenvs (fenv env x) x

-- keeps a copy of the current type environment and restores it at the end (to make a monad state behave like a monad reader)
freezeTEnv :: Monad m => UpdateM m e a -> UpdateM m e a
freezeTEnv m = do
	(env,_) <- lift State.get
	lns <- m
	(_,procs) <- lift State.get
	lift (State.put (env,procs))
	return lns

-- keeps a copy of the lens environment (to make it behave like a reader)
freezeEnv :: Pf (EnvPutlensM s v) -> Pf (EnvPutlensM s v)
freezeEnv = ResetStatePut Env (\s v -> return)

-- creates a new environment for a sub-lens (to make it behave like a reader)
newEnv :: (Env -> s -> Env) ->  Pf (EnvPutlensM s v) -> Pf (EnvPutlensM s v)
newEnv upd = ResetStatePut Env (\(Just s) v env -> return $ upd env s)

getProcedureArgs :: MonadPlus m => String -> UpdateM m e ProcArgs
getProcedureArgs n = do
	(envT,procs) <- lift $ lift $ State.get
	case Map.lookup n procs of
		Just p -> return p
		Nothing -> error $ "procedure " ++ show n ++ " not found in" ++ show (Map.keys procs)

writeEnvT ::Monad m => EnvT -> UpdateM m s ()
writeEnvT envT = do { ((evars,svars),procs) <- lift State.get; lift $ State.put ((envT,svars),procs) }

writeProcedure :: (Eq v,Eq s,MonadPlus m) => String -> Type s -> Type v -> Pf (EnvPutlensM s v) -> StateT Prevs m ()
writeProcedure name s v f = do
	(names,decls) <- State.get
	State.put (names,Map.insert name (DynPf (PutlnsM (envM) s v) f) decls)

runUpdateM :: Monad m => UpdateM m s a -> EnvVars s -> ProcsArgs -> StateT Prevs (ReaderT TypeEnv m) a
runUpdateM m envs procs = State.mapStateT (Reader.mapReaderT (\m -> State.evalStateT m (envs,procs))) m
