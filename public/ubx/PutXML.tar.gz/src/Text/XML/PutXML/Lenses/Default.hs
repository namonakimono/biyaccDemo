
module Text.XML.PutXML.Lenses.Default where

import Text.XML.PutXML.DTD.Type
import Text.XML.HaXml.DtdToHaskell.TypeDef hiding (List,Maybe,List1,String)
import Generics.Putlenses.Putlens
import Generics.Putlenses.Language
import GHC.InOut
import Data.Set (Set(..))
import qualified Data.Set as Set

type Generator = forall a. Type a -> a

-- | Default generator for representable types
defvalue :: Generator
defvalue a = let deps = typeDependencies a in defvalue' deps Nothing a

defvalue' :: TypeDeps -> Maybe Name -> Generator
defvalue' deps p Int = 0
defvalue' deps p Float = 0
defvalue' deps p String = Str ""
defvalue' deps p Bool = False
defvalue' deps p One = ()
defvalue' deps p (Either a@(isEmptyType -> True) b) = Left (defvalue' deps p a)
defvalue' deps p (Either a b@(isEmptyType -> True)) = Right (defvalue' deps p b)
defvalue' deps Nothing (Either a b) = Left (defvalue' deps Nothing a)
defvalue' deps (Just p) (Either a b) = if countId deps p a <= countId deps p b
	then Left (defvalue' deps (Just p) a)
	else Right (defvalue' deps (Just p) b)
defvalue' deps p (Prod a b) = (defvalue' deps p a,defvalue' deps p b)
defvalue' deps p (List a) = []
defvalue' deps p (Data n t) = inn $ defvalue' deps (Just n) t
defvalue' deps p (Tag n t) = defvalue' deps p t
defvalue' deps p (Cut a) = defvalue' deps p a
defvalue' deps p a = error $ "no default for " ++ show a
--defvalue' deps p (XList xmin xmax (Set.toList -> [])) = []
--defvalue' deps p (XList xmin xmax (Set.toList -> DynT xt:xts)) = map (Dyn xt) $ replicate xmin (defvalue' deps p xt)

-- | Counts the number of recursive invocations in a functor
countId :: TypeDeps -> Name -> Type a -> Int
countId deps n (Either a b) = min (countId deps n a) (countId deps n b)
countId deps n (Prod a b) = countId deps n a + countId deps n b
countId deps n (List a) = 0 -- as long as we return the empty list, there is no problem with recursive invocations
countId deps n (XList xmin xmax xts) = if xmin == 0 then 0 else Set.foldr (\(DynT t) i -> countId deps n t + i) 0 xts
countId deps n (Tag _ t) = countId deps n t
countId deps n (Data s t) = case lookup s deps of
	Just ss -> if elem n ss then 1 else 0
	Nothing -> 0
countId deps n (Cut a) = countId deps n a
countId deps n _ = 0

-- tests if an XML sequence never has values (eg, lists are empty if the inner type is empty)
isEmptyType :: Type a -> Bool
isEmptyType (getLiteral -> Just a) = False
isEmptyType One = True
isEmptyType (Cut a) = True -- values to be deleted are empty
isEmptyType (Either a b) = isEmptyType a && isEmptyType b
isEmptyType (Prod a b) = isEmptyType a && isEmptyType b
isEmptyType (List a) = isEmptyType a
isEmptyType (isAttEl -> True) = False
--isEmptyType (XList _ _ xts) = and $ map (applyDynT isNonEmptyType) (Set.toList xts)

-- tests if an XML sequence always has some value (eg, lists may not have values)
isNonEmptyType :: Type a -> Bool
isNonEmptyType (getLiteral -> Just a) = True
isNonEmptyType One = False
isNonEmptyType (Either a b) = isNonEmptyType a || isNonEmptyType b
isNonEmptyType (Prod a b) = isNonEmptyType a || isNonEmptyType b
isNonEmptyType (List a) = False
isNonEmptyType (isAttEl -> True) = True
isNonEmptyType (XList _ _ xts) = False