module Text.XML.PutXML.Lenses.ViewPf where

import Text.XML.PutXML.Lenses.View
import Text.XML.PutXML.Lenses.Pf
import Text.XML.PutXML.DTD.Type as Type
import Generics.Putlenses.Putlens
import Generics.Putlenses.Language
import Text.XML.HaXml.DtdToHaskell.TypeDef hiding (List,List1,Any)
import GHC.InOut
import Control.Monad
import Text.PrettyPrint.HughesPJ
import Control.Monad.State (State(..))
import qualified Control.Monad.State as ST
import Data.Map (Map(..))
import qualified Data.Map as Map
import Text.XML.PutXML.Lenses.Lib
import Generics.Putlenses.Examples.Examples
import Data.Maybe
import Control.Monad.Reader (Reader(..),MonadReader(..),ReaderT(..))
import qualified Control.Monad.Reader as Reader
import Data.Set (Set(..))
import qualified Data.Set as Set
import Data.Map (Map(..))
import qualified Data.Map as Map
import Control.Monad.Identity

import Debug.Trace

data ViewEnvPf rwm m a where
	ViewEnvPf :: Eq b => rwm (Pf (PutlensM m a b)) -> Type b -> ViewEnvPf rwm m a
	
data RefEnvPf rwm m a where
	RefEnvPf :: Eq b => rwm (Pf (PutlensM m b a)) -> Type a -> RefEnvPf rwm m a

liftViewEnvPf :: (MonadPlus m,Monad st,Monad rwm) => RulePfT m st -> RuleEnvPfT m rwm st
liftViewEnvPf r a = do
	ViewPf f b <- r a
	return $ ViewEnvPf (return f) b

data ViewPf m a where
	ViewPf :: Eq b => Pf (PutlensM m a b) -> Type b -> ViewPf m a	
	
data RefPf m a where
	RefPf :: Eq b => Pf (PutlensM m b a) -> Type b -> RefPf m a	
	
data ViewPf' a where
	ViewPf' :: Eq b => Pf (Lens a b) -> Type b -> ViewPf' a	

applyViewPf :: Monad m => (forall b . Eq b => Pf (PutlensM m a b) -> Type b -> r) -> ViewPf m a -> r
applyViewPf f (ViewPf l b) = f l b

type RulePf m lensm a = Type a -> m (ViewPf lensm a)
type RulePfT m lensm = forall a . Eq a => RulePf m lensm a

type QueryPf m lensm a r = Type a -> m (Pf (PutlensM lensm a r))
type RulePfQ m lensm r = forall a . Eq a => QueryPf m lensm a r

type RuleEnvPf m rwm lensm a = Type a -> m (ViewEnvPf rwm lensm a)
type RuleEnvPfT m rwm lensm = forall a . Eq a => RuleEnvPf m rwm lensm a

type RefRulePf m lensm a = Type a -> m (RefPf lensm a)
type RefRulePfT m lensm = forall a . Eq a => RefRulePf m lensm a

type RefRuleEnvPf m rwm lensm a = Type a -> m (RefEnvPf rwm lensm a)
type RefRuleEnvPfT m rwm lensm = forall a . Eq a => RefRuleEnvPf m rwm lensm a

data ViewPfWithDecls m a where
	ViewPfW :: Eq b => PfWithDecls (PutlensM m a b) -> Type b -> ViewPfWithDecls m a

data ViewPfWithDecls' a where
	ViewPfW' :: Eq b => PfWithDecls (Lens a b) -> Type b -> ViewPfWithDecls' a

data RefPfWithDecls m a where
	RefPfW :: Eq b => PfWithDecls (PutlensM m b a) -> Type b -> RefPfWithDecls m a
	
data RefPfWithDecls' a where
	RefPfW' :: Eq b => PfWithDecls (Lens b a) -> Type b -> RefPfWithDecls' a

compMPutPf :: (Monad m,Eq b,Monad rwm) => Type b -> rwm (Pf (PutlensM m a b)) -> rwm (Pf (PutlensM m b c)) -> rwm (Pf (PutlensM m a c))
compMPutPf b = liftM2 (CompPut b)
prodMPutPf :: (Monad m,Eq v1,Eq v2,Monad rwm) => rwm (Pf (PutlensM m s1 v1)) -> rwm (Pf (PutlensM m s2 v2)) -> rwm (Pf (PutlensM m (s1,s2) (v1,v2)))
prodMPutPf = liftM2 (ProdPut)
sumMPutPf :: (Monad m,Monad rwm) => rwm (Pf (PutlensM m s1 v1)) -> rwm (Pf (PutlensM m s2 v2)) -> rwm (Pf (PutlensM m (Either s1 s2) (Either v1 v2)))
sumMPutPf = liftM2 (SumPut)

nopPf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
nopPf a = return $ ViewPf IdPut a

-- instead of deletion a type, marks it for deletion
cutPf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
cutPf a = return $ ViewPf IdPut (Cut a)

delPf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
delPf a = return $ ViewPf KeepDefPut One

insPf :: (MonadPlus m,Monad lensm) => Dynamic -> RulePfT m lensm
insPf (Dyn t v) One = return $ ViewPf (IgnorePut v) t
insPf _ _ = mzero

(>>>>) :: (MonadPlus m,Monad lensm) => RulePfT m lensm -> RulePfT m lensm -> RulePfT m lensm
(r >>>> s) a = do ViewPf f b <- r a
                  ViewPf g c <- s b
                  return $ ViewPf (CompPut b f g) c

(||||) :: (MonadPlus m,Monad lensm) => RulePfT m lensm-> RulePfT m lensm -> RulePfT m lensm
(r |||| s) x = r x `mplus` s x

tryPf :: (MonadPlus m,Monad lensm) => RulePfT m lensm -> RulePfT m lensm
tryPf r = r |||| nopPf

manyPf :: (MonadPlus m,Monad lensm) => RulePfT m lensm -> RulePfT m lensm
manyPf r = (r >>>> manyPf r) |||| nopPf

many1Pf :: (MonadPlus m,Monad lensm) => RulePfT m lensm -> RulePfT m lensm
many1Pf r = (r >>>> manyPf r)

oncePf :: (MonadPlus m,Monad lensm) => RulePfT m lensm -> RulePfT m lensm
oncePf r a@(getLiteral -> Just _) = r a
oncePf r One = r One
oncePf r (Cut a) = r (Cut a)
oncePf r (Data (Name "@" _) a) = do
	ViewPf f b <- oncePf r a
	return $ ViewPf (CompPut a InnPut f) b
oncePf r a@(isAttEl -> True) = r a
oncePf r (List a) = r (List a) `mplus` (do
	ViewPf f b <- oncePf r a
	return $ ViewPf (MapPut f) (List b))
oncePf r (Prod a b) = r (Prod a b) `mplus` (do
    ViewPf f c <- oncePf r a
    return $ ViewPf (f `ProdPut` IdPut) (Prod c b))
        `mplus` (do
    ViewPf g d <- oncePf r b
    return $ ViewPf (IdPut `ProdPut` g) (Prod a d))
oncePf r (Either a b) = r (Either a b) `mplus` (do
    ViewPf f c <- oncePf r a
    return $ ViewPf (f `SumPut` IdPut) (Either c b))
    `mplus` (do
    ViewPf g d <- oncePf r b
    return $ ViewPf (IdPut `SumPut` g) (Either a d))
oncePf r a = error $ "oncePf undefined for " ++ show a

getVPfAttElM :: Monad lensm => TypeM lensm -> Type a -> Maybe (String,ViewPf lensm a)
--getVPfElM st (Data (Name "@" _) t) = do
--	(n,ViewPf f b) <- getVPfElM st t
--	return (n,ViewPf (CompPut t InnPut f) b)
--getVPfElM st (Data (Name x n) p@(Prod (Data (Name "@" _) as) es)) = return (x,ViewPf (CompPut p InnPut $ InnPut `ProdPut` IdPut) (Prod as es))
--getVPfElM st (Data (Name x n) t) = return (x,ViewPf InnPut t)
getVPfAttElM st (Data (Name x n) t) = do
	ViewPf f t' <- gmapPfT remove t
	return (x,ViewPf (CompPut t InnPut f) t')
  where remove (Data (Name "@" _) a) = return $ ViewPf InnPut a
        remove a = nopPf a
getVPfAttElM st (Tag x t) = Just (x,ViewPf IdPut t)
getVPfAttElM st a = Nothing

getVPfAttEl :: Monad lensm => Type a -> Maybe (String,ViewPf lensm a)
--getVPfEl (Data (Name "@" _) t) = do
--	(n,ViewPf f b) <- getVPfEl t
--	return (n,ViewPf (CompPut t InnPut f) b)
--getVPfEl (Data (Name x n) p@(Prod (Data (Name "@" _) as) es)) = return (x,ViewPf (CompPut p InnPut $ InnPut `ProdPut` IdPut) (Prod as es))
--getVPfEl (Data (Name x n) t) = return (x,ViewPf InnPut t)
getVPfAttEl (Data (Name x n) t) = do
	ViewPf f t' <- gmapPfT remove t
	return (x,ViewPf (CompPut t InnPut f) t')
  where remove (Data (Name "@" _) a) = return $ ViewPf InnPut a
        remove a = nopPf a
getVPfAttEl (Tag x t) = Just (x,ViewPf IdPut t)
getVPfAttEl a = Nothing

ruleToEnvPf :: (MonadPlus m,Monad lensm,Monad rwm) => RulePfT m lensm -> RuleEnvPfT m rwm lensm
ruleToEnvPf r a = do
	ViewPf f b <- r a
	return $ ViewEnvPf (return f) b

gmapPfT :: (MonadPlus m,Monad lensm) => RulePfT m lensm -> RulePfT m lensm
gmapPfT r a = do
	ViewEnvPf f b <- gmapEnvPfT (ruleToEnvPf r) a
	return $ ViewPf (Reader.runReader f Map.empty) b

-- used to iterate over XML sequences (products,eithers,lists)
gmapEnvPfT :: (MonadPlus m,Monad lensm,Monad rwm) => RuleEnvPfT m rwm lensm -> RuleEnvPfT m rwm lensm
gmapEnvPfT r (getLiteral -> Just a) = r a
gmapEnvPfT r One = return $ ViewEnvPf (return IdPut) One
gmapEnvPfT r (Cut a) = return $ ViewEnvPf (return IdPut) (Cut a)
gmapEnvPfT r (Data (Name "@" _) a) = do
	ViewEnvPf f b <- gmapEnvPfT r a
	return $ ViewEnvPf (compMPutPf a (return InnPut) f) b
gmapEnvPfT r a@(isAttEl -> True) = r a
gmapEnvPfT r (Prod a b) = do
	ViewEnvPf f a' <- gmapEnvPfT r a
	ViewEnvPf g b' <- gmapEnvPfT r b
	ViewPf h c <- tryPf removeProdOnePf (Prod a' b')
	return $ ViewEnvPf (compMPutPf (Prod a' b') (f `prodMPutPf` g) (return h)) c
gmapEnvPfT r (Either a b) = do
	ViewEnvPf f a' <- gmapEnvPfT r a
	ViewEnvPf g b' <- gmapEnvPfT r b
	ViewPf h c <- tryPf (removeEitherOnePf |||| removeEitherListOnePf) (Either a' b')
	return $ ViewEnvPf (compMPutPf (Either a' b') (f `sumMPutPf` g) (return h)) c
gmapEnvPfT r (List a) = do
	ViewEnvPf f a' <- gmapEnvPfT r a
	ViewPf h c <- tryPf removeListOnePf (List a')
	return $ ViewEnvPf (compMPutPf (List a') (liftM MapPut f) (return h)) c
gmapEnvPfT r x@(XList xmin xmax xts) = do
	(xts',l) <- gmapEnvPfTXList r $ Set.toList xts
	return $ ViewEnvPf (liftM MapPut l) (XList xmin xmax $ Set.fromList xts')
gmapEnvPfT r a = error $ "gmapPfT undefined for" ++ show a

gmapEnvPfTXList :: (MonadPlus m,Monad rwm,Monad lensm) => RuleEnvPfT m rwm lensm -> [DynType] -> m ([DynType],rwm (Pf (PutlensM lensm Dynamic Dynamic)))
gmapEnvPfTXList r [] = return ([],return IdPut)
gmapEnvPfTXList r (DynT t:ts) = do
	ViewEnvPf f t' <- gmapEnvPfT r t
	(ts',g) <- gmapEnvPfTXList r ts 
	let l = liftM2 (IfSthenelsePut (applyDyn (\a x -> teqBool a t)))
				(compMPutPf t (return $ DynPut t) $ compMPutPf t' f (return $ UndynPut t')) g
	return (DynT t':ts',l)

-- used to iterate over XML sequences (products,eithers,lists), but returning a refinement rather than a lens
refinePfT :: (MonadPlus m,Monad lensm) => RefRulePfT m lensm -> RefRulePfT m lensm
refinePfT r (getLiteral -> Just a) = r a
refinePfT r One = return $ RefPf IdPut One
refinePfT r (Data (Name "@" _) a) = do
	RefPf f b <- refinePfT r a
	return $ RefPf (CompPut a f OutPut) b
refinePfT r a@(isAttEl -> True) = r a
refinePfT r (Prod a b) = do
	RefPf f a' <- refinePfT r a
	RefPf g b' <- refinePfT r b
	return $ RefPf (f `ProdPut` g) (Prod a' b')
refinePfT r (Either a b) = do
	RefPf f a' <- refinePfT r a
	RefPf g b' <- refinePfT r b
	return $ RefPf (f `SumPut` g) (Either a' b')
refinePfT r (List a) = do
	RefPf f a' <- refinePfT r a
	return $ RefPf (MapPut f) (List a')
refinePfT r x@(XList xmin xmax xts) = do
	(xts',l) <- refinePfTXList r $ Set.toList xts
	return $ RefPf (MapPut l) (XList xmin xmax $ Set.fromList xts')
refinePfT r a = error $ "refinePfT undefined for" ++ show a

refinePfTXList :: (MonadPlus m,Monad lensm) => RefRulePfT m lensm -> [DynType] -> m ([DynType],Pf (PutlensM lensm Dynamic Dynamic))
refinePfTXList r [] = return ([],IdPut)
refinePfTXList r (DynT t:ts) = do
	RefPf f t' <- refinePfT r t
	(ts',g) <- refinePfTXList r ts 
	let l = IfVthenelsePut (applyDyn (\a x -> teqBool a t)) (CompPut t' (DynPut t') $ CompPut t f (UndynPut t)) g
	return (DynT t':ts',l)

seqRefPf :: (MonadPlus m,Monad lensm) => RefRulePfT m lensm -> RefRulePfT m lensm -> RefRulePfT m lensm
seqRefPf r s a = do RefPf f b <- r a
                    RefPf g c <- s b
                    return $ RefPf (CompPut b g f) c

untagPf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
untagPf a@(Data n t) = return $ ViewPf InnPut t
untagPf (Tag s t) = nopPf t
untagPf a = error $ "untagPf: " ++ show a

untagRefPf :: (MonadPlus m,Monad lensm) => RefRulePfT m lensm
untagRefPf a@(Data n t) = return $ RefPf OutPut t
untagRefPf (Tag s t) = return (RefPf IdPut t)
untagRefPf a = error $ "untagRefPf: " ++ show a

removeProdOnePf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
removeProdOnePf (Prod One b) = return $ ViewPf AddfstOnePut b
removeProdOnePf (Prod a One) = return $ ViewPf AddsndOnePut a
removeProdOnePf _ = mzero

removeEitherEqPf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
removeEitherEqPf (Either a a') = case teq a a' of
	Just Eq -> return $ ViewPf InjlSPut a
	Nothing -> nopPf (Either a a')
removeEitherEqPf _ = mzero

removeEitherOnePf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
removeEitherOnePf (Either One One) = return $ ViewPf InjlSPut One
removeEitherOnePf _ = mzero

removeEitherListOnePf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
removeEitherListOnePf (Either (List a) One) = return $ ViewPf (CompPut (Either (List a) (List a)) (IdPut `SumPut` UnnilPut) InjlSPut) (List a)
removeEitherListOnePf (Either One (List a)) = return $ ViewPf (CompPut (Either (List a) (List a)) (UnnilPut `SumPut` IdPut) InjlSPut) (List a)
removeEitherListOnePf _ = mzero

removeListListPf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
removeListListPf (List (List a)) = return $ ViewPf ConcatPut (List a)
removeListListPf _ = mzero

removeListEitherOnePf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
removeListEitherOnePf (List (Either a One)) = return $ ViewPf FilterleftPut (List a)
removeListEitherOnePf (List (Either One a)) = return $ ViewPf FilterrightPut (List a)
removeListEitherOnePf _ = mzero

removeListOnePf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
removeListOnePf (List One) = return $ ViewPf ListOneEqPut One
removeListOnePf _ = mzero

gmapPfQ :: (MonadPlus m,Monad lensm,Eq r) => Type r -> r -> Pf (PutlensM lensm (r,r) r) -> RulePfQ m lensm r -> RulePfQ m lensm r
gmapPfQ t zero plus r (getLiteral -> Just a) = r a
gmapPfQ t zero plus r One = return $ IgnorePut zero
gmapPfQ t zero plus r (Cut a) = return $ CompPut One KeepDefPut (IgnorePut zero)
gmapPfQ t zero plus r (Data (Name "@" _) a) = do
	f <- gmapPfQ t zero plus r a
	return $ CompPut a InnPut f
gmapPfQ t zero plus r a@(isAttEl -> True) = r a
gmapPfQ t zero plus r (Prod a b) = do
	f <- gmapPfQ t zero plus r a
	g <- gmapPfQ t zero plus r b
	return $ CompPut (Prod t t) (f `ProdPut` g) plus
gmapPfQ t zero plus r (Either a b) = do
	f <- gmapPfQ t zero plus r a
	g <- gmapPfQ t zero plus r b
	return $ CompPut (Either t t) (f `SumPut` g) InjlSPut
gmapPfQ t zero plus r (List a) = do
	f <- gmapPfQ t zero plus r a
	return $ CompPut (List t) (MapPut f) (UnfoldrsPut plus zero)
gmapPfQ t zero plus r a = error $ "gmapPfQ undefined for" ++ show a
	
gmapPfXListQ :: (MonadPlus m,Monad lensm) => RulePfT m lensm -> RulePfT m lensm
gmapPfXListQ r (getLiteral -> Just a) = r a
gmapPfXListQ r One = r One
gmapPfXListQ r (Data (Name "@" _) a) = do
	ViewPf f b <- gmapPfXListQ r a
	return $ ViewPf (CompPut a InnPut f) b
gmapPfXListQ r a@(isAttEl -> True) = r a
gmapPfXListQ r (Prod a b) = do
	ViewPf f a' <- gmapPfXListQ r a
	ViewPf g b' <- gmapPfXListQ r b
	ViewPf h r <- mergePfQ a' b'
	return $ ViewPf (CompPut (Prod a' b') (f `ProdPut` g) h) r
gmapPfXListQ r (Either a b) = do
	ViewPf f a' <- gmapPfXListQ r a
	ViewPf g b' <- gmapPfXListQ r b
	ViewPf h r <- joinPfQ a' b'
	return $ ViewPf (CompPut (Either a' b') (f `SumPut` g) h) r
gmapPfXListQ r (List a) = do
	ViewPf f a' <- gmapPfXListQ r a
	ViewPf g r <- flattenPfQ 0 Nothing a'
	return $ ViewPf (CompPut (List a') (MapPut f) g) r
gmapPfXListQ r (XList xmin xmax xts) = error "xlists in gmapPfQ"
gmapPfXListQ r a = error $ "gmapPfXListQ undefined for" ++ show a
	
-- different types because we may need to concatenate "different" XLists
mergePfQ :: (Eq r1,Eq r2,MonadPlus m,Monad lensm) => Type r1 -> Type r2 -> m (ViewPf lensm (r1,r2)) --a
mergePfQ (XList xmin xmax xts) (XList ymin ymax yts)
    | Set.null (Set.intersection xts yts) = let p (Dyn t v) = Set.member (DynT t) xts in return $ ViewPf (AppendByPut p) xlist
    | isJust xmax && xmin == fromJust xmax = return $ ViewPf (AppendLeftPut xmin) xlist
    | isJust ymax && ymin == fromJust ymax = return $ ViewPf (AppendRightPut ymin) xlist
    | otherwise = return $ ViewPf (AppendBiasPut xmin ymin xmax ymax) xlist
  where xlist = XList (xmin + ymin) (addMaxs xmax ymax) (Set.union xts yts)	
mergePfQ a b = return $ ViewPf IdPut (Prod a b)

joinPfQ :: (Eq r1,Eq r2,MonadPlus m,Monad lensm) => Type r1 -> Type r2 -> m (ViewPf lensm (Either r1 r2)) --a
joinPfQ (XList xmin xmax xts) (XList ymin ymax yts)
    | Set.null (Set.intersection xts yts) = let p (Dyn t v) = Set.member (DynT t) xts in return $ ViewPf (JoinByPut p) xlist
	| otherwise = return $ ViewPf (JoinBiasPut (geqMaxs xmax ymax)) xlist
  where xlist = XList (min xmin ymin) (if geqMaxs xmax ymax then xmax else ymax) (Set.union xts yts)
joinPfQ a b = return $ ViewPf IdPut (Either a b)

flattenPfQ :: (MonadPlus m,Monad lensm) => Int -> Maybe Int -> Type r -> m (ViewPf lensm [r]) --a
flattenPfQ ymin ymax x@(XList xmin xmax xts)
    | isJust xmax && xmin == fromJust xmax = return $ ViewPf (ConcatPosPut xmin) xlist
	| otherwise = return $ ViewPf (ConcatBiasPut ymin ymax xmin xmax) xlist
  where xlist = XList (ymin * xmin) (multMaxs ymax xmax) xts
flattenPfQ ymin ymax x = error $ "flattenQ " ++ show x

emptyPfQ :: (MonadPlus m,Monad lensm) => RulePfT m lensm --[Dynamic]
emptyPfQ a = return $ ViewPf (CompPut One KeepDefPut UnnilPut) (XList 0 (Just 0) Set.empty)

wrapPfQ :: (MonadPlus m,Monad lensm) => RulePfT m lensm --[Dynamic]
wrapPfQ a = return $ ViewPf (CompPut Any (UndynPut a) $ unwrapPutPf Any) (XList 1 (Just 1) $ Set.singleton $ DynT a)

mkXListPf :: (MonadPlus m,Monad lensm) => RulePfT m lensm -- [Dynamic]
mkXListPf a@(XList _ _ _) = nopPf a
mkXListPf a = gmapPfXListQ keepEls a
    where keepEls One = emptyPfQ One
          keepEls a = wrapPfQ a

xlist2listPf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
xlist2listPf x@(XList _ (Just 0) _) = error $ "path result set is always empty (incorrect path?) " ++ show x
xlist2listPf x@(XList _ _ (Set.toList -> [])) = error $ "path result set is always empty (incorrect path?) " ++ show x
xlist2listPf (XList _ _ (Set.toList -> [DynT t])) = return $ ViewPf (MapPut (DynPut t)) (List t)
xlist2listPf x@(XList _ _ (Set.toList -> ts)) = do
	ViewPf f e <- dyntypes2EitherPf ts
	return $ ViewPf (MapPut f) (List e)

dyntypes2EitherPf :: (MonadPlus m,Monad st) => [DynType] -> m (ViewPf st Dynamic)
dyntypes2EitherPf [DynT t] = return $ ViewPf (DynPut t) t
dyntypes2EitherPf (DynT a:ts) = do
	ViewPf f b <- dyntypes2EitherPf ts
	return $ ViewPf (EitherSPut (\(Dyn t v) -> teqBool t a) (DynPut a) f) (Either a b)

viewPf2view' :: Eq a => Type a -> ViewPf Identity a -> View' a
viewPf2view' a (ViewPf f b) = View' (evalLns Map.empty a b $ Put2Lens f) b

removeViewOnesPf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
removeViewOnesPf = manyPf (oncePf removeProdOnePf)

assocRightPf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
assocRightPf (Prod (Prod a b) c) = return $ ViewPf AssoclPut (Prod a (Prod b c))
assocRightPf _ = mzero

coassocRightPf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
coassocRightPf (Either (Either a b) c) = return $ ViewPf CoassoclPut (Either a (Either b c))
coassocRightPf _ = mzero

distributePf :: (MonadPlus m,Monad lensm) => RulePfT m lensm
distributePf (Prod (Either a b) c) = return $ ViewPf UndistlPut (Either (Prod a c) (Prod b c))
distributePf (Prod a (Either b c)) = return $ ViewPf UndistrPut (Either (Prod a b) (Prod a c))
distributePf a = mzero

distLeftPf :: (MonadPlus m,Monad st) => RulePfT m st
distLeftPf (Prod (Either a b) c) = return $ ViewPf UndistlPut (Either (Prod a c) (Prod b c))
distLeftPf _ = mzero

-- given an arbitrary type, checks whether all children are of the same type and returns it
homogeneousT :: (MonadPlus m,Eq v) => Type v -> m DynType
homogeneousT a = do { xs <- homogeneousT' a; return (list2eithers $ Set.toList xs) }

list2eithers :: [DynType] -> DynType
list2eithers [] = error "list cannot be empty"
list2eithers [x] = x
list2eithers (x:xs) = applyDynT2 (\a b -> DynT (Either a b)) x (list2eithers xs)

homogeneousT' :: (MonadPlus m,Eq v) => Type v -> m (Set DynType)
homogeneousT' (getLiteral -> Just a) = return $ Set.singleton $ DynT a
homogeneousT' One = return Set.empty
homogeneousT' a@(isAttEl -> True) = return $ Set.singleton $ DynT a
homogeneousT' (Prod a b) = do
	m1 <- homogeneousT' a
	m2 <- homogeneousT' b
	return (Set.union m1 m2)
homogeneousT' (Either a b) = do
	m1 <- homogeneousT' a
	m2 <- homogeneousT' b
	return (Set.union m1 m2)
homogeneousT' (List a) = homogeneousT' a

elementEither :: Type a -> Bool
elementEither (getLiteral -> Just a) = True
elementEither (isAttEl -> True) = True
elementEither (Either a b) = elementEither a && elementEither b
elementEither a = False

distributeViewPatterns :: (MonadPlus m,Monad lensm,Eq pats,Eq v2) => Type pats -> Type v2 -> m (RefPf lensm (pats,v2))
distributeViewPatterns (Either pat pats) v = do
	RefPf f a <- distributeViewPatterns pats v
	let x = Either (Prod pat v) (Prod pats v)
	return $ RefPf (CompPut x (IdPut `SumPut` f) DistlPut) (Either (Prod pat v) a)
distributeViewPatterns pat v = return $ RefPf IdPut (Prod pat v)

elemsType :: Eq a => Type a -> Set DynType
elemsType One = Set.empty
elemsType (getLiteral -> Just a) = Set.singleton (DynT a)
elemsType a@(isAttEl -> True) = Set.singleton (DynT a)
elemsType (Prod a b) = elemsType a `Set.union` elemsType b
elemsType (Either a b) = elemsType a `Set.union` elemsType b
elemsType (List a) = elemsType a
elemsType a = error $ "elemsType: " ++ show a

eitherType :: MonadPlus m => [DynType] -> m DynType
eitherType [] = return $ DynT One
eitherType [DynT a] = return $ DynT a
eitherType (DynT a:xs) = do
	DynT b <- eitherType xs
	return $ DynT $ Either a b

--collapsePfT :: (MonadPlus m,Monad lensm,Eq v) => Type v -> RulePfQ m lensm v
--collapsePfT = undefined
--
---- collapses a type whose top-level elements are of the same type into a single value (requiring all values to be equal)
--collapseT :: (MonadPlus m,Monad lensm,Eq v) => Type v -> RuleQ m lensm v
--collapseT v a = gmapQ (Right ()) plus (rule v) a >>= \f -> return (f .< injlPut)
--	where
--	plus = undistsPut
--	     .< ((addsndPut (\e v -> return v) -|-< addsndOnePut) .< injrsPut -|-< (addfstOnePut -|-< addsndOnePut))
--	     .< coassocrPut .< (injlsPut -|-< idPut)
--	rule :: (MonadPlus m,Monad lensm,Eq v) => Type v -> RuleQ m lensm (Either v ())
--	rule v t = case teq t v of { Just Type.Eq -> return uninjlPut; Nothing -> error "collapseT"{-return (keepDefPut t .< uninjrPut)-} }