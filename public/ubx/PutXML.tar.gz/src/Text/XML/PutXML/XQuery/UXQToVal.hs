-- Semantics of uXQ queries
module Text.XML.PutXML.XQuery.UXQToVal where

import Text.XML.PutXML.DTD.Normalize
import Text.XML.PutXML.Update.Patterns
import Text.XML.PutXML.Update.AST
import Text.XML.PutXML.XQuery.UXQ 
import Text.XML.PutXML.Lenses.Lib
import Text.XML.PutXML.DTD.SubType
import Text.XML.PutXML.Lenses.View
import Generics.Putlenses.Putlens
import Text.XML.HaXml.DtdToHaskell.TypeDef as TypeDef hiding (List,String)
import Control.Monad.State (State,MonadState,StateT)
import qualified Control.Monad.State as State
import Control.Monad.Reader (Reader,MonadReader,ReaderT)
import qualified Control.Monad.Reader as Reader
import Text.XML.PutXML.XPath.HXT.XPathDataTypes as XPath hiding (Name(..),Env(..))
import Control.Monad
import Control.Monad.Trans
import Control.Monad.Identity
import Text.XML.PutXML.DTD.Type as Type
import Data.Map (Map(..))
import qualified Data.Map as Map
import Text.XML.HXT.DOM.QualifiedName
import Text.XML.PutXML.Generic.Rewrite
import Data.Set (Set(..))
import qualified Data.Set as Set
import GHC.InOut
import Data.Maybe
import Data.List

import Debug.Trace

data ViewXQ where
	ViewXQ :: Eq b => Reader Env b -> Type b -> ViewXQ

type QueryM m = ReaderT TypeEnv (ReaderT (EnvT,Int,Maybe XVar) m)
-- the integer models a unique number for internally generated variables (like variables under a different namespace)
-- the variable denotes a possibly current root

-- creates a new unique variable from an environment
newVar :: Monad m => (XVar -> QueryM m a) -> QueryM m a
newVar q = do
	(_,i,_) <- lift Reader.ask
	let newvar = "%"++show i
	Reader.mapReaderT (Reader.local (\(envT,i,r) -> (envT,succ i,r))) (q newvar)

--evaluXQWithRoot :: (Eq a,MonadPlus m) => TypeEnv -> XQExpr -> Env -> Type a -> m (a -> Dynamic)
--evaluXQWithRoot tenv expr env a = do
--	Rewrite f b <- uXQ2viewWithRoot tenv expr (Map.map (applyDyn (\t v -> DynT t)) env) a
--	return $ Dyn b . Reader.runReader f env
--
--evaluXQ :: MonadPlus m => TypeEnv -> XQExpr -> Env -> m Dynamic
--evaluXQ tenv expr env = do
--	ViewXQ f b <- uXQ2view tenv expr (Map.map (applyDyn (\t v -> DynT t)) env)
--	return $ Dyn b $ Reader.runReader f env

--uXQ2view :: MonadPlus m => TypeEnv -> XQExpr -> EnvT -> m ViewXQ
--uXQ2view tenv expr envT = Reader.runReaderT (Reader.runReaderT (uXQ2val expr) tenv) (envT,0,Nothing)
--
--uXQ2boolview :: MonadPlus m => TypeEnv -> XQExpr -> EnvT -> m (Reader Env Bool)
--uXQ2boolview tenv expr envT = Reader.runReaderT (Reader.runReaderT (uXQ2bool expr) tenv) (envT,0,Nothing)
--
--uXQ2viewWithRoot :: (Eq a,MonadPlus m) => TypeEnv -> XQExpr -> EnvT -> Type a -> m (Rewrite (Reader Env) a)
--uXQ2viewWithRoot tenv expr envT a = Reader.runReaderT (Reader.runReaderT (uXQ2valWithRoot expr a) tenv) (envT,0,Nothing)
--
--uXQ2boolviewWithRoot :: (Eq a,MonadPlus m) => TypeEnv -> XQExpr -> EnvT -> Type a -> m (Reader Env (a -> Bool))
--uXQ2boolviewWithRoot tenv expr envT a = Reader.runReaderT (Reader.runReaderT (uXQ2boolWithRoot expr a) tenv) (envT,0,Nothing)

uXQ2valWithRoot :: (Eq a,MonadPlus m) => XQExpr -> Type a -> QueryM m (Rewrite (Reader Env) a)
uXQ2valWithRoot expr a = newRootVar $ \root -> snapshotXQR root (uXQ2val expr) a

cpath2valWithRoot :: (Eq a,MonadPlus m) => CPath -> Type a -> QueryM m (Rewrite (Reader Env) a)
cpath2valWithRoot p a = uXQ2valWithRoot (XQPath p) a

uXQ2boolWithRoot :: (Eq a,MonadPlus m) => XQExpr -> Type a -> QueryM m (Reader Env (a -> Bool))
uXQ2boolWithRoot expr a = do { Rewrite f a <- uXQ2valWithRoot expr a; return (liftM2 (.) (return $ boolean a) f) }

runXQ :: MonadPlus m => TypeEnv -> Maybe String -> EnvT -> QueryM m a -> m a
runXQ tenv root envT m = Reader.runReaderT (Reader.runReaderT m tenv) (envT,0,root)

uXQ2val :: MonadPlus m => XQExpr -> QueryM m ViewXQ
uXQ2val XQEmpty = return $ ViewXQ (return ()) One
uXQ2val (XQProd e e') = do
	ViewXQ f a <- uXQ2val e
	ViewXQ f' a' <- uXQ2val e'
	return $ ViewXQ (do { x <- f; x' <- f'; return (x,x') }) (Prod a a')
uXQ2val (XQElem n e) = do 
	ViewXQ f a <- uXQ2val e
	Rewrite g b <- sortAttributes (Type.ReaderT Type.Env Type.Identity) a -- handles attributes
	return $ ViewXQ (do { x <- f; y <- g; return (y x) }) (Tag n b)
uXQ2val (XQAttr n e) = do 
	ViewXQ f a <- uXQ2val e
	lns <- evalsubtype a String -- checks whether the result is a base type
	return $ ViewXQ (liftM (simplecreate lns) f) (Tag (mkAtt n) String)	
--uXQ2val (XQString w) = return $ ViewXQ (return $ Str w) String
--uXQ2val (XQVar x) = lookupXQVar x
uXQ2val (XQLet pat e1 e2) = do
	ViewXQ f a <- uXQ2val e1
	Rewrite g b <- snapshotXQPatR pat (uXQ2val e2) a
	return $ ViewXQ (do { x <- f; y <- g; return (y x) }) b
--uXQ2val (XQBool b) = return $ ViewXQ (return b) Bool
uXQ2val (XQIf c e1 e2) = do
	f <- uXQ2bool c
	ViewXQ g1 b1 <- uXQ2val e1
	ViewXQ g2 b2 <- uXQ2val e2
	let aux = f >>= \y -> if y then liftM Left g1 else liftM Right g2
	return $ ViewXQ aux (Either b1 b2)
uXQ2val (XQBinOp op e e') = uXQBinOp2val op e e'
--uXQ2val (XQChild x) = xqchild x
--uXQ2val (XQAttribute x) = xqattribute x
--uXQ2val (XQDoS x) = xqdos x
--uXQ2val (XQNodeTest e n) = do
--	ViewXQ f a <- uXQ2val e
--	Rewrite g b <- gmapR (uXQNodeTest2generic n) a
--	return $ ViewXQ (do { x <- f; y <- g; return (y x) }) b
uXQ2val (XQFor var e1 e2) = do -- (does not change the root -- from global to local -- to follow the behavior of XQuery)
	ViewXQ f a <- uXQ2val e1
	Rewrite g b <- gmapR (snapshotXQR var (uXQ2val e2)) a
	return $ ViewXQ (do { x <- f; y <- g; return (y x) }) b
uXQ2val (XQPath path) = cpath2val path
--uXQ2val (XQFct name args) = function2val name args

xqchild :: MonadPlus m => String -> QueryM m ViewXQ
xqchild x = do
	ViewXQ f a <- lookupXQVar x -- this is more general than the original uXQ
	Rewrite g b <- (untagR `seqR` gmapR keepElement) a -- we need to find all top-level elements first and then return their children
	return $ ViewXQ (do { x <- f; y <- g; return (y x) }) b	
  where keepElement a@(Data n t) = nopR a									-- keep elements
        keepElement a@(Tag n _) = if isAtt n then delR a else nopR a		-- delete attributes
        keepElement a = nopR a												-- keep text, etc elements

xqattribute :: MonadPlus m => String -> QueryM m ViewXQ
xqattribute x = do
	ViewXQ f a <- lookupXQVar x -- this is more general than the original uXQ
	Rewrite g b <- (untagR `seqR` gmapR keepAttribute) a -- we need to find all top-level elements first and then return their children
	return $ ViewXQ (do { x <- f; y <- g; return (y x) }) b	
  where keepAttribute a@(Tag n t) = if isAtt n then nopR a	else delR a			-- keep attributes
        keepAttribute a = delR a												-- delete otherwise

xqdos :: MonadPlus m => String -> QueryM m ViewXQ
xqdos x = do
	ViewXQ f a <- lookupXQVar x -- this is more general than the original uXQ
	Rewrite g b <- dos a -- we need to find all top-level elements first and then return their children
	return $ ViewXQ (do { x <- f; y <- g; return (y x) }) b

-- assumes that we are already focused on single values
xqnodetest :: MonadPlus m => NodeTest -> String -> QueryM m ViewXQ
xqnodetest n x = do
	ViewXQ f a <- lookupXQVar x -- this is more general than the original uXQ
	Rewrite g b <- uXQNodeTest2generic n a
	return $ ViewXQ (do { x <- f; y <- g; return (y x) }) b

cpath2val :: MonadPlus m => CPath -> QueryM m ViewXQ
cpath2val CPathSelf = getRoot >>= cpath2val . CPathVar
cpath2val CPathChild = getRoot >>= xqchild
cpath2val CPathAttribute = getRoot >>= xqattribute
cpath2val CPathDoS = getRoot >>= xqdos
cpath2val (CPathNodeTest n) = getRoot >>= xqnodetest n
cpath2val (CPathSlash p p') = do -- for x in p return p' (also updating the root for relative paths)
	ViewXQ f a <- cpath2val p
	newRootVar $ \root -> do
		Rewrite g b <- gmapR (snapshotXQR root (cpath2val p')) a
		return $ ViewXQ (do { x <- f; y <- g; return (y x) }) b
cpath2val (CPathFilter expr) = getRoot >>= \root -> uXQ2val $ XQIf expr (XQPath $ CPathVar root) XQEmpty
cpath2val (CPathVar x) = lookupXQVar x
cpath2val (CPathString str) = return $ ViewXQ (return $ Str str) String
cpath2val (CPathBool bool) = return $ ViewXQ (return bool) Bool
cpath2val (CPathSnapshot pat path) = do
	ViewXQ f a <- cpath2val CPathSelf
	Rewrite g b <- snapshotXQPatR pat (cpath2val path) a
	return $ ViewXQ (do { x <- f; y <- g; return (y x) }) b
cpath2val (CPathFct fct args) = function2val fct args

newRootVar :: Monad m => (XVar -> QueryM m a) -> QueryM m a
newRootVar q = newVar $ \var -> setRoot var (q var)

-- the root value is not yet added to the environment, just its variable name
setRoot :: Monad m => XVar -> QueryM m a -> QueryM m a
setRoot var q = Reader.mapReaderT (Reader.local (\(env,i,root) -> (env,i,Just var))) q
	
getRoot :: Monad m => QueryM m XVar
getRoot = lift Reader.ask >>= \(_,_,root) -> maybe (fail "no root variable defined, try a relative path") return root

-- evaluates the descendantorself axis over an arbitrary type, generating a list of sums type
dos :: (Monad m,Monad rwm,Eq a) => Type a -> m (Rewrite rwm a)
dos a = case subtreeElsType a of DynT e -> return $ Rewrite (return (map (applyDyn (\a x -> injectdos e a x)) . doslist a)) (List e)

-- injects dynamic values into a sum type
injectdos :: Type eith -> Type a -> a -> eith
injectdos e a x = fromJust (injectdos' e a x)

injectdos' :: MonadPlus m => Type eith -> Type a -> a -> m eith
injectdos' (Either t1 t2) a x = liftM Left (injectdos' t1 a x) `mplus` liftM Right (injectdos' t2 a x)
injectdos' t a x = case teq t a of { Just Type.Eq -> return x; otherwise -> fail "could not inject type (this shouldn't happen!)" }

-- evaluates the descendantorself axis over an arbitrary value
doslist :: Type a -> a -> [Dynamic]
doslist One () = []
doslist (getLiteral -> Just a) x = []
doslist (getAtt -> Just a) x = []
doslist a@(Tag l t) x = Dyn a x : doslist t x
doslist a@(Data l t) x = Dyn a x : doslist t (out x)
doslist (Prod a b) (x,y) = doslist a x ++ doslist b y
doslist (Either a b) e = either (doslist a) (doslist b) e
doslist (List a) l = concatMap (doslist a) l

-- changes the environment based on the current value
snapshotXQR :: MonadPlus m => XVar -> QueryM m ViewXQ -> RRuleT (QueryM m) (Reader Env)
snapshotXQR var e a = Reader.mapReaderT (Reader.local (\(envT,i,r) -> (Map.insert var (DynT a) envT,i,r))) $ do 
	ViewXQ f b <- e
	let aux = Reader.reader $ \env x -> Reader.runReader f (Map.insert var (Dyn a x) env)
	return $ Rewrite aux b
	
-- changes the environment based on the current value (using a pattern)
snapshotXQPatR :: MonadPlus m => Pat -> QueryM m ViewXQ -> RRuleT (QueryM m) (Reader Env)
snapshotXQPatR pat e a = do
	View' f p <- evalmatchsource pat a -- the pattern type must be a view of the current value
	patvars <- listPatVariables Type.Identity p -- get the pattern variables
	let modifyEnvT envT = foldr (\(View g (Tag (varName -> n) t)) m -> Map.insert n (DynT t) m) envT patvars -- update the pattern variable types
	    modifyEnv env x = foldr (\(View g (Tag (varName -> n) t)) m -> Map.insert n (Dyn t $ (get' g . get f) x) m) env patvars -- update the pattern variable values
	Reader.mapReaderT (Reader.local (\(envT,i,r) -> (modifyEnvT envT,i,r))) $ do
		ViewXQ f b <- e
		let aux = Reader.reader $ \env x -> Reader.runReader f (modifyEnv env x)
		return $ Rewrite aux b

-- | Filter only nodes that satisfy a particular node test and deletes the remaining
-- assumes that we are already focused on elements
uXQNodeTest2generic :: (MonadPlus m,Monad rwm) => NodeTest -> RRuleT m rwm
uXQNodeTest2generic (NameTest n) = rewriteName
	where rewriteName a | localPart n == "*" || getXName a == localPart n = nopR a
	      rewriteName a = delR a
uXQNodeTest2generic (PI s) = fail "processing units not supported"
uXQNodeTest2generic (TypeTest XPNode) = nodeR
    where nodeR :: (MonadPlus m,Monad rwm) => RRuleT m rwm
          nodeR a@(Tag (isAtt -> True) _) = delR a
          nodeR a = nopR a
uXQNodeTest2generic (TypeTest XPCommentNode) = fail "comment nodes unsupported"
uXQNodeTest2generic (TypeTest XPPINode) = fail "pi nodes unsupported"
uXQNodeTest2generic (TypeTest XPTextNode) = rewriteText
    where rewriteText :: (MonadPlus m,Monad rwm) => RRuleT m rwm
          rewriteText a = if isLiteral a then nopR a else delR a
uXQNodeTest2generic (TypeTest XPString) = \a -> return $ Rewrite (return $ Str . toXPathString a) String

lookupXQVar :: MonadPlus m => XVar -> QueryM m ViewXQ
lookupXQVar x = do
	(envT,_,_) <- lift Reader.ask
	case Map.lookup x envT of
		Just (DynT t) -> return $ ViewXQ (lookupEnv t x) t
		Nothing -> error $ "variable " ++ show x ++ " not found in " ++ show envT
  where lookupEnv t x = do { env <- Reader.ask; return $ unDyn t ((Map.!) env x) }

uXQBinOp2val :: MonadPlus m => XPath.Op -> XQExpr -> XQExpr -> QueryM m ViewXQ
uXQBinOp2val XPath.Or = uXQBoolOp2bool (||)
uXQBinOp2val XPath.And = uXQBoolOp2bool (&&)
uXQBinOp2val XPath.Eq = uXQCompOp2bool (\a b x y -> tcompare EQ a b x y)
uXQBinOp2val XPath.NEq = uXQCompOp2bool (\a b x y -> tcompare LT a b x y || tcompare GT a b x y)
uXQBinOp2val XPath.Less = uXQCompOp2bool (\a b x y -> tcompare LT a b x y)
uXQBinOp2val XPath.Greater = uXQCompOp2bool (\a b x y -> tcompare GT a b x y)
uXQBinOp2val XPath.LessEq = uXQCompOp2bool (\a b x y -> tcompare LT a b x y || tcompare EQ a b x y)
uXQBinOp2val XPath.GreaterEq = uXQCompOp2bool (\a b x y -> tcompare GT a b x y || tcompare EQ a b x y)
uXQBinOp2val XPath.Plus = uXQFloatOp2val (\x y -> x+y)
uXQBinOp2val XPath.Minus = uXQFloatOp2val (\x y -> x-y)
uXQBinOp2val XPath.Div = uXQIntOp2val div
uXQBinOp2val XPath.Mod = uXQIntOp2val mod
uXQBinOp2val XPath.Mult = uXQFloatOp2val (\x y -> x*y)
uXQBinOp2val XPath.Unary = fail "unary unsupported"
uXQBinOp2val XPath.Union = \e e' -> do
	ViewXQ f a <- uXQ2val e
	ViewXQ g b <- uXQ2val e'
	return $ ViewXQ (do { x <- f; y <- g; return (x,y) }) (Prod a b)

uXQBoolOp2bool :: MonadPlus m => (Bool -> Bool -> Bool) -> XQExpr -> XQExpr -> QueryM m ViewXQ
uXQBoolOp2bool op e e' = do
	f <- uXQ2bool e
	g <- uXQ2bool e'
	return $ ViewXQ (do { x <- f; y <- g; return (x `op` y) }) Bool

uXQCompOp2bool :: MonadPlus m => (forall a b. (Eq a,Eq b) => Type a -> Type b -> a -> b -> Bool) -> XQExpr -> XQExpr -> QueryM m ViewXQ
uXQCompOp2bool op e e' = do
	ViewXQ f a <- uXQ2val e
	ViewXQ g b <- uXQ2val e'
	return $ ViewXQ (do { x <- f; y <- g; return (op a b x y) }) Bool

uXQFloatOp2val :: MonadPlus m => (Float -> Float -> Float) -> XQExpr -> XQExpr -> QueryM m ViewXQ
uXQFloatOp2val op e e' = do
	f <- uXQ2float e
	g <- uXQ2float e'
	return $ ViewXQ (do { x <- f; y <- g; return (Str $ show (x `op` y)) }) String

uXQIntOp2val :: MonadPlus m => (Int -> Int -> Int) -> XQExpr -> XQExpr -> QueryM m ViewXQ
uXQIntOp2val op e e' = do
	f <- uXQ2int e
	g <- uXQ2int e'
	return $ ViewXQ (do { x <- f; y <- g; return (Str $ show (x `op` y)) }) String

uXQ2bool :: MonadPlus m => XQExpr -> QueryM m (Reader Env Bool)
uXQ2bool e = do
	ViewXQ f Bool <- cpath2val (CPathFct "boolean" [e])
	return f

uXQ2float :: MonadPlus m => XQExpr -> QueryM m (Reader Env Float)
uXQ2float e = do
	ViewXQ f a <- uXQ2val e
	lns <- evalsubtype a String
	return $ liftM (castToFloat String . simplecreate lns) f

uXQ2int :: MonadPlus m => XQExpr -> QueryM m (Reader Env Int)
uXQ2int e = do
	ViewXQ f a <- uXQ2val e
	lns <- evalsubtype a String
	return $ liftM (castToInt String . simplecreate lns) f

function2val :: MonadPlus m => String -> [XQExpr] -> QueryM m ViewXQ
function2val "boolean" [e] = do
	ViewXQ f a <- uXQ2val e
	return $ ViewXQ (do { x <- f; return $ boolean a x }) Bool

boolean :: Type a -> a -> Bool
boolean String = not . null . unStr
boolean Int = (/=0)
boolean Type.Float = (/=0)
boolean Bool = id
boolean One = const False
boolean (Cut a) = const False
boolean (List a) = not . null
boolean (Prod a b) = \(x,y) -> boolean a x || boolean b y
boolean (Either a b) = either (boolean a) (boolean b)
boolean a@(getAtt -> Just (Tag n t)) = boolean t
boolean a@(getEl -> Just t) = const True
boolean a = error $ "boolean: " ++ show a

-- Compares the atomic types in two regular tree types (the condition only needs to hold for any pair of values)
tcompare :: Ordering -> Type a -> Type b -> a -> b -> Bool
tcompare is Int Int x y = compare x y == is
tcompare is Type.Float Type.Float x y = compare x y == is
tcompare is String String x y = compare x y == is
tcompare is Bool Bool x y = compare x y == is
tcompare is (Tag (isAtt -> True) a) b x y = tcompare is a b x y -- in XPath we can write @id='1'
tcompare is a (Tag (isAtt -> True) b) x y = tcompare is a b x y -- in XPath we can write '1'=@id
tcompare is (List a) b xs y = or $ map (\x -> tcompare is a b x y) xs
tcompare is a (List b) x ys = or $ map (\y -> tcompare is a b x y) ys
tcompare is (Prod a b) c (x,y) z = tcompare is a c x z || tcompare is b c y z
tcompare is a (Prod b c) x (y,z) = tcompare is a b x y || tcompare is a c x z
tcompare is (Either a b) c (Left x) z = tcompare is a c x z
tcompare is (Either a b) c (Right y) z = tcompare is b c y z
tcompare is a (Either b c) x (Left y) = tcompare is a b x y
tcompare is a (Either b c) x (Right z) = tcompare is a c x z
tcompare is a b x y = case teq a b of
	Just Type.Eq -> gcomp a x y == is
	Nothing -> False --trace ("s: "++show a ++"\nv: "++show b ++"\nvs: "++gshow a x ++"\nvv: "++gshow b y) False
--tcompare is a b x y = False -- trace ("failed casting " ++ show a ++ " " ++ show b) False

-- splits an arbitrary type into a product with attributes to the left and elements to the right
splitAtts :: (MonadPlus m,Monad lensm) => TypeM lensm -> RRuleT m lensm
splitAtts lensm a = do
	Rewrite f atts <- gmapR keepAtt a
	Rewrite g els <- gmapR keepNonAtt a
	return $ Rewrite (liftM2 split f g) (Prod atts els)
  where keepAtt (getAtt -> Just att) = nopR att
        keepAtt a = delR a
        keepNonAtt (getAtt -> Just att) = delR att
        keepNonAtt a = nopR a
        split f g x = (f x,g x)

-- gets all attributes in an arbitrary type (possibly repeated)
attlist :: Type a -> a -> [(String,Dynamic)]
attlist One () = []
--attlist (getLiteral -> Just a) x = []
attlist (getAtt -> Just (Tag (attName -> n) t)) x = [(n,Dyn t x)]
--attlist (getEl -> Just a) x = []
attlist (Prod a b) (x,y) = attlist a x ++ attlist b y
attlist (Either a b) e = either (attlist a) (attlist b) e
attlist (List a) l = concatMap (attlist a) l

-- given a list of attribute values and an arbitrary type of attributes (atomic types are One or atts), tries to embed the attributes into the type
populateAttType :: [(String,Dynamic)] -> Type a -> a
populateAttType atts a = fromJust $ do { (v,[]) <- State.runStateT (populateAttType' a) atts; return v }

populateAttType' :: Type a -> StateT [(String,Dynamic)] Maybe a
populateAttType' One = return ()
populateAttType' (getAtt -> Just (Tag (attName -> n) t)) = State.get >>= \atts -> case lookup n atts of
	Nothing -> mzero
	Just d@(Dyn t' v) -> case teq t t' of
		Just Type.Eq -> State.put (delete (n,d) atts) >> return v
		Nothing -> error "attributes must have the same type"
populateAttType' (Prod a b) = do { x <- populateAttType' a; y <- populateAttType' b; return (x,y) }
populateAttType' (Either a b) = liftM (Left) (populateAttType' a) `mplus` liftM Right (populateAttType' b)
populateAttType' (List a) = liftM (:[]) (populateAttType' a)

sortAttributes :: (MonadPlus m,Monad lensm) => TypeM lensm -> RRuleT m lensm
sortAttributes lensm a = do
	Rewrite f (Prod as es) <- splitAtts lensm a
	Rewrite g asprod <- atts as
	return $ Rewrite (liftM2 (.) (liftM2 (><) g (return id)) f) (Prod asprod es)

-- collect all attributes of a type into a product of sorted optional attributes (fails for repeated elements!)
atts :: (MonadPlus m,Monad rwm) => RRuleT m rwm
atts a = case attributesType a of DynT p -> return $ Rewrite (return $ injectatts p . norepeatedatts) p
  where norepeatedatts = sortBy (\(x,_) (y,_) -> if x == y then error "repeated att names" else compare x y) . attlist a

-- tries to fit a list of attribute values into a product of optional attributes
injectatts :: Type prod -> [(String,Dynamic)] -> prod
injectatts One [] = ()
injectatts One l = error $ "injectatts: impossible non-empty atts "++show l
injectatts (Prod a b) l = let (x,l1) = injectatt a l
                              y = injectatts b l1
                          in (x,y)
injectatts a l = let (x,l1) = injectatt a l in if null l1 then x else error ("injectatts: impossible")

injectatt :: Type att -> [(String,Dynamic)] -> (att,[(String,Dynamic)])
injectatt (Either One (Tag (attName -> n) t)) xs = case lookup n xs of
	Just dyn@(Dyn a v) -> case teq a t of { Just Type.Eq -> (Right v,delete (n,dyn) xs) ; Nothing -> error $ "injectatt: impossible " ++ show a ++" "++ show t }
	Nothing -> (Left (),xs)
injectatt (Tag (attName -> n) t) xs = case lookup n xs of
	Just dyn@(Dyn a v) -> case teq a t of { Just Type.Eq -> (v,delete (n,dyn) xs) ; Nothing -> error $ "injectatt: impossible " ++ show a ++" "++ show t }
	Nothing -> error "injectatt: non-optional att not found"

-- creates a sorted product of attributes (set as optional) found in a type
attributesType :: Eq a => Type a -> DynType
attributesType a = aux (Map.toList s)
	where s = attributeSet a
	      aux [] = DynT One
	      aux [(n,(True,DynT t))] = DynT $ Either One (Tag (mkAtt n) t)
	      aux [(n,(False,DynT t))] = DynT $ Tag (mkAtt n) t
	      aux ((n,(True,DynT t)):xs) = applyDynT (\b -> DynT $ Prod (Either One (Tag (mkAtt n) t)) b) (aux xs)
	      aux ((n,(False,DynT t)):xs) = applyDynT (\b -> DynT $ Prod (Tag (mkAtt n) t) b) (aux xs)

-- computes a list of attributes in an arbitrary type: boolean for optionals..
attributeSet :: Eq a => Type a -> Map String (Bool,DynType)
attributeSet One = Map.empty
attributeSet (getAtt -> Just (Tag (attName -> n) t)) = Map.singleton n (False,DynT t)
attributeSet (Either a b) = optionalAtts (attributeSet a) `Map.union` optionalAtts (attributeSet b)
attributeSet (Prod a b) = attributeSet a `Map.union` attributeSet b
attributeSet (List a) = optionalAtts (attributeSet a)

optionalAtts :: Map String (Bool,DynType) -> Map String (Bool,DynType)
optionalAtts = Map.map (\(b,t) -> (True,t))

--attributeNames :: Eq a => Type a -> Set String
--attributeNames One = Set.empty
--attributeNames (getLiteral -> Just a) = Set.empty
--attributeNames (getAtt -> Just (Tag (attName -> n) t)) = Set.singleton s
--attributeNames (getEl -> Just a) = Set.empty
--attributeNames (Prod a b) = attributeNames a `Set.union` attributeNames b
--attributeNames (List a) = attributeNames a
--attributeNames (Either a b) = attributeNames a `Set.union` attributeNames b

-- converts an arbitrary type into a product of (possibly optional) attributes
--attributesProduct :: (MonadPlus m,Monad lensm) => TypeM lensm -> RefRulePfT m lensm
--attributesProduct (getAtt -> Just a) = RefPf IdPut a
--attributesProduct One = RefPf IdPut a
--attributesProduct (Either a b) = do
--	RefPf f x <- attributesProduct a
--	RefPf f' x' <- optionalAtts x
--	RefPf g y <- attributesProduct b
--	RefPf g' y' <- optionalAtts y
--	return $ ((CompPut (Prod x' y') (AddsndPut (\s v -> return $ emptyOptionalAtts y')) $ CompPut x' f' f) `EitherLPut` (CompPut (Prod x' y') (AddfstPut (\s v -> return $ emptyOptionalAtts x')) $ CompPut y' g' g)) (Prod x' y')
--attributesProduct (List a) = do
--	RefPf f x <- attributesProduct a

--emptyOptionalAtts :: Type a -> a
--emptyOptionalAtts (Either One (getAtt -> Just a)) = Left ()
--emptyOptionalAtts (Prod a b) = (emptyOptionalAtts a,emptyOptionalAtts b)
--
--optionalAtts :: (MonadPlus m,Monad lensm) => TypeM lensm -> RefRulePfT m lensm
--optionalAtts (Either One (getAtt -> Just a)) = RefPf IdPut (Either One a)
--optionalAtts (Prod a b) = do
--	RefPf f x <- optionalAtts a
--	RefPf g y <- optionalAtts b
--	return $ RefPf (f `ProdPut` g) (Prod x y)
--
--sortAtts :: TypeM lensm -> RefRulePfT m lensm
--sortAtts a = 
--
---- splits variables into a product with the wanted variables to the left and the right, possibly duplicated
---- shall signal an error if a variable is not used in either side (currently I pass all variables, and do not return an error)
--splitViewAtts :: (MonadPlus m,Monad lensm) => TypeM lensm -> Set XVar -> Set XVar -> RefRulePfT m lensm
--splitViewAtts lensm l r v = do
--	ViewPf f a <- manyPf (oncePf (removeProdOnePf |||| assocRightPf)) v
--	RefPf g b <- splitViewAtts' l r a
--	RefPf h v' <- remOnes lensm b
--	f' <- inv (PutlnsM lensm v a) f
--	return $ RefPf (CompPut b h $ CompPut a g f') v'
--  where
--	remOnes :: (MonadPlus m,Monad lensm) => TypeM lensm -> RefRulePfT m lensm
--	remOnes lensm (Prod x y) = do
--		ViewPf f x' <- removeViewOnesPf x
--		ViewPf g y' <- removeViewOnesPf y
--		f' <- inv (PutlnsM lensm x x') f
--		g' <- inv (PutlnsM lensm y y') g
--		return $ RefPf (f' `ProdPut` g') (Prod x' y')
--	remOnes _ a = return $ RefPf IdPut a
--
---- assumes right-associated products with no units (besides an empty view of course)
--splitViewAtts' :: (MonadPlus m,Monad lensm) => Set XVar -> Set XVar -> RefRulePfT m lensm
--splitViewAtts' l r v@(Tag (attName -> n) t) = aux l r v
--  where
--	aux :: (MonadPlus m,Monad lensm) => Set XVar -> Set XVar -> RefRulePfT m lensm
--	aux l r v@(Tag (attName -> n) t)
--		| Set.member n l && Set.member n r = return $ RefPf DupPut (Prod v v)
--		| Set.member n l = return $ RefPf AddsndOnePut (Prod v One)
--		| Set.member n r = return $ RefPf AddfstOnePut (Prod One v)
--		| otherwise = error $ "view variable $" ++ n ++ " not used, breaks injectivity"
--splitViewAtts' l r (Prod v@(Tag (attName -> n) t) vs) = do
--	RefPf f p <- splitViewAtts' (Set.delete n l) (Set.delete n r) vs
--	aux l r v f p
--  where
--	aux :: (Eq vs,MonadPlus m,Monad lensm) => Set XVar -> Set XVar -> Type v -> Pf (PutlensM lensm vs' vs) -> Type vs' -> m (RefPf lensm (v,vs))
--	aux l r v@(Tag (attName -> n) t) f (Prod xs ys)
--		| Set.member n l && Set.member n r = return $ RefPf (CompPut (Prod (Prod v v) (Prod xs ys)) DistpPut (DupPut `ProdPut` f)) (Prod (Prod v xs) (Prod v ys))
--	    | Set.member n l = return $ RefPf (CompPut (Prod v (Prod xs ys)) AssoclPut (IdPut `ProdPut` f)) (Prod (Prod v xs) ys)
--		| Set.member n r = return $ RefPf (CompPut (Prod v (Prod xs ys)) SubrPut (IdPut `ProdPut` f)) (Prod xs (Prod v ys))
--		| otherwise = error $ "view variable $" ++ n ++ " not used, breaks injectivity"
--splitViewAtts' l r One = return $ RefPf AddsndOnePut (Prod One One)
--splitViewAtts' l r v = error $ "splitView " ++ show v
