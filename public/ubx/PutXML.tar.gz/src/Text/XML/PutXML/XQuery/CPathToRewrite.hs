module Text.XML.PutXML.XQuery.CPathToRewrite where
	
import Text.XML.PutXML.DTD.Type as Type
import Text.XML.PutXML.Lenses.Pf
import Text.XML.PutXML.XQuery.UXQ
import Text.XML.PutXML.Lenses.View
import Text.XML.PutXML.Lenses.ViewPf
import Control.Monad.Reader (Reader(..),ReaderT(..),MonadReader(..))
import qualified Control.Monad.Reader as Reader
import Control.Monad.State (State(..),StateT(..),MonadState(..))
import Text.XML.PutXML.XPath.HXT.XPathDataTypes as XPath hiding (Name(..),Env(..))
import qualified Control.Monad.State as State
import Control.Monad
import Control.Monad.Trans
import Text.XML.HXT.DOM.QualifiedName
import Text.XML.PutXML.XQuery.UXQToVal
import Text.XML.PutXML.Generic.Rewrite
import Data.Map (Map(..))
import qualified Data.Map as Map
import Text.XML.PutXML.Lenses.Lib
import {-# SOURCE #-} Text.XML.PutXML.Update.CoreToLenses
import Text.XML.PutXML.Update.Patterns
import Generics.Putlenses.Language
import Generics.Putlenses.Putlens as Putlens
import Generics.Putlenses.Examples.Examples
import Text.XML.PutXML.Update.CoreAST

import Debug.Trace

cpath2rewrite :: MonadPlus m => CPath -> RRuleT (RewriteM m) (Reader Env) -> RRuleT (RewriteM m) (Reader Env)
cpath2rewrite CPathSelf rule = rule
cpath2rewrite CPathChild rule = child2rewrite rule
cpath2rewrite CPathAttribute rule = attribute2rewrite rule
cpath2rewrite CPathDoS rule = error "dos unsupported as a rewrite rule"
cpath2rewrite (CPathNodeTest nt) rule = nodetest2rewrite nt rule
cpath2rewrite (CPathSlash p1 p2) rule = cpath2rewrite p1 (cpath2rewrite p2 rule)
cpath2rewrite (CPathFilter cond) rule = if2rewrite cond rule nopR
cpath2rewrite (CPathVar var) rule = constant2rewrite rule
cpath2rewrite (CPathString str) rule = constant2rewrite rule
cpath2rewrite (CPathBool b) rule = constant2rewrite rule
cpath2rewrite (CPathSnapshot pat path) rule = case2rewrite (XQPath path) [(pat,rule)]
cpath2rewrite (CPathFct n args) rule = error "functions unsupported as rewrite rules"

child2rewrite :: MonadPlus m => RRuleT (RewriteM m) (Reader Env) -> RRuleT (RewriteM m) (Reader Env)
child2rewrite rule = gmapR (childrenR (gmapR (rewriteChild rule)))
  where rewriteChild :: MonadPlus m => RRuleT (RewriteM m) (Reader Env) -> RRuleT (RewriteM m) (Reader Env)
        rewriteChild rule a@(Data n t) = rule a
        rewriteChild rule a@(Tag n _) = if isAtt n then nopR a else rule a
        rewriteChild rule a = nopR a

attribute2rewrite :: MonadPlus m => RRuleT (RewriteM m) (Reader Env) -> RRuleT (RewriteM m) (Reader Env)
attribute2rewrite rule = gmapR (childrenR (gmapR (rewriteAtt rule)))
  where rewriteAtt :: MonadPlus m => RRuleT (RewriteM m) (Reader Env) -> RRuleT (RewriteM m) (Reader Env)
        rewriteAtt rule a@(Tag n _) = if isAtt n then rule a else nopR a
        rewriteAtt rule a = nopR a

-- assumes that we are already focused on elements
nodetest2rewrite :: MonadPlus m => NodeTest -> RRuleT (RewriteM m) (Reader Env) -> RRuleT (RewriteM m) (Reader Env)
nodetest2rewrite (NameTest n) r = rewriteName r
	where rewriteName r a | localPart n == "*" || getXName a == localPart n = r a
	                      | otherwise = nopR a
nodetest2rewrite (PI s) r = error "processing units not supported"
nodetest2rewrite (TypeTest XPNode) r = nodeR r
    where nodeR :: MonadPlus m => RRuleT (RewriteM m) (Reader Env) -> RRuleT (RewriteM m) (Reader Env)
          nodeR r a@(Tag (isAtt -> True) _) = nopR a
          nodeR r a = r a
nodetest2rewrite (TypeTest XPCommentNode) r = error "comment nodes unsupported"
nodetest2rewrite (TypeTest XPPINode) r = error "pi nodes unsupported"
nodetest2rewrite (TypeTest XPTextNode) r = rewriteText r
    where rewriteText :: MonadPlus m => RRuleT (RewriteM m) (Reader Env) -> RRuleT (RewriteM m) (Reader Env)
          rewriteText r a = if isLiteral a then r a else nopR a
nodetest2rewrite (TypeTest XPString) r = nopR -- treated as constant

constant2rewrite :: MonadPlus m => RRuleT (RewriteM m) (Reader Env) -> RRuleT (RewriteM m) (Reader Env)
constant2rewrite rule = error "constant rewrite" --nopR

addRewriteEnvVar :: (Eq a,MonadPlus m) => String -> Type a -> (Env -> s -> a) -> RewriteM m (Env -> s -> Env)
addRewriteEnvVar n a f = do
	(evars) <- lift State.get
	lift $ State.put (Map.insert n (DynT a) evars)
	return $ \env e -> Map.insert n (Dyn a $ f env e) env

--addRewriteTEnvVar :: (Eq a,MonadPlus m) => String -> Type a -> RewriteM m ()
--addRewriteTEnvVar n a = do
--	evars <- lift Reader.ask
--	lift $ State.put (Map.insert n (DynT a) evars)

addRewriteEnvVars :: (MonadPlus m,Monad st) => [View st vars] -> (Env -> s -> vars) -> RewriteM m (Env -> s -> Env)
addRewriteEnvVars [] f = return $ \env x -> env
addRewriteEnvVars (View g (Tag (varName -> n) x):xs) f = do
	fenv <- addRewriteEnvVar n x (\env x -> get' g $ f env x)
	fenvs <- addRewriteEnvVars xs f
	return $ \env x -> fenvs (fenv env x) x

runRewriteM :: MonadPlus m => RewriteM m a -> UpdateM m s a
runRewriteM = State.mapStateT $ Reader.mapReaderT (\m -> State.get >>= \((evars,svars),_) -> lift $ State.evalStateT m (evars))

runRewriteQuery :: MonadPlus m => QueryM m a -> RewriteM m a
runRewriteQuery m = lift (lift State.get) >>= \(envT) -> runQueryWith m Nothing envT

-- keeps a copy of the current type environment and restores it at the end (to make a monad state behave like a monad reader)
freezeRewriteTEnv :: Monad m => RewriteM m a -> RewriteM m a
freezeRewriteTEnv m = do
	env <- lift State.get
	lns <- m
	lift $ State.put env
	return lns
