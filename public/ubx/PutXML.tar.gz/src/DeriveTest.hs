module DeriveTest where

import Text.XML.PutXML.BiPutXML.Derive 
import Text.XML.PutXML.XQuery.XQueryPretty
import Text.XML.PutXML.Update.Parser
import Text.XML.PutXML.Update.AST
import Text.XML.PutXML.XPath.HXT.XPathDataTypes ( Expr )
import Text.PrettyPrint.HughesPJ
import qualified Data.Map  as Map
import Text.XML.PutXML.XQuery.XQueryAST (XQuery)
import qualified Text.XML.PutXML.XQuery.XQueryAST  as XQ
import Text.XML.PutXML.XPath.HXT.XPathDataTypes ( Expr )
import qualified Text.XML.PutXML.XPath.HXT.XPathDataTypes as XPath hiding (Env)

e1 = UExprElement "title" [] [UExprPath ( XPath.VarExpr ("", "vtitle") )]
e2 = UExprPath ( XPath.VarExpr ("", "vtitle") )


main = do
--  t2 <- deriveUExpr e2 Map.empty (XQ.XExprStr "$book/title")
--  putStrLn $ render $ prXQuery $  head $ Map.elems t2
--  t1 <- deriveUExpr e1 Map.empty (XQ.XExprStr "$book")
--  putStrLn $ render $ prXQuery $  head $ Map.elems t1  
  program <- readFile "test/bookstore/get.upd"  
  let ast = parse ( scan program)
--  putStrLn $ show ast
--  putStrLn "--------------------------------------------------------------------------------------------------------------"
  xq <- deriveProgram ast
  putStrLn $ render $ prXQuery xq 
