module Main where

import UI.PutXML.Menu
import Text.XML.HaXml.Parse
import Text.XML.HaXml.DtdToHaskell.TypeDef hiding (ppTypeDef,mangle)
import Text.XML.PutXML.DTD.HaXml.TypeDef
import Text.XML.HaXml.DtdToHaskell.Convert
import Text.XML.HaXml.Types hiding (Name)
import Data.List
import GHC.Generics
import GHC.InOut
import Control.Monad
import Unsafe.Coerce
import Text.PrettyPrint.HughesPJ
import Text.XML.HaXml.DtdToHaskell.Instance
import Data.Maybe
import Text.XML.HaXml.Namespaces
import System.IO
import System.Environment
import System.Console.GetOpt
import System.Exit
import UI.PutXML.GenHaskell

import Text.XML.PutXML.Update.Parser
import Text.ParserCombinators.Parsec
import Text.XML.PutXML.Update.Token
import Text.XML.PutXML.Update.AST 

-----------------------------------------------------------------------------

parseProgram :: String -> IO Program
parseProgram filename = do
	file <- readFile filename
	let tokenLst = parse t "" file
	case tokenLst of
		Left err -> error "token err"
		Right tokLst -> return $ nParser (tokLst)

main = menu

menu :: IO ()
menu = do
	argv <- getArgs
	opts <- liftM defaultHsOpts $ parseOptions startOpt options argv
	menuTypes opts

menuTypes :: Options -> IO ()
menuTypes opts = do
	maybeSourceDTD opts
	maybeViewDTD opts
	maybeBiFluXType opts

maybeBiFluXType :: Options -> IO ()
maybeBiFluXType opts = do
	case optBiFluXFile opts of
		Just _ -> biFluXType opts
		Nothing -> return ()

biFluXType :: Options -> IO ()
biFluXType opts = do
	prog <- run "Input BiFluX program missing" $ optBiFluXFile opts
	hs <- run "" $ optBiFluXHsFile opts
	ast <- parseProgram prog
	generateHaskellBX ast hs

maybeSourceDTD :: Options -> IO ()
maybeSourceDTD opts = do
	case optSourceDtdFile opts of
		Just _ -> sourceDTD opts
		Nothing -> return ()

sourceDTD :: Options -> IO ()
sourceDTD opts = do
	sdtd <- run "Source DTD missing" $ optSourceDtdFile opts
	shs <- run "" $ optSourceHsFile opts
	generateHaskellDTD sdtd shs

maybeViewDTD :: Options -> IO ()
maybeViewDTD opts = do
	case optViewDtdFile opts of
		Just _ -> viewDTD opts
		Nothing -> return ()

viewDTD :: Options -> IO ()
viewDTD opts = do
	vdtd <- run "View DTD missing" $ optViewDtdFile opts
	vhs <- run "" $ optViewHsFile opts
	generateHaskellDTD vdtd vhs
	

-- * Command line options

-- | Record type to hold all program options.
data Options = Options
	{
		  optSourceDtdFile	:: Maybe FilePath
		, optViewDtdFile :: Maybe FilePath
		, optSourceHsFile :: Maybe FilePath
		, optViewHsFile :: Maybe FilePath
		, optBiFluXFile :: Maybe FilePath
		, optBiFluXHsFile :: Maybe FilePath
	}

-- | Default options.
startOpt :: Options
startOpt = Options
	{ optSourceDtdFile		= Nothing
	, optViewDtdFile		= Nothing
	, optSourceHsFile       = Nothing
	, optViewHsFile         = Nothing
	, optBiFluXFile         = Nothing
	, optBiFluXHsFile       = Nothing
	}

defaultHsOpts :: Options -> Options
defaultHsOpts = defaultSourceHsOpts . defaultViewHsOpts . defaultBiFluXHsOpts

defaultSourceHsOpts :: Options -> Options
defaultSourceHsOpts opts = if isNothing (optSourceHsFile opts)
	then maybe opts (\x -> opts { optSourceHsFile = Just (mangle (trim x) ++".hs") }) (optSourceDtdFile opts)
	else opts

defaultViewHsOpts :: Options -> Options
defaultViewHsOpts opts = if isNothing (optViewHsFile opts)
	then maybe opts (\x -> opts { optViewHsFile = Just (mangle (trim x) ++".hs") }) (optViewDtdFile opts)
	else opts

defaultBiFluXHsOpts :: Options -> Options
defaultBiFluXHsOpts opts = if isNothing (optBiFluXHsFile opts)
	then maybe opts (\x -> opts { optBiFluXHsFile = Just (mangle (trim x) ++".hs") }) (optBiFluXFile opts)
	else opts

-- | Description of all available program options.
options :: Opts Options
options =
   [ Option "h" ["help"]
        (NoArg (\opt -> exitHelp options))
        "Show usage info"
   , Option "" ["sdtd"]
        (ReqArg (\arg opt -> return opt { optSourceDtdFile = Just arg }) "FILE")
        "Source DTD File"
   , Option "" ["vdtd"]
        (ReqArg (\arg opt -> return opt { optViewDtdFile = Just arg }) "FILE")
        "View DTD File"
   , Option "" ["shs"]
        (ReqArg (\arg opt -> return opt { optSourceHsFile = Just arg }) "FILE")
        "Generated Haskell File with the representation of the source DTD"
   , Option "" ["vhs"]
        (ReqArg (\arg opt -> return opt { optViewHsFile = Just arg }) "FILE")
        "Generated Haskell File with the representation of the view DTD"
   , Option "" ["bx"]
        (ReqArg (\arg opt -> return opt { optBiFluXFile = Just arg }) "FILE")
        "Argument BiFluX program"
   , Option "" ["bxhs"]
        (ReqArg (\arg opt -> return opt { optBiFluXHsFile = Just arg }) "FILE")
        "Generated Haskell File with the representation of the type declarations in a BiFluX program"
   ]

