module UI.PutXML.LensMenu where

import System.IO
import System.Environment
import System.Console.GetOpt
import UI.PutXML.Menu
import Control.Monad
import Generics.Putlenses.Putlens
import Text.XML.PutXML.DTD.Type
import Text.XML.PutXML.Update.AST
import Text.XML.PutXML.Update.UpdateToCore
import Text.XML.PutXML.Update.CoreToLenses
import Text.XML.HaXml.DtdToHaskell.TypeDef hiding (ppTypeDef,mangle,List,Any,String)
import Text.XML.HaXml.ShowXmlLazy
import Text.XML.HaXml.Namespaces
import Text.XML.HaXml.DtdToHaskell.Convert
import Text.XML.HaXml.XmlContent hiding (List,String)

data Options = Options
	{
		  optInputSourceFile	:: Maybe FilePath
		, optInputTargetFile    :: Maybe FilePath
		, optOutputFile	        :: Maybe FilePath
		, optDirection          :: Bool
	}

startOpt :: Options
startOpt = Options
	{ optInputSourceFile	= Nothing
	, optInputTargetFile	= Nothing
	, optOutputFile		= Nothing
	, optDirection		= False
	}

options :: Opts Options
options =
   [ Option "h" ["help"]
        (NoArg (\opt -> exitHelp options))
        "Show usage info"
   , Option "s" ["source"]
        (ReqArg (\arg opt -> return opt { optInputSourceFile = Just arg }) "FILE")
        "Input XML Source File"
   , Option "t" ["target"]
        (ReqArg (\arg opt -> return opt { optInputTargetFile = Just arg }) "FILE")
        "Input XML Target File"
   , Option "o" ["output"]
        (ReqArg (\arg opt -> return opt { optOutputFile = Just arg }) "FILE")
        "Output XML File (default: stdout)"
   , Option "f" ["forward"]
        (NoArg (\opt -> return opt { optDirection = True }))
        "Run the bidirectional transformation in the forward direction (requires an source file)"
   , Option "b" ["backward"]
	(NoArg (\opt -> return opt { optDirection = False }))
	"Run the bidirectional transformation in the backward direction (requires a source file and a modified target file)"
   ]

generateLens :: (Eq a,Eq b,MonadPlus m) => Type a -> Type b -> EnvT -> Program -> m (Lens a b)
generateLens s v tenv ast = do
	cast <- program2core tenv ast
	lns <- evalcprogram cast tenv s v
	return lns

lensmenu :: (XmlContent a,XmlContent b,Eq a,Eq b) => Type a -> Type b -> EnvT -> Program -> IO ()
lensmenu s v tenv ast = do
	argv <- getArgs
	opts <- parseOptions startOpt options argv
	lns <- generateLens s v tenv ast
	if optDirection opts
		then forward opts s v lns
		else backward opts s v lns

readTypedXml :: XmlContent a => Type a -> FilePath -> IO a
readTypedXml t file = fReadXml file

forward :: (XmlContent a,XmlContent b,Eq a,Eq b) => Options -> Type a -> Type b -> Lens a b -> IO ()
forward opts s v lns = do
	putStrLn "Running forward transformation..."
	-- parse XML Source File
	srcFilePath <- run "input XML source file missing" $ optInputSourceFile opts
	-- translate XML source into an Haskell value
	src <- readTypedXml s srcFilePath
	-- run forward transformation
	let tgt = get lns src
	-- print output XML target
	out <- maybe (return stdout) (\f -> openFile f WriteMode) (optOutputFile opts)
	hPutStrLn out $ showXml False tgt
	hClose out

backward :: (XmlContent a,XmlContent b,Eq a,Eq b) => Options -> Type a -> Type b -> Lens a b -> IO ()
backward opts s v lns = do
	putStrLn "Running backward transformation..."
	-- parse XML Source File
	srcFilePath <- run "input XML source file missing" $ optInputSourceFile opts
	-- translate XML source into an Haskell value
	src <- readTypedXml s srcFilePath
	-- parse XML Target File
	tgtFilePath' <- run "input XML target file missing" $ optInputTargetFile opts
	-- translate XML target into an Haskell value
	tgt' <- readTypedXml v tgtFilePath'
	-- run backward transformation
	let src' = simpleput lns src tgt'
	-- print output XML target
	out <- maybe (return stdout) (\f -> openFile f WriteMode) (optOutputFile opts)
	hPutStrLn out $ showXml False src'
	hClose out
