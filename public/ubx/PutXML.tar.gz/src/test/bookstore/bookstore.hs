{-# LANGUAGE DeriveGeneric #-}
module Bookstore where

import Text.XML.HaXml.XmlContent hiding (List1)
import Text.XML.HaXml.Types
import Text.XML.PutXML.DTD.TypeDef
import Text.XML.PutXML.DTD.Type
import Text.XML.HaXml.DtdToHaskell.TypeDef (Name(..))
import GHC.Generics


newtype Bookstore = Bookstore [Book] 		deriving (Eq,Show,Generic)
data Book = Book Title Author Year Price
          deriving (Eq,Show,Generic)
newtype Title = Title String 		deriving (Eq,Show,Generic)
newtype Author = Author String 		deriving (Eq,Show,Generic)
newtype Year = Year String 		deriving (Eq,Show,Generic)
newtype Price = Price String 		deriving (Eq,Show,Generic)
instance HTypeable Bookstore where
    toHType x = Defined "bookstore" [] []
instance XmlContent Bookstore where
    toContents (Bookstore a) =
        [CElem (Elem (N "bookstore") [] (concatMap toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["bookstore"]
        ; interior e $ return (Bookstore) `apply` many parseContents
        } `adjustErr` ("in <bookstore>, "++)
instance HTypeable Book where
    toHType x = Defined "book" [] []
instance XmlContent Book where
    toContents (Book a b c d) =
        [CElem (Elem (N "book") [] (toContents a ++ toContents b ++
                                    toContents c ++ toContents d)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["book"]
        ; interior e $ return (Book) `apply` parseContents
                       `apply` parseContents `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <book>, "++)
instance HTypeable Title where
    toHType x = Defined "title" [] []
instance XmlContent Title where
    toContents (Title a) =
        [CElem (Elem (N "title") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["title"]
        ; interior e $ return (Title) `apply` (text `onFail` return "")
        } `adjustErr` ("in <title>, "++)
instance HTypeable Author where
    toHType x = Defined "author" [] []
instance XmlContent Author where
    toContents (Author a) =
        [CElem (Elem (N "author") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["author"]
        ; interior e $ return (Author) `apply` (text `onFail` return "")
        } `adjustErr` ("in <author>, "++)
instance HTypeable Year where
    toHType x = Defined "year" [] []
instance XmlContent Year where
    toContents (Year a) =
        [CElem (Elem (N "year") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["year"]
        ; interior e $ return (Year) `apply` (text `onFail` return "")
        } `adjustErr` ("in <year>, "++)
instance HTypeable Price where
    toHType x = Defined "price" [] []
instance XmlContent Price where
    toContents (Price a) =
        [CElem (Elem (N "price") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["price"]
        ; interior e $ return (Price) `apply` (text `onFail` return "")
        } `adjustErr` ("in <price>, "++)
instance Typeable Bookstore where
    typeof = Data (Name "bookstore" "Bookstore") typeof
instance Typeable Book where
    typeof = Data (Name "book" "Book") typeof
instance Typeable Title where
    typeof = Data (Name "title" "Title") typeof
instance Typeable Author where
    typeof = Data (Name "author" "Author") typeof
instance Typeable Year where
    typeof = Data (Name "year" "Year") typeof
instance Typeable Price where
    typeof = Data (Name "price" "Price") typeof
