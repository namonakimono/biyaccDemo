{-# LANGUAGE DeriveGeneric #-}
module News where

import Text.XML.HaXml.XmlContent hiding (List1)
import Text.XML.HaXml.Types
import Text.XML.PutXML.DTD.HaXml.TypeDef
import Text.XML.PutXML.DTD.Type
import Text.XML.HaXml.DtdToHaskell.TypeDef (Name(..))
import GHC.Generics


newtype NEWSPAPER = NEWSPAPER (List1 ARTICLE) 		deriving (Eq,Show,Generic)
data ARTICLE = ARTICLE ARTICLE_Attrs HEADLINE BYLINE LEAD BODY
                       NOTES
             deriving (Eq,Show,Generic)
data ARTICLE_Attrs = ARTICLE_Attrs
    { aRTICLEAUTHOR :: String
    , aRTICLEEDITOR :: (Mb String)
    , aRTICLEDATE :: (Mb String)
    , aRTICLEEDITION :: (Mb ARTICLE_EDITION)
    } deriving (Eq,Show,Generic)
data ARTICLE_EDITION = ARTICLE_EDITION_one  |  ARTICLE_EDITION_two
                     deriving (Eq,Show,Generic)
newtype HEADLINE = HEADLINE String 		deriving (Eq,Show,Generic)
newtype BYLINE = BYLINE String 		deriving (Eq,Show,Generic)
newtype LEAD = LEAD String 		deriving (Eq,Show,Generic)
newtype BODY = BODY String 		deriving (Eq,Show,Generic)
newtype NOTES = NOTES String 		deriving (Eq,Show,Generic)
instance HTypeable NEWSPAPER where
    toHType x = Defined "NEWSPAPER" [] []
instance XmlContent NEWSPAPER where
    toContents (NEWSPAPER a) =
        [CElem (Elem (N "NEWSPAPER") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["NEWSPAPER"]
        ; interior e $ return (NEWSPAPER) `apply` parseContents
        } `adjustErr` ("in <NEWSPAPER>, "++)
instance HTypeable ARTICLE where
    toHType x = Defined "ARTICLE" [] []
instance XmlContent ARTICLE where
    toContents (ARTICLE as a b c d e) =
        [CElem (Elem (N "ARTICLE") (toAttrs as) (toContents a ++
                                                 toContents b ++ toContents c ++ toContents d ++
                                                 toContents e)) ()]
    parseContents = do
        { e@(Elem _ as _) <- element ["ARTICLE"]
        ; interior e $ return (ARTICLE (fromAttrs as))
                       `apply` parseContents `apply` parseContents `apply` parseContents
                       `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <ARTICLE>, "++)
instance XmlAttributes ARTICLE_Attrs where
    fromAttrs as =
        ARTICLE_Attrs
          { aRTICLEAUTHOR = definiteA fromAttrToStr "ARTICLE" "AUTHOR" as
          , aRTICLEEDITOR = possibleMbA fromAttrToStr "EDITOR" as
          , aRTICLEDATE = possibleMbA fromAttrToStr "DATE" as
          , aRTICLEEDITION = possibleMbA fromAttrToTyp "EDITION" as
          }
    toAttrs v = catMaybes 
        [ toAttrFrStr "AUTHOR" (aRTICLEAUTHOR v)
        , mbToAttr toAttrFrStr "EDITOR" (aRTICLEEDITOR v)
        , mbToAttr toAttrFrStr "DATE" (aRTICLEDATE v)
        , mbToAttr toAttrFrTyp "EDITION" (aRTICLEEDITION v)
        ]
instance XmlAttrType ARTICLE_EDITION where
    fromAttrToTyp n (N n',v)
        | n==n'     = translate (attr2str v)
        | otherwise = Nothing
      where translate "one" = Just ARTICLE_EDITION_one
            translate "two" = Just ARTICLE_EDITION_two
            translate _ = Nothing
    toAttrFrTyp n ARTICLE_EDITION_one = Just (N n, str2attr "one")
    toAttrFrTyp n ARTICLE_EDITION_two = Just (N n, str2attr "two")
instance HTypeable HEADLINE where
    toHType x = Defined "HEADLINE" [] []
instance XmlContent HEADLINE where
    toContents (HEADLINE a) =
        [CElem (Elem (N "HEADLINE") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["HEADLINE"]
        ; interior e $ return (HEADLINE) `apply` (text `onFail` return "")
        } `adjustErr` ("in <HEADLINE>, "++)
instance HTypeable BYLINE where
    toHType x = Defined "BYLINE" [] []
instance XmlContent BYLINE where
    toContents (BYLINE a) =
        [CElem (Elem (N "BYLINE") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["BYLINE"]
        ; interior e $ return (BYLINE) `apply` (text `onFail` return "")
        } `adjustErr` ("in <BYLINE>, "++)
instance HTypeable LEAD where
    toHType x = Defined "LEAD" [] []
instance XmlContent LEAD where
    toContents (LEAD a) =
        [CElem (Elem (N "LEAD") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["LEAD"]
        ; interior e $ return (LEAD) `apply` (text `onFail` return "")
        } `adjustErr` ("in <LEAD>, "++)
instance HTypeable BODY where
    toHType x = Defined "BODY" [] []
instance XmlContent BODY where
    toContents (BODY a) =
        [CElem (Elem (N "BODY") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["BODY"]
        ; interior e $ return (BODY) `apply` (text `onFail` return "")
        } `adjustErr` ("in <BODY>, "++)
instance HTypeable NOTES where
    toHType x = Defined "NOTES" [] []
instance XmlContent NOTES where
    toContents (NOTES a) =
        [CElem (Elem (N "NOTES") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["NOTES"]
        ; interior e $ return (NOTES) `apply` (text `onFail` return "")
        } `adjustErr` ("in <NOTES>, "++)
instance Typeable NEWSPAPER where
    typeof = Data (Name "NEWSPAPER" "NEWSPAPER") typeof
instance Typeable ARTICLE where
    typeof = Data (Name "ARTICLE" "ARTICLE") typeof
instance Typeable ARTICLE_Attrs where
    typeof = Data (Name "@" "ARTICLE_Attrs") (Prod (Prod (Tag "@AUTHOR" typeof) (Tag "@EDITOR" typeof)) (Prod (Tag "@DATE" typeof) (Tag "@EDITION" typeof)))
instance Typeable ARTICLE_EDITION where
    typeof = Data (Name "EDITION" "ARTICLE_EDITION") typeof
instance Typeable HEADLINE where
    typeof = Data (Name "HEADLINE" "HEADLINE") typeof
instance Typeable BYLINE where
    typeof = Data (Name "BYLINE" "BYLINE") typeof
instance Typeable LEAD where
    typeof = Data (Name "LEAD" "LEAD") typeof
instance Typeable BODY where
    typeof = Data (Name "BODY" "BODY") typeof
instance Typeable NOTES where
    typeof = Data (Name "NOTES" "NOTES") typeof
