{-# LANGUAGE DeriveGeneric, GADTs #-}

module Test where

import Text.XML.PutXML.DTD.TypeDecl
import Text.XML.PutXML.XQuery.UXQToVal
import Text.XML.HaXml.ShowXmlLazy
import Text.XML.PutXML.Update.Patterns
import UI.PutXML.Menu
import Text.XML.HaXml.Parse
import Generics.Putlenses.Putlens
import Text.XML.HaXml.DtdToHaskell.TypeDef hiding (ppTypeDef,mangle,List,Any,String)
import Text.XML.PutXML.DTD.HaXml.TypeDef
import Text.XML.HaXml.DtdToHaskell.Convert
import Text.XML.HaXml.Types hiding (Name)
import Data.List
import GHC.Generics
import GHC.InOut
import Control.Monad
import Unsafe.Coerce
import Text.PrettyPrint.HughesPJ hiding (Str)
import Text.XML.HaXml.DtdToHaskell.Instance
import System.IO
import Data.Maybe
import Text.XML.HaXml.Namespaces
import System.Directory
import System.Process
import Text.XML.PutXML.XPath.XPathToLenses
import Text.XML.PutXML.XPath.XPathToFunction
import Text.XML.PutXML.XPath.XPathToGeneric
import UI.PutXML.GenHaskell
import Text.XML.PutXML.Lenses.Lib as Lib
import qualified Data.Map as Map
import Text.XML.PutXML.DTD.Type as Type
import Generics.Putlenses.Examples.Examples
import Text.XML.PutXML.Lenses.Default
import Generics.Putlenses.Language
import Text.XML.PutXML.DTD.SubType
import Text.XML.PutXML.Lenses.View as View
import Text.XML.PutXML.Lenses.Pf
import Text.XML.PutXML.Update.UpdateToLenses
import Text.XML.PutXML.Update.AST
import Text.XML.PutXML.Update.Parser hiding (FIRST,LAST)
import Text.XML.HaXml.XmlContent hiding (List,String)
import qualified Text.XML.PutXML.XPath.HXT.XPathDataTypes as XPath
import Control.Monad.Reader (Reader(..),MonadReader(..),ReaderT(..))
import qualified Control.Monad.Reader as Reader
import Control.Monad.State (State,MonadState,StateT)
import qualified Control.Monad.State as ST
import Control.Monad.Identity
import Control.Monad.Trans.Maybe
import Text.XML.PutXML.DTD.Normalize
import Control.Monad.Trans

import Debug.Trace

import qualified Code
import qualified Model
import qualified DCode
import qualified DModel
import qualified TCode
import qualified TModel

import qualified Bookstore
import qualified Books
import Data.Set (Set(..))
import qualified Data.Set as Set
import qualified People
import qualified Fromtokyo
import qualified Section
import qualified Sec
import qualified Netscape
import qualified Xbel
import qualified Addrbook
import qualified Index


import Unsafe.Coerce

testL1 :: IO ()
testL1 = do
	let a = Prod (Either Int (Cut Int)) (List $ Either Int (Cut Int))
	View lns b <- normalizeT Type.Identity a
	case teq b (List Int) of
		Just Eq -> do
			let s = (Right 1,[Right 3,Left 2,Right 4])
			let v = [5,6] :: [Int]
			print $ simpleput (put2lens lns) s v


testL :: IO ()
testL = do
	let lns = (keepsndDefPut String .< phiPut (> 0)) .\/< (keepsndDefPut String .< phiPut (\x -> x < 3))
	print $ simpleput (put2lens lns) (1,Str "abc") (Right (-1))

testN :: IO ()
testN = do
	let x = Prod (List Int) $ Prod Int $ List Int
	View f y <- normalizeT Type.Identity x
	print y

testS' :: IO ()
testS' = ST.evalStateT testS ([],Map.empty)
testS :: StateT Prevs IO ()
testS = do
	let s = List Int
	let v = List (Prod Int Int)
	lns <- subtypeputNormWithDecls Type.Identity s v
	lns' <- evalUpdPutlnsM Type.Identity v s lns
--	lift $ print $ get (put2lens lns') $ [1,2]
	lift $ print $ simplecreate (put2lens lns') [1,2]


tC = do
	v' <- (fReadXml "Test/constructor/v.xml"):: IO Model.Initials
	putStrLn "##### modified view #####"
	putStrLn $ show v'
	s <- (fReadXml "Test/constructor/s.xml"):: IO Code.Mainclass
        putStrLn "##### original source #####"
	putStrLn $ show s
		
	program <- readFile "Test/constructor/uC.upd"  
	let ast = parse ( scan program)
	putStrLn $ show ast

	let tenv = (Map.mapKeys ("s:"++) Code.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Model.typeEnv)
	lns <- program2lens ast tenv (typeof :: Type Code.Mainclass) (typeof :: Type Model.Initials )
	let v = get lns s
	putStrLn "##### original view #####"
   	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'




td = do
	s <- (fReadXml "Test/delta/s.xml"):: IO DCode.Code
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/delta/v.xml"):: IO DModel.Deltas
	putStrLn "##### modified view #####"
	putStrLn $ show v'

	program <- readFile "Test/delta/uDelta.upd"  
	let ast = parse ( scan program)
	putStrLn $ show ast


	let tenv = (Map.mapKeys ("s:"++) DCode.typeEnv) `Map.union` (Map.mapKeys ("v:"++) DModel.typeEnv)
	lns <- program2lens ast tenv (typeof :: Type DCode.Code) (typeof :: Type DModel.Deltas )
	let v = get lns s
	putStrLn "##### original view #####"
        --	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'


tt = do
	s <- (fReadXml "Test/observation/s.xml"):: IO TCode.Reths
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/observation/v.xml"):: IO TModel.Observs
	putStrLn "##### modified view #####"
	putStrLn $ show v'

	program <- readFile "Test/observation/uObservation.upd"  
	let ast = parse ( scan program)
	putStrLn $ show ast

	let tenv = (Map.mapKeys ("s:"++) TCode.typeEnv) `Map.union` (Map.mapKeys ("v:"++) TModel.typeEnv)
	lns <- program2lens ast tenv (typeof :: Type TCode.Reths) (typeof :: Type TModel.Observs )
	let v = get lns s
	putStrLn "##### original view #####"
        --	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'


testAddrbook = do
	s <- (fReadXml "Test/addrbook/s.xml"):: IO Addrbook.Addrbook
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/addrbook/v.xml"):: IO Index.Addrbook
	putStrLn "##### modified view #####"
	putStrLn $ show v'
		
	program <- readFile "Test/addrbook/addrbook.upd"  
	let ast = parse ( scan program)
	putStrLn $ show ast
	
	let tenv = (Map.mapKeys ("s:"++) Addrbook.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Index.typeEnv)
	lns <- program2lens ast tenv (typeof :: Type Addrbook.Addrbook) (typeof :: Type Index.Addrbook)
	let v = get lns s
	putStrLn "##### original view #####"
	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'

testBookstore = do
	s <- (fReadXml "Test/bookstore/s.xml"):: IO Bookstore.Bookstore
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/bookstore/v.xml"):: IO Books.Books
	putStrLn "##### modified view #####"
	putStrLn $ show v'
		
	program <- readFile "Test/bookstore/bookstore.upd"  
	let ast = parse ( scan program)
	putStrLn $ show ast
	
	let tenv = (Map.mapKeys ("s:"++) Bookstore.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Books.typeEnv)
	lns <- program2lens ast tenv (typeof :: Type Bookstore.Bookstore) (typeof :: Type Books.Books)
	let v = get lns s
	putStrLn "##### original view #####"
	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'

testPeople = do
	s <- (fReadXml "Test/people/s.xml"):: IO People.People
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/people/v.xml"):: IO Fromtokyo.Fromtokyo
	putStrLn "##### modified view #####"
	putStrLn $ showXml False v'
		
	program <- readFile "Test/people/people.upd"  
	let ast = parse ( scan program)
	putStrLn $ show ast
	
	let tenv = (Map.mapKeys ("s:"++) People.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Fromtokyo.typeEnv)
	lns <- program2lens ast tenv (typeof :: Type People.People) (typeof :: Type Fromtokyo.Fromtokyo)
	let v = get lns s
	putStrLn "##### original view #####"
	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'

testPeople2 = do
	s <- (fReadXml "Test/people/s.xml"):: IO People.People
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/people/v.xml"):: IO Fromtokyo.Fromtokyo
	putStrLn "##### modified view #####"
	putStrLn $ showXml False v'
		
	program <- readFile "Test/people/people2.upd"  
	let ast = parse ( scan program)
	putStrLn $ show ast
	
	let tenv = (Map.mapKeys ("s:"++) People.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Fromtokyo.typeEnv)
	lns <- program2lens ast tenv (typeof :: Type People.People) (typeof :: Type Fromtokyo.Fromtokyo)
	let v = get lns s
	putStrLn "##### original view #####"
	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'

testSections = do
	s <- (fReadXml "Test/nestedsections/s.xml"):: IO Section.Sections
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/nestedsections/v.xml"):: IO Sec.Secs
	putStrLn "##### modified view #####"
	putStrLn $ show v'
		
	program <- readFile "Test/nestedsections/sections.upd"  
	let ast = parse (scan program)
	putStrLn $ show ast
	
	let tenv = (Map.mapKeys ("s:"++) Section.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Sec.typeEnv)
	lns <- program2lens ast tenv (typeof :: Type Section.Sections) (typeof :: Type Sec.Secs)
	let v = get lns s
	putStrLn "##### original view #####"
	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'

testSections2 = do
	s <- (fReadXml "Test/nestedsections/s.xml"):: IO Section.Sections
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/nestedsections/v.xml"):: IO Sec.Secs
	putStrLn "##### modified view #####"
	putStrLn $ show v'
		
	program <- readFile "Test/nestedsections/sections2.upd"  
	let ast = parse (scan program)
	putStrLn $ show ast
	
	let tenv = (Map.mapKeys ("s:"++) Section.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Sec.typeEnv)
	lns <- program2lens ast tenv (typeof :: Type Section.Sections) (typeof :: Type Sec.Secs)
	let v = get lns s
	putStrLn "##### original view #####"
	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'

bookmarkTypes = do
	program <- readFile "Test/bookmark/bookmark.upd"  
	let (Program _ _ _ decls) = parse ( scan program)
	    tdecls = typeDecls decls
	    modnames = Map.mapKeys (\n -> ("s",n)) Netscape.typeEnv `Map.union` Map.mapKeys (\n -> ("v",n)) Xbel.typeEnv
	putStrLn $ render $ mkDeclsTypeEnv modnames tdecls

-- generated by bookmarkTypes
bookmarkNc = (List (Either (Data (Name "dt" "Dt") typeof :: Type Netscape.Dt) (Data (Name "dd" "Dd") typeof :: Type Netscape.Dd)))
bookmarkXc = (List (Either (Data (Name "bookmark" "Bookmark") typeof :: Type Xbel.Bookmark) (Data (Name "folder" "Folder") typeof :: Type Xbel.Folder)))
bookmarkTypeEnv = Map.insert "Nc" (DynT bookmarkNc) $ Map.insert "Xc" (DynT bookmarkXc) $ Map.empty

testBookmark = do
	s <- (fReadXml "Test/bookmark/netscape.xml"):: IO Netscape.Html
	putStrLn "##### original source #####"
	putStrLn $ show s
	v' <- (fReadXml "Test/bookmark/xbel.xml"):: IO Xbel.Xbel
	putStrLn "##### modified view #####"
	putStrLn $ show v'
		
	program <- readFile "Test/bookmark/bookmark.upd"  
	let ast = parse (scan program)
	putStrLn $ show ast
	
	let tenv = (Map.mapKeys ("s:"++) Netscape.typeEnv) `Map.union` (Map.mapKeys ("v:"++) Xbel.typeEnv) `Map.union` bookmarkTypeEnv
	lns <- program2lens ast tenv (typeof :: Type Netscape.Html) (typeof :: Type Xbel.Xbel)
--	let v = get lns s
--	putStrLn "##### original view #####"
--	putStrLn $ show v
	putStrLn "##### modified source #####"
	let s' = simpleput lns s v'
	putStrLn $ showXml False s'


testsub = do
	let x = Tag "dt" (Prod One (Tag "a" (Prod (Tag "@href" String) String)))
	    y = (Either ((Data (Name "dd" "Dd") typeof) :: Type Netscape.Dd) ((Data (Name "dt" "Dt") typeof) :: Type Netscape.Dt))
--	let s = Data (Name "dt" "Dt") $ Data (Name "a" "A") $ typeof :: Type (F Netscape.A)
--	    v = Tag "dt" $ Data (Name "a" "A") $ typeof :: Type (F Netscape.A)
	pf <- subtype x y
	putStrLn $ render $ pprintPfWithDecls (LnsM Type.Identity y x) pf

ssub = do
	let s = (List (Tag "el" String))
	    v = (Prod One One)
	pf <- subtype v s
--	pf <- subtypeputWithDecls
--	lns <- evalsubtype v s
	putStrLn $ render $ pprintPfWithDecls (LnsM Type.Identity s v) pf
--	print $ simplecreate lns ((),())
--	print $ get lns ["q"]

--listifyT :: (MonadPlus m,Monad lensm,Eq x) => Type x -> RuleQ m lensm [x]

--testGeneric = do
--	let Right path = parseXPath "title"
--	Rewrite' g s' <- xpath2generic path (singleInsertionRule True String (const "qweasd")) Map.empty (typeof :: Type Section.Subsection)
--	putStrLn $ show s'
--	putStrLn $ gshow s' (g $ Section.Subsection (Section.Title "") (Right ()))
	
--singleInsertionRule :: (Eq b,MonadPlus m) => Bool -> Type b -> (Env -> b) -> RRuleT m	
--xpath2generic :: (Eq a,MonadPlus m) => Expr -> RRuleT m -> Env -> Type a -> m (Rewrite' a)	

--testToString' = do
--	let lns = (initMb (uncastStringMaybePut :: PutlensM (MaybeT Identity) Int Int String))
--	putStrLn $ show $ runIdentity $ quickcreateM lns "1"
--
--testToString = do
--	let lns = ((toXPathStringPut (Prod Int Bool)))
--	putStrLn $ show $ runIdentity $ runMaybeT $ quickcreateM lns "1 True"

--testReplace = do
--	lns <- ST.evalStateT prog (Map.empty,(Map.empty,[],Map.empty))
--	let x = simpleput (put2lensWith Map.empty lns) (Addrbook.Person (Addrbook.Name "hugo") (Addrbook.Email "1",[Addrbook.Email "2"]) (Addrbook.Tel "12345")) (Addrbook.Email "default")
--	putStrLn $ show x
--	return ()
--  where
--	Right email1 = parseXPath "email[1]"
--	s = typeof :: Type Addrbook.Person
--	v = Tag "$email" $ typeof :: Type Addrbook.Email
--	prog = singleReplace2lens [] Nothing email1 (UExprPath $ XPath.VarExpr ("","email")) s v
--	
--testReplace2 = do
--	lns <- ST.evalStateT prog (Map.empty,(Map.empty,[],Map.empty))
--	let x = simpleput (put2lensWith Map.empty lns) (Addrbook.Person (Addrbook.Name "") (Addrbook.Email "1",[Addrbook.Email "2"]) (Addrbook.Tel "12345")) (Addrbook.Name "hugo")
--	putStrLn $ show x
--	return ()
--  where
--	Right namePath = parseXPath "name"
--	s = typeof :: Type Addrbook.Person
--	v = Tag "$name" $ typeof :: Type Addrbook.Name
--	prog = singleReplace2lens [] Nothing namePath (UExprPath $ XPath.VarExpr ("","name")) s v
--	
--testReplace3 = do
--	lns <- ST.evalStateT prog (Map.empty,(Map.empty,[],Map.empty))
--	let x = simpleput (put2lensWith Map.empty lns) (People.Person (People.Name "hugo") (People.City "Tokyo")) ()
--	putStrLn $ show x
--	return ()
--  where
--	Right cityPath = parseXPath "city"
--	s = typeof :: Type People.Person
--	v = One
--	prog = pluralReplace2lens [] Nothing cityPath (UExprPath $ XPath.LiteralExpr "Kyoto") s v

--pathex4 :: IO ()
--pathex4 = do
--	let Right path = parseXPath "$source/sections/section/subsection[title/text() = $subsec/@title/text()]"
--	    x = Section.Sections []
--	View' f b <- xpath2lens path (Map.insert "source" (Dyn (Tag "#sroot" $ typeof :: Type Section.Sections) x) $ Map.singleton "subsec" (Dyn typeof $ Sec.Subsec undefined ())) Int
--	putStrLn $ show b
--	Eq <- teq b (List $ List Char)
--	let s = put (put2lensNoGetPut $ f .< mapPut (withS (pntPut (\env e -> "Kyoto"))) .< listOneEqPut) (People.Person (People.Name "hugo") (People.City "Tokyo")) ()
--	putStrLn $ show s

--pathex2 :: IO ()
--pathex2 = do
--	let Right path = parseXPath "name"
--	View' f b <- xpath2lens path Map.empty (typeof :: Type Addrbook.Person)
--	putStrLn $ show b
--	Eq <- teq b (typeof :: Type Addrbook.Name)
--	let s = simpleput f (Addrbook.Person (Addrbook.Name "") (Addrbook.Email "1",[Addrbook.Email "2"]) (Addrbook.Tel "12345")) (Addrbook.Name "hugo")
--	putStrLn $ show s
--
--pathex :: IO ()
--pathex = do
--	let Right path = parseXPath "email[1]"
--	View' f b <- xpath2homlens path Map.empty (typeof :: Type Addrbook.Person)
----	putStrLn $ show b
--	Eq <- teq b (List (typeof :: Type Addrbook.Email))
--	let s = simpleput f (Addrbook.Person (Addrbook.Name "hugo") (Addrbook.Email "1",[Addrbook.Email "2"]) (Addrbook.Tel "12345")) [Addrbook.Email "default"]
--	putStrLn $ show s
	
--pathex' path = do
--	ViewEnv f b <- xpath2envputlens path Map.empty (typeof :: Type Addrbook.Addrbook)
--	putStrLn $ show b

--exmatch = do
--	let pat = ElementPat "person" [VarPat (VarT "name" (NameT "name")),VarPat (VarT "tel" (NameT "tel")),VarPat (VarT "email" (NameT "email"))]
--	    v = typeof :: Type Index.Person
--	View.Ref g vpat <- evalmatchviewput (rstTypeM One) pat One v
--	putStrLn $ show vpat
--
--exsub = fromJust $ do
--	let pat = (Tag "person" (Prod One (Prod (typeof :: Type Index.Name) (Prod (typeof :: Type Index.Email) (typeof :: Type Index.Tel)))))
--	    v = typeof :: Type Addrbook.Person
--	lns <- subtypeput (rstTypeM v) pat v
--	return lns

--exsplit = do
--	View.Ref f r <- splitView One (Set.fromList ["c","b","e"]) (Set.fromList ["a","b","d"]) $ Prod (Prod (Prod (Tag "$a" Int) (Tag "$b" Int)) (Tag "$c" Int)) (Prod (Tag "$d" Int) (Tag "$e" Int))
--	putStrLn $ show r

--peopleN = [("Sebastian","Uganda"),("Hugo","Braga"),("Zhenjiang","Tokyo")]
--getN = get' namesFromTokyo peopleN
--putN = put (put2lens namesFromTokyo) peopleN ["Zhenjiang","Zan"]
--
--namesFromTokyo :: Putlens st e [(String,String)] [String]
--namesFromTokyo = matchPut skey vkey p create recover put
--	where
--	skey st = fst
--	vkey st = id
--	p = (\x -> x=="Tokyo" || x=="XXXX") . snd
--	create = \st v -> (v,"XXXX")
--	recover st (n,"Tokyo") = Nothing
--	recover st (n,"XXXX") = Nothing
--	recover st (n,c) = trace (show (n,c)) $ if c < "Tokyo" then Just ((n,c),FIRST) else Just ((n,c),LAST)
--	put = keepsndPut

--exlns :: Lens [Book] (String,[Book])
--exlns = put2lens lns
--	where
--    lns = consPut .< keepsndDefPut (List book) .< remsndOnePut .< uninjlPut .< unsafeInvPut (eitherREPut (g -|-< botPut)) .< f
--    f = (remsndOnePut .< uninjlPut .< unsafeInvPut (eitherREPut (idPut -|-< botPut)) .< f ><< idPut) .< addsndOnePut
--    g = (remsndOnePut .< (outPut ><< idPut) ><< idPut) .< addsndOnePut

ex4 = fromJust $ do
	lns <- subtype (Tag "book" $ Float) (Prod (Tag "book" $ Int) Int)
--	return $ create lns (1.0)
	return lns

--book = typeof :: Type Book
--ex3 = do
--	lns <- subtype (Prod (Tag "book" $ Tag "title" $ List Char) (List book)) (List book)
--	let b1 = Book (Title "title") (Author "author") (Year "year") (Price "price")
--	putStrLn $ render $ pprintPfWithDecls (Lns typeof typeof) lns
--	return $ get lns [b1]
--	putStrLn $ show $ create lns ("qwe",[b1])

--ex2 = do
--	let store = Bookstore []
--	let s = typeof :: Type Bookstore
--	let env = Map.singleton "s" (Dyn s $ store)
--	let Right e = parseXPath "$s/bookstore"
--	View' lns r <- xpath2xlistlens e env s
--	putStrLn $ show r
--	putStrLn $ gshow r $ get lns store

--exzip = fromJust $ do
--	lns <- evalsubtype (List (Prod Int Bool)) (Prod (List Int) (List Bool))
--	return $ create lns [(1,True),(2,False)]
--
--n1 = Either (Prod Int (Prod (List Int) (Prod (List Float) (List Float)))) (Either (Prod Float (Prod (List Float) (List Float))) (Prod Float (List Float)))
--b2 = (Either One (Either (Either (Prod Float (List Float)) Zero) (Either (Either (Prod Int (Prod (List Int) (List Float))) Zero) Zero)))
--
--ex1 = fromJust $ subtype (Prod (Prod (List Int) (List Float)) (List Float)) (Prod (List Int) (List Float))
--
--x = Prod (Prod (List Float) (List Int)) (List Int)
--y = Prod (List Float) (List Int)
--
--r = Either (Either b (Either b a)) One
--b = Tag "b" One
--a = Tag "a" One
--normr = (Either One (Either (Prod (Tag "b" One) One) (Either (Prod (Tag "b" One) One) (Prod (Tag "a" One) One))))
--
--c1 = (Prod b One) `Either` ((Prod b One) `Either` Zero)
--
--rhs = Either (Prod (Tag "l1" Int) Int) $ Either (Prod (Tag "l2" Bool) Bool) $ Either (Prod (Tag "l1" Char) Char) (Prod (Tag "l2" Float) Float)

--testnorm a = do
--	x <- norm' a
--	putStrLn $ applyViewPf (\l b -> show b ++ "\n" ++ show l) x
--testclunorm a = fromJust $ (norm' >>>> clu) a >>= return . applyViewPf (\l b -> show b)
--testclu a = fromJust $ clu a >>= return . applyViewPf (\l b -> show b)
--testhcf a = fromJust $ hcf a >>= return . applyDynT (\t -> show t)
--testkag a = fromJust $ clutokag a >>= return . (\(t,ts) -> show t ++ "\n" ++ show ts)

exs = fromJust $ do
	lns <- evalsubtype (Prod (List Int) (List Int)) (List Int)
	return $ get lns ([1,2,3,4])
exs2 = fromJust $ do
	lns <- evalsubtype (List Int) (Prod (List Int) (List Int))
	return $ create lns ([1,2,3,4])

--netscape :: Html
--netscape = Html (Head "My Bookmarks") (Body (H1 "my bookmarks") sdl1)
--sdl1 = Dl [Left sdt1,Right sdd1,Left sdt3]
--sdt1 = Dt (A (A_Attrs { aHref = "foo.com"}) "Foo's")
--sdd1 = Dd (H3 "my folder") sdl2
--sdl2 = Dl [Left sdt2]
--sdt2 = Dt (A (A_Attrs { aHref = "stefanzan.com"}) "stefanzan")
--sdt3 = Dt (A (A_Attrs { aHref = "bar.edu"}) "Bar's")
--
--netlns str = let (Right path) = parseXPath str
--                 Just lns = xpath2dynlens path Map.empty (typeof :: Type Html)
--             in lns
--
--dllns str = let (Right path) = parseXPath str
--                Just lns = xpath2dynlens path Map.empty (typeof :: Type Dl)
--            in lns
--
--headtxt = netlns "html/body/text()"
--get1 = get headtxt netscape
--put1 = put headtxt netscape [Dyn String "qwe"]
--bodytxt = netlns "html/body/dl/*[position() > 1 and position() < last()]"
--get2 = get bodytxt netscape
--put2 = put bodytxt netscape (Dyn typeof (Dt (A (A_Attrs { aHref = "hugo.com"}) "Hugo")):get2)

test = generateHaskellDTD "netscape.dtd" "Netscape.hs"
-- same as "./dist/build/PutXML/PutXML -t --sdtd src/test/netscape.dtd --shs src/test/Netscape.hs"

test2 = generateHaskellDTD "news.dtd" "News.hs"

testpath = parseXPath "/bookstore/book/title"

testpath2 = parseXPath "/bookstore/book[1]/title"

testpath3 = parseXPath "/bookstore/book/price/text()"

testpath4 = parseXPath "/bookstore/book[price>35]/title"

{-sf :: ([(Pos,Char)],Last)
sf = ([(0,'a'),(1,'b'),(2,'c'),(3,'d'),(4,'e')],4)
vf :: [(Pos,Char)]
vf = [(1,'y'),(2,'x'),(3,'y')]
	
v1 = "yxy"

lf :: (Show a,Eq a) => Lens [a] [a]
lf = put2lens $ filterWithPos (\li (i,x) -> i > 1 && i < li-1)

vf2 :: [(Pos,Char)]
vf2 = [(0,'a'),(1,'b'),(3,'d'),(5,'w')]

v2 = "abdw"

lf2 :: (Show a,Eq a) => Lens [a] [a]
lf2 = put2lens $ filterWithPos (\li (i,x) -> i /= 2 && i /= 4)-}
