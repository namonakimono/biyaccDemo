{-# LANGUAGE DeriveGeneric #-}
module InjTest where

import Text.XML.BiFluX.Update.InjCheck
import Text.XML.BiFluX.Update.Gen
import Text.XML.BiFluX.DTD.HaXml.TypeDef
import Text.XML.BiFluX.DTD.Type
import Text.XML.BiFluX.DTD.SubType
import Text.XML.BiFluX.Update.Parser
import Text.XML.BiFluX.XPath.XPathToLenses
import Text.XML.BiFluX.Lenses.Lib 
import Text.XML.BiFluX.Lenses.Default 
import Text.XML.BiFluX.Lenses.View 
import qualified Text.XML.BiFluX.XPath.HXT.XPathDataTypes as XPath hiding (Env)
import qualified Text.XML.HaXml.DtdToHaskell.TypeDef as DTDT
import qualified Text.XML.HXT.DOM.QualifiedName as DOMN
--import Text.XML.BiFluX.XPath.HXT.XPathDataTypes hiding (Env)
import Data.List
import Data.Maybe
import Data.Map (Map(..))
import qualified Data.Map as Map
import qualified Data.Char as Char
import Control.Monad
import Generics.Putlenses.Putlens
import Generics.Putlenses.Language
import Generics.Putlenses.Examples.Examples
import UI.BiFluX.GenHaskell

import Text.XML.HaXml.XmlContent hiding (List1)
import Text.XML.HaXml.Types
import Text.XML.HaXml.DtdToHaskell.TypeDef (Name(..))
import GHC.Generics
import Text.XML.HaXml.Parse (xmlParse)
--sDTD = generateHaskellDTD "test/bookstore/bookstore.dtd" "test/bookstore/bookstore.hs"
--vDTD = generateHaskellDTD "test/bookstore/books.dtd"     "test/bookstore/books.hs"
----------------------------------------------------------------------------------
--1. type
data Bookstore = Bookstore [Book] 		deriving (Eq,Show,Generic)
data Book = Book Title Author Year Price
          deriving (Eq,Show,Generic)
newtype Title = Title String 		deriving (Eq,Show,Generic)
newtype Author = Author String 		deriving (Eq,Show,Generic)
newtype Year = Year String 		deriving (Eq,Show,Generic)
newtype Price = Price String 		deriving (Eq,Show,Generic)
instance HTypeable Bookstore where
    toHType x = Defined "bookstore" [] []
instance XmlContent Bookstore where
    toContents (Bookstore a) =
        [CElem (Elem (N "bookstore") [] (concatMap toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["bookstore"]
        ; interior e $ return (Bookstore) `apply` many parseContents
        } `adjustErr` ("in <bookstore>, "++)
instance HTypeable Book where
    toHType x = Defined "book" [] []
instance XmlContent Book where
    toContents (Book a b c d) =
        [CElem (Elem (N "book") [] (toContents a ++ toContents b ++
                                    toContents c ++ toContents d)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["book"]
        ; interior e $ return (Book) `apply` parseContents
                       `apply` parseContents `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <book>, "++)
instance HTypeable Title where
    toHType x = Defined "title" [] []
instance XmlContent Title where
    toContents (Title a) =
        [CElem (Elem (N "title") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["title"]
        ; interior e $ return (Title) `apply` (text `onFail` return "")
        } `adjustErr` ("in <title>, "++)
instance HTypeable Author where
    toHType x = Defined "author" [] []
instance XmlContent Author where
    toContents (Author a) =
        [CElem (Elem (N "author") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["author"]
        ; interior e $ return (Author) `apply` (text `onFail` return "")
        } `adjustErr` ("in <author>, "++)
instance HTypeable Year where
    toHType x = Defined "year" [] []
instance XmlContent Year where
    toContents (Year a) =
        [CElem (Elem (N "year") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["year"]
        ; interior e $ return (Year) `apply` (text `onFail` return "")
        } `adjustErr` ("in <year>, "++)
instance HTypeable Price where
    toHType x = Defined "price" [] []
instance XmlContent Price where
    toContents (Price a) =
        [CElem (Elem (N "price") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["price"]
        ; interior e $ return (Price) `apply` (text `onFail` return "")
        } `adjustErr` ("in <price>, "++)
instance Typeable Bookstore where
    typeof = Data (Name "bookstore" "Bookstore") typeof
instance Typeable Book where
    typeof = Data (Name "book" "Book") typeof
instance Typeable Title where
    typeof = Data (Name "title" "Title") typeof
instance Typeable Author where
    typeof = Data (Name "author" "Author") typeof
instance Typeable Year where
    typeof = Data (Name "year" "Year") typeof
instance Typeable Price where
    typeof = Data (Name "price" "Price") typeof

newtype Books = Books [Vbook] 		deriving (Eq,Show,Generic)
data Vbook = Vbook Vtitle Vprice
           deriving (Eq,Show,Generic)
newtype Vtitle = Vtitle String 		deriving (Eq,Show,Generic)
newtype Vprice = Vprice String 		deriving (Eq,Show,Generic)
instance HTypeable Books where
    toHType x = Defined "books" [] []
instance XmlContent Books where
    toContents (Books a) =
        [CElem (Elem (N "books") [] (concatMap toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["books"]
        ; interior e $ return (Books) `apply` many parseContents
        } `adjustErr` ("in <books>, "++)
instance HTypeable Vbook where
    toHType x = Defined "vbook" [] []
instance XmlContent Vbook where
    toContents (Vbook a b) =
        [CElem (Elem (N "vbook") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["vbook"]
        ; interior e $ return (Vbook) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <vbook>, "++)
instance HTypeable Vtitle where
    toHType x = Defined "vtitle" [] []
instance XmlContent Vtitle where
    toContents (Vtitle a) =
        [CElem (Elem (N "vtitle") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["vtitle"]
        ; interior e $ return (Vtitle) `apply` (text `onFail` return "")
        } `adjustErr` ("in <vtitle>, "++)
instance HTypeable Vprice where
    toHType x = Defined "vprice" [] []
instance XmlContent Vprice where
    toContents (Vprice a) =
        [CElem (Elem (N "vprice") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["vprice"]
        ; interior e $ return (Vprice) `apply` (text `onFail` return "")
        } `adjustErr` ("in <vprice>, "++)
instance Typeable Books where
    typeof = Data (Name "books" "Books") typeof
instance Typeable Vbook where
    typeof = Data (Name "vbook" "Vbook") typeof
instance Typeable Vtitle where
    typeof = Data (Name "vtitle" "Vtitle") typeof
instance Typeable Vprice where
    typeof = Data (Name "vprice" "Vprice") typeof


-----------------------------------------------------------
--2. data

main = do
  vXmlContent <- (fReadXml "test/bookstore/v.xml"):: IO Books
  sXmlContent <- (fReadXml "test/bookstore/s.xml"):: IO Bookstore
  putStrLn "Source data:"
  putStrLn $ show sXmlContent
  putStrLn "--------------------------------------------------------------------------------------------------------------"
  putStrLn "View data: "
  putStrLn $ show vXmlContent  
  putStrLn "--------------------------------------------------------------------------------------------------------------"
  putStrLn "Update Query:"
  program <- readFile "test/bookstore/bookstore.upd"
  let ast = parse ( scan program)
  putStrLn $ show ast
  putStrLn "--------------------------------------------------------------------------------------------------------------"
  putStrLn "Now execution"
  bool <- checkProgram ast (typeof:: Type Books) 
  if bool
    then putStrLn "check Passed!"
    else putStrLn "not full embedded into source."

