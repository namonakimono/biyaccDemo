module Text.XML.BiFluX.DTD.Type where

import GHC.InOut
import Text.XML.HaXml.DtdToHaskell.TypeDef hiding (List,Maybe,List1,Any,String,mkAtt)
import Text.XML.BiFluX.DTD.HaXml.TypeDef hiding (mkAtt)
import Control.Monad
import Unsafe.Coerce
import Control.Monad.State (State(..))
import qualified Control.Monad.State as State
import Control.Monad.Reader (Reader(..))
import qualified Control.Monad.Reader as Reader
import Data.Maybe
import Generics.Putlenses.Putlens
import Data.Map (Map(..))
import qualified Data.Map as Map
import Data.List
import Data.Set (Set(..))
import qualified Data.Set as Set
import qualified Control.Monad.Identity as Identity
import GHC.Generics
import qualified Control.Monad.Trans.Maybe as Maybe

data D_Str
data C_Str

instance Datatype D_Str where
  datatypeName _ = "Str"
  moduleName   _ = "Text.XML.BiFluX.DTD.Type"

instance Constructor C_Str where
  conName _ = "" -- JPM: I'm not sure this is the right implementation...

instance Generic Str where
  type Rep Str = D1 D_Str (C1 C_Str (S1 NoSelector (Rec0 Str)))
  from x = M1 (M1 (M1 (K1 x)))
  to (M1 (M1 (M1 (K1 x)))) = x

type Env = Map String Dynamic
type EnvT = Map String DynType

lookupEnv :: String -> Env -> Dynamic
lookupEnv n env = case Map.lookup n env of
	Just d -> d
	Nothing -> error $ "variable " ++ n ++ " not in the environment"

data Phi -- empty type used for regular expression subtyping
instance Eq Phi where
	x == y = False
data Tau -- maximal type
instance Eq Tau
data Meet a b
instance Eq (Meet a b)

data Str = Str { unStr :: String }
instance Show Str where show (Str x) = show x
instance Eq Str where (Str x) == (Str y) = x == y
instance Ord Str where compare (Str x) (Str y) = compare x y

data Type a where
	Int :: Type Int
	Float :: Type Float
	String :: Type Str
	Bool :: Type Bool
	One :: Type ()
	Cut :: Type a -> Type a -- some special kind for values "to be deleted", i.e., replaced by One
	Either :: (Eq a,Eq b) => Type a -> Type b -> Type (Either a b)
	Prod :: (Eq a,Eq b) => Type a -> Type b -> Type (a,b)
	List :: Eq a => Type a -> Type [a]
	Data :: (Eq a,Eq (F a),InOut a) => Name -> Type (F a) -> Type a			-- mutually recursive Haskell datatype
	Tag :: Eq a => String -> Type a -> Type a						-- tagged XML element or attribute, variables
	TypeRef :: String -> Type a -> Type a -- to handle recursive type references

	XList :: Int -> Maybe Int -> Set DynType -> Type [Dynamic] -- special type only internally used for lists when evaluating xpath expressions
	Zero :: Type Phi
	Tau :: Type Tau
	Meet :: (Eq a,Eq b) => Type a -> Type b -> Type (Meet a b)
	
	Fun    :: (Eq a,Eq b) => Type a -> Type b -> Type (a -> b)
	LnsM    :: (Eq a,Eq b) => TypeM m -> Type a -> Type b -> Type (LensM m a b)
	PutlnsM :: (Eq a,Eq b) => TypeM m -> Type a -> Type b -> Type (PutlensM m a b)
	Any    :: Type Dynamic
	
	Env :: Type Env -- just a type annotation
	
	AppM :: TypeM m -> Type a -> Type (m a)

-- type representation for monads
data TypeM (m :: * -> *) where
	Identity :: TypeM Identity.Identity
	StateT :: Type st -> TypeM m -> TypeM (State.StateT st m)
	ReaderT :: Type r -> TypeM m -> TypeM (Reader.ReaderT r m)
	MaybeT :: TypeM m -> TypeM (Maybe.MaybeT m)

data EqualM (m1 :: * -> *) (m2 :: * -> *) where
    EqM :: EqualM m1 m1

maybeT :: (Eq a) => Type a -> Type (Maybe a)
maybeT a = Data (Name "" "Maybe") (Either One a)

tMeq :: MonadPlus m => TypeM m1 -> TypeM m2 -> m (EqualM m1 m2)
tMeq Identity Identity = return EqM
tMeq (StateT st m) (StateT st' m') = do
	Eq <- teq st st'
	EqM <- tMeq m m'
	return EqM
tMeq (ReaderT r m) (ReaderT r' m') = do
	Eq <- teq r r'
	EqM <- tMeq m m'
	return EqM
tMeq (MaybeT m) (MaybeT m') = do
	EqM <- tMeq m m'
	return EqM
tMeq a b = fail $ "not equal: " ++ show a ++ " " ++ show b

-- subtree type extraction (all children elements (at any depth) of a type)
subtreeElsType :: Eq a => Type a -> DynType
subtreeElsType a = if Set.null s then DynT One else foldr1 (applyDynT2 (\a b -> DynT (Either a b))) (Set.toList s)
	where s = subtreeSet a

subtreeSet :: Eq a => Type a -> Set DynType
subtreeSet a = State.evalState (subtrees' a) [] 
subtrees' :: Eq a => Type a -> State [Name] (Set DynType)
subtrees' One = return Set.empty
subtrees' (getLiteral -> Just a) = return $ Set.empty
subtrees' (getEl -> Just a@(Tag l t)) = do -- to ignore attributes
	s <- subtrees' t
	return $ Set.singleton (DynT a) `Set.union` s
subtrees' (getAtt -> Just a@(Tag l t)) = return Set.empty
subtrees' a@(Data l t) = do
	names <- State.get
	if elem l names
		then return Set.empty
		else do
			State.put (l:names)
			s <- subtrees' t
			return $ Set.singleton (DynT a) `Set.union` s
subtrees' (Prod a b) = do
	s1 <- subtrees' a
	s2 <- subtrees' b
	return $ s1 `Set.union` s2
subtrees' (List a) = subtrees' a
subtrees' (Either a b) = do
	s1 <- subtrees' a
	s2 <- subtrees' b
	return $ s1 `Set.union` s2
subtrees' a = error $ "subtrees': "++show a

type TypeEnv = Map String DynType
type TypeDeps = [(Name,[Name])]

typeDependencies :: Type a -> TypeDeps
typeDependencies t = map (\(x,_) -> (x, [ y | (x,z1) <- deps, (z2,y) <- deps, y /= x, isPath z1 z2] )) deps
	where deps = State.execState (typeDependencies' Nothing t) []
	      isPath x y = if x == y then True else case lookup x deps of { Just z -> isPath z y; Nothing -> False }

typeDependencies' :: Maybe Name -> Type a -> State.State [(Name,Name)] ()
typeDependencies' c (Either a b) = typeDependencies' c a >> typeDependencies' c b
typeDependencies' c (Prod a b) = typeDependencies' c a >> typeDependencies' c b
typeDependencies' c (List a) = typeDependencies' c a
typeDependencies' c (XList _ _ xts) = mapM (\(DynT t) -> typeDependencies' c t) (Set.toList xts) >> return ()
typeDependencies' c (Tag n t) = typeDependencies' c t
typeDependencies' c (Data n t) = do
	deps <- State.get
	let deps' = if isJust c then deps++[(fromJust c,n)] else deps
	State.put deps'
	case lookup n deps' of
		Just _ -> return ()
		otherwise -> typeDependencies' (Just n) t
typeDependencies' c a = return ()

isAttEl t = isData t || isTag t
isData :: Type a -> Bool
isData (Data _ _) = True
isData _ = False
isTag :: Type a -> Bool
isTag (Tag _ _) = True
isTag _ = False

isLiteral Int = True
isLiteral Float = True
isLiteral Bool = True
isLiteral String = True
isLiteral a = False 

getAtt :: Type a -> Maybe (Type a)
getAtt a@(Tag n t) = if isAtt n then return a else Nothing
getAtt a = Nothing

getEl :: Type a -> Maybe (Type a)
getEl a@(Tag n t) = if isAtt n then Nothing else Just a
getEl a@(Data _ _) = Just a
getEl a = Nothing

getName :: Type a -> Maybe String
getName (Tag s t) = Just s
getName (Data (Name s _) t) = Just s
getName a = Nothing

getLiteral :: Type a -> Maybe (Type a)
getLiteral a = if isLiteral a then Just a else Nothing

getXName :: Type a -> String
getXName (Tag s t) = if isAtt s then tail s else s
getXName (Data (Name s n) t) = s
getXName _ = ""
	
getHName :: Type a -> String
getHName (Data (Name s n) t) = n
getHName _ = ""
	
isVar n = isPrefixOf "$" n
mkVar n = '$':n
isAtt n = isPrefixOf "@" n
mkAtt n = '@':n
varName :: String -> String
varName ('$':n) = n
varName s = error $ show s ++ " not a variable"
attName :: String -> String
attName ('@':n) = n
attName s = error $ show s ++ " not an attribute"
isVarTag :: Type a -> Maybe (String,Type a)
isVarTag (Tag n v) = if isVar n then Just (n,v) else Nothing
isVarTag _ = Nothing
	
instance Show (Type a) where
	show Int = "Int"
	show Float = "Float"
	show String = "String"
	show Bool = "Bool"
	show One = "One"
	show (Cut a) = "(Cut "++show a++")"
	show (Either a b) = "(Either " ++ show a ++ " " ++ show b ++ ")"
	show (Prod a b) = "(Prod " ++ show a ++ " " ++ show b ++ ")"
	show (List a) = "(List " ++ show a ++ ")"
	show (XList i j ts) = "(XList " ++ show i ++ " (" ++ show j ++ ") " ++ show ts ++ ")"
	show (Data (Name x@"@" n) t) = "(Data (Name "++show x++" "++show n++") " ++ show t ++ ")"
	show (Data (Name x@"dt" n) t) = "(Data (Name "++show x++" "++show n++") " ++ show t++")"
	show (Data (Name x n) t) = "((Data (Name "++show x++" "++show n++") " ++ "typeof) :: Type "++n++")"
	show (Tag x t) = "(Tag " ++ show x ++ " " ++ show t ++ ")" -- TODO: do something about recursive tags?
	show Zero = "Zero"
	show Tau = "Tau"
	show (Meet a b) = "(Meet " ++ show a ++ " " ++ show b ++ ")"
	show (Fun a b) = "(Fun " ++ show a ++ " " ++ show b ++ ")"
	show (LnsM m a b) = "(LnsM " ++ show m ++ " " ++ show a ++ " " ++ show b ++ ")"
	show (PutlnsM m a b) = "(PutlnsM " ++ show m ++ " " ++ show a ++ " " ++ show b ++ ")"
	show Any = "Any"
	show Env = "Env"
	show (AppM m a) = "(AppM "++show m++" "++show a++")"

instance Show (TypeM m) where
	show Identity = "Identity"
	show (StateT m a) = "(StateT "++ show m ++" "++show a++")"
	show (ReaderT m a) = "(ReaderT "++ show m ++" "++show a++")"
	show (MaybeT m) = "(MaybeT "++ show m ++")"

data Equal a b where
    Eq :: Equal a a

instance Eq (Type a) where
	x == y = case teq x y of { Just Eq -> True; Nothing -> False }

teqListBool :: [DynType] -> Bool
teqListBool [] = True
teqListBool [x] = True
teqListBool (DynT x:DynT y:xs) = teqBool x y && teqListBool (DynT y:xs)

teqBool :: Type a -> Type b -> Bool
teqBool a b = case teq a b of { Just Eq -> True; Nothing -> False }

teqMaybe :: Type a -> Type b -> Maybe (Equal a b)
teqMaybe = teq

teq :: MonadPlus m => Type a -> Type b -> m (Equal a b)
teq Int Int = return Eq
teq Float Float = return Eq
teq String String = return Eq
teq Bool Bool = return Eq
teq One One = return Eq
teq (Either a b) (Either c d) = do
	Eq <- teq a c
	Eq <- teq b d
	return Eq
teq (Prod a b) (Prod c d) = do
	Eq <- teq a c
	Eq <- teq b d
	return Eq
teq (List a) (List b) = do
	Eq <- teq a b
	return Eq
teq (Data n a) (Data m b) = do
	guard (hName n == hName m)
	return (unsafeCoerce Eq)
teq (Tag n a) (Tag m b) = do
	guard (n == m)
	teq a b
teq Tau Tau = return Eq
teq Zero Zero = return Eq
teq (Meet a b) (Meet c d) = do
	Eq <- teq a c
	Eq <- teq b d
	return Eq
teq (Fun a b) (Fun c d) = do
	Eq <- teq a c
	Eq <- teq b d
	return Eq
teq (LnsM m a b) (LnsM m' c d) = do
	EqM <- tMeq m m'
	Eq <- teq a c
	Eq <- teq b d
	return Eq
teq (PutlnsM m a b) (PutlnsM m' c d) = do
	EqM <-  tMeq m m'
	Eq <- teq a c
	Eq <- teq b d
	return Eq
teq (XList xmin xmax xts) (XList ymin ymax yts) = do
	guard (xmin == ymin && xmax == ymax)
	guard (teqXList (Set.toList xts) (Set.toList yts))
	return Eq
teq Env Env = return Eq  
teq a b = mzero

teqXList :: [DynType] -> [DynType] -> Bool
teqXList [] [] = True
teqXList (xt:xts) (yt:yts) = applyDynT2 teqBool xt yt && teqXList xts yts
teqXList _ _ = False

geq :: Type a -> a -> a -> Bool
geq a x y = gcomp a x y == EQ

gcomp :: Type a -> a -> a -> Ordering
gcomp Int x y = compare x y
gcomp Float x y = compare x y
gcomp String x y = compare x y
gcomp Bool x y = compare x y
gcomp One x y = compare x y
gcomp (Either a b) (Left x) (Left y) = gcomp a x y
gcomp (Either a b) (Left x) (Right y) = LT
gcomp (Either a b) (Right x) (Left y) = GT
gcomp (Either a b) (Right x) (Right y) = gcomp b x y
gcomp (Prod a b) (x1,x2) (y1,y2) = let p = gcomp a x1 y1 in case p of { EQ -> gcomp b x2 y2; otherwise -> p }
gcomp (List a) [] [] = EQ
gcomp (List a) [] (y:ys) = LT
gcomp (List a) (x:xs) [] = GT
gcomp (List a) (x:xs) (y:ys) = let l = gcomp a x y in case l of { EQ -> gcomp (List a) xs ys; otherwise -> l }
gcomp (Data n t) x y = gcomp t (out x) (out y)
gcomp (Tag n t) x y = gcomp t x y

gshow :: Type a -> a -> String
gshow (Cut a) x = gshow a x
gshow Int x = show x
gshow Float x = show x
gshow Bool x = show x
gshow One x = show x
gshow (Either a b) (Left x) = "(Left " ++ gshow a x ++ ")"
gshow (Either a b) (Right y) = "(Right " ++ gshow b y ++ ")"
gshow (Prod a b) (x,y) = "(" ++ gshow a x ++ "," ++ gshow b y ++ ")"
gshow String str = show str
gshow (List a) [] = "[]"
gshow (List a) (x:xs) = gshow a x ++ ":" ++ gshow (List a) xs
gshow (Data (Name _ n) t) x = n ++ "[" ++ gshow t (out x) ++ "]"
gshow (Tag n t) x = gshow t x
gshow (XList _ _ ts) [] = "[]"
gshow a@(XList _ _ _) (x:xs) = show x ++ ":" ++ gshow a xs
gshow (PutlnsM m s v) f = "lns"
gshow a x = error $ "gshow not defined for " ++ show a

-- | Explicit Haskell type representations
class Eq a => Typeable a where
	typeof :: Type a

instance Typeable Int where
	typeof = Int
instance Typeable Float where
	typeof = Float
instance Typeable Str where
	typeof = String
instance Typeable Bool where
	typeof = Bool
instance Typeable () where
	typeof = One
instance (Typeable a,Typeable b) => Typeable (Either a b) where
	typeof = Either typeof typeof
instance (Typeable a,Typeable b) => Typeable (a,b) where
	typeof = Prod typeof typeof
instance Typeable a => Typeable [a] where
	typeof = List typeof
--instance (Typeable a,Typeable b) => Typeable (a -> b) where
--	typeof = Fun typeof typeof	
--instance (Typeable a,Typeable b) => Typeable (Lens a b) where
--	typeof = Lns typeof typeof	
--instance (Typeable st,Typeable e,Typeable a,Typeable b) => Typeable (Putlens st e a b) where
--	typeof = PutlnsM typeof typeof typeof typeof	
instance Typeable Dynamic where
	typeof = Any

--instance Eq (a -> b)
--instance Eq (Lens a b)
--instance Eq (Putlens st e a b)
--instance Typeable Env where typeof = Env

data DynFun where
	DynFyn :: (Eq a,Eq b) => Type a -> Type b -> (a -> b) -> DynFun

instance Eq DynFun where
	x == y = False

instance Show DynFun where
	show (DynFyn a b f) = "function between " ++ show a ++ " " ++ show b

-- | A generic type encapsulator.
data Dynamic where
    Dyn :: Eq a => Type a -> a -> Dynamic

instance Eq Dynamic where
	(Dyn a x) == (Dyn b y) = case teq a b of { Just Eq -> x == y; otherwise -> False }
	
instance Show Dynamic where
	show (Dyn t v) = gshow t v

-- Convert a regular type to a dynamic type.
mkDyn :: Eq a => Type a -> a -> Dynamic
mkDyn a v = Dyn a v

-- Apply a generic function to a dynamically typed value.
applyDyn :: (forall a . Eq a => Type a -> a -> b) -> Dynamic -> b
applyDyn f (Dyn ta a) = f ta a

applyDyn2 :: (forall a b. (Eq a,Eq b) => Type a -> a -> Type b -> b -> c) -> Dynamic -> Dynamic -> c
applyDyn2 f (Dyn ta a) (Dyn tb b) = f ta a tb b

unDyn :: Type a -> Dynamic -> a
unDyn t = applyDyn (\t' v -> case teq t t' of { Just Eq -> v; otherwise -> error $ "unDyn failed " ++ show t ++ " " ++ show t'} )

data DynType where
    DynT :: Eq a => Type a -> DynType

instance Show DynType where
	show (DynT t) = show t

instance Ord DynType where
	a <= b = show a <= show b

instance Eq DynType where
	(DynT a) == (DynT b) = case teq a b of { Just Eq -> True; otherwise -> False }

applyDynT :: (forall a . Eq a => Type a -> b) -> DynType -> b
applyDynT f (DynT t) = f t

applyDynT2 :: (forall a b . (Eq a,Eq b) => Type a -> Type b -> c) -> DynType -> DynType -> c
applyDynT2 f (DynT a) (DynT b) = f a b

uninjl :: Either a b -> a
uninjl = either id (error "uninjl")

uninjr :: Either a b -> b
uninjr = either (error "uninjr") id


	
	