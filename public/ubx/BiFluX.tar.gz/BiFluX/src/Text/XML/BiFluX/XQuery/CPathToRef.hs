module Text.XML.BiFluX.XQuery.CPathToRef where

import Text.XML.BiFluX.Update.Patterns	
import Text.XML.BiFluX.DTD.Type
import Text.XML.BiFluX.Lenses.Pf
import Text.XML.BiFluX.XQuery.UXQ
import Text.XML.BiFluX.Lenses.View
import Text.XML.BiFluX.Lenses.ViewPf
import Control.Monad.Reader (Reader(..),ReaderT(..),MonadReader(..))
import qualified Control.Monad.Reader as Reader
import Control.Monad.State (State(..),StateT(..),MonadState(..))
import Text.XML.BiFluX.XPath.HXT.XPathDataTypes as XPath hiding (Name(..),Env(..))
import qualified Control.Monad.State as State
import Control.Monad
import Control.Monad.Trans
import Text.XML.HXT.DOM.QualifiedName
import Text.XML.BiFluX.XQuery.UXQToVal
import Text.XML.BiFluX.Generic.Rewrite
import Data.Map (Map(..))
import qualified Data.Map as Map
import Data.Set (Set(..))
import qualified Data.Set as Set
import {-# SOURCE #-} Text.XML.BiFluX.Update.CoreToLenses
import Text.XML.BiFluX.Lenses.Lib
import Text.XML.BiFluX.DTD.SubType
import Generics.Putlenses.Putlens as Putlenses
import Text.XML.BiFluX.DTD.Normalize

import Debug.Trace

type XQM m = StateT Prevs (ReaderT TypeEnv (StateT EnvT m))

-- view paths must be rooted
-- assumes that the view is a product of variables
rootedcpath2ref :: (Eq s,MonadPlus m) => Type s -> CPath -> RefRulePfT (XQM m) (EnvM)
--rootedcpath2ref s path One = do -- source/environment variable --TODO: this is not really required, as all empty view updates are pre-processed
--	ViewXQ f b <- runXQuery (cpath2val path) -- runs the path over the environment
--	return $ RefPf (PntPut $ \s -> State.get >>= \env -> return $ Reader.runReader f env) b	
rootedcpath2ref s (CPathSlash (CPathVar var) path) v = do -- view variable
	RefPf f (Prod v1@(Tag _ a) One) <- splitView (envM) (Set.singleton var) Set.empty v
	RefPf g b <- cpath2ref s path a
	return $ RefPf (CompPut a g $ CompPut (Prod v1 One) RemsndOnePut f) b
rootedcpath2ref s (CPathVar var) v = do -- view variable
	RefPf f (Prod v1@(Tag _ a) One) <- splitView (envM) (Set.singleton var) Set.empty v
	return $ RefPf (CompPut (Prod v1 One) RemsndOnePut f) a

-- assumes that the view is a regular type (not a product of variables)
cpath2ref :: (Eq s,MonadPlus m) => Type s -> CPath -> RefRulePfT (XQM m) (EnvM)
cpath2ref s CPathSelf = return . RefPf IdPut
cpath2ref s CPathChild = child2ref
cpath2ref s CPathAttribute = attribute2ref
cpath2ref s CPathDoS = error "dos2ref"
cpath2ref s (CPathNodeTest nt) = nodetest2ref nt
cpath2ref s (CPathSlash p1 p2) = slash2ref (cpath2ref s p1) (cpath2ref s p2)
cpath2ref s (CPathFilter cond) = \v -> do -- view condition
 	p <- runXQuery (uXQ2boolWithRoot cond v) -- relative view path
	return $ RefPf (PhiPut $ Reader.runReader p Map.empty) v -- we do not consider view variables	
cpath2ref s (CPathVar var) = \v -> do
	(evars) <- lift State.get
	case Map.lookup var evars of
		Just (DynT t) -> constant2ref s t (unDyn t . lookupEnv var) v
		Nothing -> error "refs: variable not found"
cpath2ref s (CPathString str) = constant2ref s String (const $ Str str)
cpath2ref s (CPathBool b) = constant2ref s Bool (const b)
--cpath2ref s (CPathSnapshot pat path) = \v -> do
--	Ref' f p <- evalmatchview pat v
--	vars <- listPatVariables (updM s) p
--	updEnv <- addExprViewVars vars (simplecreate f) v
--	RefPf g c <- cpath2ref s path v
--	return $ RefPf (ModifySt (\s v env -> return $ updEnv env v) g) c
cpath2ref s (CPathFct n args) = error "functions unsupported as refs"

child2ref :: (MonadPlus m) => RefRulePfT (XQM m) (EnvM)
child2ref = (untagRefPf `seqRefPf` refinePfT keepChildren)
  where keepChildren :: (MonadPlus m,Monad st) => RefRulePfT m st				
        keepChildren a@(Data n t) = return $ RefPf IdPut a											-- keep elements
        keepChildren a@(Tag n _) = if isAtt n then error "child ref" else return $ RefPf IdPut a	-- delete attributes
        keepChildren a = return $ RefPf IdPut a														-- keep text, etc elements

attribute2ref :: (MonadPlus m) => RefRulePfT (XQM m) (EnvM)
attribute2ref = (untagRefPf `seqRefPf` refinePfT keepAtts)
  where keepAtts a@(Tag n t) = if isAtt n then return $ RefPf IdPut a	else error $ "attribute2ref " ++ show a		-- keep attributes
        keepAtts One = return $ RefPf IdPut One
        keepAtts a = error $ "attribute2ref " ++ show a																-- delete otherwise

nodetest2ref :: (MonadPlus m) => NodeTest -> RefRulePfT (XQM m) (EnvM)
nodetest2ref (NameTest n) = keepName
  where keepName :: (MonadPlus m,Monad st) => RefRulePfT m st
        keepName One = return $ RefPf IdPut One
        keepName a | localPart n == "*" || getXName a == localPart n = return (RefPf IdPut a)
                   | otherwise = error $ "nametest2ref: " ++ show n ++ " " ++ show a
nodetest2ref (PI s) = error "processing units not supported"
nodetest2ref (TypeTest XPNode) = nodeRef
  where nodeRef a@(Tag (isAtt -> True) _) = error "node ref"
        nodeRef a = return (RefPf IdPut a)
nodetest2ref (TypeTest XPCommentNode) = error "comment nodes unsupported"
nodetest2ref (TypeTest XPPINode) = error "pi nodes unsupported"
nodetest2ref (TypeTest XPTextNode) = keepText
  where keepText a = if isLiteral a then return (RefPf IdPut a) else error "textnode ref"
nodetest2ref (TypeTest XPString) = keepString -- currently we only support the case when the children are exactly a single literal
  where keepString a = if isLiteral a then return (RefPf (FromStringPut a) String) else error "string ref"

slash2ref :: MonadPlus m => RefRulePfT (XQM m) (EnvM) -> RefRulePfT (XQM m) (EnvM) -> RefRulePfT (XQM m) (EnvM)
slash2ref p1 p2 = p1 `seqRefPf` refinePfT p2

constant2ref :: (MonadPlus m,Eq a) => Type s -> Type a -> (Env -> a) -> RefRulePfT (XQM m) (EnvM)
constant2ref s a upd v = do
	f <- subtypeputNormWithDecls (envM) v One -- the view must be empty
	return $ RefPf (CompPut One (PntPut $ \s -> State.get >>= return . upd) f) a

-- splits variables into a product with the wanted variables to the left and the right, possibly duplicated
-- shall signal an error if a variable is not used in either side (currently I pass all variables, and do not return an error)
splitView :: (MonadPlus m,Monad lensm) => TypeM lensm -> Set XVar -> Set XVar -> RefRulePfT m lensm
splitView lensm l r v = do
	ViewPf f a <- manyPf (oncePf (removeProdOnePf |||| assocRightPf)) v
	RefPf g b <- splitView' l r a
	RefPf h v' <- remOnes lensm b
	f' <- inv (PutlnsM lensm v a) f
	return $ RefPf (CompPut b h $ CompPut a g f') v'
  where
	remOnes :: (MonadPlus m,Monad lensm) => TypeM lensm -> RefRulePfT m lensm
	remOnes lensm (Prod x y) = do
		ViewPf f x' <- removeViewOnesPf x
		ViewPf g y' <- removeViewOnesPf y
		f' <- inv (PutlnsM lensm x x') f
		g' <- inv (PutlnsM lensm y y') g
		return $ RefPf (f' `ProdPut` g') (Prod x' y')
	remOnes _ a = return $ RefPf IdPut a

-- assumes right-associated products with no units (besides an empty view of course)
splitView' :: (MonadPlus m,Monad lensm) => Set XVar -> Set XVar -> RefRulePfT m lensm
splitView' l r v@(Tag (varName -> n) t) = aux l r v
  where
	aux :: (MonadPlus m,Monad lensm) => Set XVar -> Set XVar -> RefRulePfT m lensm
	aux l r v@(Tag (varName -> n) t)
		| Set.member n l && Set.member n r = return $ RefPf DupPut (Prod v v)
		| Set.member n l = return $ RefPf AddsndOnePut (Prod v One)
		| Set.member n r = return $ RefPf AddfstOnePut (Prod One v)
		| otherwise = error $ "view variable $" ++ n ++ " not used, breaks injectivity"
splitView' l r (Prod v@(Tag (varName -> n) t) vs) = do
	RefPf f p <- splitView' (Set.delete n l) (Set.delete n r) vs
	aux l r v f p
  where
	aux :: (Eq vs,MonadPlus m,Monad lensm) => Set XVar -> Set XVar -> Type v -> Pf (PutlensM lensm vs' vs) -> Type vs' -> m (RefPf lensm (v,vs))
	aux l r v@(Tag (varName -> n) t) f (Prod xs ys)
		| Set.member n l && Set.member n r = return $ RefPf (CompPut (Prod (Prod v v) (Prod xs ys)) DistpPut (DupPut `ProdPut` f)) (Prod (Prod v xs) (Prod v ys))
	    | Set.member n l = return $ RefPf (CompPut (Prod v (Prod xs ys)) AssoclPut (IdPut `ProdPut` f)) (Prod (Prod v xs) ys)
		| Set.member n r = return $ RefPf (CompPut (Prod v (Prod xs ys)) SubrPut (IdPut `ProdPut` f)) (Prod xs (Prod v ys))
		| otherwise = error $ "view variable $" ++ n ++ " not used, breaks injectivity"
splitView' l r One = return $ RefPf AddsndOnePut (Prod One One)
splitView' l r v = error $ "splitView " ++ show v

addExprViewVar :: (Eq a,MonadPlus m) => String -> Type a -> (v -> a) -> Type v -> XQM m (Env -> v -> Env)
addExprViewVar n a f v = do
	(evars) <- lift State.get
	lift $ State.put (Map.insert n (DynT a) evars)
	return $ \env v1 -> Map.insert n (Dyn a $ f v1) env

addExprViewVars :: MonadPlus m => [EnvView vars] -> (v -> vars) -> Type v -> XQM m (Env -> v -> Env)
addExprViewVars [] f v = return $ \env x -> env
addExprViewVars (View g (Tag (varName -> n) y):ys) f v = do
	fenv <- addExprViewVar n y (get' g . f) v
	fenvs <- addExprViewVars ys f v
	return $ \env x -> fenvs (fenv env x) x

runXQuery :: MonadPlus m => QueryM m a -> XQM m a
runXQuery m = do
	tenv <- Reader.ask
	(envT) <- lift State.get
	lift $ lift $ lift $ runXQ tenv Nothing envT m
