-- Syntax of uXQ queries, as defined in http://arxiv.org/pdf/0807.1211v1.pdf and http://www.nmis.isti.cnr.it/manghi/papers/mypapers/jfp2005.pdf
module Text.XML.BiFluX.XQuery.UXQ where

import {-# SOURCE #-} Text.XML.BiFluX.Update.AST
import Text.XML.BiFluX.XPath.HXT.XPathDataTypes as XPath
import Data.Generics.TH
import Data.Set (Set(..))
import qualified Data.Set as Set

-- | The type of paths handled by our language
data CPath = CPathSelf		-- . = CPathSelf ; self::a = CPathSlash CPathSelf (CPathNodeTest (NameTest a)); self axis
           | CPathChild		-- axis
           | CPathAttribute	-- axis
           | CPathDoS 		-- //a = CPathSlash CPathDoS (CPathNodeTest (NameTest a)); descendant-or-self axis: not supported for lenses or generic functions, only uXQ expressions
           | CPathNodeTest XPath.NodeTest  
           | CPathSlash CPath CPath -- p / p'
           | CPathFilter XQExpr -- focused on a single element   p[e] = CPathSlash p (CPathFilter e)
           | CPathVar XVar -- $x
           | CPathString String -- 'abc'
		   | CPathBool Bool -- true | false
           | CPathSnapshot Pat CPath -- special case, NOT needed for a parser
		   | CPathFct String [XQExpr]
		deriving (Eq,Show)

-- | The type of general expressions handled by our language
data XQExpr = XQEmpty							-- ()
            | XQProd XQExpr XQExpr				-- e,e'
            | XQElem String XQExpr				-- n[e] when we construct an element we must put all attributes first and sorted
            | XQAttr String XQExpr				-- @n='e'
--            | XQString String					-- w
--            | XQVar XVar						-- x (any variable)
			| XQLet Pat XQExpr XQExpr			-- let x = e in e'
--			| XQBool Bool						-- true | false
			| XQIf XQExpr XQExpr XQExpr			-- if c then e else e'
			| XQBinOp XPath.Op XQExpr XQExpr	-- e ~~ e'
--			| XQTreeVar XVar					-- x- (tree variables, i.e., variables of atomic types) (we generalize and don't consider specific tree variables)
--			| XQChild XVar						-- x/child (for generic variables)
--			| XQAttribute XVar					-- x/child (for generic variables)
--			| XQDoS XVar						-- x/descendantorself (for generic variables)
--			| XQNodeTest XQExpr XPath.NodeTest	-- e :: n
			| XQFor XVar XQExpr XQExpr			-- for x- \in e return e' (still for tree variables)
			| XQPath CPath						-- special case to consider core paths (since their implementation as core uXQ is very different)
--			| XQFct FctName [XQExpr]
	deriving (Eq,Show)

type XVar = String

-- needs to take bindings into account
cpathVars :: CPath -> Set XVar
cpathVars CPathSelf = Set.empty
cpathVars CPathChild = Set.empty
cpathVars CPathAttribute = Set.empty
cpathVars CPathDoS = Set.empty
cpathVars (CPathNodeTest n) = Set.empty
cpathVars (CPathSlash p p') = cpathVars p `Set.union` cpathVars p'
cpathVars (CPathFilter e) = uXQVars e
cpathVars (CPathVar v) = Set.singleton v
cpathVars (CPathString s) = Set.empty
cpathVars (CPathBool b) = Set.empty
cpathVars (CPathSnapshot pat p) = cpathVars p `Set.difference` patVars pat
cpathVars (CPathFct n e) = foldr (\e m -> uXQVars e `Set.union` m) Set.empty e

-- needs to take bindings into account
uXQVars :: XQExpr -> Set XVar
uXQVars XQEmpty = Set.empty
uXQVars (XQProd e e') = uXQVars e `Set.union` uXQVars e'
uXQVars (XQElem n e) = uXQVars e
uXQVars (XQAttr n e) = uXQVars e
uXQVars (XQLet pat e e') = (uXQVars e `Set.union` uXQVars e') `Set.difference` patVars pat
uXQVars (XQIf c e e') = uXQVars c `Set.union` uXQVars e `Set.union` uXQVars e'
uXQVars (XQBinOp _ e e') = uXQVars e `Set.union` uXQVars e'
uXQVars (XQFor v e e') = (uXQVars e `Set.union` uXQVars e') `Set.difference` Set.singleton v
uXQVars (XQPath p) = cpathVars p

uXQsVars :: [XQExpr] -> Set XVar
uXQsVars = foldr (\e s -> uXQVars e `Set.union` s) Set.empty

isRelativeCPath :: CPath -> Bool
isRelativeCPath CPathSelf = True
isRelativeCPath CPathChild = True
isRelativeCPath CPathAttribute = True
isRelativeCPath CPathDoS = True
isRelativeCPath (CPathNodeTest n) = True
isRelativeCPath (CPathSlash p p') = isRelativeCPath p
isRelativeCPath (CPathFilter e) = True
isRelativeCPath (CPathVar v) = False
isRelativeCPath (CPathString s) = False
isRelativeCPath (CPathBool b) = False
isRelativeCPath (CPathSnapshot pat p) = True
isRelativeCPath (CPathFct n es) = or (map isRelativeExpr es)

isRelativeExpr :: XQExpr -> Bool
isRelativeExpr XQEmpty = False
isRelativeExpr (XQProd e1 e2) = isRelativeExpr e1 || isRelativeExpr e2
isRelativeExpr (XQElem n e) = isRelativeExpr e
isRelativeExpr (XQAttr n e) = isRelativeExpr e
isRelativeExpr (XQLet pat e1 e2) = isRelativeExpr e1 || isRelativeExpr e2
isRelativeExpr (XQIf e1 e2 e3) = isRelativeExpr e1 || isRelativeExpr e2 || isRelativeExpr e3
isRelativeExpr (XQBinOp _ e1 e2) = isRelativeExpr e1 || isRelativeExpr e2
isRelativeExpr (XQFor x e1 e2) = isRelativeExpr e1 || isRelativeExpr e2
isRelativeExpr (XQPath path) = isRelativeCPath path

isRootedCPath :: CPath -> Maybe (XVar,CPath)
isRootedCPath CPathSelf = Nothing
isRootedCPath CPathChild = Nothing
isRootedCPath CPathAttribute = Nothing
isRootedCPath CPathDoS = Nothing
isRootedCPath (CPathNodeTest n) = Nothing
isRootedCPath (CPathSlash p p') = do
	(x,rp) <- isRootedCPath p
	return (x,CPathSlash rp p')
isRootedCPath (CPathFilter e) = Nothing
isRootedCPath (CPathVar v) = Just (v,CPathSelf)
isRootedCPath (CPathString s) = Nothing
isRootedCPath (CPathBool b) = Nothing
isRootedCPath (CPathSnapshot pat p) = Nothing
isRootedCPath (CPathFct n es) = Nothing

rootCPath :: XVar -> CPath -> CPath
rootCPath var path = CPathSlash (CPathVar var) path

isPathExpr :: XQExpr -> Maybe CPath
isPathExpr (XQPath p) = Just p
isPathExpr e = Nothing

andExpr :: [XQExpr] -> XQExpr
andExpr [] = XQPath $ CPathBool True
andExpr [e] = e
andExpr (e:es) = XQBinOp XPath.And e (andExpr es)

--relativeToRootedExpr :: XVar -> XQExpr -> XQExpr
--relativeToRootedExpr var XQEmpty = XQEmpty
--relativeToRootedExpr var (XQProd e1 e2) = XQProd (relativeToRootedExpr var e1) (relativeToRootedExpr var e2)
--relativeToRootedExpr var (XQElem n e) = XQElem n (relativeToRootedExpr var e)
--relativeToRootedExpr var (XQAttr n e) = XQAttr n (relativeToRootedExpr var e)
--relativeToRootedExpr var (XQLet pat e1 e2) = XQLet pat (relativeToRootedExpr var e1) (relativeToRootedExpr var e2)
--relativeToRootedExpr var (XQIf c e1 e2) = XQIf (relativeToRootedExpr var c) (relativeToRootedExpr var e1) (relativeToRootedExpr var e2)
--relativeToRootedExpr var (XQBinOp op e1 e2) = XQBinOp op (relativeToRootedExpr var e1) (relativeToRootedExpr var e2)
--relativeToRootedExpr var (XQFor v e1 e2) = XQFor v (relativeToRootedExpr var e1) (relativeToRootedExpr var e2)
--relativeToRootedExpr var (XQPath path) = XQPath (relativeToRootedPath var path)
