module Text.XML.BiFluX.XQuery.UXQToRef where
	
import Text.XML.BiFluX.DTD.Type as Type
import Text.XML.BiFluX.Lenses.Pf
import Text.XML.BiFluX.XQuery.UXQ
import Text.XML.BiFluX.Lenses.View
import Text.XML.BiFluX.Lenses.ViewPf
import Control.Monad.Reader (Reader(..),ReaderT(..),MonadReader(..))
import qualified Control.Monad.Reader as Reader
import Control.Monad.State (State(..),StateT(..),MonadState(..))
import qualified Control.Monad.State as State
import Control.Monad
import Control.Monad.Trans
import Text.XML.HXT.DOM.QualifiedName
import Text.XML.BiFluX.XQuery.UXQToVal
import Text.XML.BiFluX.Generic.Rewrite
import Data.Map (Map(..))
import qualified Data.Map as Map
import Data.Set (Set(..))
import qualified Data.Set as Set
import Generics.Putlenses.Language
import Text.XML.BiFluX.Lenses.Lib
import Generics.Putlenses.Putlens
import Text.XML.BiFluX.DTD.SubType
import Data.List
import {-# SOURCE #-} Text.XML.BiFluX.Update.CoreToLenses
import Text.XML.BiFluX.XQuery.CPathToRef
import Text.XML.BiFluX.Update.Patterns
import Text.XML.BiFluX.DTD.Normalize

-- the view is a product of variables
uXQ2ref :: (Eq s,MonadPlus m) => Type s -> XQExpr -> RefRulePfT (XQM m) (EnvM)
uXQ2ref s XQEmpty One = return $ RefPf IdPut One
uXQ2ref s (XQProd e e') v = do
	RefPf f (Prod x y) <- splitView (envM) (uXQVars e) (uXQVars e') v
	RefPf g x' <- uXQ2ref s e x
	RefPf h y' <- uXQ2ref s e'  y
	return $ RefPf (CompPut (Prod x y) (g `ProdPut` h) f) (Prod x' y')
uXQ2ref s (XQElem n e) v = do
	RefPf f x <- uXQ2ref s e v
	RefPf g y <- sortAttributesPf (envM) x -- handles attributes
	return $ RefPf (CompPut x g f) (Tag n y)
uXQ2ref s (XQAttr n e) v = do
	RefPf f x <- uXQ2ref s e v
	g <- subtypeputNormWithDecls (envM) x String -- checks whether the result is a base type
	return $ RefPf (CompPut x g f) (Tag (mkAtt n) String)	
uXQ2ref s (XQLet pat e e') v = do -- like letV, always binds a new view variable
	RefPf f (Prod v1 v2) <- splitView (envM) (uXQVars e) (viewvars v `Set.difference` uXQVars e) v
	RefPf g a <- uXQ2ref s e v1
	RefPf h p <- matchviewputWithDecls (envM) pat a
	vars <- listPatVariables (envM) p
	updEnv <- addExprViewVars vars fst (Prod p v2)
	RefPf i c <- uXQ2ref s e' (Prod p v2)
	let lns = CompPut (Prod v1 v2) (CompPut a h g `ProdPut` IdPut) f
	return $ RefPf (CompPut (Prod p v2) i $ UpdateSt (\s s' env -> return $ updEnv env s') lns) c
uXQ2ref s (XQIf cond e e') v = do -- like ifV, requires a view condition
	p <- runViewQuery (uXQ2bool cond) v
	RefPf f x <- uXQ2ref s e v
	RefPf g y <- uXQ2ref s e' v
	iso <- isomorphismPf (envM) x y -- TODO: change this condition
	return $ RefPf (IfVthenelsePut p f (CompPut y iso g)) x
uXQ2ref s (XQBinOp op e e') v = error "binary operations unsupported as lenses"
uXQ2ref s (XQFor var e e') v = do
	RefPf f x <- uXQ2ref s e v
	RefPf g y <- refinePfT (rule s var e') x
	return $ RefPf (CompPut x g f) y
  where rule :: (Eq s,MonadPlus m) => Type s -> XVar -> XQExpr -> RefRulePfT (XQM m) (EnvM)
        rule s var expr v = uXQ2ref s expr (Tag (mkVar var) v)
uXQ2ref s (XQPath path) v = rootedcpath2ref s path v

-- splits an arbitrary type into a product with attributes to the left and elements to the right
splitAttsPf :: (MonadPlus m,Monad lensm) => TypeM lensm => RefRulePfT m lensm
splitAttsPf lensm One = return $ RefPf AddsndOnePut (Prod One One)
splitAttsPf lensm (getLiteral -> Just a) = return $ RefPf AddfstOnePut (Prod One a)
splitAttsPf lensm (getEl -> Just a) = return $ RefPf AddfstOnePut (Prod One a)
splitAttsPf lensm (getAtt -> Just a) = return $ RefPf AddsndOnePut (Prod a One)
splitAttsPf lensm (Prod a b) = do
	RefPf f p1@(Prod a1 a2) <- splitAttsPf lensm a
	RefPf g p2@(Prod b1 b2) <- splitAttsPf lensm b
	return $ RefPf (CompPut (Prod p1 p2) DistpPut (f `ProdPut` g)) (Prod (Prod a1 b1) (Prod a2 b2))
splitAttsPf lensm (Either a b) = do
	RefPf f p1@(Prod a1 a2) <- splitAttsPf lensm a
	RefPf g p2@(Prod b1 b2) <- splitAttsPf lensm b
	let x = Either (Either (Prod a1 a2) (Prod a1 b2)) (Either (Prod b1 a2) (Prod b1 b2))
	return $ RefPf (CompPut x UndistsPut (CompPut p1 InjlPut f `SumPut` CompPut p2 InjrPut g)) (Prod (Either a1 b1) (Either a2 b2))
splitAttsPf lensm (List a) = do
	RefPf f p1@(Prod a1 a2) <- splitAttsPf lensm a
	let x = List p1
	return $ RefPf (CompPut x (unzipPutPf a1 a2) (MapPut f)) (Prod (List a1) (List a2))

sortAttributesPf :: (MonadPlus m,Monad lensm) => TypeM lensm -> RefRulePfT m lensm
sortAttributesPf lensm a = splitAttsPf lensm a >>= aux lensm
	where aux :: (MonadPlus m,Monad lensm) => TypeM lensm -> RefPf lensm a -> m (RefPf lensm a)
	      aux lensm (RefPf f p@(Prod as es)) = do
			RefPf g asprod <- attsPf lensm as
			return $ RefPf (CompPut p (g `ProdPut` IdPut) f) (Prod asprod es)

attsPf :: (MonadPlus m,Monad lensm) => TypeM lensm -> RefRulePfT m lensm
attsPf lensm a = case attributesType a of DynT p -> return $ RefPf (Val (PutlnsM lensm p a) $ isoPut (toAtts a p) (fromAtts a p)) p
	where toAtts a p = injectatts p . sortBy (\(x,_) (y,_) -> if x == y then error "repeated att names" else compare x y) . attlist a
	      fromAtts a p x = populateAttType (attlist p x) a




