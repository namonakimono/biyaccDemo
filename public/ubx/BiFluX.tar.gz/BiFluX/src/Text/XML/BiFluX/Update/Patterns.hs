module Text.XML.BiFluX.Update.Patterns where

import Text.XML.BiFluX.Generic.Rewrite
import Text.XML.BiFluX.Lenses.ViewPf
import Text.XML.BiFluX.Update.AST
import Text.XML.BiFluX.Update.CoreAST
import Text.XML.BiFluX.DTD.Type as Type
import Text.XML.BiFluX.Lenses.Lib
import Generics.Putlenses.Putlens as Putlenses
import Generics.Putlenses.Language
import Text.XML.BiFluX.Lenses.View
import Text.XML.BiFluX.Lenses.Pf hiding (Ref)
import Text.XML.BiFluX.DTD.SubType
import Control.Monad.State (State(..),MonadState(..),StateT)
import qualified Control.Monad.State as State
import Control.Monad.Reader (Reader(..),MonadReader(..),ReaderT)
import qualified Control.Monad.Reader as Reader
import qualified Text.XML.HaXml.DtdToHaskell.TypeDef as TD
import Data.Maybe
import Control.Monad
import Data.Map (Map(..))
import qualified Data.Map as Map
import Text.XML.BiFluX.DTD.Normalize

import Debug.Trace

evalmatchVars :: (Eq a,MonadPlus m) => Pat -> TypeEnv -> Type a -> m [View' a]
evalmatchVars pat tenv a = do
	DynT p <- inferPatTypeWith tenv pat a -- infer the type for the pattern
	let pNoVars = removeProdVariables p -- removes the variable tags
	evalsubtypeput Type.Identity a pNoVars -- a <: pat
	lns <- evalsubtypeput Type.Identity pNoVars a -- pat <: a
	vars <- getPatVariables p -- gets only the variables
	liftM (map (applyView (\f r -> View' (put2lensErr "evalmatchVars" (lns .< f)) r))) (listPatVariables Type.Identity vars)

evalmatch :: (Eq a,MonadPlus m) => Pat -> TypeEnv -> Type a -> m (View' a)
evalmatch pat tenv a = do
	DynT p <- inferPatTypeWith tenv pat a -- infer the type for the pattern
	let pNoVars = removeProdVariables p -- removes the variable tags
	evalsubtype a pNoVars -- a <: pat
	lns <-  trace (show pNoVars ++ " " ++ show a)   evalsubtype pNoVars a -- pat <: a
	vars <- getPatVariables p -- gets only the variables
	return $ View' lns vars  --

match :: (Eq a,MonadPlus m) => Pat -> TypeEnv -> Type a -> m (ViewPfWithDecls' a)
match pat tenv a = do
	DynT p <- inferPatTypeWith tenv pat a -- infer the type for the pattern
	let pNoVars = removeProdVariables p -- removes the variable tags
	subtype a pNoVars -- is the type is a subtype of the pattern
	lns <- subtype pNoVars a -- is the pattern is a subtype of the type
	vars <- getPatVariables p -- gets only the variables
	return $ ViewPfW' lns vars

evalmatchsource :: (Eq s,MonadPlus m,MonadReader TypeEnv m) => Pat -> Type s -> m (View' s)
evalmatchsource pat s = do
	tenv <- Reader.ask
	DynT p <- inferPatTypeWith tenv pat s
	let pNoVars = removeProdVariables p
	lns <- evalsubtype pNoVars s
	vars <- getPatVariables p
	return $ View' lns vars

evalmatchsourceput :: (Eq s,MonadPlus m,Monad st,MonadReader TypeEnv m) => TypeM st -> Pat -> Type s -> m (View st s)
evalmatchsourceput st pat s = do
	tenv <- Reader.ask
	DynT p <- inferPatTypeWith tenv pat s
	let pNoVars = removeProdVariables p
	lns <- evalsubtypeput st pNoVars s
	vars <- getPatVariables p
	return $ View lns vars
	
evalmatchsourceput' :: (Eq s,MonadPlus m,Monad st) => TypeM st -> Pat -> TypeEnv -> Type s -> m (View st s)
evalmatchsourceput' st pat tenv s = do
	DynT p <- inferPatTypeWith tenv pat s
	let pNoVars = removeProdVariables p
	lns <- evalsubtypeput st pNoVars s
	vars <- getPatVariables p
	return $ View lns vars
	
matchsource :: (Eq s,MonadPlus m) => Pat -> TypeEnv -> Type s -> m (ViewPfWithDecls' s)
matchsource pat tenv s = do
	DynT p <- inferPatTypeWith tenv pat s
	let pNoVars = removeProdVariables p
	lns <- subtype pNoVars s
	vars <- getPatVariables p
	return $ ViewPfW' lns vars
	
matchsourceputWithDecls :: (Eq s,MonadPlus m,Monad st,MonadReader TypeEnv m) => TypeM st -> Pat -> Type s -> (StateT Prevs m) (ViewPf st s)
matchsourceputWithDecls st pat s = do
	tenv <- Reader.ask
	DynT p <- inferPatTypeWith tenv pat s
	let pNoVars = removeProdVariables p
	lns <- subtypeputNormWithDecls st pNoVars s
	vars <- getPatVariables p
	return $ ViewPf lns vars

casesourceputWithDecls :: (Eq s,MonadPlus m,MonadReader TypeEnv m,Monad lensm) => TypeM lensm -> [Pat] -> Type s -> (StateT Prevs m) (ViewPf lensm s)
casesourceputWithDecls st pats s = do
	tenv <- Reader.ask
	ViewPf f s' <- normalizePfT st s
	DynT p <- inferPatsTypeWith tenv pats s'
	let pNoVars = removePatsVariables p
	lns <- subtypeputNormWithDecls st pNoVars s'
	vars <- getPatsVariables p
	return $ ViewPf (CompPut s' f lns) vars

evalcase :: (Eq s,MonadPlus m,MonadReader TypeEnv m) => [Pat] -> Type s -> m (Rewrite' s)
evalcase pats s = do
	tenv <- Reader.ask
	DynT p <- inferPatsTypeWith tenv pats s
	let pNoVars = removePatsVariables p
	lns <- evalsubtype s pNoVars
	vars <- getPatsVariables p
	return $ Rewrite (return $ Putlenses.simplecreate lns) vars

evalmatchview :: (Eq v,MonadPlus m,MonadReader TypeEnv m) => Pat -> Type v -> m (Ref' v)
evalmatchview pat v = do
	tenv <- Reader.ask
	DynT p <- inferPatTypeWith tenv pat v
	checkPatVariables p -- view must not have non-variable elements
	let pNoVars = removeProdVariables p
	lns <- evalsubtype v pNoVars
	vars <- getPatVariables p
	return $ Ref' lns vars
	
evalmatchviewput :: (Eq v,MonadPlus m,Monad lensm) => TypeM lensm -> Pat -> TypeEnv -> Type v -> m (Ref lensm v)	
evalmatchviewput st pat tenv v = do
	DynT p <- inferPatTypeWith tenv pat v
	checkPatVariables p -- view must not have non-variable elements
	let pNoVars = removeProdVariables p
	lns <- evalsubtypeput st v pNoVars
	vars <- getPatVariables p
	return $ Ref lns vars

-- the pattern may be bigger than the view, so it may contain source types
matchview :: Eq v => MonadPlus m => Pat -> TypeEnv -> Type v -> m (RefPfWithDecls' v)
matchview pat tenv v = do
	DynT p <- inferPatTypeWith tenv pat v -- view variables first, otherwise search for source variables: source is not used for anything but to look for element types
	checkPatVariables p -- view must not have non-variable elements
	let pNoVars = removeProdVariables p
	lns <- subtype v pNoVars -- since variables are annotated as tags into the type, they would mess with subtyping, so we remove them to check for subtyping
	vars <- getPatVariables p
	return $ RefPfW' lns vars

matchviewputWithDecls :: (Eq v,MonadPlus m,Monad lensm,MonadReader TypeEnv m) => TypeM lensm -> Pat -> Type v -> (StateT Prevs m) (RefPf lensm v)	
matchviewputWithDecls st pat v = do
	tenv <- Reader.ask
	DynT p <- inferPatTypeWith tenv pat v
	checkPatVariables p -- view must not have non-variable elements
	let pNoVars = removeProdVariables p
	lns <- subtypeputNormWithDecls st v pNoVars
	vars <- getPatVariables p
	return $ RefPf lns vars

caseviewputWithDecls :: (MonadPlus m,MonadReader TypeEnv m,Monad st,Eq v) => TypeM st -> [Pat] -> Type v -> (StateT Prevs m) (RefPf st v)
caseviewputWithDecls st pats v = do
	tenv <- Reader.ask
	DynT p <- inferPatsTypeWith tenv pats v
	checkPatsVariables p -- view must not have non-variable elements
	let pNoVars = removePatsVariables p
	lns <- subtypeputNormWithDecls st v pNoVars
	vars <- getPatsVariables p
	return $ RefPf lns vars

checkPatsVariables :: MonadPlus m => Type a -> m ()
checkPatsVariables (Either a b) = checkPatsVariables a >> checkPatsVariables b
checkPatsVariables a = checkPatVariables a

checkPatVariables :: MonadPlus m => Type a -> m ()
checkPatVariables (Prod a b) = checkPatVariables a >> checkPatVariables b
checkPatVariables (Tag s t) = if isVar s then return () else checkPatVariables t
checkPatVariables a = error $ "found a non-variable " ++ show a

removePatsVariables :: Type a -> Type a
removePatsVariables (Either a b) = Either (removePatsVariables a) (removePatsVariables b)
removePatsVariables a = removeProdVariables a

removeProdVariables :: Type a -> Type a
removeProdVariables (Prod a b) = Prod (removeProdVariables a) (removeProdVariables b)
removeProdVariables x@(Tag s t) = if isVar s then t else Tag s (removeProdVariables t)
removeProdVariables a = a

getPatsVariables :: MonadPlus m => Type a -> m (Type a)
getPatsVariables (Either a b) = do
	x <- getPatsVariables a
	y <- getPatsVariables b
	return $ Either x y
getPatsVariables a = getPatVariables a

-- given pattern type (elements or tuples), returns a product of variables
getPatVariables :: MonadPlus m => Type a -> m (Type a)
getPatVariables (Prod a b) = do
	x <- getPatVariables a
	y <- getPatVariables b
	return $ Prod x y
getPatVariables x@(Tag s t) = if isVar s then return x else getPatVariables t
getPatVariables a = return a

--listPatVariableRules :: MonadPlus m => Type a -> m [(Var,CRule)]
--listPatVariableRules (Prod a b) = do
--	xs <- listPatVariableRules a
--	ys <- listPatVariableRules b
--	return $ (map (\(v,r) -> (v,CRuleFirst r)) xs) ++ (map (\(v,r) -> (v,CRuleSecond r)) ys)
--listPatVariableRules x@(Tag s@(isVar -> True) t) = return [(s,CRuleSkip)]
--listPatVariableRules x = return []

listPatVariableTypes :: (MonadPlus m,Monad st) => TypeM st -> Type vars -> m [(Var,DynType)]
listPatVariableTypes st vars = liftM (map (\(View _ (Tag (varName -> n) t)) -> (n,DynT t))) (listPatVariables st vars)

-- splits a product of tags into a list of tags (ignoring non-variables)
-- for example when pattern matching over the source we may ignore some matched pieces and abstract them away
listPatVariables :: (MonadPlus m,Monad st) => TypeM st -> Type vars -> m [View st vars]
listPatVariables st vars = listPatVariables' vars idPut

listPatVariables' :: (MonadPlus m,Monad st) => Type a -> PutlensM st vars a -> m [View st vars]
listPatVariables' (Prod a b) lns = do
	xs <- listPatVariables' a (lns .< keepsndDefPut b)
	ys <- listPatVariables' b (lns .< keepfstDefPut a)
	return (xs++ys)
listPatVariables' x@(Tag s@(isVar -> True) t) lns = return [View lns x]
listPatVariables' x lns = return []

-- splits a product of tags into a list of tags
listPatVariablesPf :: (MonadPlus m,Monad st) => TypeM st -> Type vars -> m [ViewPf st vars]
listPatVariablesPf st vars = listPatVariablesPf' vars IdPut

listPatVariablesPf' :: (MonadPlus m,Monad st) => Type a -> Pf (PutlensM st vars a) -> m [ViewPf st vars]
listPatVariablesPf' (Prod a b) lns = do
	xs <- listPatVariablesPf' a (CompPut (Prod a b) lns KeepsndDefPut)
	ys <- listPatVariablesPf' b (CompPut (Prod a b) lns KeepfstDefPut)
	return (xs++ys)
listPatVariablesPf' x@(Tag s@(isVar -> True) t) lns = return [ViewPf lns x]
listPatVariablesPf' x lns = return []

prodTypes :: [DynType] -> DynType
prodTypes [] = DynT One
prodTypes [DynT t] = DynT t
prodTypes (DynT t:ts) = applyDynT (\r -> DynT $ Prod t r) (prodTypes ts)

prodVariables :: [(String,DynType)] -> DynType
prodVariables [] = DynT One
prodVariables [(v,DynT t)] = DynT (Tag (mkVar v) t)
prodVariables ((v,DynT t):ts) = applyDynT (\r -> DynT $ Prod (Tag (mkVar v) t) r) (prodVariables ts)

prodViews :: (Eq s,Monad m) => [ViewPf m s] -> ViewPf m s
prodViews [] = ViewPf KeepPut One
prodViews [ViewPf f a] = ViewPf f a
prodViews (ViewPf f a:vs) = case prodViews vs of
	ViewPf g b -> ViewPf (f `UnforkPut` g) (Prod a b)	

inferPatsTypeWith :: (Eq a,MonadPlus m) => TypeEnv -> [Pat] -> Type a -> m DynType
inferPatsTypeWith tenv pats a = liftM eitherPats $ mapM (\pats -> inferPatTypeWith tenv pats a) pats

inferPatsType :: MonadPlus m => TypeEnv -> [Pat] -> m DynType
inferPatsType tenv = liftM eitherPats . mapM (inferPatType tenv)

eitherPats :: [DynType] -> DynType
eitherPats [t] = t
eitherPats (t:ts) = applyDynT2 (\x y -> DynT (Either x y)) t (eitherPats ts)

-- the type is used to look for existing type names
-- currently we do not support non-annotated variables, what would require more powerful type inference algorithms
-- receives a starting type like XDuce's type inference algorithm, but here we are only using it for checking a trivial single variable pattern...
inferPatTypeWith :: (Eq a,MonadPlus m) => TypeEnv -> Pat -> Type a -> m DynType
inferPatTypeWith tenv (VarPat (VarV v)) a = return $ DynT $ Tag (mkVar v) a
inferPatTypeWith tenv pat a = inferPatType tenv pat

inferPatType :: MonadPlus m => TypeEnv -> Pat -> m DynType
inferPatType tenv (SequencePat pats) = liftM (foldType (\x y -> DynT $ Prod x y)) $ mapM (inferPatType tenv) pats
inferPatType tenv (ElementPat name pats) = liftM (applyDynT (DynT . Tag name)) $ inferPatType tenv (SequencePat pats)
inferPatType tenv (AttributePat name varp) = liftM (applyDynT toAttribute) $ inferPatVarType tenv varp
    where toAttribute :: Eq a => Type a -> DynType
          toAttribute a@(Tag (varName -> _) (getLiteral -> Just _)) = DynT (Tag (mkAtt name) a)
          toAttribute a@(getLiteral -> Just _) = DynT (Tag (mkAtt name) a)
          toAttribute a = error $ "non-primitive attribute content " ++ show a
inferPatType tenv (VarPat var) = inferPatVarType tenv var
	
inferPatVarType :: MonadPlus m => TypeEnv -> VarP -> m DynType
inferPatVarType tenv (VarV v) = error $ "non-annotated variables " ++ show v ++ " currently unsupported"
inferPatVarType tenv (VarT v t) = liftM (applyDynT (DynT . Tag (mkVar v))) $ inferAstType tenv t
inferPatVarType tenv (VarTP t) = inferAstType tenv t

foldType :: (forall a b . (Eq a,Eq b) => Type a -> Type b -> DynType) -> [DynType] -> DynType
foldType f [] = DynT One
foldType f [t] = t
foldType f (t:ts) = applyDynT2 f t (foldType f ts)

inferAstType :: MonadPlus m => TypeEnv -> AstType -> m DynType
inferAstType tenv EmptyT = return $ DynT One
inferAstType tenv (NameT n) = case Map.lookup n tenv of
	Just t -> return t
	Nothing -> fail $ "type declaration " ++ show n ++ "not defined"
inferAstType tenv (ElementT n t) = liftM (applyDynT (DynT . Tag n)) $ inferAstType tenv t
inferAstType tenv (AttributeT n t) = liftM (applyDynT toAttribute) $ inferAstType tenv t
    where toAttribute :: Eq a => Type a -> DynType
          toAttribute a@(getLiteral -> Just _) = DynT (Tag (mkAtt n) a)
          toAttribute a = error $ "non-primitive attribute content " ++ show a
inferAstType tenv (SequenceT t1 t2) = do
	DynT a <- inferAstType tenv t1
	DynT b <- inferAstType tenv t2
	return $ DynT $ Prod a b
inferAstType tenv (StarT t) = liftM (applyDynT (DynT . List)) $ inferAstType tenv t
inferAstType tenv (ChoiceT t1 t2) = do
	DynT a <- inferAstType tenv t1
	DynT b <- inferAstType tenv t2
	return $ DynT $ Either a b
inferAstType tenv StringT = return $ DynT String


