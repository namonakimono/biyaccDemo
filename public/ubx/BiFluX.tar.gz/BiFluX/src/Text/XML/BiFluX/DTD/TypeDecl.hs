module Text.XML.BiFluX.DTD.TypeDecl where

import Text.PrettyPrint.HughesPJ
import Text.XML.BiFluX.Update.AST
import Text.XML.BiFluX.DTD.Type
import Data.List.Split
import Data.Map (Map(..))
import qualified Data.Map as Map
import Text.XML.BiFluX.DTD.HaXml.TypeDef hiding (mkAtt)

type ModNames = Map String String -- pairs (mod:name,hsName)

impschemas2modnames :: [ImportSchema] -> ModNames
impschemas2modnames [] = Map.empty
impschemas2modnames (Import file n:xs) = Map.insert n (mangle (trim file)) (impschemas2modnames xs)

impsschemas2envs :: [ImportSchema] -> Doc
impsschemas2envs [] = text "Map.empty"
impsschemas2envs (Import hs n:xs) = text "Map.union"
	<+> parens (text "Map.mapKeys" <+> parens (text (show (n++":")++"++")) <+> text ((mangle (trim hs))++".typeEnv"))
	<+> parens (impsschemas2envs xs)

mkBXTypeEnv :: Program -> Doc
mkBXTypeEnv (Program imps _ _ decls) = mkDeclsTypeEnv modnames (typeDecls decls) <> text "\n" <> text "typeEnv =" <+> mkBXRoot decls doc
	where modnames = impschemas2modnames imps
	      doc = impsschemas2envs imps

mkBXRoot :: [Decl] -> Doc -> Doc
mkBXRoot decls doc = (foldr (\(x,t) m -> text "Map.insert" <+> text (show x) <+> parens (text "DynT" <+> text ("type"++x)) <+> parens m) doc . typeDecls) decls

mkDeclsTypeEnv :: ModNames -> [(String,AstType)] -> Doc
mkDeclsTypeEnv modnames = foldr (\(n,d) doc -> typedecl2doc modnames n d <> text "\n" <> doc) (text "")

typedecl2doc :: ModNames -> String -> AstType -> Doc
typedecl2doc modnames name t = text ("type"++name) <+> text "=" <+> astType2doc modnames t

astType2doc :: ModNames -> AstType -> Doc
astType2doc modnames EmptyT = text "One"
astType2doc modnames (NameT n) = case sepBy ":" n of
	[s] -> parens $ text "TypeRef" <+> text (show s) <+> text ("type"++s) -- non-qualified
	[m,s] -> case Map.lookup m modnames of
		Just str -> parens (text "typeof ::" <+> text "Type" <+> text ((Map.!) modnames m ++"."++mangle s)) -- qualified
		Nothing -> error $ "cannot find string " ++ show m ++ " in " ++ show modnames 
astType2doc modnames (ElementT n t) = parens $ text ("Tag " ++ show n) <+> astType2doc modnames t
astType2doc modnames (AttributeT n t) = parens $ text ("Tag " ++ show (mkAtt n)) <+> astType2doc modnames t
astType2doc modnames (SequenceT t1 t2) = parens $ text "Prod" <+> astType2doc modnames t1 <+> astType2doc modnames t2
astType2doc modnames (ChoiceT t1 t2) = parens $ text "Either" <+> astType2doc modnames t1 <+> astType2doc modnames t2
astType2doc modnames (StarT t1) = parens $ text "List" <+> astType2doc modnames t1
astType2doc modnames StringT = parens $ text "String"
