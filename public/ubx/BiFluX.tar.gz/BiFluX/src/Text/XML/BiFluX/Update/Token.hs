module Text.XML.BiFluX.Update.Token where
import Text.ParserCombinators.Parsec
import System.Environment
import Data.Char
import Data.List

data Token
    = IMPORT | TYPE | DOC
    | START 
    | PROCEDURE | UPDATE | BY | FOR | VIEW | MATCHING | SOURCE  
    | INSERT | BEFORE | AFTER | VALUE | AS | LAST | FIRST | INTO 
    | DELETE | FROM | REPLACE | WITH 
    | CREATE | KEEP
    | EITHER | MATCH | UNMATCHV | UNMATCHS  | ARROW 
    | CASE | OF 
    | WHERE | IF | THEN | ELSE 
    | LET | ASSIGN | IN 
    | STAG | ETAG | ATSIGN | TLT | TGT 
    | LSB | RSB | LP | RP | LB | RB  -- LSB {, LB [, LP (
    | QEQ | QNEQ| STAR | OPT | PLUS 
    | COMMA | COLON | SEMI  -- , : ;
    | QDSLASH | QSLASH | QDOT 
    | QEMark | QMinus
    | QName String | QString String  -- QName abc, QString 'abc' or "abc" 
    | TokenEOF
    | QXmlText String  -- <> fdfa fdaf <> -- must keep the original things including spaces.
--    | CommentStart -- <!-- 
    | QTName String  -- start with captilized letter.     
--    | QLet | QIf  -- XQuery let and if
    | QVar String
    | QEOF
    | QError String
    | QReturn 
    | QTrue | QFalse
    | TST  | TET
    | QAttrName String --added attribute name
--    | QSelf | QChild | QAttribute  --path token But: this is not keyword ???  OOOr: consider it as normal string. distinguish at parser level.
    |  AND | OR
    | FORVIEW
  deriving (Eq, Show)


-- for skip spaces and newlines
skipManySN :: Parser ()
skipManySN = skipMany (space <|> newline) <?> ""


t :: Parser [Token]
t = do { 
      skipManySN
    ; t1 <- (try tComment) <|> (try tImport) <|> (try tVar) <|> (try tXmlExp) <|> (try tForView)<|> (try tToken) <|> (try tEOF) <|> (try tName) <|> (try tSString) <|> (try tDString) <|> (try tNum)
    ; if (t1 /= [QEOF])
         then do {
                t2 <- t
              ; return (t1 ++ t2) }
      else
          return []
    }
--    <?> "token"


tComment :: Parser [Token]
tComment = do {
             skipManySN
           ; try(string "<!--")  <|> try(string "(:")
           ; comment <- manyTill anyChar (try(string "-->") <|> try(string ":)"))
           ; return []
           }


tImport :: Parser [Token]
tImport = do {
            skipManySN
          ; try (string "import" <|> string "IMPORT") <?> "import_IMPORT"
          ; skipManySN
          ; char '\'' <|> char '\"' <?> "import_quote"
          ; dtdFName <- endBy1 (many (letter <|> digit <|> char '_' <|> char '.')) (char '\"' <|> char '\'') 
          ; skipManySN
          ; string "as" <|> string "AS" <?> "import_AS"
          ; skipManySN
          ; sOrV <- getName
          ; return (IMPORT : QName (head dtdFName) : AS : QName sOrV : [])
          }


tToken :: Parser [Token]
tToken =  (try tAnd) <|> (try tOR) <|>(try tEither) <|> (try tArrow) <|> (try tAssign) 
         <|> (try tAtsign) <|> (try tLSB) <|> (try tRSB) <|> (try tLP)  <|> (try tRP) <|> (try tLB) 
         <|> (try tRB) <|> (try tQNeq)<|> (try tQeq) <|> (try tStar)  <|> (try tOpt) <|> (try tPlus) <|> (try tComma) <|> (try tColon)
         <|> (try tSemi) <|> (try tQDSlash ) <|>(try tQslash) <|> (try tQdot)
         <|> (try tLT)  <|> (try tGT)

tForView :: Parser [Token]
tForView = do {
    try(string "for") <|> try(string "FOR") <?> "keyword_FOR"
  ; skipManySN
  ; try(string "view") <|> try(string "VIEW") <?> "keyword_VIEW"
  ; return [FORVIEW]
}


--todo: IF and Let are ambiguous.
tIf :: Parser [Token]
tIf = do {
        string "if" <|> string "IF" <?> "keyword_IF"
      ; return [IF]
      }


--todo: let
--(endBy1 () (many1 space))
tLet :: Parser [Token]
tLet = do {
         string "let" <|> string "LET" <?> "keyword_LET"
       ; return [LET]
       }

-- end 
------------------------------------------------

tArrow :: Parser [Token]
tArrow = do {
           string "->" <?> "keyword_MATCH"
         ; return [ARROW]
         }

tAnd :: Parser [Token]
tAnd = do {
          char '&';
          char '&';
          return [AND]
          }

tOR :: Parser [Token]
tOR = do {
        char '|';
        char '|';
        return [OR]
      } 

tEither :: Parser [Token]
tEither = do {
            char '|'
          ; return [EITHER]
          }

tAssign :: Parser [Token]
tAssign = do {
            string ":=" <?> "keyword_MATCH"
          ; return [ASSIGN]
          }

tAtsign :: Parser [Token]
tAtsign = do {
            char '@' <?> "keyword_@"
          ; return [ATSIGN]
          }

tLSB :: Parser [Token]
tLSB = do {
         char '{' <?> "keyword_{"
       ; return [LSB]
       }

tRSB :: Parser [Token]
tRSB = do {
         char '}' <?> "keyword_}"
       ; return [RSB]
       }

tLP :: Parser [Token]
tLP = do {
        char '(' <?> "keyword_("
      ; return [LP]
      }

tRP :: Parser [Token]
tRP = do {
        char ')' <?> "keyword_)"
      ; return [RP]
      }

tLB :: Parser [Token]
tLB = do {
        char '[' <?> "keyword_["
      ; return [LB]
      }

tRB :: Parser [Token]
tRB = do {
        char ']' <?> "keyword_]"
      ; return [RB]
      }

tQeq :: Parser [Token]
tQeq = do {
         char '=' <?> "keyword_="
       ; return [QEQ]
       }

tQNeq :: Parser [Token]
tQNeq = do {
         char '!'; 
         char '=' <?> "keyword_="
       ; return [QNEQ]
       }


tStar :: Parser [Token]
tStar = do {
           char '*' <?> "keyword_*"
         ; return [STAR]
         }

tOpt :: Parser [Token]
tOpt = do {
         char '?' <?> "keyword_?"
       ; return [OPT]
       }

tPlus :: Parser [Token]
tPlus = do {
          char '+' <?> "keyword_+"
        ; return [PLUS]
        }

tComma :: Parser [Token]
tComma = do {
           char ',' <?> "keyword_,"
         ; return [COMMA]
         }
tColon :: Parser [Token]
tColon = do {
           char ':' <?> "keyword_,"
         ; return [COLON]
         }
tSemi :: Parser [Token]
tSemi = do {
          char ';' <?> "keyword_;"
        ; return [SEMI]
        }

tQDSlash ::Parser [Token]
tQDSlash = do {
             char '/' 
           ; char '/'
           ; return [QDSLASH]
         }


tQslash :: Parser [Token]
tQslash = do {
           char '/' <?> "keyword_/"
         ; return [QSLASH]
         }



tQdot :: Parser [Token]
tQdot = do {
          char '.' <?> "keyword_."
        ; return [QDOT]
        }

--    | QEMark | QMinus
tQEMark :: Parser [Token]
tQEMark = do {
          char '!' <?> "keyword_!"
        ; return [QEMark]
        }

tQMinus :: Parser [Token]
tQMinus = do {
          char '-' <?> "keyword_-"
        ; return [QMinus]
        }

-----------------------------------------------------------------------------------

tVar :: Parser [Token]
tVar = do {
      skipManySN
    ; var <- try (getVar )
    ; return [QVar var]
    }

-- todo: EOF is not like this !!!
tEOF :: Parser [Token]
tEOF = do {
         skipManySN
       --(endBy1 (string "EOF") (many1 space))
       ; try eof
       ; return [QEOF]
       }

--tName include keyword and normal names
tName :: Parser [Token]
tName = do {
          skipManySN
        ; name <- getName <|> getTName
        -- judge the name whether it is a reserved token or not.
        ; case lookup name tokenList of
            Just token -> return [token]
            Nothing    -> case isUpper (head name) of
                            True ->  return [(QTName name)]
                            False -> return [(QName name)]
        }


tNum :: Parser [Token]
tNum = do {
         skipManySN
       ; num <- getDigits
       ; return [QString num]
       }


tokenList :: [(String, Token)]
tokenList = [("import", IMPORT),("IMPORT", IMPORT), ("type", TYPE), ("TYPE", TYPE), ("doc", DOC), ("DOC", DOC), ("start", START), ("START", START), ("procedure", PROCEDURE), ("PROCEDURE", PROCEDURE), ("update", UPDATE), ("UPDATE", UPDATE), ("by", BY), ("BY", BY) , ("for", FOR), ("FOR", FOR), ("view", VIEW), ("VIEW", VIEW), ("matching", MATCHING), ("MATCHING", MATCHING), ("source", SOURCE), ("SOURCE", SOURCE), ("as", AS), ("AS", AS), ("insert", INSERT), ("INSERT", INSERT), ("before", BEFORE), ("after", AFTER), ("AFTER", AFTER), ("value", VALUE), ("VALUE", VALUE), ("last", LAST), ("LAST", LAST), ("first", FIRST), ("FIRST", FIRST), ("into", INTO), ("INTO", INTO), ("delete", DELETE), ("DELETE", DELETE), ("from", FROM), ("FROM", FROM), ("replace", REPLACE), ("REPLACE", REPLACE), ("with", WITH), ("WITH", WITH), ("create", CREATE), ("CREATE", CREATE), ("keep", KEEP), ("KEEP", KEEP), ("match", MATCH), ("MATCH", MATCH), ("unmatchv", UNMATCHV), ("UNMATCHV", UNMATCHV), ("unmatchs", UNMATCHS), ("UNMATCHS", UNMATCHS), ("in", IN), ("IN", IN), ("case", CASE), ("CASE", CASE), ("of", OF), ("OF", OF), ("where", WHERE), ("WHERE", WHERE), ("then", THEN), ("THEN", THEN), ("eles", ELSE), ("ELSE", ELSE), ("return", QReturn), ("RETURN", QReturn), ("true", QTrue), ("fase", QFalse), ("let", LET), ("LET", LET), ("if", IF), ("IF", IF)] --, ("self", QSelf), ("child", QChild), ("attribute", QAttribute)]


tSString :: Parser [Token]
tSString = do {
             skipManySN
           ; try(char '\'')
           ; str <- (manyTill (noneOf "\'") (string "\'")) 
           ; return [QString str]
          }
           <?> "tSString"

tDString :: Parser [Token]
tDString = do {
             skipManySN
           ; try(string "\"")
           ; str <- (manyTill (noneOf "\"") (string "\"")) 
           ; return [QString str]
          }
           <?> "tDString"


--todo: exp can also be variables
-- not only string.
tXmlExp :: Parser [Token]
tXmlExp = do {
            skipManySN
          ; try (lookAhead (char '<' >> spaces >> letter))
          ; char '<'
          ; skipManySN
          ; tagName <- getName
          ; skipManySN
          ; attrTokenLst <- sepEndBy (tAttr) (many1 space)
          ; skipManySN
          ; do {
              try ( char '/' >> char '>') 
            ; return ((TST: QName tagName : []) ++ (foldr (++) [] attrTokenLst) ++   (ETAG: []))
            }
            <|> 
            do {
              char '>'
            ; tokens <- sepEndBy ((try tXmlVar) <|>(try tXmlString) <|> (try tXmlExp)) ((lookAhead (skipManySN >> anyChar )))
                        <|> tEmpty
            ; skipManySN
            ; char '<'
            ; char '/'
            ; skipManySN
            ; tagName1 <- getName
            ; skipManySN
            ; char '>'
            ; return ((TST: QName tagName : []) 
                      ++ (foldr (++) [] attrTokenLst) 
                      ++ (TET : [])
                      ++ (foldr (++) [] tokens )
                      ++ (STAG: QName tagName1 : TET: []))
            }
          }


tXmlString :: Parser [Token]
tXmlString = do {
               skipManySN
             ; try (lookAhead (noneOf "<")) --no: shall check </
             ; str <- manyTill anyChar (lookAhead (char '<'))
             ; return [QString str]
             }

tEmpty :: Parser [[Token]]
tEmpty = do {
           return []
         }

tXmlVar :: Parser [Token]
tXmlVar = do {
            skipManySN
          ; try (char '{')
          ; skipManySN
          ; var <- getVar
          ; skipManySN
          ; char '}'
          ; return [QVar var]
          }
    <|> do {
          skipManySN
        ; var <- getVar
        ; skipManySN
        ; return [QVar var]
        }


--todo: tAttr need consider var {$var}
--either string or variable 
tAttr :: Parser [Token]
tAttr = do {
          skipManySN
        ; attrName <- getName
        ; skipManySN
        ; char '='
        ; skipManySN
        ; do {
            try(char '"' <|> char '\'')
          ; value <- manyTill (anyChar) (char '"' <|> char '\'')
          ; return (QAttrName attrName : QEQ : QString value: [])
          }
          <|>
          do {
            try (char '{')
          ; skipManySN        
          ; var <- getVar
          ; skipManySN
          ; char '}'
          ; return (QAttrName attrName : QEQ : QVar var: [])
          }
          <|>
          do {
            var <- getVar
          ; return (QAttrName attrName : QEQ : QVar var: [])
          }
        }



tLT :: Parser [Token]
tLT = do {
          char '<' <?> "keyword_<"
        ; return [TLT]
}

tGT :: Parser [Token]
tGT = do {
          char '>' <?> "keyword_>"
        ; return [TGT]
}

--------------------------------------------------------------------------
-- Helper functions
-------------------------------------------------------------------------

--heper function: get name like: abv ab2 ab_2.
-- i.e. start with a lower case letter, then followed by either leteer or digit or _
getName :: Parser String
getName = do {
            fstChr <- lower
          ; rest <- many (alphaNum <|> char '_')
          ; return (fstChr : rest)
          }
    <?> "getName"

getDigits :: Parser String
getDigits = do {
             num <- many1 digit
           ; return num
           }


--helper function: get variable start with $
getVar :: Parser String
getVar = do {
           char '$'
         ; var <- getName
         ; return var
         }
    <?> "getVar"

-- get Type Name
-- i.e. first letter is captilized.
-- todo: TName cannot be keyword

getTName :: Parser String
getTName = do {
             fstChr <- upper
           ; rest <- many (alphaNum <|> char '_')
           ; return (fstChr : rest)
           }
    <?> "getTName"
