module Text.XML.BiFluX.Update.AST where

import Data.Set (Set(..))
import qualified Data.Set as Set
import Data.Generics.TH
import Text.XML.BiFluX.XQuery.UXQ
import Data.List
import Text.XML.BiFluX.XPath.HXT.XPathDataTypes as XPath hiding (Name(..))
import Control.Monad

data Program  = Program [ImportSchema] [VarBind] Start [Decl]
                deriving (Eq,Show)

data VarBind = VarBind Var FilePath --string
                deriving (Eq,Show)

data ImportSchema = Import FilePath String deriving (Eq,Show)

data Decl = ProcedureDecl Procedure
          | TypeDecl String AstType
		deriving (Eq,Show)  

data Procedure = Procedure Name [(ProcVar,AstType)] Stmts
	deriving (Eq,Show)

data Start  = Start Name [XQExpr]
             deriving (Eq,Show)

data ProcVar = ProcSVar Var -- source $x AS a
			 | ProcVVar Var -- view $x AS a
			 | ProcEVar Var -- $x as a
	deriving (Eq,Show)

type Stmts = [Stmt]

data Stmt = StmtUpd Upd [WhereCond]
          | StmtIF  BoolExpr Stmts Stmts
          | StmtLet Pat  XQExpr Stmts  
          | StmtP Name [XQExpr]
          | StmtCase XQExpr [(Pat,Stmts)]
            deriving (Eq,Show)


data WhereCond = WhereBool BoolExpr
               | WhereBind Var XQExpr 
                 deriving (Eq,Show)

data SInsertionLocation = UBEFORE | UAFTER deriving (Eq,Show)
data PInsertionLocation = ULAST  | UFIRST deriving (Show,Eq)

data Upd  = SingleInsertion SInsertionLocation (Maybe Pat) CPath XQExpr
          | PluralInsertion PInsertionLocation (Maybe Pat) CPath XQExpr 
          | SingleDeletion (Maybe Pat) CPath
          | PluralDeletion (Maybe Pat) CPath
          | SingleReplace (Maybe Pat) CPath XQExpr
          | PluralReplace (Maybe Pat) CPath XQExpr
          | UpdateSource (Maybe Pat) CPath Stmts  
          | UpdateView (Maybe Pat) CPath ViewStmts (Maybe Pat) CPath (Maybe MatchCond)      
          | UpdateKeep CPath -- the intuition for keep as first/last is not very good, we should just drop it
          | UpdateCreate XQExpr
            deriving (Eq,Show)

type ViewStmts = [ViewStmt]

data ViewStmt = ViewStmtMatch Stmts                       
              | ViewStmtUMV   Stmts
              | ViewStmtUMS   Stmts
              deriving (Eq,Show)

data MatchCond = MatchBY CPath
	           | MatchSV CPath CPath  
                deriving (Eq,Show)         

type BoolExpr = XQExpr
	
data Pat = SequencePat [Pat]
         | ElementPat Name [Pat]
         | AttributePat Name VarP
         | VarPat VarP
         deriving (Eq,Show)
     
data VarP = VarV Var
          | VarT Var AstType
          | VarTP AstType
         deriving (Eq,Show)

data AstType = EmptyT
             | NameT Name -- reference to a type declaration name
             | ElementT String AstType
             | AttributeT String AstType
             | SequenceT AstType AstType
             | StarT AstType
             | ChoiceT AstType AstType
             | StringT
			deriving (Eq,Show)
-- t? and t+ should be parsed as derived forms t|() and t,t*

type Var = String
type Name = String

findProcedureDecl :: Name -> [Decl] -> Maybe Procedure
findProcedureDecl name xs = do { ProcedureDecl p <- find test xs; return p }
	where test (ProcedureDecl (Procedure n _ _)) = n == name
	      test (TypeDecl _ _) = False

procedureDecls :: [Decl] -> [Procedure]
procedureDecls [] = []
procedureDecls (ProcedureDecl p:xs) = p : procedureDecls xs
procedureDecls (x:xs) = procedureDecls xs

typeDecls :: [Decl] -> [(String,AstType)]
typeDecls [] = []
typeDecls (TypeDecl n d:xs) = (n,d) : typeDecls xs
typeDecls (x:xs) = typeDecls xs

isProcS :: ProcVar -> Bool
isProcS (ProcSVar v) = True
isProcS _ = False

isProcV :: ProcVar -> Bool
isProcV (ProcVVar v) = True
isProcV _ = False

isProcE :: ProcVar -> Bool
isProcE (ProcEVar v) = True
isProcE _ = False

splitViewStmts :: [ViewStmt] -> ([Stmts],[Stmts],[Stmts])
splitViewStmts [] = ([],[],[])
splitViewStmts (ViewStmtMatch s:vs) = let (xs,ys,zs) = splitViewStmts vs in (s:xs,ys,zs)
splitViewStmts (ViewStmtUMV s:vs) = let (xs,ys,zs) = splitViewStmts vs in (xs,s:ys,zs)
splitViewStmts (ViewStmtUMS s:vs) = let (xs,ys,zs) = splitViewStmts vs in (xs,ys,s:zs)

splitProcVars :: [(ProcVar,a)] -> ([(Var,a)],[(Var,a)],[(Var,a)])
splitProcVars [] = ([],[],[])
splitProcVars ((ProcSVar v,t):ps) = let (xs,ys,zs) = splitProcVars ps in ((v,t):xs,ys,zs)
splitProcVars ((ProcVVar v,t):ps) = let (xs,ys,zs) = splitProcVars ps in (xs,(v,t):ys,zs)
splitProcVars ((ProcEVar v,t):ps) = let (xs,ys,zs) = splitProcVars ps in (xs,ys,(v,t):zs)

matchPaths (MatchBY path) = (path,path)
matchPaths (MatchSV paths pathv) = (paths,pathv)

matchVars :: MatchCond -> Set Var
matchVars (MatchBY p) = cpathVars p
matchVars (MatchSV sp vp) = cpathVars sp `Set.union` cpathVars vp

mbMatchVars :: Maybe MatchCond -> Set Var
mbMatchVars Nothing = Set.empty
mbMatchVars (Just m) = matchVars m

unionVars :: [Set Var] -> Set Var
unionVars = foldr (\e s -> e `Set.union` s) Set.empty

vstmtsVars = unionVars . map vstmtVars

vstmtVars :: ViewStmt -> Set Var
vstmtVars (ViewStmtMatch stmts) = stmtsVars stmts
vstmtVars (ViewStmtUMV stmts) = stmtsVars stmts
vstmtVars (ViewStmtUMS stmts) = stmtsVars stmts

stmtsVars = unionVars . map stmtVars

stmtVars :: Stmt -> Set Var
stmtVars (StmtUpd upd cond) = updVars upd `Set.union` wheresVars cond
stmtVars (StmtIF cond s1 s2) = uXQVars cond `Set.union` stmtsVars s1 `Set.union` stmtsVars s2
stmtVars (StmtLet pat expr s) = (uXQVars expr `Set.union` stmtsVars s) `Set.difference` patVars pat
stmtVars (StmtP name exprs) = uXQsVars exprs
stmtVars (StmtCase expr xs) = uXQVars expr `Set.union` caseStmtVars xs

caseStmtVars :: [(Pat,Stmts)] -> Set Var
caseStmtVars [] = Set.empty
caseStmtVars ((p,s):xs) = (stmtsVars s `Set.difference` patVars p) `Set.union` caseStmtVars xs

mbPatVars :: Maybe Pat -> Set Var
mbPatVars Nothing = Set.empty
mbPatVars (Just pat) = patVars pat

-- variables in the left-hand side of a pattern
patVars :: Pat -> Set Var
patVars path = $(everything [| Set.union |] (mkQ [| Set.empty |] 'f) [t| Pat |]) path
    where f :: VarP -> Set Var
          f (VarV v) = Set.singleton v
          f (VarT v _) = Set.singleton v

updVars :: Upd -> Set Var
updVars (SingleInsertion _ pat path expr) = (cpathVars path `Set.union` uXQVars expr) `Set.difference` mbPatVars pat
updVars (PluralInsertion _ pat path expr) = (cpathVars path `Set.union` uXQVars expr) `Set.difference` mbPatVars pat
updVars (SingleDeletion pat path) = cpathVars path `Set.difference` mbPatVars pat
updVars (PluralDeletion pat path) = cpathVars path `Set.difference` mbPatVars pat
updVars (SingleReplace pat path expr) = (cpathVars path `Set.union` uXQVars expr) `Set.difference` mbPatVars pat
updVars (PluralReplace pat path expr) = (cpathVars path `Set.union` uXQVars expr) `Set.difference` mbPatVars pat
updVars (UpdateSource pat path stmts) = (cpathVars path `Set.union` stmtsVars stmts) `Set.difference` mbPatVars pat
updVars (UpdateView spat spath vstmts vpat vpath mcond) = (cpathVars spath `Set.union` cpathVars vpath `Set.union` vstmtsVars vstmts `Set.union` mbMatchVars mcond) `Set.difference` (mbPatVars spat `Set.union` mbPatVars vpat)
updVars (UpdateKeep path) = cpathVars path
updVars (UpdateCreate expr) = uXQVars expr

wheresVars = unionVars . map whereVars

whereVars :: WhereCond -> Set Var
whereVars (WhereBool expr) = uXQVars expr
whereVars (WhereBind var expr) = Set.insert var (uXQVars expr)

splitWheres :: [WhereCond] -> ([XQExpr],[(Var,XQExpr)])
splitWheres [] = ([],[])
splitWheres (WhereBool e:ws) = let (xs,ys) = splitWheres ws in (e:xs,ys)
splitWheres (WhereBind v e:ws) = let (xs,ys) = splitWheres ws in (xs,(v,e):ys)

whereBindConds :: [(Var,XQExpr)] -> XQExpr
whereBindConds = andExpr . map (\(v,e) -> XQBinOp XPath.Eq (XQPath $ CPathVar v) e)

whereCond :: WhereCond -> BoolExpr
whereCond (WhereBool expr) = expr
whereCond (WhereBind v e) = XQBinOp XPath.Eq (XQPath $ CPathVar v) e 

whereConds :: [WhereCond] -> BoolExpr
whereConds = andExpr . map whereCond

procedureArgVars :: Procedure -> (Name,[ProcVar])
procedureArgVars (Procedure n args stmts) = (n,map fst args)

-- if a statement has at least one relative source path
stmtsRelativeSourcePaths :: Stmts -> Bool
stmtsRelativeSourcePaths = foldr (\x b -> stmtRelativeSourcePaths x || b) False

stmtRelativeSourcePaths :: Stmt -> Bool
stmtRelativeSourcePaths stmt = False -- TODO: we should implement this check!


