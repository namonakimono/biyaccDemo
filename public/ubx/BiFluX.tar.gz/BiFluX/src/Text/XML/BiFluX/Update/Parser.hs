{-# OPTIONS_GHC -w #-}
module Text.XML.BiFluX.Update.Parser where
import Text.XML.BiFluX.Update.Token 
import Data.Char
import Data.List
import qualified Data.Text as T
import Data.Maybe
import Text.XML.HXT.DOM.QualifiedName as HXTQN
import Text.XML.BiFluX.Update.AST 
import Text.XML.BiFluX.XQuery.UXQ
import Text.XML.BiFluX.XPath.HXT.XPathDataTypes as XPath

-- parser produced by Happy Version 1.18.9

data HappyAbsSyn 
	= HappyTerminal (Token)
	| HappyErrorToken Int
	| HappyAbsSyn4 (Program)
	| HappyAbsSyn5 ([ImportSchema])
	| HappyAbsSyn6 (ImportSchema)
	| HappyAbsSyn7 ([VarBind])
	| HappyAbsSyn8 (VarBind)
	| HappyAbsSyn9 (Start)
	| HappyAbsSyn10 ([XQExpr])
	| HappyAbsSyn11 ([Decl])
	| HappyAbsSyn12 (Decl)
	| HappyAbsSyn13 (Procedure)
	| HappyAbsSyn14 ([(ProcVar, AstType)])
	| HappyAbsSyn15 ((ProcVar, AstType))
	| HappyAbsSyn16 ([Stmt])
	| HappyAbsSyn18 (Stmt)
	| HappyAbsSyn19 ([(Pat, Stmts)])
	| HappyAbsSyn20 ((Pat, Stmts))
	| HappyAbsSyn21 ([WhereCond])
	| HappyAbsSyn22 (WhereCond)
	| HappyAbsSyn23 (BoolExpr)
	| HappyAbsSyn24 (Upd)
	| HappyAbsSyn25 (Maybe Pat)
	| HappyAbsSyn26 (Maybe MatchCond)
	| HappyAbsSyn27 ([ViewStmt])
	| HappyAbsSyn29 (ViewStmt)
	| HappyAbsSyn30 (MatchCond)
	| HappyAbsSyn31 (XQExpr)
	| HappyAbsSyn35 (XPath.Op)
	| HappyAbsSyn40 (CPath)
	| HappyAbsSyn42 ([Pat])
	| HappyAbsSyn43 (Pat)
	| HappyAbsSyn44 (VarP)
	| HappyAbsSyn45 (AstType)

{- to allow type-synonyms as our monads (likely
 - with explicitly-specified bind and return)
 - in Haskell98, it seems that with
 - /type M a = .../, then /(HappyReduction M)/
 - is not allowed.  But Happy is a
 - code-generator that can just substitute it.
type HappyReduction m = 
	   Int 
	-> (Token)
	-> HappyState (Token) (HappyStk HappyAbsSyn -> [(Token)] -> m HappyAbsSyn)
	-> [HappyState (Token) (HappyStk HappyAbsSyn -> [(Token)] -> m HappyAbsSyn)] 
	-> HappyStk HappyAbsSyn 
	-> [(Token)] -> m HappyAbsSyn
-}

action_0,
 action_1,
 action_2,
 action_3,
 action_4,
 action_5,
 action_6,
 action_7,
 action_8,
 action_9,
 action_10,
 action_11,
 action_12,
 action_13,
 action_14,
 action_15,
 action_16,
 action_17,
 action_18,
 action_19,
 action_20,
 action_21,
 action_22,
 action_23,
 action_24,
 action_25,
 action_26,
 action_27,
 action_28,
 action_29,
 action_30,
 action_31,
 action_32,
 action_33,
 action_34,
 action_35,
 action_36,
 action_37,
 action_38,
 action_39,
 action_40,
 action_41,
 action_42,
 action_43,
 action_44,
 action_45,
 action_46,
 action_47,
 action_48,
 action_49,
 action_50,
 action_51,
 action_52,
 action_53,
 action_54,
 action_55,
 action_56,
 action_57,
 action_58,
 action_59,
 action_60,
 action_61,
 action_62,
 action_63,
 action_64,
 action_65,
 action_66,
 action_67,
 action_68,
 action_69,
 action_70,
 action_71,
 action_72,
 action_73,
 action_74,
 action_75,
 action_76,
 action_77,
 action_78,
 action_79,
 action_80,
 action_81,
 action_82,
 action_83,
 action_84,
 action_85,
 action_86,
 action_87,
 action_88,
 action_89,
 action_90,
 action_91,
 action_92,
 action_93,
 action_94,
 action_95,
 action_96,
 action_97,
 action_98,
 action_99,
 action_100,
 action_101,
 action_102,
 action_103,
 action_104,
 action_105,
 action_106,
 action_107,
 action_108,
 action_109,
 action_110,
 action_111,
 action_112,
 action_113,
 action_114,
 action_115,
 action_116,
 action_117,
 action_118,
 action_119,
 action_120,
 action_121,
 action_122,
 action_123,
 action_124,
 action_125,
 action_126,
 action_127,
 action_128,
 action_129,
 action_130,
 action_131,
 action_132,
 action_133,
 action_134,
 action_135,
 action_136,
 action_137,
 action_138,
 action_139,
 action_140,
 action_141,
 action_142,
 action_143,
 action_144,
 action_145,
 action_146,
 action_147,
 action_148,
 action_149,
 action_150,
 action_151,
 action_152,
 action_153,
 action_154,
 action_155,
 action_156,
 action_157,
 action_158,
 action_159,
 action_160,
 action_161,
 action_162,
 action_163,
 action_164,
 action_165,
 action_166,
 action_167,
 action_168,
 action_169,
 action_170,
 action_171,
 action_172,
 action_173,
 action_174,
 action_175,
 action_176,
 action_177,
 action_178,
 action_179,
 action_180,
 action_181,
 action_182,
 action_183,
 action_184,
 action_185,
 action_186,
 action_187,
 action_188,
 action_189,
 action_190,
 action_191,
 action_192,
 action_193,
 action_194,
 action_195,
 action_196,
 action_197,
 action_198,
 action_199,
 action_200,
 action_201,
 action_202,
 action_203,
 action_204,
 action_205,
 action_206,
 action_207,
 action_208,
 action_209,
 action_210,
 action_211,
 action_212,
 action_213,
 action_214,
 action_215,
 action_216,
 action_217,
 action_218,
 action_219,
 action_220,
 action_221,
 action_222,
 action_223,
 action_224,
 action_225,
 action_226,
 action_227,
 action_228,
 action_229,
 action_230,
 action_231,
 action_232,
 action_233,
 action_234,
 action_235,
 action_236,
 action_237,
 action_238,
 action_239,
 action_240,
 action_241,
 action_242,
 action_243,
 action_244,
 action_245,
 action_246,
 action_247,
 action_248,
 action_249,
 action_250,
 action_251,
 action_252,
 action_253,
 action_254,
 action_255,
 action_256,
 action_257,
 action_258,
 action_259,
 action_260,
 action_261,
 action_262,
 action_263,
 action_264,
 action_265,
 action_266,
 action_267,
 action_268,
 action_269,
 action_270,
 action_271,
 action_272,
 action_273,
 action_274,
 action_275,
 action_276,
 action_277,
 action_278,
 action_279,
 action_280,
 action_281,
 action_282,
 action_283,
 action_284,
 action_285,
 action_286,
 action_287,
 action_288,
 action_289,
 action_290,
 action_291,
 action_292,
 action_293,
 action_294,
 action_295,
 action_296,
 action_297,
 action_298,
 action_299,
 action_300,
 action_301,
 action_302,
 action_303,
 action_304,
 action_305,
 action_306,
 action_307,
 action_308,
 action_309,
 action_310,
 action_311,
 action_312,
 action_313,
 action_314,
 action_315,
 action_316,
 action_317,
 action_318,
 action_319,
 action_320,
 action_321,
 action_322,
 action_323,
 action_324,
 action_325,
 action_326,
 action_327,
 action_328,
 action_329,
 action_330,
 action_331,
 action_332,
 action_333,
 action_334,
 action_335,
 action_336,
 action_337,
 action_338,
 action_339,
 action_340,
 action_341,
 action_342,
 action_343,
 action_344,
 action_345,
 action_346,
 action_347,
 action_348,
 action_349,
 action_350,
 action_351,
 action_352,
 action_353,
 action_354,
 action_355,
 action_356,
 action_357,
 action_358,
 action_359,
 action_360,
 action_361,
 action_362,
 action_363,
 action_364,
 action_365,
 action_366,
 action_367,
 action_368,
 action_369,
 action_370,
 action_371,
 action_372,
 action_373,
 action_374,
 action_375,
 action_376,
 action_377,
 action_378,
 action_379,
 action_380,
 action_381,
 action_382,
 action_383,
 action_384,
 action_385,
 action_386,
 action_387,
 action_388,
 action_389,
 action_390,
 action_391,
 action_392,
 action_393,
 action_394,
 action_395,
 action_396,
 action_397,
 action_398,
 action_399,
 action_400,
 action_401,
 action_402 :: () => Int -> ({-HappyReduction (HappyIdentity) = -}
	   Int 
	-> (Token)
	-> HappyState (Token) (HappyStk HappyAbsSyn -> [(Token)] -> (HappyIdentity) HappyAbsSyn)
	-> [HappyState (Token) (HappyStk HappyAbsSyn -> [(Token)] -> (HappyIdentity) HappyAbsSyn)] 
	-> HappyStk HappyAbsSyn 
	-> [(Token)] -> (HappyIdentity) HappyAbsSyn)

happyReduce_1,
 happyReduce_2,
 happyReduce_3,
 happyReduce_4,
 happyReduce_5,
 happyReduce_6,
 happyReduce_7,
 happyReduce_8,
 happyReduce_9,
 happyReduce_10,
 happyReduce_11,
 happyReduce_12,
 happyReduce_13,
 happyReduce_14,
 happyReduce_15,
 happyReduce_16,
 happyReduce_17,
 happyReduce_18,
 happyReduce_19,
 happyReduce_20,
 happyReduce_21,
 happyReduce_22,
 happyReduce_23,
 happyReduce_24,
 happyReduce_25,
 happyReduce_26,
 happyReduce_27,
 happyReduce_28,
 happyReduce_29,
 happyReduce_30,
 happyReduce_31,
 happyReduce_32,
 happyReduce_33,
 happyReduce_34,
 happyReduce_35,
 happyReduce_36,
 happyReduce_37,
 happyReduce_38,
 happyReduce_39,
 happyReduce_40,
 happyReduce_41,
 happyReduce_42,
 happyReduce_43,
 happyReduce_44,
 happyReduce_45,
 happyReduce_46,
 happyReduce_47,
 happyReduce_48,
 happyReduce_49,
 happyReduce_50,
 happyReduce_51,
 happyReduce_52,
 happyReduce_53,
 happyReduce_54,
 happyReduce_55,
 happyReduce_56,
 happyReduce_57,
 happyReduce_58,
 happyReduce_59,
 happyReduce_60,
 happyReduce_61,
 happyReduce_62,
 happyReduce_63,
 happyReduce_64,
 happyReduce_65,
 happyReduce_66,
 happyReduce_67,
 happyReduce_68,
 happyReduce_69,
 happyReduce_70,
 happyReduce_71,
 happyReduce_72,
 happyReduce_73,
 happyReduce_74,
 happyReduce_75,
 happyReduce_76,
 happyReduce_77,
 happyReduce_78,
 happyReduce_79,
 happyReduce_80,
 happyReduce_81,
 happyReduce_82,
 happyReduce_83,
 happyReduce_84,
 happyReduce_85,
 happyReduce_86,
 happyReduce_87,
 happyReduce_88,
 happyReduce_89,
 happyReduce_90,
 happyReduce_91,
 happyReduce_92,
 happyReduce_93,
 happyReduce_94,
 happyReduce_95,
 happyReduce_96,
 happyReduce_97,
 happyReduce_98,
 happyReduce_99,
 happyReduce_100,
 happyReduce_101,
 happyReduce_102,
 happyReduce_103,
 happyReduce_104,
 happyReduce_105,
 happyReduce_106,
 happyReduce_107,
 happyReduce_108,
 happyReduce_109,
 happyReduce_110,
 happyReduce_111,
 happyReduce_112,
 happyReduce_113,
 happyReduce_114,
 happyReduce_115,
 happyReduce_116,
 happyReduce_117,
 happyReduce_118,
 happyReduce_119,
 happyReduce_120,
 happyReduce_121,
 happyReduce_122,
 happyReduce_123,
 happyReduce_124,
 happyReduce_125,
 happyReduce_126,
 happyReduce_127,
 happyReduce_128,
 happyReduce_129,
 happyReduce_130,
 happyReduce_131,
 happyReduce_132,
 happyReduce_133,
 happyReduce_134,
 happyReduce_135,
 happyReduce_136,
 happyReduce_137,
 happyReduce_138,
 happyReduce_139,
 happyReduce_140,
 happyReduce_141,
 happyReduce_142,
 happyReduce_143,
 happyReduce_144,
 happyReduce_145,
 happyReduce_146,
 happyReduce_147,
 happyReduce_148,
 happyReduce_149,
 happyReduce_150,
 happyReduce_151,
 happyReduce_152,
 happyReduce_153,
 happyReduce_154,
 happyReduce_155,
 happyReduce_156,
 happyReduce_157 :: () => ({-HappyReduction (HappyIdentity) = -}
	   Int 
	-> (Token)
	-> HappyState (Token) (HappyStk HappyAbsSyn -> [(Token)] -> (HappyIdentity) HappyAbsSyn)
	-> [HappyState (Token) (HappyStk HappyAbsSyn -> [(Token)] -> (HappyIdentity) HappyAbsSyn)] 
	-> HappyStk HappyAbsSyn 
	-> [(Token)] -> (HappyIdentity) HappyAbsSyn)

action_0 (46) = happyShift action_4
action_0 (4) = happyGoto action_5
action_0 (5) = happyGoto action_2
action_0 (6) = happyGoto action_3
action_0 _ = happyFail

action_1 (46) = happyShift action_4
action_1 (5) = happyGoto action_2
action_1 (6) = happyGoto action_3
action_1 _ = happyFail

action_2 (46) = happyShift action_4
action_2 (114) = happyShift action_10
action_2 (6) = happyGoto action_7
action_2 (7) = happyGoto action_8
action_2 (8) = happyGoto action_9
action_2 _ = happyFail

action_3 _ = happyReduce_2

action_4 (109) = happyShift action_6
action_4 _ = happyFail

action_5 (122) = happyAccept
action_5 _ = happyFail

action_6 (62) = happyShift action_15
action_6 _ = happyFail

action_7 _ = happyReduce_3

action_8 (48) = happyShift action_14
action_8 (114) = happyShift action_10
action_8 (8) = happyGoto action_12
action_8 (9) = happyGoto action_13
action_8 _ = happyFail

action_9 _ = happyReduce_5

action_10 (97) = happyShift action_11
action_10 _ = happyFail

action_11 (49) = happyShift action_23
action_11 _ = happyFail

action_12 _ = happyReduce_6

action_13 (47) = happyShift action_21
action_13 (50) = happyShift action_22
action_13 (11) = happyGoto action_18
action_13 (12) = happyGoto action_19
action_13 (13) = happyGoto action_20
action_13 _ = happyFail

action_14 (97) = happyShift action_17
action_14 _ = happyFail

action_15 (109) = happyShift action_16
action_15 _ = happyFail

action_16 _ = happyReduce_4

action_17 (109) = happyShift action_28
action_17 _ = happyFail

action_18 (47) = happyShift action_21
action_18 (50) = happyShift action_22
action_18 (12) = happyGoto action_27
action_18 (13) = happyGoto action_20
action_18 _ = happyReduce_1

action_19 _ = happyReduce_12

action_20 _ = happyReduce_14

action_21 (113) = happyShift action_26
action_21 _ = happyFail

action_22 (109) = happyShift action_25
action_22 _ = happyFail

action_23 (93) = happyShift action_24
action_23 _ = happyFail

action_24 (111) = happyShift action_32
action_24 _ = happyFail

action_25 (93) = happyShift action_31
action_25 _ = happyFail

action_26 (97) = happyShift action_30
action_26 _ = happyFail

action_27 _ = happyReduce_13

action_28 (93) = happyShift action_29
action_28 _ = happyFail

action_29 (54) = happyShift action_52
action_29 (80) = happyShift action_53
action_29 (83) = happyShift action_54
action_29 (88) = happyShift action_55
action_29 (91) = happyShift action_56
action_29 (105) = happyShift action_57
action_29 (107) = happyShift action_58
action_29 (109) = happyShift action_59
action_29 (111) = happyShift action_60
action_29 (112) = happyShift action_61
action_29 (114) = happyShift action_62
action_29 (116) = happyShift action_63
action_29 (117) = happyShift action_64
action_29 (118) = happyShift action_65
action_29 (10) = happyGoto action_45
action_29 (32) = happyGoto action_46
action_29 (33) = happyGoto action_47
action_29 (34) = happyGoto action_48
action_29 (36) = happyGoto action_49
action_29 (40) = happyGoto action_50
action_29 (41) = happyGoto action_51
action_29 _ = happyReduce_11

action_30 (80) = happyShift action_40
action_30 (88) = happyShift action_41
action_30 (93) = happyShift action_42
action_30 (109) = happyShift action_43
action_30 (113) = happyShift action_44
action_30 (45) = happyGoto action_39
action_30 _ = happyFail

action_31 (55) = happyShift action_36
action_31 (57) = happyShift action_37
action_31 (114) = happyShift action_38
action_31 (14) = happyGoto action_34
action_31 (15) = happyGoto action_35
action_31 _ = happyReduce_19

action_32 (94) = happyShift action_33
action_32 _ = happyFail

action_33 _ = happyReduce_7

action_34 (94) = happyShift action_116
action_34 (102) = happyShift action_117
action_34 _ = happyFail

action_35 _ = happyReduce_17

action_36 (114) = happyShift action_115
action_36 _ = happyFail

action_37 (114) = happyShift action_114
action_37 _ = happyFail

action_38 (62) = happyShift action_113
action_38 _ = happyFail

action_39 (72) = happyShift action_109
action_39 (99) = happyShift action_110
action_39 (100) = happyShift action_111
action_39 (101) = happyShift action_112
action_39 _ = happyReduce_15

action_40 (95) = happyShift action_108
action_40 _ = happyFail

action_41 (109) = happyShift action_107
action_41 _ = happyFail

action_42 (80) = happyShift action_40
action_42 (88) = happyShift action_41
action_42 (93) = happyShift action_42
action_42 (94) = happyShift action_106
action_42 (109) = happyShift action_43
action_42 (113) = happyShift action_44
action_42 (45) = happyGoto action_105
action_42 _ = happyFail

action_43 (95) = happyShift action_103
action_43 (103) = happyShift action_104
action_43 _ = happyFail

action_44 _ = happyReduce_147

action_45 (94) = happyShift action_101
action_45 (102) = happyShift action_102
action_45 _ = happyFail

action_46 _ = happyReduce_9

action_47 (89) = happyShift action_93
action_47 (90) = happyShift action_94
action_47 (97) = happyShift action_95
action_47 (98) = happyShift action_96
action_47 (99) = happyShift action_97
action_47 (101) = happyShift action_98
action_47 (108) = happyShift action_99
action_47 (109) = happyShift action_100
action_47 (37) = happyGoto action_92
action_47 _ = happyReduce_79

action_48 (120) = happyShift action_90
action_48 (121) = happyShift action_91
action_48 (35) = happyGoto action_89
action_48 _ = happyReduce_83

action_49 _ = happyReduce_92

action_50 (95) = happyShift action_86
action_50 (105) = happyShift action_87
action_50 (106) = happyShift action_88
action_50 _ = happyReduce_91

action_51 (103) = happyShift action_85
action_51 _ = happyFail

action_52 (114) = happyShift action_84
action_52 _ = happyFail

action_53 (54) = happyShift action_52
action_53 (80) = happyShift action_53
action_53 (83) = happyShift action_54
action_53 (88) = happyShift action_55
action_53 (91) = happyShift action_56
action_53 (95) = happyShift action_82
action_53 (105) = happyShift action_57
action_53 (106) = happyShift action_83
action_53 (107) = happyShift action_58
action_53 (109) = happyShift action_59
action_53 (111) = happyShift action_60
action_53 (112) = happyShift action_61
action_53 (114) = happyShift action_62
action_53 (116) = happyShift action_63
action_53 (117) = happyShift action_64
action_53 (118) = happyShift action_65
action_53 (32) = happyGoto action_81
action_53 (33) = happyGoto action_47
action_53 (34) = happyGoto action_48
action_53 (36) = happyGoto action_49
action_53 (40) = happyGoto action_50
action_53 (41) = happyGoto action_51
action_53 _ = happyFail

action_54 (80) = happyShift action_40
action_54 (88) = happyShift action_77
action_54 (93) = happyShift action_78
action_54 (109) = happyShift action_79
action_54 (113) = happyShift action_44
action_54 (114) = happyShift action_80
action_54 (43) = happyGoto action_74
action_54 (44) = happyGoto action_75
action_54 (45) = happyGoto action_76
action_54 _ = happyFail

action_55 (109) = happyShift action_73
action_55 _ = happyFail

action_56 (80) = happyShift action_71
action_56 (88) = happyShift action_55
action_56 (105) = happyShift action_57
action_56 (107) = happyShift action_58
action_56 (109) = happyShift action_59
action_56 (111) = happyShift action_60
action_56 (112) = happyShift action_61
action_56 (114) = happyShift action_62
action_56 (116) = happyShift action_63
action_56 (117) = happyShift action_64
action_56 (40) = happyGoto action_72
action_56 (41) = happyGoto action_51
action_56 _ = happyFail

action_57 (80) = happyShift action_71
action_57 (88) = happyShift action_55
action_57 (105) = happyShift action_57
action_57 (107) = happyShift action_58
action_57 (109) = happyShift action_59
action_57 (111) = happyShift action_60
action_57 (112) = happyShift action_61
action_57 (114) = happyShift action_62
action_57 (116) = happyShift action_63
action_57 (117) = happyShift action_64
action_57 (40) = happyGoto action_70
action_57 (41) = happyGoto action_51
action_57 _ = happyFail

action_58 _ = happyReduce_110

action_59 (93) = happyShift action_68
action_59 (95) = happyShift action_69
action_59 (103) = happyReduce_134
action_59 _ = happyReduce_131

action_60 (93) = happyShift action_67
action_60 _ = happyReduce_118

action_61 _ = happyReduce_119

action_62 _ = happyReduce_117

action_63 _ = happyReduce_120

action_64 _ = happyReduce_121

action_65 (109) = happyShift action_66
action_65 _ = happyFail

action_66 (87) = happyShift action_162
action_66 (110) = happyShift action_163
action_66 (119) = happyShift action_164
action_66 (38) = happyGoto action_160
action_66 (39) = happyGoto action_161
action_66 _ = happyFail

action_67 (94) = happyShift action_159
action_67 _ = happyFail

action_68 (54) = happyShift action_52
action_68 (80) = happyShift action_53
action_68 (83) = happyShift action_54
action_68 (88) = happyShift action_55
action_68 (91) = happyShift action_56
action_68 (94) = happyShift action_158
action_68 (105) = happyShift action_57
action_68 (107) = happyShift action_58
action_68 (109) = happyShift action_59
action_68 (111) = happyShift action_60
action_68 (112) = happyShift action_61
action_68 (114) = happyShift action_62
action_68 (116) = happyShift action_63
action_68 (117) = happyShift action_64
action_68 (118) = happyShift action_65
action_68 (10) = happyGoto action_157
action_68 (32) = happyGoto action_46
action_68 (33) = happyGoto action_47
action_68 (34) = happyGoto action_48
action_68 (36) = happyGoto action_49
action_68 (40) = happyGoto action_50
action_68 (41) = happyGoto action_51
action_68 _ = happyReduce_11

action_69 (54) = happyShift action_52
action_69 (80) = happyShift action_53
action_69 (83) = happyShift action_54
action_69 (88) = happyShift action_55
action_69 (91) = happyShift action_56
action_69 (105) = happyShift action_57
action_69 (107) = happyShift action_58
action_69 (109) = happyShift action_59
action_69 (111) = happyShift action_60
action_69 (112) = happyShift action_61
action_69 (114) = happyShift action_62
action_69 (116) = happyShift action_63
action_69 (117) = happyShift action_64
action_69 (118) = happyShift action_65
action_69 (32) = happyGoto action_156
action_69 (33) = happyGoto action_47
action_69 (34) = happyGoto action_48
action_69 (36) = happyGoto action_49
action_69 (40) = happyGoto action_50
action_69 (41) = happyGoto action_51
action_69 _ = happyFail

action_70 (95) = happyShift action_86
action_70 (105) = happyShift action_87
action_70 (106) = happyShift action_88
action_70 _ = happyReduce_111

action_71 (95) = happyShift action_82
action_71 (106) = happyShift action_83
action_71 _ = happyFail

action_72 (92) = happyShift action_155
action_72 (95) = happyShift action_86
action_72 (105) = happyShift action_87
action_72 (106) = happyShift action_88
action_72 _ = happyFail

action_73 _ = happyReduce_127

action_74 (84) = happyShift action_154
action_74 _ = happyFail

action_75 _ = happyReduce_140

action_76 (72) = happyShift action_109
action_76 (99) = happyShift action_110
action_76 (100) = happyShift action_111
action_76 (101) = happyShift action_112
action_76 _ = happyReduce_144

action_77 (109) = happyShift action_153
action_77 _ = happyFail

action_78 (80) = happyShift action_40
action_78 (88) = happyShift action_77
action_78 (93) = happyShift action_78
action_78 (94) = happyShift action_106
action_78 (109) = happyShift action_79
action_78 (113) = happyShift action_44
action_78 (114) = happyShift action_80
action_78 (42) = happyGoto action_150
action_78 (43) = happyGoto action_151
action_78 (44) = happyGoto action_75
action_78 (45) = happyGoto action_152
action_78 _ = happyFail

action_79 (95) = happyShift action_149
action_79 (103) = happyShift action_104
action_79 _ = happyFail

action_80 (62) = happyShift action_148
action_80 _ = happyReduce_143

action_81 (81) = happyShift action_147
action_81 _ = happyFail

action_82 (54) = happyShift action_52
action_82 (80) = happyShift action_53
action_82 (83) = happyShift action_54
action_82 (88) = happyShift action_55
action_82 (91) = happyShift action_56
action_82 (105) = happyShift action_57
action_82 (107) = happyShift action_58
action_82 (109) = happyShift action_59
action_82 (111) = happyShift action_60
action_82 (112) = happyShift action_61
action_82 (114) = happyShift action_62
action_82 (116) = happyShift action_63
action_82 (117) = happyShift action_64
action_82 (118) = happyShift action_65
action_82 (32) = happyGoto action_146
action_82 (33) = happyGoto action_47
action_82 (34) = happyGoto action_48
action_82 (36) = happyGoto action_49
action_82 (40) = happyGoto action_50
action_82 (41) = happyGoto action_51
action_82 _ = happyFail

action_83 (80) = happyShift action_71
action_83 (88) = happyShift action_55
action_83 (99) = happyShift action_145
action_83 (105) = happyShift action_57
action_83 (107) = happyShift action_58
action_83 (109) = happyShift action_59
action_83 (111) = happyShift action_60
action_83 (112) = happyShift action_61
action_83 (114) = happyShift action_62
action_83 (116) = happyShift action_63
action_83 (117) = happyShift action_64
action_83 (40) = happyGoto action_144
action_83 (41) = happyGoto action_51
action_83 _ = happyFail

action_84 (85) = happyShift action_143
action_84 _ = happyFail

action_85 (103) = happyShift action_142
action_85 _ = happyFail

action_86 (54) = happyShift action_52
action_86 (80) = happyShift action_53
action_86 (83) = happyShift action_54
action_86 (88) = happyShift action_55
action_86 (91) = happyShift action_56
action_86 (105) = happyShift action_57
action_86 (107) = happyShift action_58
action_86 (109) = happyShift action_59
action_86 (111) = happyShift action_60
action_86 (112) = happyShift action_61
action_86 (114) = happyShift action_62
action_86 (116) = happyShift action_63
action_86 (117) = happyShift action_64
action_86 (118) = happyShift action_65
action_86 (32) = happyGoto action_141
action_86 (33) = happyGoto action_47
action_86 (34) = happyGoto action_48
action_86 (36) = happyGoto action_49
action_86 (40) = happyGoto action_50
action_86 (41) = happyGoto action_51
action_86 _ = happyFail

action_87 (80) = happyShift action_71
action_87 (88) = happyShift action_55
action_87 (105) = happyShift action_57
action_87 (107) = happyShift action_58
action_87 (109) = happyShift action_59
action_87 (111) = happyShift action_60
action_87 (112) = happyShift action_61
action_87 (114) = happyShift action_62
action_87 (116) = happyShift action_63
action_87 (117) = happyShift action_64
action_87 (40) = happyGoto action_140
action_87 (41) = happyGoto action_51
action_87 _ = happyFail

action_88 (80) = happyShift action_138
action_88 (88) = happyShift action_55
action_88 (99) = happyShift action_139
action_88 (105) = happyShift action_57
action_88 (107) = happyShift action_58
action_88 (109) = happyShift action_59
action_88 (111) = happyShift action_60
action_88 (112) = happyShift action_61
action_88 (114) = happyShift action_62
action_88 (116) = happyShift action_63
action_88 (117) = happyShift action_64
action_88 (40) = happyGoto action_137
action_88 (41) = happyGoto action_51
action_88 _ = happyFail

action_89 (80) = happyShift action_71
action_89 (88) = happyShift action_55
action_89 (91) = happyShift action_56
action_89 (105) = happyShift action_57
action_89 (107) = happyShift action_58
action_89 (109) = happyShift action_59
action_89 (111) = happyShift action_60
action_89 (112) = happyShift action_61
action_89 (114) = happyShift action_62
action_89 (116) = happyShift action_63
action_89 (117) = happyShift action_64
action_89 (118) = happyShift action_65
action_89 (33) = happyGoto action_135
action_89 (36) = happyGoto action_136
action_89 (40) = happyGoto action_50
action_89 (41) = happyGoto action_51
action_89 _ = happyFail

action_90 _ = happyReduce_94

action_91 _ = happyReduce_95

action_92 (80) = happyShift action_71
action_92 (88) = happyShift action_55
action_92 (91) = happyShift action_56
action_92 (105) = happyShift action_57
action_92 (107) = happyShift action_58
action_92 (109) = happyShift action_59
action_92 (111) = happyShift action_60
action_92 (112) = happyShift action_61
action_92 (114) = happyShift action_62
action_92 (116) = happyShift action_63
action_92 (117) = happyShift action_64
action_92 (118) = happyShift action_65
action_92 (33) = happyGoto action_134
action_92 (40) = happyGoto action_50
action_92 (41) = happyGoto action_51
action_92 _ = happyFail

action_93 (97) = happyShift action_133
action_93 _ = happyReduce_99

action_94 (97) = happyShift action_132
action_94 _ = happyReduce_100

action_95 _ = happyReduce_97

action_96 _ = happyReduce_98

action_97 _ = happyReduce_105

action_98 _ = happyReduce_103

action_99 _ = happyReduce_104

action_100 _ = happyReduce_106

action_101 _ = happyReduce_8

action_102 (54) = happyShift action_52
action_102 (80) = happyShift action_53
action_102 (83) = happyShift action_54
action_102 (88) = happyShift action_55
action_102 (91) = happyShift action_56
action_102 (105) = happyShift action_57
action_102 (107) = happyShift action_58
action_102 (109) = happyShift action_59
action_102 (111) = happyShift action_60
action_102 (112) = happyShift action_61
action_102 (114) = happyShift action_62
action_102 (116) = happyShift action_63
action_102 (117) = happyShift action_64
action_102 (118) = happyShift action_65
action_102 (32) = happyGoto action_131
action_102 (33) = happyGoto action_47
action_102 (34) = happyGoto action_48
action_102 (36) = happyGoto action_49
action_102 (40) = happyGoto action_50
action_102 (41) = happyGoto action_51
action_102 _ = happyFail

action_103 (80) = happyShift action_40
action_103 (88) = happyShift action_41
action_103 (93) = happyShift action_42
action_103 (109) = happyShift action_43
action_103 (113) = happyShift action_44
action_103 (45) = happyGoto action_130
action_103 _ = happyFail

action_104 (80) = happyShift action_128
action_104 (109) = happyShift action_129
action_104 _ = happyFail

action_105 (72) = happyShift action_109
action_105 (94) = happyShift action_126
action_105 (99) = happyShift action_110
action_105 (100) = happyShift action_111
action_105 (101) = happyShift action_112
action_105 (102) = happyShift action_127
action_105 _ = happyFail

action_106 _ = happyReduce_152

action_107 (95) = happyShift action_125
action_107 _ = happyFail

action_108 (80) = happyShift action_40
action_108 (88) = happyShift action_41
action_108 (93) = happyShift action_42
action_108 (109) = happyShift action_43
action_108 (113) = happyShift action_44
action_108 (45) = happyGoto action_124
action_108 _ = happyFail

action_109 (80) = happyShift action_40
action_109 (88) = happyShift action_41
action_109 (93) = happyShift action_42
action_109 (109) = happyShift action_43
action_109 (113) = happyShift action_44
action_109 (45) = happyGoto action_123
action_109 _ = happyFail

action_110 _ = happyReduce_148

action_111 _ = happyReduce_156

action_112 _ = happyReduce_157

action_113 (80) = happyShift action_40
action_113 (88) = happyShift action_41
action_113 (93) = happyShift action_42
action_113 (109) = happyShift action_43
action_113 (113) = happyShift action_44
action_113 (45) = happyGoto action_122
action_113 _ = happyFail

action_114 (62) = happyShift action_121
action_114 _ = happyFail

action_115 (62) = happyShift action_120
action_115 _ = happyFail

action_116 (97) = happyShift action_119
action_116 _ = happyFail

action_117 (55) = happyShift action_36
action_117 (57) = happyShift action_37
action_117 (114) = happyShift action_38
action_117 (15) = happyGoto action_118
action_117 _ = happyFail

action_118 _ = happyReduce_18

action_119 (51) = happyShift action_197
action_119 (58) = happyShift action_198
action_119 (66) = happyShift action_199
action_119 (68) = happyShift action_200
action_119 (70) = happyShift action_201
action_119 (71) = happyShift action_202
action_119 (77) = happyShift action_203
action_119 (80) = happyShift action_204
action_119 (83) = happyShift action_205
action_119 (91) = happyShift action_206
action_119 (109) = happyShift action_207
action_119 (16) = happyGoto action_193
action_119 (17) = happyGoto action_194
action_119 (18) = happyGoto action_195
action_119 (24) = happyGoto action_196
action_119 _ = happyFail

action_120 (80) = happyShift action_40
action_120 (88) = happyShift action_41
action_120 (93) = happyShift action_42
action_120 (109) = happyShift action_43
action_120 (113) = happyShift action_44
action_120 (45) = happyGoto action_192
action_120 _ = happyFail

action_121 (80) = happyShift action_40
action_121 (88) = happyShift action_41
action_121 (93) = happyShift action_42
action_121 (109) = happyShift action_43
action_121 (113) = happyShift action_44
action_121 (45) = happyGoto action_191
action_121 _ = happyFail

action_122 (72) = happyShift action_109
action_122 (99) = happyShift action_110
action_122 (100) = happyShift action_111
action_122 (101) = happyShift action_112
action_122 _ = happyReduce_22

action_123 (99) = happyShift action_110
action_123 (100) = happyShift action_111
action_123 (101) = happyShift action_112
action_123 _ = happyReduce_149

action_124 (72) = happyShift action_109
action_124 (96) = happyShift action_190
action_124 (99) = happyShift action_110
action_124 (100) = happyShift action_111
action_124 (101) = happyShift action_112
action_124 _ = happyFail

action_125 (80) = happyShift action_40
action_125 (88) = happyShift action_41
action_125 (93) = happyShift action_42
action_125 (109) = happyShift action_43
action_125 (113) = happyShift action_44
action_125 (45) = happyGoto action_189
action_125 _ = happyFail

action_126 _ = happyReduce_150

action_127 (80) = happyShift action_40
action_127 (88) = happyShift action_41
action_127 (93) = happyShift action_42
action_127 (109) = happyShift action_43
action_127 (113) = happyShift action_44
action_127 (45) = happyGoto action_188
action_127 _ = happyFail

action_128 _ = happyReduce_146

action_129 _ = happyReduce_145

action_130 (72) = happyShift action_109
action_130 (96) = happyShift action_187
action_130 (99) = happyShift action_110
action_130 (100) = happyShift action_111
action_130 (101) = happyShift action_112
action_130 _ = happyFail

action_131 _ = happyReduce_10

action_132 _ = happyReduce_102

action_133 _ = happyReduce_101

action_134 _ = happyReduce_96

action_135 (89) = happyShift action_93
action_135 (90) = happyShift action_94
action_135 (97) = happyShift action_95
action_135 (98) = happyShift action_96
action_135 (99) = happyShift action_97
action_135 (101) = happyShift action_98
action_135 (108) = happyShift action_99
action_135 (109) = happyShift action_100
action_135 (37) = happyGoto action_92
action_135 _ = happyFail

action_136 _ = happyReduce_93

action_137 (105) = happyShift action_87
action_137 _ = happyReduce_113

action_138 _ = happyReduce_133

action_139 _ = happyReduce_128

action_140 (95) = happyShift action_86
action_140 (105) = happyShift action_87
action_140 (106) = happyShift action_88
action_140 _ = happyReduce_112

action_141 (96) = happyShift action_186
action_141 _ = happyFail

action_142 (109) = happyShift action_185
action_142 _ = happyFail

action_143 (54) = happyShift action_52
action_143 (80) = happyShift action_53
action_143 (83) = happyShift action_54
action_143 (88) = happyShift action_55
action_143 (91) = happyShift action_56
action_143 (105) = happyShift action_57
action_143 (107) = happyShift action_58
action_143 (109) = happyShift action_59
action_143 (111) = happyShift action_60
action_143 (112) = happyShift action_61
action_143 (114) = happyShift action_62
action_143 (116) = happyShift action_63
action_143 (117) = happyShift action_64
action_143 (118) = happyShift action_65
action_143 (32) = happyGoto action_184
action_143 (33) = happyGoto action_47
action_143 (34) = happyGoto action_48
action_143 (36) = happyGoto action_49
action_143 (40) = happyGoto action_50
action_143 (41) = happyGoto action_51
action_143 _ = happyFail

action_144 (105) = happyShift action_87
action_144 _ = happyReduce_132

action_145 _ = happyReduce_129

action_146 (96) = happyShift action_183
action_146 _ = happyFail

action_147 (54) = happyShift action_52
action_147 (80) = happyShift action_53
action_147 (83) = happyShift action_54
action_147 (88) = happyShift action_55
action_147 (91) = happyShift action_56
action_147 (105) = happyShift action_57
action_147 (107) = happyShift action_58
action_147 (109) = happyShift action_59
action_147 (111) = happyShift action_60
action_147 (112) = happyShift action_61
action_147 (114) = happyShift action_62
action_147 (116) = happyShift action_63
action_147 (117) = happyShift action_64
action_147 (118) = happyShift action_65
action_147 (32) = happyGoto action_182
action_147 (33) = happyGoto action_47
action_147 (34) = happyGoto action_48
action_147 (36) = happyGoto action_49
action_147 (40) = happyGoto action_50
action_147 (41) = happyGoto action_51
action_147 _ = happyFail

action_148 (80) = happyShift action_40
action_148 (88) = happyShift action_41
action_148 (93) = happyShift action_42
action_148 (109) = happyShift action_43
action_148 (113) = happyShift action_44
action_148 (45) = happyGoto action_181
action_148 _ = happyFail

action_149 (80) = happyShift action_40
action_149 (88) = happyShift action_77
action_149 (93) = happyShift action_78
action_149 (109) = happyShift action_79
action_149 (113) = happyShift action_44
action_149 (114) = happyShift action_80
action_149 (42) = happyGoto action_179
action_149 (43) = happyGoto action_151
action_149 (44) = happyGoto action_75
action_149 (45) = happyGoto action_180
action_149 _ = happyFail

action_150 (94) = happyShift action_178
action_150 _ = happyFail

action_151 (102) = happyShift action_177
action_151 _ = happyReduce_135

action_152 (72) = happyShift action_109
action_152 (94) = happyShift action_126
action_152 (99) = happyShift action_110
action_152 (100) = happyShift action_111
action_152 (101) = happyShift action_112
action_152 (102) = happyShift action_176
action_152 _ = happyFail

action_153 (95) = happyShift action_175
action_153 _ = happyFail

action_154 (54) = happyShift action_52
action_154 (80) = happyShift action_53
action_154 (83) = happyShift action_54
action_154 (88) = happyShift action_55
action_154 (91) = happyShift action_56
action_154 (105) = happyShift action_57
action_154 (107) = happyShift action_58
action_154 (109) = happyShift action_59
action_154 (111) = happyShift action_60
action_154 (112) = happyShift action_61
action_154 (114) = happyShift action_62
action_154 (116) = happyShift action_63
action_154 (117) = happyShift action_64
action_154 (118) = happyShift action_65
action_154 (32) = happyGoto action_174
action_154 (33) = happyGoto action_47
action_154 (34) = happyGoto action_48
action_154 (36) = happyGoto action_49
action_154 (40) = happyGoto action_50
action_154 (41) = happyGoto action_51
action_154 _ = happyFail

action_155 _ = happyReduce_90

action_156 (96) = happyShift action_173
action_156 _ = happyFail

action_157 (94) = happyShift action_172
action_157 (102) = happyShift action_102
action_157 _ = happyFail

action_158 _ = happyReduce_122

action_159 _ = happyReduce_123

action_160 (87) = happyShift action_170
action_160 (110) = happyShift action_163
action_160 (119) = happyShift action_171
action_160 (39) = happyGoto action_169
action_160 _ = happyFail

action_161 _ = happyReduce_108

action_162 _ = happyReduce_88

action_163 (97) = happyShift action_168
action_163 _ = happyFail

action_164 (54) = happyShift action_52
action_164 (80) = happyShift action_53
action_164 (83) = happyShift action_54
action_164 (86) = happyShift action_167
action_164 (88) = happyShift action_55
action_164 (91) = happyShift action_56
action_164 (105) = happyShift action_57
action_164 (107) = happyShift action_58
action_164 (109) = happyShift action_59
action_164 (111) = happyShift action_60
action_164 (112) = happyShift action_61
action_164 (114) = happyShift action_62
action_164 (116) = happyShift action_63
action_164 (117) = happyShift action_64
action_164 (118) = happyShift action_65
action_164 (31) = happyGoto action_165
action_164 (32) = happyGoto action_166
action_164 (33) = happyGoto action_47
action_164 (34) = happyGoto action_48
action_164 (36) = happyGoto action_49
action_164 (40) = happyGoto action_50
action_164 (41) = happyGoto action_51
action_164 _ = happyFail

action_165 (54) = happyShift action_52
action_165 (80) = happyShift action_53
action_165 (83) = happyShift action_54
action_165 (86) = happyShift action_255
action_165 (88) = happyShift action_55
action_165 (91) = happyShift action_56
action_165 (105) = happyShift action_57
action_165 (107) = happyShift action_58
action_165 (109) = happyShift action_59
action_165 (111) = happyShift action_60
action_165 (112) = happyShift action_61
action_165 (114) = happyShift action_62
action_165 (116) = happyShift action_63
action_165 (117) = happyShift action_64
action_165 (118) = happyShift action_65
action_165 (32) = happyGoto action_254
action_165 (33) = happyGoto action_47
action_165 (34) = happyGoto action_48
action_165 (36) = happyGoto action_49
action_165 (40) = happyGoto action_50
action_165 (41) = happyGoto action_51
action_165 _ = happyFail

action_166 _ = happyReduce_77

action_167 (109) = happyShift action_253
action_167 _ = happyFail

action_168 (54) = happyShift action_52
action_168 (80) = happyShift action_53
action_168 (83) = happyShift action_54
action_168 (88) = happyShift action_55
action_168 (91) = happyShift action_56
action_168 (105) = happyShift action_57
action_168 (107) = happyShift action_58
action_168 (109) = happyShift action_59
action_168 (111) = happyShift action_60
action_168 (112) = happyShift action_61
action_168 (114) = happyShift action_62
action_168 (116) = happyShift action_63
action_168 (117) = happyShift action_64
action_168 (118) = happyShift action_65
action_168 (32) = happyGoto action_252
action_168 (33) = happyGoto action_47
action_168 (34) = happyGoto action_48
action_168 (36) = happyGoto action_49
action_168 (40) = happyGoto action_50
action_168 (41) = happyGoto action_51
action_168 _ = happyFail

action_169 _ = happyReduce_107

action_170 _ = happyReduce_89

action_171 (54) = happyShift action_52
action_171 (80) = happyShift action_53
action_171 (83) = happyShift action_54
action_171 (86) = happyShift action_251
action_171 (88) = happyShift action_55
action_171 (91) = happyShift action_56
action_171 (105) = happyShift action_57
action_171 (107) = happyShift action_58
action_171 (109) = happyShift action_59
action_171 (111) = happyShift action_60
action_171 (112) = happyShift action_61
action_171 (114) = happyShift action_62
action_171 (116) = happyShift action_63
action_171 (117) = happyShift action_64
action_171 (118) = happyShift action_65
action_171 (31) = happyGoto action_250
action_171 (32) = happyGoto action_166
action_171 (33) = happyGoto action_47
action_171 (34) = happyGoto action_48
action_171 (36) = happyGoto action_49
action_171 (40) = happyGoto action_50
action_171 (41) = happyGoto action_51
action_171 _ = happyFail

action_172 _ = happyReduce_130

action_173 _ = happyReduce_114

action_174 (85) = happyShift action_249
action_174 _ = happyFail

action_175 (80) = happyShift action_40
action_175 (88) = happyShift action_41
action_175 (93) = happyShift action_42
action_175 (109) = happyShift action_43
action_175 (113) = happyShift action_44
action_175 (114) = happyShift action_80
action_175 (44) = happyGoto action_247
action_175 (45) = happyGoto action_248
action_175 _ = happyFail

action_176 (80) = happyShift action_40
action_176 (88) = happyShift action_77
action_176 (93) = happyShift action_78
action_176 (109) = happyShift action_79
action_176 (113) = happyShift action_44
action_176 (114) = happyShift action_80
action_176 (42) = happyGoto action_245
action_176 (43) = happyGoto action_151
action_176 (44) = happyGoto action_75
action_176 (45) = happyGoto action_246
action_176 _ = happyFail

action_177 (80) = happyShift action_40
action_177 (88) = happyShift action_77
action_177 (93) = happyShift action_78
action_177 (109) = happyShift action_79
action_177 (113) = happyShift action_44
action_177 (114) = happyShift action_80
action_177 (42) = happyGoto action_243
action_177 (43) = happyGoto action_151
action_177 (44) = happyGoto action_75
action_177 (45) = happyGoto action_244
action_177 _ = happyFail

action_178 _ = happyReduce_141

action_179 (96) = happyShift action_242
action_179 _ = happyFail

action_180 (72) = happyShift action_109
action_180 (96) = happyShift action_187
action_180 (99) = happyShift action_110
action_180 (100) = happyShift action_111
action_180 (101) = happyShift action_112
action_180 (102) = happyShift action_241
action_180 _ = happyFail

action_181 (72) = happyShift action_109
action_181 (99) = happyShift action_110
action_181 (100) = happyShift action_111
action_181 (101) = happyShift action_112
action_181 _ = happyReduce_142

action_182 (82) = happyShift action_240
action_182 _ = happyFail

action_183 _ = happyReduce_115

action_184 (115) = happyShift action_239
action_184 _ = happyFail

action_185 (93) = happyShift action_238
action_185 _ = happyReduce_126

action_186 _ = happyReduce_116

action_187 _ = happyReduce_153

action_188 (72) = happyShift action_109
action_188 (94) = happyShift action_237
action_188 (99) = happyShift action_110
action_188 (100) = happyShift action_111
action_188 (101) = happyShift action_112
action_188 _ = happyFail

action_189 (72) = happyShift action_109
action_189 (96) = happyShift action_236
action_189 (99) = happyShift action_110
action_189 (100) = happyShift action_111
action_189 (101) = happyShift action_112
action_189 _ = happyFail

action_190 _ = happyReduce_154

action_191 (72) = happyShift action_109
action_191 (99) = happyShift action_110
action_191 (100) = happyShift action_111
action_191 (101) = happyShift action_112
action_191 _ = happyReduce_20

action_192 (72) = happyShift action_109
action_192 (99) = happyShift action_110
action_192 (100) = happyShift action_111
action_192 (101) = happyShift action_112
action_192 _ = happyReduce_21

action_193 (104) = happyShift action_235
action_193 _ = happyReduce_26

action_194 _ = happyReduce_16

action_195 _ = happyReduce_23

action_196 (79) = happyShift action_234
action_196 (21) = happyGoto action_232
action_196 (22) = happyGoto action_233
action_196 _ = happyReduce_37

action_197 (80) = happyShift action_219
action_197 (88) = happyShift action_221
action_197 (93) = happyShift action_78
action_197 (105) = happyShift action_57
action_197 (107) = happyShift action_58
action_197 (109) = happyShift action_222
action_197 (111) = happyShift action_60
action_197 (112) = happyShift action_61
action_197 (113) = happyShift action_44
action_197 (114) = happyShift action_223
action_197 (116) = happyShift action_63
action_197 (117) = happyShift action_64
action_197 (25) = happyGoto action_230
action_197 (40) = happyGoto action_231
action_197 (41) = happyGoto action_51
action_197 (43) = happyGoto action_218
action_197 (44) = happyGoto action_75
action_197 (45) = happyGoto action_76
action_197 _ = happyFail

action_198 (59) = happyShift action_227
action_198 (60) = happyShift action_228
action_198 (62) = happyShift action_229
action_198 _ = happyFail

action_199 (67) = happyShift action_226
action_199 (80) = happyShift action_219
action_199 (88) = happyShift action_221
action_199 (93) = happyShift action_78
action_199 (105) = happyShift action_57
action_199 (107) = happyShift action_58
action_199 (109) = happyShift action_222
action_199 (111) = happyShift action_60
action_199 (112) = happyShift action_61
action_199 (113) = happyShift action_44
action_199 (114) = happyShift action_223
action_199 (116) = happyShift action_63
action_199 (117) = happyShift action_64
action_199 (25) = happyGoto action_224
action_199 (40) = happyGoto action_225
action_199 (41) = happyGoto action_51
action_199 (43) = happyGoto action_218
action_199 (44) = happyGoto action_75
action_199 (45) = happyGoto action_76
action_199 _ = happyFail

action_200 (80) = happyShift action_219
action_200 (85) = happyShift action_220
action_200 (88) = happyShift action_221
action_200 (93) = happyShift action_78
action_200 (105) = happyShift action_57
action_200 (107) = happyShift action_58
action_200 (109) = happyShift action_222
action_200 (111) = happyShift action_60
action_200 (112) = happyShift action_61
action_200 (113) = happyShift action_44
action_200 (114) = happyShift action_223
action_200 (116) = happyShift action_63
action_200 (117) = happyShift action_64
action_200 (25) = happyGoto action_216
action_200 (40) = happyGoto action_217
action_200 (41) = happyGoto action_51
action_200 (43) = happyGoto action_218
action_200 (44) = happyGoto action_75
action_200 (45) = happyGoto action_76
action_200 _ = happyFail

action_201 (61) = happyShift action_215
action_201 _ = happyFail

action_202 (80) = happyShift action_71
action_202 (88) = happyShift action_55
action_202 (105) = happyShift action_57
action_202 (107) = happyShift action_58
action_202 (109) = happyShift action_59
action_202 (111) = happyShift action_60
action_202 (112) = happyShift action_61
action_202 (114) = happyShift action_62
action_202 (116) = happyShift action_63
action_202 (117) = happyShift action_64
action_202 (40) = happyGoto action_214
action_202 (41) = happyGoto action_51
action_202 _ = happyFail

action_203 (54) = happyShift action_52
action_203 (80) = happyShift action_53
action_203 (83) = happyShift action_54
action_203 (88) = happyShift action_55
action_203 (91) = happyShift action_56
action_203 (105) = happyShift action_57
action_203 (107) = happyShift action_58
action_203 (109) = happyShift action_59
action_203 (111) = happyShift action_60
action_203 (112) = happyShift action_61
action_203 (114) = happyShift action_62
action_203 (116) = happyShift action_63
action_203 (117) = happyShift action_64
action_203 (118) = happyShift action_65
action_203 (32) = happyGoto action_213
action_203 (33) = happyGoto action_47
action_203 (34) = happyGoto action_48
action_203 (36) = happyGoto action_49
action_203 (40) = happyGoto action_50
action_203 (41) = happyGoto action_51
action_203 _ = happyFail

action_204 (54) = happyShift action_52
action_204 (80) = happyShift action_53
action_204 (83) = happyShift action_54
action_204 (88) = happyShift action_55
action_204 (91) = happyShift action_56
action_204 (105) = happyShift action_57
action_204 (107) = happyShift action_58
action_204 (109) = happyShift action_59
action_204 (111) = happyShift action_60
action_204 (112) = happyShift action_61
action_204 (114) = happyShift action_62
action_204 (116) = happyShift action_63
action_204 (117) = happyShift action_64
action_204 (118) = happyShift action_65
action_204 (23) = happyGoto action_211
action_204 (32) = happyGoto action_212
action_204 (33) = happyGoto action_47
action_204 (34) = happyGoto action_48
action_204 (36) = happyGoto action_49
action_204 (40) = happyGoto action_50
action_204 (41) = happyGoto action_51
action_204 _ = happyFail

action_205 (80) = happyShift action_40
action_205 (88) = happyShift action_77
action_205 (93) = happyShift action_78
action_205 (109) = happyShift action_79
action_205 (113) = happyShift action_44
action_205 (114) = happyShift action_80
action_205 (43) = happyGoto action_210
action_205 (44) = happyGoto action_75
action_205 (45) = happyGoto action_76
action_205 _ = happyFail

action_206 (51) = happyShift action_197
action_206 (58) = happyShift action_198
action_206 (66) = happyShift action_199
action_206 (68) = happyShift action_200
action_206 (70) = happyShift action_201
action_206 (71) = happyShift action_202
action_206 (77) = happyShift action_203
action_206 (80) = happyShift action_204
action_206 (83) = happyShift action_205
action_206 (109) = happyShift action_207
action_206 (16) = happyGoto action_209
action_206 (18) = happyGoto action_195
action_206 (24) = happyGoto action_196
action_206 _ = happyFail

action_207 (93) = happyShift action_208
action_207 _ = happyFail

action_208 (54) = happyShift action_52
action_208 (80) = happyShift action_53
action_208 (83) = happyShift action_54
action_208 (88) = happyShift action_55
action_208 (91) = happyShift action_56
action_208 (105) = happyShift action_57
action_208 (107) = happyShift action_58
action_208 (109) = happyShift action_59
action_208 (111) = happyShift action_60
action_208 (112) = happyShift action_61
action_208 (114) = happyShift action_62
action_208 (116) = happyShift action_63
action_208 (117) = happyShift action_64
action_208 (118) = happyShift action_65
action_208 (10) = happyGoto action_294
action_208 (32) = happyGoto action_46
action_208 (33) = happyGoto action_47
action_208 (34) = happyGoto action_48
action_208 (36) = happyGoto action_49
action_208 (40) = happyGoto action_50
action_208 (41) = happyGoto action_51
action_208 _ = happyReduce_11

action_209 (92) = happyShift action_293
action_209 (104) = happyShift action_235
action_209 _ = happyFail

action_210 (84) = happyShift action_292
action_210 _ = happyFail

action_211 (81) = happyShift action_291
action_211 _ = happyFail

action_212 _ = happyReduce_40

action_213 (78) = happyShift action_290
action_213 _ = happyFail

action_214 (95) = happyShift action_86
action_214 (105) = happyShift action_87
action_214 (106) = happyShift action_88
action_214 _ = happyReduce_61

action_215 (54) = happyShift action_52
action_215 (80) = happyShift action_53
action_215 (83) = happyShift action_54
action_215 (88) = happyShift action_55
action_215 (91) = happyShift action_56
action_215 (105) = happyShift action_57
action_215 (107) = happyShift action_58
action_215 (109) = happyShift action_59
action_215 (111) = happyShift action_60
action_215 (112) = happyShift action_61
action_215 (114) = happyShift action_62
action_215 (116) = happyShift action_63
action_215 (117) = happyShift action_64
action_215 (118) = happyShift action_65
action_215 (32) = happyGoto action_289
action_215 (33) = happyGoto action_47
action_215 (34) = happyGoto action_48
action_215 (36) = happyGoto action_49
action_215 (40) = happyGoto action_50
action_215 (41) = happyGoto action_51
action_215 _ = happyFail

action_216 (80) = happyShift action_71
action_216 (88) = happyShift action_55
action_216 (105) = happyShift action_57
action_216 (107) = happyShift action_58
action_216 (109) = happyShift action_59
action_216 (111) = happyShift action_60
action_216 (112) = happyShift action_61
action_216 (114) = happyShift action_62
action_216 (116) = happyShift action_63
action_216 (117) = happyShift action_64
action_216 (40) = happyGoto action_288
action_216 (41) = happyGoto action_51
action_216 _ = happyFail

action_217 (69) = happyShift action_287
action_217 (95) = happyShift action_86
action_217 (105) = happyShift action_87
action_217 (106) = happyShift action_88
action_217 _ = happyFail

action_218 (85) = happyShift action_286
action_218 _ = happyFail

action_219 (95) = happyShift action_285
action_219 (106) = happyShift action_83
action_219 _ = happyFail

action_220 (80) = happyShift action_219
action_220 (88) = happyShift action_221
action_220 (93) = happyShift action_78
action_220 (105) = happyShift action_57
action_220 (107) = happyShift action_58
action_220 (109) = happyShift action_222
action_220 (111) = happyShift action_60
action_220 (112) = happyShift action_61
action_220 (113) = happyShift action_44
action_220 (114) = happyShift action_223
action_220 (116) = happyShift action_63
action_220 (117) = happyShift action_64
action_220 (25) = happyGoto action_283
action_220 (40) = happyGoto action_284
action_220 (41) = happyGoto action_51
action_220 (43) = happyGoto action_218
action_220 (44) = happyGoto action_75
action_220 (45) = happyGoto action_76
action_220 _ = happyFail

action_221 (109) = happyShift action_282
action_221 _ = happyFail

action_222 (93) = happyShift action_68
action_222 (95) = happyShift action_281
action_222 (103) = happyShift action_104
action_222 _ = happyReduce_131

action_223 (62) = happyShift action_148
action_223 (85) = happyReduce_143
action_223 (96) = happyReduce_143
action_223 (102) = happyReduce_143
action_223 _ = happyReduce_117

action_224 (80) = happyShift action_71
action_224 (88) = happyShift action_55
action_224 (105) = happyShift action_57
action_224 (107) = happyShift action_58
action_224 (109) = happyShift action_59
action_224 (111) = happyShift action_60
action_224 (112) = happyShift action_61
action_224 (114) = happyShift action_62
action_224 (116) = happyShift action_63
action_224 (117) = happyShift action_64
action_224 (40) = happyGoto action_280
action_224 (41) = happyGoto action_51
action_224 _ = happyFail

action_225 (95) = happyShift action_86
action_225 (105) = happyShift action_87
action_225 (106) = happyShift action_88
action_225 _ = happyReduce_50

action_226 (80) = happyShift action_219
action_226 (88) = happyShift action_221
action_226 (93) = happyShift action_78
action_226 (105) = happyShift action_57
action_226 (107) = happyShift action_58
action_226 (109) = happyShift action_222
action_226 (111) = happyShift action_60
action_226 (112) = happyShift action_61
action_226 (113) = happyShift action_44
action_226 (114) = happyShift action_223
action_226 (116) = happyShift action_63
action_226 (117) = happyShift action_64
action_226 (25) = happyGoto action_278
action_226 (40) = happyGoto action_279
action_226 (41) = happyGoto action_51
action_226 (43) = happyGoto action_218
action_226 (44) = happyGoto action_75
action_226 (45) = happyGoto action_76
action_226 _ = happyFail

action_227 (80) = happyShift action_219
action_227 (88) = happyShift action_221
action_227 (93) = happyShift action_78
action_227 (105) = happyShift action_57
action_227 (107) = happyShift action_58
action_227 (109) = happyShift action_222
action_227 (111) = happyShift action_60
action_227 (112) = happyShift action_61
action_227 (113) = happyShift action_44
action_227 (114) = happyShift action_223
action_227 (116) = happyShift action_63
action_227 (117) = happyShift action_64
action_227 (25) = happyGoto action_276
action_227 (40) = happyGoto action_277
action_227 (41) = happyGoto action_51
action_227 (43) = happyGoto action_218
action_227 (44) = happyGoto action_75
action_227 (45) = happyGoto action_76
action_227 _ = happyFail

action_228 (80) = happyShift action_219
action_228 (88) = happyShift action_221
action_228 (93) = happyShift action_78
action_228 (105) = happyShift action_57
action_228 (107) = happyShift action_58
action_228 (109) = happyShift action_222
action_228 (111) = happyShift action_60
action_228 (112) = happyShift action_61
action_228 (113) = happyShift action_44
action_228 (114) = happyShift action_223
action_228 (116) = happyShift action_63
action_228 (117) = happyShift action_64
action_228 (25) = happyGoto action_274
action_228 (40) = happyGoto action_275
action_228 (41) = happyGoto action_51
action_228 (43) = happyGoto action_218
action_228 (44) = happyGoto action_75
action_228 (45) = happyGoto action_76
action_228 _ = happyFail

action_229 (63) = happyShift action_272
action_229 (64) = happyShift action_273
action_229 _ = happyFail

action_230 (80) = happyShift action_71
action_230 (88) = happyShift action_55
action_230 (105) = happyShift action_57
action_230 (107) = happyShift action_58
action_230 (109) = happyShift action_59
action_230 (111) = happyShift action_60
action_230 (112) = happyShift action_61
action_230 (114) = happyShift action_62
action_230 (116) = happyShift action_63
action_230 (117) = happyShift action_64
action_230 (40) = happyGoto action_271
action_230 (41) = happyGoto action_51
action_230 _ = happyFail

action_231 (52) = happyShift action_270
action_231 (95) = happyShift action_86
action_231 (105) = happyShift action_87
action_231 (106) = happyShift action_88
action_231 _ = happyFail

action_232 (79) = happyShift action_234
action_232 (22) = happyGoto action_269
action_232 _ = happyReduce_27

action_233 _ = happyReduce_35

action_234 (54) = happyShift action_52
action_234 (80) = happyShift action_53
action_234 (83) = happyShift action_54
action_234 (88) = happyShift action_55
action_234 (91) = happyShift action_56
action_234 (105) = happyShift action_57
action_234 (107) = happyShift action_58
action_234 (109) = happyShift action_59
action_234 (111) = happyShift action_60
action_234 (112) = happyShift action_61
action_234 (114) = happyShift action_268
action_234 (116) = happyShift action_63
action_234 (117) = happyShift action_64
action_234 (118) = happyShift action_65
action_234 (23) = happyGoto action_267
action_234 (32) = happyGoto action_212
action_234 (33) = happyGoto action_47
action_234 (34) = happyGoto action_48
action_234 (36) = happyGoto action_49
action_234 (40) = happyGoto action_50
action_234 (41) = happyGoto action_51
action_234 _ = happyFail

action_235 (51) = happyShift action_197
action_235 (58) = happyShift action_198
action_235 (66) = happyShift action_199
action_235 (68) = happyShift action_200
action_235 (70) = happyShift action_201
action_235 (71) = happyShift action_202
action_235 (77) = happyShift action_203
action_235 (80) = happyShift action_204
action_235 (83) = happyShift action_205
action_235 (109) = happyShift action_207
action_235 (18) = happyGoto action_266
action_235 (24) = happyGoto action_196
action_235 _ = happyFail

action_236 _ = happyReduce_155

action_237 _ = happyReduce_151

action_238 (94) = happyShift action_264
action_238 (111) = happyShift action_265
action_238 _ = happyFail

action_239 (54) = happyShift action_52
action_239 (80) = happyShift action_53
action_239 (83) = happyShift action_54
action_239 (88) = happyShift action_55
action_239 (91) = happyShift action_56
action_239 (105) = happyShift action_57
action_239 (107) = happyShift action_58
action_239 (109) = happyShift action_59
action_239 (111) = happyShift action_60
action_239 (112) = happyShift action_61
action_239 (114) = happyShift action_62
action_239 (116) = happyShift action_63
action_239 (117) = happyShift action_64
action_239 (118) = happyShift action_65
action_239 (32) = happyGoto action_263
action_239 (33) = happyGoto action_47
action_239 (34) = happyGoto action_48
action_239 (36) = happyGoto action_49
action_239 (40) = happyGoto action_50
action_239 (41) = happyGoto action_51
action_239 _ = happyFail

action_240 (54) = happyShift action_52
action_240 (80) = happyShift action_53
action_240 (83) = happyShift action_54
action_240 (88) = happyShift action_55
action_240 (91) = happyShift action_56
action_240 (105) = happyShift action_57
action_240 (107) = happyShift action_58
action_240 (109) = happyShift action_59
action_240 (111) = happyShift action_60
action_240 (112) = happyShift action_61
action_240 (114) = happyShift action_62
action_240 (116) = happyShift action_63
action_240 (117) = happyShift action_64
action_240 (118) = happyShift action_65
action_240 (32) = happyGoto action_262
action_240 (33) = happyGoto action_47
action_240 (34) = happyGoto action_48
action_240 (36) = happyGoto action_49
action_240 (40) = happyGoto action_50
action_240 (41) = happyGoto action_51
action_240 _ = happyFail

action_241 (80) = happyShift action_40
action_241 (88) = happyShift action_77
action_241 (93) = happyShift action_78
action_241 (109) = happyShift action_79
action_241 (113) = happyShift action_44
action_241 (114) = happyShift action_80
action_241 (42) = happyGoto action_245
action_241 (43) = happyGoto action_151
action_241 (44) = happyGoto action_75
action_241 (45) = happyGoto action_244
action_241 _ = happyFail

action_242 _ = happyReduce_138

action_243 _ = happyReduce_136

action_244 (72) = happyShift action_109
action_244 (99) = happyShift action_110
action_244 (100) = happyShift action_111
action_244 (101) = happyShift action_112
action_244 (102) = happyShift action_241
action_244 _ = happyReduce_144

action_245 _ = happyReduce_137

action_246 (72) = happyShift action_109
action_246 (94) = happyShift action_237
action_246 (99) = happyShift action_110
action_246 (100) = happyShift action_111
action_246 (101) = happyShift action_112
action_246 (102) = happyShift action_241
action_246 _ = happyFail

action_247 (96) = happyShift action_261
action_247 _ = happyFail

action_248 (72) = happyShift action_109
action_248 (96) = happyShift action_236
action_248 (99) = happyShift action_110
action_248 (100) = happyShift action_111
action_248 (101) = happyShift action_112
action_248 _ = happyFail

action_249 (54) = happyShift action_52
action_249 (80) = happyShift action_53
action_249 (83) = happyShift action_54
action_249 (88) = happyShift action_55
action_249 (91) = happyShift action_56
action_249 (105) = happyShift action_57
action_249 (107) = happyShift action_58
action_249 (109) = happyShift action_59
action_249 (111) = happyShift action_60
action_249 (112) = happyShift action_61
action_249 (114) = happyShift action_62
action_249 (116) = happyShift action_63
action_249 (117) = happyShift action_64
action_249 (118) = happyShift action_65
action_249 (32) = happyGoto action_260
action_249 (33) = happyGoto action_47
action_249 (34) = happyGoto action_48
action_249 (36) = happyGoto action_49
action_249 (40) = happyGoto action_50
action_249 (41) = happyGoto action_51
action_249 _ = happyFail

action_250 (54) = happyShift action_52
action_250 (80) = happyShift action_53
action_250 (83) = happyShift action_54
action_250 (86) = happyShift action_259
action_250 (88) = happyShift action_55
action_250 (91) = happyShift action_56
action_250 (105) = happyShift action_57
action_250 (107) = happyShift action_58
action_250 (109) = happyShift action_59
action_250 (111) = happyShift action_60
action_250 (112) = happyShift action_61
action_250 (114) = happyShift action_62
action_250 (116) = happyShift action_63
action_250 (117) = happyShift action_64
action_250 (118) = happyShift action_65
action_250 (32) = happyGoto action_254
action_250 (33) = happyGoto action_47
action_250 (34) = happyGoto action_48
action_250 (36) = happyGoto action_49
action_250 (40) = happyGoto action_50
action_250 (41) = happyGoto action_51
action_250 _ = happyFail

action_251 (109) = happyShift action_258
action_251 _ = happyFail

action_252 _ = happyReduce_109

action_253 (119) = happyShift action_257
action_253 _ = happyFail

action_254 _ = happyReduce_78

action_255 (109) = happyShift action_256
action_255 _ = happyFail

action_256 (119) = happyShift action_326
action_256 _ = happyFail

action_257 _ = happyReduce_87

action_258 (119) = happyShift action_325
action_258 _ = happyFail

action_259 (109) = happyShift action_324
action_259 _ = happyFail

action_260 _ = happyReduce_80

action_261 _ = happyReduce_139

action_262 _ = happyReduce_81

action_263 _ = happyReduce_82

action_264 _ = happyReduce_124

action_265 (94) = happyShift action_323
action_265 _ = happyFail

action_266 _ = happyReduce_24

action_267 _ = happyReduce_38

action_268 (84) = happyShift action_322
action_268 _ = happyReduce_117

action_269 _ = happyReduce_36

action_270 (51) = happyShift action_197
action_270 (58) = happyShift action_198
action_270 (66) = happyShift action_199
action_270 (68) = happyShift action_200
action_270 (70) = happyShift action_201
action_270 (71) = happyShift action_202
action_270 (73) = happyShift action_318
action_270 (74) = happyShift action_319
action_270 (75) = happyShift action_320
action_270 (77) = happyShift action_203
action_270 (80) = happyShift action_204
action_270 (83) = happyShift action_205
action_270 (91) = happyShift action_321
action_270 (109) = happyShift action_207
action_270 (16) = happyGoto action_314
action_270 (18) = happyGoto action_195
action_270 (24) = happyGoto action_196
action_270 (27) = happyGoto action_315
action_270 (28) = happyGoto action_316
action_270 (29) = happyGoto action_317
action_270 _ = happyFail

action_271 (52) = happyShift action_313
action_271 (95) = happyShift action_86
action_271 (105) = happyShift action_87
action_271 (106) = happyShift action_88
action_271 _ = happyFail

action_272 (65) = happyShift action_312
action_272 _ = happyFail

action_273 (65) = happyShift action_311
action_273 _ = happyFail

action_274 (80) = happyShift action_71
action_274 (88) = happyShift action_55
action_274 (105) = happyShift action_57
action_274 (107) = happyShift action_58
action_274 (109) = happyShift action_59
action_274 (111) = happyShift action_60
action_274 (112) = happyShift action_61
action_274 (114) = happyShift action_62
action_274 (116) = happyShift action_63
action_274 (117) = happyShift action_64
action_274 (40) = happyGoto action_310
action_274 (41) = happyGoto action_51
action_274 _ = happyFail

action_275 (61) = happyShift action_309
action_275 (95) = happyShift action_86
action_275 (105) = happyShift action_87
action_275 (106) = happyShift action_88
action_275 _ = happyFail

action_276 (80) = happyShift action_71
action_276 (88) = happyShift action_55
action_276 (105) = happyShift action_57
action_276 (107) = happyShift action_58
action_276 (109) = happyShift action_59
action_276 (111) = happyShift action_60
action_276 (112) = happyShift action_61
action_276 (114) = happyShift action_62
action_276 (116) = happyShift action_63
action_276 (117) = happyShift action_64
action_276 (40) = happyGoto action_308
action_276 (41) = happyGoto action_51
action_276 _ = happyFail

action_277 (61) = happyShift action_307
action_277 (95) = happyShift action_86
action_277 (105) = happyShift action_87
action_277 (106) = happyShift action_88
action_277 _ = happyFail

action_278 (80) = happyShift action_71
action_278 (88) = happyShift action_55
action_278 (105) = happyShift action_57
action_278 (107) = happyShift action_58
action_278 (109) = happyShift action_59
action_278 (111) = happyShift action_60
action_278 (112) = happyShift action_61
action_278 (114) = happyShift action_62
action_278 (116) = happyShift action_63
action_278 (117) = happyShift action_64
action_278 (40) = happyGoto action_306
action_278 (41) = happyGoto action_51
action_278 _ = happyFail

action_279 (95) = happyShift action_86
action_279 (105) = happyShift action_87
action_279 (106) = happyShift action_88
action_279 _ = happyReduce_52

action_280 (95) = happyShift action_86
action_280 (105) = happyShift action_87
action_280 (106) = happyShift action_88
action_280 _ = happyReduce_49

action_281 (54) = happyShift action_52
action_281 (80) = happyShift action_301
action_281 (83) = happyShift action_54
action_281 (88) = happyShift action_221
action_281 (91) = happyShift action_56
action_281 (93) = happyShift action_78
action_281 (105) = happyShift action_57
action_281 (107) = happyShift action_58
action_281 (109) = happyShift action_222
action_281 (111) = happyShift action_60
action_281 (112) = happyShift action_61
action_281 (113) = happyShift action_44
action_281 (114) = happyShift action_223
action_281 (116) = happyShift action_63
action_281 (117) = happyShift action_64
action_281 (118) = happyShift action_65
action_281 (32) = happyGoto action_156
action_281 (33) = happyGoto action_47
action_281 (34) = happyGoto action_48
action_281 (36) = happyGoto action_49
action_281 (40) = happyGoto action_50
action_281 (41) = happyGoto action_51
action_281 (42) = happyGoto action_179
action_281 (43) = happyGoto action_151
action_281 (44) = happyGoto action_75
action_281 (45) = happyGoto action_180
action_281 _ = happyFail

action_282 (95) = happyShift action_175
action_282 _ = happyReduce_127

action_283 (80) = happyShift action_71
action_283 (88) = happyShift action_55
action_283 (105) = happyShift action_57
action_283 (107) = happyShift action_58
action_283 (109) = happyShift action_59
action_283 (111) = happyShift action_60
action_283 (112) = happyShift action_61
action_283 (114) = happyShift action_62
action_283 (116) = happyShift action_63
action_283 (117) = happyShift action_64
action_283 (40) = happyGoto action_305
action_283 (41) = happyGoto action_51
action_283 _ = happyFail

action_284 (69) = happyShift action_304
action_284 (95) = happyShift action_86
action_284 (105) = happyShift action_87
action_284 (106) = happyShift action_88
action_284 _ = happyFail

action_285 (54) = happyShift action_52
action_285 (80) = happyShift action_301
action_285 (83) = happyShift action_54
action_285 (88) = happyShift action_302
action_285 (91) = happyShift action_56
action_285 (93) = happyShift action_42
action_285 (105) = happyShift action_57
action_285 (107) = happyShift action_58
action_285 (109) = happyShift action_303
action_285 (111) = happyShift action_60
action_285 (112) = happyShift action_61
action_285 (113) = happyShift action_44
action_285 (114) = happyShift action_62
action_285 (116) = happyShift action_63
action_285 (117) = happyShift action_64
action_285 (118) = happyShift action_65
action_285 (32) = happyGoto action_146
action_285 (33) = happyGoto action_47
action_285 (34) = happyGoto action_48
action_285 (36) = happyGoto action_49
action_285 (40) = happyGoto action_50
action_285 (41) = happyGoto action_51
action_285 (45) = happyGoto action_124
action_285 _ = happyFail

action_286 _ = happyReduce_65

action_287 (54) = happyShift action_52
action_287 (80) = happyShift action_53
action_287 (83) = happyShift action_54
action_287 (88) = happyShift action_55
action_287 (91) = happyShift action_56
action_287 (105) = happyShift action_57
action_287 (107) = happyShift action_58
action_287 (109) = happyShift action_59
action_287 (111) = happyShift action_60
action_287 (112) = happyShift action_61
action_287 (114) = happyShift action_62
action_287 (116) = happyShift action_63
action_287 (117) = happyShift action_64
action_287 (118) = happyShift action_65
action_287 (32) = happyGoto action_300
action_287 (33) = happyGoto action_47
action_287 (34) = happyGoto action_48
action_287 (36) = happyGoto action_49
action_287 (40) = happyGoto action_50
action_287 (41) = happyGoto action_51
action_287 _ = happyFail

action_288 (69) = happyShift action_299
action_288 (95) = happyShift action_86
action_288 (105) = happyShift action_87
action_288 (106) = happyShift action_88
action_288 _ = happyFail

action_289 _ = happyReduce_62

action_290 (91) = happyShift action_298
action_290 _ = happyFail

action_291 (51) = happyShift action_197
action_291 (58) = happyShift action_198
action_291 (66) = happyShift action_199
action_291 (68) = happyShift action_200
action_291 (70) = happyShift action_201
action_291 (71) = happyShift action_202
action_291 (77) = happyShift action_203
action_291 (80) = happyShift action_204
action_291 (83) = happyShift action_205
action_291 (91) = happyShift action_206
action_291 (109) = happyShift action_207
action_291 (16) = happyGoto action_193
action_291 (17) = happyGoto action_297
action_291 (18) = happyGoto action_195
action_291 (24) = happyGoto action_196
action_291 _ = happyFail

action_292 (54) = happyShift action_52
action_292 (80) = happyShift action_53
action_292 (83) = happyShift action_54
action_292 (88) = happyShift action_55
action_292 (91) = happyShift action_56
action_292 (105) = happyShift action_57
action_292 (107) = happyShift action_58
action_292 (109) = happyShift action_59
action_292 (111) = happyShift action_60
action_292 (112) = happyShift action_61
action_292 (114) = happyShift action_62
action_292 (116) = happyShift action_63
action_292 (117) = happyShift action_64
action_292 (118) = happyShift action_65
action_292 (32) = happyGoto action_296
action_292 (33) = happyGoto action_47
action_292 (34) = happyGoto action_48
action_292 (36) = happyGoto action_49
action_292 (40) = happyGoto action_50
action_292 (41) = happyGoto action_51
action_292 _ = happyFail

action_293 _ = happyReduce_25

action_294 (94) = happyShift action_295
action_294 (102) = happyShift action_102
action_294 _ = happyFail

action_295 _ = happyReduce_30

action_296 (85) = happyShift action_354
action_296 _ = happyFail

action_297 (82) = happyShift action_353
action_297 _ = happyFail

action_298 (80) = happyShift action_40
action_298 (88) = happyShift action_77
action_298 (93) = happyShift action_78
action_298 (109) = happyShift action_79
action_298 (113) = happyShift action_44
action_298 (114) = happyShift action_80
action_298 (19) = happyGoto action_350
action_298 (20) = happyGoto action_351
action_298 (43) = happyGoto action_352
action_298 (44) = happyGoto action_75
action_298 (45) = happyGoto action_76
action_298 _ = happyFail

action_299 (54) = happyShift action_52
action_299 (80) = happyShift action_53
action_299 (83) = happyShift action_54
action_299 (88) = happyShift action_55
action_299 (91) = happyShift action_56
action_299 (105) = happyShift action_57
action_299 (107) = happyShift action_58
action_299 (109) = happyShift action_59
action_299 (111) = happyShift action_60
action_299 (112) = happyShift action_61
action_299 (114) = happyShift action_62
action_299 (116) = happyShift action_63
action_299 (117) = happyShift action_64
action_299 (118) = happyShift action_65
action_299 (32) = happyGoto action_349
action_299 (33) = happyGoto action_47
action_299 (34) = happyGoto action_48
action_299 (36) = happyGoto action_49
action_299 (40) = happyGoto action_50
action_299 (41) = happyGoto action_51
action_299 _ = happyFail

action_300 _ = happyReduce_54

action_301 (54) = happyShift action_52
action_301 (80) = happyShift action_53
action_301 (83) = happyShift action_54
action_301 (88) = happyShift action_55
action_301 (91) = happyShift action_56
action_301 (95) = happyShift action_285
action_301 (105) = happyShift action_57
action_301 (106) = happyShift action_83
action_301 (107) = happyShift action_58
action_301 (109) = happyShift action_59
action_301 (111) = happyShift action_60
action_301 (112) = happyShift action_61
action_301 (114) = happyShift action_62
action_301 (116) = happyShift action_63
action_301 (117) = happyShift action_64
action_301 (118) = happyShift action_65
action_301 (32) = happyGoto action_81
action_301 (33) = happyGoto action_47
action_301 (34) = happyGoto action_48
action_301 (36) = happyGoto action_49
action_301 (40) = happyGoto action_50
action_301 (41) = happyGoto action_51
action_301 _ = happyFail

action_302 (109) = happyShift action_348
action_302 _ = happyFail

action_303 (93) = happyShift action_68
action_303 (95) = happyShift action_347
action_303 (103) = happyShift action_104
action_303 _ = happyReduce_131

action_304 (54) = happyShift action_52
action_304 (80) = happyShift action_53
action_304 (83) = happyShift action_54
action_304 (88) = happyShift action_55
action_304 (91) = happyShift action_56
action_304 (105) = happyShift action_57
action_304 (107) = happyShift action_58
action_304 (109) = happyShift action_59
action_304 (111) = happyShift action_60
action_304 (112) = happyShift action_61
action_304 (114) = happyShift action_62
action_304 (116) = happyShift action_63
action_304 (117) = happyShift action_64
action_304 (118) = happyShift action_65
action_304 (32) = happyGoto action_346
action_304 (33) = happyGoto action_47
action_304 (34) = happyGoto action_48
action_304 (36) = happyGoto action_49
action_304 (40) = happyGoto action_50
action_304 (41) = happyGoto action_51
action_304 _ = happyFail

action_305 (69) = happyShift action_345
action_305 (95) = happyShift action_86
action_305 (105) = happyShift action_87
action_305 (106) = happyShift action_88
action_305 _ = happyFail

action_306 (95) = happyShift action_86
action_306 (105) = happyShift action_87
action_306 (106) = happyShift action_88
action_306 _ = happyReduce_51

action_307 (54) = happyShift action_52
action_307 (80) = happyShift action_53
action_307 (83) = happyShift action_54
action_307 (88) = happyShift action_55
action_307 (91) = happyShift action_56
action_307 (105) = happyShift action_57
action_307 (107) = happyShift action_58
action_307 (109) = happyShift action_59
action_307 (111) = happyShift action_60
action_307 (112) = happyShift action_61
action_307 (114) = happyShift action_62
action_307 (116) = happyShift action_63
action_307 (117) = happyShift action_64
action_307 (118) = happyShift action_65
action_307 (32) = happyGoto action_344
action_307 (33) = happyGoto action_47
action_307 (34) = happyGoto action_48
action_307 (36) = happyGoto action_49
action_307 (40) = happyGoto action_50
action_307 (41) = happyGoto action_51
action_307 _ = happyFail

action_308 (61) = happyShift action_343
action_308 (95) = happyShift action_86
action_308 (105) = happyShift action_87
action_308 (106) = happyShift action_88
action_308 _ = happyFail

action_309 (54) = happyShift action_52
action_309 (80) = happyShift action_53
action_309 (83) = happyShift action_54
action_309 (88) = happyShift action_55
action_309 (91) = happyShift action_56
action_309 (105) = happyShift action_57
action_309 (107) = happyShift action_58
action_309 (109) = happyShift action_59
action_309 (111) = happyShift action_60
action_309 (112) = happyShift action_61
action_309 (114) = happyShift action_62
action_309 (116) = happyShift action_63
action_309 (117) = happyShift action_64
action_309 (118) = happyShift action_65
action_309 (32) = happyGoto action_342
action_309 (33) = happyGoto action_47
action_309 (34) = happyGoto action_48
action_309 (36) = happyGoto action_49
action_309 (40) = happyGoto action_50
action_309 (41) = happyGoto action_51
action_309 _ = happyFail

action_310 (61) = happyShift action_341
action_310 (95) = happyShift action_86
action_310 (105) = happyShift action_87
action_310 (106) = happyShift action_88
action_310 _ = happyFail

action_311 (80) = happyShift action_219
action_311 (88) = happyShift action_221
action_311 (93) = happyShift action_78
action_311 (105) = happyShift action_57
action_311 (107) = happyShift action_58
action_311 (109) = happyShift action_222
action_311 (111) = happyShift action_60
action_311 (112) = happyShift action_61
action_311 (113) = happyShift action_44
action_311 (114) = happyShift action_223
action_311 (116) = happyShift action_63
action_311 (117) = happyShift action_64
action_311 (25) = happyGoto action_339
action_311 (40) = happyGoto action_340
action_311 (41) = happyGoto action_51
action_311 (43) = happyGoto action_218
action_311 (44) = happyGoto action_75
action_311 (45) = happyGoto action_76
action_311 _ = happyFail

action_312 (80) = happyShift action_219
action_312 (88) = happyShift action_221
action_312 (93) = happyShift action_78
action_312 (105) = happyShift action_57
action_312 (107) = happyShift action_58
action_312 (109) = happyShift action_222
action_312 (111) = happyShift action_60
action_312 (112) = happyShift action_61
action_312 (113) = happyShift action_44
action_312 (114) = happyShift action_223
action_312 (116) = happyShift action_63
action_312 (117) = happyShift action_64
action_312 (25) = happyGoto action_337
action_312 (40) = happyGoto action_338
action_312 (41) = happyGoto action_51
action_312 (43) = happyGoto action_218
action_312 (44) = happyGoto action_75
action_312 (45) = happyGoto action_76
action_312 _ = happyFail

action_313 (51) = happyShift action_197
action_313 (58) = happyShift action_198
action_313 (66) = happyShift action_199
action_313 (68) = happyShift action_200
action_313 (70) = happyShift action_201
action_313 (71) = happyShift action_202
action_313 (73) = happyShift action_318
action_313 (74) = happyShift action_319
action_313 (75) = happyShift action_320
action_313 (77) = happyShift action_203
action_313 (80) = happyShift action_204
action_313 (83) = happyShift action_205
action_313 (91) = happyShift action_336
action_313 (109) = happyShift action_207
action_313 (16) = happyGoto action_314
action_313 (18) = happyGoto action_195
action_313 (24) = happyGoto action_196
action_313 (27) = happyGoto action_335
action_313 (28) = happyGoto action_316
action_313 (29) = happyGoto action_317
action_313 _ = happyFail

action_314 (104) = happyShift action_235
action_314 _ = happyReduce_74

action_315 (53) = happyShift action_334
action_315 _ = happyFail

action_316 (72) = happyShift action_333
action_316 _ = happyReduce_68

action_317 _ = happyReduce_69

action_318 (76) = happyShift action_332
action_318 _ = happyFail

action_319 (76) = happyShift action_331
action_319 _ = happyFail

action_320 (76) = happyShift action_330
action_320 _ = happyFail

action_321 (51) = happyShift action_197
action_321 (58) = happyShift action_198
action_321 (66) = happyShift action_199
action_321 (68) = happyShift action_200
action_321 (70) = happyShift action_201
action_321 (71) = happyShift action_202
action_321 (77) = happyShift action_203
action_321 (80) = happyShift action_204
action_321 (83) = happyShift action_205
action_321 (91) = happyShift action_206
action_321 (109) = happyShift action_207
action_321 (16) = happyGoto action_193
action_321 (17) = happyGoto action_329
action_321 (18) = happyGoto action_195
action_321 (24) = happyGoto action_196
action_321 _ = happyFail

action_322 (54) = happyShift action_52
action_322 (80) = happyShift action_53
action_322 (83) = happyShift action_54
action_322 (88) = happyShift action_55
action_322 (91) = happyShift action_56
action_322 (105) = happyShift action_57
action_322 (107) = happyShift action_58
action_322 (109) = happyShift action_59
action_322 (111) = happyShift action_60
action_322 (112) = happyShift action_61
action_322 (114) = happyShift action_62
action_322 (116) = happyShift action_63
action_322 (117) = happyShift action_64
action_322 (118) = happyShift action_65
action_322 (32) = happyGoto action_328
action_322 (33) = happyGoto action_47
action_322 (34) = happyGoto action_48
action_322 (36) = happyGoto action_49
action_322 (40) = happyGoto action_50
action_322 (41) = happyGoto action_51
action_322 _ = happyFail

action_323 _ = happyReduce_125

action_324 (119) = happyShift action_327
action_324 _ = happyFail

action_325 _ = happyReduce_86

action_326 _ = happyReduce_85

action_327 _ = happyReduce_84

action_328 _ = happyReduce_39

action_329 (92) = happyShift action_375
action_329 _ = happyFail

action_330 (51) = happyShift action_197
action_330 (58) = happyShift action_198
action_330 (66) = happyShift action_199
action_330 (68) = happyShift action_200
action_330 (70) = happyShift action_201
action_330 (71) = happyShift action_202
action_330 (77) = happyShift action_203
action_330 (80) = happyShift action_204
action_330 (83) = happyShift action_205
action_330 (91) = happyShift action_206
action_330 (109) = happyShift action_207
action_330 (16) = happyGoto action_193
action_330 (17) = happyGoto action_374
action_330 (18) = happyGoto action_195
action_330 (24) = happyGoto action_196
action_330 _ = happyFail

action_331 (51) = happyShift action_197
action_331 (58) = happyShift action_198
action_331 (66) = happyShift action_199
action_331 (68) = happyShift action_200
action_331 (70) = happyShift action_201
action_331 (71) = happyShift action_202
action_331 (77) = happyShift action_203
action_331 (80) = happyShift action_204
action_331 (83) = happyShift action_205
action_331 (91) = happyShift action_206
action_331 (109) = happyShift action_207
action_331 (16) = happyGoto action_193
action_331 (17) = happyGoto action_373
action_331 (18) = happyGoto action_195
action_331 (24) = happyGoto action_196
action_331 _ = happyFail

action_332 (51) = happyShift action_197
action_332 (58) = happyShift action_198
action_332 (66) = happyShift action_199
action_332 (68) = happyShift action_200
action_332 (70) = happyShift action_201
action_332 (71) = happyShift action_202
action_332 (77) = happyShift action_203
action_332 (80) = happyShift action_204
action_332 (83) = happyShift action_205
action_332 (91) = happyShift action_206
action_332 (109) = happyShift action_207
action_332 (16) = happyGoto action_193
action_332 (17) = happyGoto action_372
action_332 (18) = happyGoto action_195
action_332 (24) = happyGoto action_196
action_332 _ = happyFail

action_333 (51) = happyShift action_197
action_333 (58) = happyShift action_198
action_333 (66) = happyShift action_199
action_333 (68) = happyShift action_200
action_333 (70) = happyShift action_201
action_333 (71) = happyShift action_202
action_333 (73) = happyShift action_318
action_333 (74) = happyShift action_319
action_333 (75) = happyShift action_320
action_333 (77) = happyShift action_203
action_333 (80) = happyShift action_204
action_333 (83) = happyShift action_205
action_333 (109) = happyShift action_207
action_333 (16) = happyGoto action_314
action_333 (18) = happyGoto action_195
action_333 (24) = happyGoto action_196
action_333 (28) = happyGoto action_371
action_333 (29) = happyGoto action_317
action_333 _ = happyFail

action_334 (80) = happyShift action_219
action_334 (88) = happyShift action_221
action_334 (93) = happyShift action_78
action_334 (105) = happyShift action_57
action_334 (107) = happyShift action_58
action_334 (109) = happyShift action_222
action_334 (111) = happyShift action_60
action_334 (112) = happyShift action_61
action_334 (113) = happyShift action_44
action_334 (114) = happyShift action_223
action_334 (116) = happyShift action_63
action_334 (117) = happyShift action_64
action_334 (25) = happyGoto action_369
action_334 (40) = happyGoto action_370
action_334 (41) = happyGoto action_51
action_334 (43) = happyGoto action_218
action_334 (44) = happyGoto action_75
action_334 (45) = happyGoto action_76
action_334 _ = happyFail

action_335 (53) = happyShift action_368
action_335 _ = happyFail

action_336 (51) = happyShift action_197
action_336 (58) = happyShift action_198
action_336 (66) = happyShift action_199
action_336 (68) = happyShift action_200
action_336 (70) = happyShift action_201
action_336 (71) = happyShift action_202
action_336 (77) = happyShift action_203
action_336 (80) = happyShift action_204
action_336 (83) = happyShift action_205
action_336 (91) = happyShift action_206
action_336 (109) = happyShift action_207
action_336 (16) = happyGoto action_193
action_336 (17) = happyGoto action_367
action_336 (18) = happyGoto action_195
action_336 (24) = happyGoto action_196
action_336 _ = happyFail

action_337 (80) = happyShift action_71
action_337 (88) = happyShift action_55
action_337 (105) = happyShift action_57
action_337 (107) = happyShift action_58
action_337 (109) = happyShift action_59
action_337 (111) = happyShift action_60
action_337 (112) = happyShift action_61
action_337 (114) = happyShift action_62
action_337 (116) = happyShift action_63
action_337 (117) = happyShift action_64
action_337 (40) = happyGoto action_366
action_337 (41) = happyGoto action_51
action_337 _ = happyFail

action_338 (61) = happyShift action_365
action_338 (95) = happyShift action_86
action_338 (105) = happyShift action_87
action_338 (106) = happyShift action_88
action_338 _ = happyFail

action_339 (80) = happyShift action_71
action_339 (88) = happyShift action_55
action_339 (105) = happyShift action_57
action_339 (107) = happyShift action_58
action_339 (109) = happyShift action_59
action_339 (111) = happyShift action_60
action_339 (112) = happyShift action_61
action_339 (114) = happyShift action_62
action_339 (116) = happyShift action_63
action_339 (117) = happyShift action_64
action_339 (40) = happyGoto action_364
action_339 (41) = happyGoto action_51
action_339 _ = happyFail

action_340 (61) = happyShift action_363
action_340 (95) = happyShift action_86
action_340 (105) = happyShift action_87
action_340 (106) = happyShift action_88
action_340 _ = happyFail

action_341 (54) = happyShift action_52
action_341 (80) = happyShift action_53
action_341 (83) = happyShift action_54
action_341 (88) = happyShift action_55
action_341 (91) = happyShift action_56
action_341 (105) = happyShift action_57
action_341 (107) = happyShift action_58
action_341 (109) = happyShift action_59
action_341 (111) = happyShift action_60
action_341 (112) = happyShift action_61
action_341 (114) = happyShift action_62
action_341 (116) = happyShift action_63
action_341 (117) = happyShift action_64
action_341 (118) = happyShift action_65
action_341 (32) = happyGoto action_362
action_341 (33) = happyGoto action_47
action_341 (34) = happyGoto action_48
action_341 (36) = happyGoto action_49
action_341 (40) = happyGoto action_50
action_341 (41) = happyGoto action_51
action_341 _ = happyFail

action_342 _ = happyReduce_44

action_343 (54) = happyShift action_52
action_343 (80) = happyShift action_53
action_343 (83) = happyShift action_54
action_343 (88) = happyShift action_55
action_343 (91) = happyShift action_56
action_343 (105) = happyShift action_57
action_343 (107) = happyShift action_58
action_343 (109) = happyShift action_59
action_343 (111) = happyShift action_60
action_343 (112) = happyShift action_61
action_343 (114) = happyShift action_62
action_343 (116) = happyShift action_63
action_343 (117) = happyShift action_64
action_343 (118) = happyShift action_65
action_343 (32) = happyGoto action_361
action_343 (33) = happyGoto action_47
action_343 (34) = happyGoto action_48
action_343 (36) = happyGoto action_49
action_343 (40) = happyGoto action_50
action_343 (41) = happyGoto action_51
action_343 _ = happyFail

action_344 _ = happyReduce_42

action_345 (54) = happyShift action_52
action_345 (80) = happyShift action_53
action_345 (83) = happyShift action_54
action_345 (88) = happyShift action_55
action_345 (91) = happyShift action_56
action_345 (105) = happyShift action_57
action_345 (107) = happyShift action_58
action_345 (109) = happyShift action_59
action_345 (111) = happyShift action_60
action_345 (112) = happyShift action_61
action_345 (114) = happyShift action_62
action_345 (116) = happyShift action_63
action_345 (117) = happyShift action_64
action_345 (118) = happyShift action_65
action_345 (32) = happyGoto action_360
action_345 (33) = happyGoto action_47
action_345 (34) = happyGoto action_48
action_345 (36) = happyGoto action_49
action_345 (40) = happyGoto action_50
action_345 (41) = happyGoto action_51
action_345 _ = happyFail

action_346 _ = happyReduce_56

action_347 (54) = happyShift action_52
action_347 (80) = happyShift action_301
action_347 (83) = happyShift action_54
action_347 (88) = happyShift action_302
action_347 (91) = happyShift action_56
action_347 (93) = happyShift action_42
action_347 (105) = happyShift action_57
action_347 (107) = happyShift action_58
action_347 (109) = happyShift action_303
action_347 (111) = happyShift action_60
action_347 (112) = happyShift action_61
action_347 (113) = happyShift action_44
action_347 (114) = happyShift action_62
action_347 (116) = happyShift action_63
action_347 (117) = happyShift action_64
action_347 (118) = happyShift action_65
action_347 (32) = happyGoto action_156
action_347 (33) = happyGoto action_47
action_347 (34) = happyGoto action_48
action_347 (36) = happyGoto action_49
action_347 (40) = happyGoto action_50
action_347 (41) = happyGoto action_51
action_347 (45) = happyGoto action_130
action_347 _ = happyFail

action_348 (95) = happyShift action_125
action_348 _ = happyReduce_127

action_349 _ = happyReduce_53

action_350 (72) = happyShift action_358
action_350 (92) = happyShift action_359
action_350 _ = happyFail

action_351 _ = happyReduce_32

action_352 (76) = happyShift action_357
action_352 _ = happyFail

action_353 (51) = happyShift action_197
action_353 (58) = happyShift action_198
action_353 (66) = happyShift action_199
action_353 (68) = happyShift action_200
action_353 (70) = happyShift action_201
action_353 (71) = happyShift action_202
action_353 (77) = happyShift action_203
action_353 (80) = happyShift action_204
action_353 (83) = happyShift action_205
action_353 (91) = happyShift action_206
action_353 (109) = happyShift action_207
action_353 (16) = happyGoto action_193
action_353 (17) = happyGoto action_356
action_353 (18) = happyGoto action_195
action_353 (24) = happyGoto action_196
action_353 _ = happyFail

action_354 (51) = happyShift action_197
action_354 (58) = happyShift action_198
action_354 (66) = happyShift action_199
action_354 (68) = happyShift action_200
action_354 (70) = happyShift action_201
action_354 (71) = happyShift action_202
action_354 (77) = happyShift action_203
action_354 (80) = happyShift action_204
action_354 (83) = happyShift action_205
action_354 (91) = happyShift action_206
action_354 (109) = happyShift action_207
action_354 (16) = happyGoto action_193
action_354 (17) = happyGoto action_355
action_354 (18) = happyGoto action_195
action_354 (24) = happyGoto action_196
action_354 _ = happyFail

action_355 _ = happyReduce_29

action_356 _ = happyReduce_28

action_357 (51) = happyShift action_197
action_357 (58) = happyShift action_198
action_357 (66) = happyShift action_199
action_357 (68) = happyShift action_200
action_357 (70) = happyShift action_201
action_357 (71) = happyShift action_202
action_357 (77) = happyShift action_203
action_357 (80) = happyShift action_204
action_357 (83) = happyShift action_205
action_357 (91) = happyShift action_206
action_357 (109) = happyShift action_207
action_357 (16) = happyGoto action_193
action_357 (17) = happyGoto action_388
action_357 (18) = happyGoto action_195
action_357 (24) = happyGoto action_196
action_357 _ = happyFail

action_358 (80) = happyShift action_40
action_358 (88) = happyShift action_77
action_358 (93) = happyShift action_78
action_358 (109) = happyShift action_79
action_358 (113) = happyShift action_44
action_358 (114) = happyShift action_80
action_358 (20) = happyGoto action_387
action_358 (43) = happyGoto action_352
action_358 (44) = happyGoto action_75
action_358 (45) = happyGoto action_76
action_358 _ = happyFail

action_359 _ = happyReduce_31

action_360 _ = happyReduce_55

action_361 _ = happyReduce_41

action_362 _ = happyReduce_43

action_363 (54) = happyShift action_52
action_363 (80) = happyShift action_53
action_363 (83) = happyShift action_54
action_363 (88) = happyShift action_55
action_363 (91) = happyShift action_56
action_363 (105) = happyShift action_57
action_363 (107) = happyShift action_58
action_363 (109) = happyShift action_59
action_363 (111) = happyShift action_60
action_363 (112) = happyShift action_61
action_363 (114) = happyShift action_62
action_363 (116) = happyShift action_63
action_363 (117) = happyShift action_64
action_363 (118) = happyShift action_65
action_363 (32) = happyGoto action_386
action_363 (33) = happyGoto action_47
action_363 (34) = happyGoto action_48
action_363 (36) = happyGoto action_49
action_363 (40) = happyGoto action_50
action_363 (41) = happyGoto action_51
action_363 _ = happyFail

action_364 (61) = happyShift action_385
action_364 (95) = happyShift action_86
action_364 (105) = happyShift action_87
action_364 (106) = happyShift action_88
action_364 _ = happyFail

action_365 (54) = happyShift action_52
action_365 (80) = happyShift action_53
action_365 (83) = happyShift action_54
action_365 (88) = happyShift action_55
action_365 (91) = happyShift action_56
action_365 (105) = happyShift action_57
action_365 (107) = happyShift action_58
action_365 (109) = happyShift action_59
action_365 (111) = happyShift action_60
action_365 (112) = happyShift action_61
action_365 (114) = happyShift action_62
action_365 (116) = happyShift action_63
action_365 (117) = happyShift action_64
action_365 (118) = happyShift action_65
action_365 (32) = happyGoto action_384
action_365 (33) = happyGoto action_47
action_365 (34) = happyGoto action_48
action_365 (36) = happyGoto action_49
action_365 (40) = happyGoto action_50
action_365 (41) = happyGoto action_51
action_365 _ = happyFail

action_366 (61) = happyShift action_383
action_366 (95) = happyShift action_86
action_366 (105) = happyShift action_87
action_366 (106) = happyShift action_88
action_366 _ = happyFail

action_367 (92) = happyShift action_382
action_367 _ = happyFail

action_368 (80) = happyShift action_219
action_368 (88) = happyShift action_221
action_368 (93) = happyShift action_78
action_368 (105) = happyShift action_57
action_368 (107) = happyShift action_58
action_368 (109) = happyShift action_222
action_368 (111) = happyShift action_60
action_368 (112) = happyShift action_61
action_368 (113) = happyShift action_44
action_368 (114) = happyShift action_223
action_368 (116) = happyShift action_63
action_368 (117) = happyShift action_64
action_368 (25) = happyGoto action_380
action_368 (40) = happyGoto action_381
action_368 (41) = happyGoto action_51
action_368 (43) = happyGoto action_218
action_368 (44) = happyGoto action_75
action_368 (45) = happyGoto action_76
action_368 _ = happyFail

action_369 (80) = happyShift action_71
action_369 (88) = happyShift action_55
action_369 (105) = happyShift action_57
action_369 (107) = happyShift action_58
action_369 (109) = happyShift action_59
action_369 (111) = happyShift action_60
action_369 (112) = happyShift action_61
action_369 (114) = happyShift action_62
action_369 (116) = happyShift action_63
action_369 (117) = happyShift action_64
action_369 (40) = happyGoto action_379
action_369 (41) = happyGoto action_51
action_369 _ = happyFail

action_370 (56) = happyShift action_378
action_370 (95) = happyShift action_86
action_370 (105) = happyShift action_87
action_370 (106) = happyShift action_88
action_370 (26) = happyGoto action_376
action_370 (30) = happyGoto action_377
action_370 _ = happyReduce_67

action_371 _ = happyReduce_70

action_372 _ = happyReduce_71

action_373 _ = happyReduce_72

action_374 _ = happyReduce_73

action_375 _ = happyReduce_64

action_376 _ = happyReduce_59

action_377 _ = happyReduce_66

action_378 (52) = happyShift action_394
action_378 (57) = happyShift action_395
action_378 _ = happyFail

action_379 (56) = happyShift action_378
action_379 (95) = happyShift action_86
action_379 (105) = happyShift action_87
action_379 (106) = happyShift action_88
action_379 (26) = happyGoto action_393
action_379 (30) = happyGoto action_377
action_379 _ = happyReduce_67

action_380 (80) = happyShift action_71
action_380 (88) = happyShift action_55
action_380 (105) = happyShift action_57
action_380 (107) = happyShift action_58
action_380 (109) = happyShift action_59
action_380 (111) = happyShift action_60
action_380 (112) = happyShift action_61
action_380 (114) = happyShift action_62
action_380 (116) = happyShift action_63
action_380 (117) = happyShift action_64
action_380 (40) = happyGoto action_392
action_380 (41) = happyGoto action_51
action_380 _ = happyFail

action_381 (56) = happyShift action_378
action_381 (95) = happyShift action_86
action_381 (105) = happyShift action_87
action_381 (106) = happyShift action_88
action_381 (26) = happyGoto action_391
action_381 (30) = happyGoto action_377
action_381 _ = happyReduce_67

action_382 _ = happyReduce_63

action_383 (54) = happyShift action_52
action_383 (80) = happyShift action_53
action_383 (83) = happyShift action_54
action_383 (88) = happyShift action_55
action_383 (91) = happyShift action_56
action_383 (105) = happyShift action_57
action_383 (107) = happyShift action_58
action_383 (109) = happyShift action_59
action_383 (111) = happyShift action_60
action_383 (112) = happyShift action_61
action_383 (114) = happyShift action_62
action_383 (116) = happyShift action_63
action_383 (117) = happyShift action_64
action_383 (118) = happyShift action_65
action_383 (32) = happyGoto action_390
action_383 (33) = happyGoto action_47
action_383 (34) = happyGoto action_48
action_383 (36) = happyGoto action_49
action_383 (40) = happyGoto action_50
action_383 (41) = happyGoto action_51
action_383 _ = happyFail

action_384 _ = happyReduce_48

action_385 (54) = happyShift action_52
action_385 (80) = happyShift action_53
action_385 (83) = happyShift action_54
action_385 (88) = happyShift action_55
action_385 (91) = happyShift action_56
action_385 (105) = happyShift action_57
action_385 (107) = happyShift action_58
action_385 (109) = happyShift action_59
action_385 (111) = happyShift action_60
action_385 (112) = happyShift action_61
action_385 (114) = happyShift action_62
action_385 (116) = happyShift action_63
action_385 (117) = happyShift action_64
action_385 (118) = happyShift action_65
action_385 (32) = happyGoto action_389
action_385 (33) = happyGoto action_47
action_385 (34) = happyGoto action_48
action_385 (36) = happyGoto action_49
action_385 (40) = happyGoto action_50
action_385 (41) = happyGoto action_51
action_385 _ = happyFail

action_386 _ = happyReduce_46

action_387 _ = happyReduce_33

action_388 _ = happyReduce_34

action_389 _ = happyReduce_45

action_390 _ = happyReduce_47

action_391 _ = happyReduce_60

action_392 (56) = happyShift action_378
action_392 (95) = happyShift action_86
action_392 (105) = happyShift action_87
action_392 (106) = happyShift action_88
action_392 (26) = happyGoto action_398
action_392 (30) = happyGoto action_377
action_392 _ = happyReduce_67

action_393 _ = happyReduce_58

action_394 (80) = happyShift action_71
action_394 (88) = happyShift action_55
action_394 (105) = happyShift action_57
action_394 (107) = happyShift action_58
action_394 (109) = happyShift action_59
action_394 (111) = happyShift action_60
action_394 (112) = happyShift action_61
action_394 (114) = happyShift action_62
action_394 (116) = happyShift action_63
action_394 (117) = happyShift action_64
action_394 (40) = happyGoto action_397
action_394 (41) = happyGoto action_51
action_394 _ = happyFail

action_395 (52) = happyShift action_396
action_395 _ = happyFail

action_396 (80) = happyShift action_71
action_396 (88) = happyShift action_55
action_396 (105) = happyShift action_57
action_396 (107) = happyShift action_58
action_396 (109) = happyShift action_59
action_396 (111) = happyShift action_60
action_396 (112) = happyShift action_61
action_396 (114) = happyShift action_62
action_396 (116) = happyShift action_63
action_396 (117) = happyShift action_64
action_396 (40) = happyGoto action_399
action_396 (41) = happyGoto action_51
action_396 _ = happyFail

action_397 (95) = happyShift action_86
action_397 (105) = happyShift action_87
action_397 (106) = happyShift action_88
action_397 _ = happyReduce_75

action_398 _ = happyReduce_57

action_399 (55) = happyShift action_400
action_399 (95) = happyShift action_86
action_399 (105) = happyShift action_87
action_399 (106) = happyShift action_88
action_399 _ = happyFail

action_400 (52) = happyShift action_401
action_400 _ = happyFail

action_401 (80) = happyShift action_71
action_401 (88) = happyShift action_55
action_401 (105) = happyShift action_57
action_401 (107) = happyShift action_58
action_401 (109) = happyShift action_59
action_401 (111) = happyShift action_60
action_401 (112) = happyShift action_61
action_401 (114) = happyShift action_62
action_401 (116) = happyShift action_63
action_401 (117) = happyShift action_64
action_401 (40) = happyGoto action_402
action_401 (41) = happyGoto action_51
action_401 _ = happyFail

action_402 (95) = happyShift action_86
action_402 (105) = happyShift action_87
action_402 (106) = happyShift action_88
action_402 _ = happyReduce_76

happyReduce_1 = happyReduce 4 4 happyReduction_1
happyReduction_1 ((HappyAbsSyn11  happy_var_4) `HappyStk`
	(HappyAbsSyn9  happy_var_3) `HappyStk`
	(HappyAbsSyn7  happy_var_2) `HappyStk`
	(HappyAbsSyn5  happy_var_1) `HappyStk`
	happyRest)
	 = HappyAbsSyn4
		 (Program happy_var_1 happy_var_2 happy_var_3 happy_var_4
	) `HappyStk` happyRest

happyReduce_2 = happySpecReduce_1  5 happyReduction_2
happyReduction_2 (HappyAbsSyn6  happy_var_1)
	 =  HappyAbsSyn5
		 ([happy_var_1]
	)
happyReduction_2 _  = notHappyAtAll 

happyReduce_3 = happySpecReduce_2  5 happyReduction_3
happyReduction_3 (HappyAbsSyn6  happy_var_2)
	(HappyAbsSyn5  happy_var_1)
	 =  HappyAbsSyn5
		 (happy_var_1 ++ [happy_var_2]
	)
happyReduction_3 _ _  = notHappyAtAll 

happyReduce_4 = happyReduce 4 6 happyReduction_4
happyReduction_4 ((HappyTerminal (QName happy_var_4)) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn6
		 (Import happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_5 = happySpecReduce_1  7 happyReduction_5
happyReduction_5 (HappyAbsSyn8  happy_var_1)
	 =  HappyAbsSyn7
		 ([happy_var_1]
	)
happyReduction_5 _  = notHappyAtAll 

happyReduce_6 = happySpecReduce_2  7 happyReduction_6
happyReduction_6 (HappyAbsSyn8  happy_var_2)
	(HappyAbsSyn7  happy_var_1)
	 =  HappyAbsSyn7
		 (happy_var_1 ++ [happy_var_2]
	)
happyReduction_6 _ _  = notHappyAtAll 

happyReduce_7 = happyReduce 6 8 happyReduction_7
happyReduction_7 (_ `HappyStk`
	(HappyTerminal (QString happy_var_5)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QVar happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn8
		 (VarBind happy_var_1 happy_var_5
	) `HappyStk` happyRest

happyReduce_8 = happyReduce 6 9 happyReduction_8
happyReduction_8 (_ `HappyStk`
	(HappyAbsSyn10  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_3)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn9
		 (Start happy_var_3  happy_var_5
	) `HappyStk` happyRest

happyReduce_9 = happySpecReduce_1  10 happyReduction_9
happyReduction_9 (HappyAbsSyn31  happy_var_1)
	 =  HappyAbsSyn10
		 ([ happy_var_1]
	)
happyReduction_9 _  = notHappyAtAll 

happyReduce_10 = happySpecReduce_3  10 happyReduction_10
happyReduction_10 (HappyAbsSyn31  happy_var_3)
	_
	(HappyAbsSyn10  happy_var_1)
	 =  HappyAbsSyn10
		 (happy_var_1 ++ [happy_var_3]
	)
happyReduction_10 _ _ _  = notHappyAtAll 

happyReduce_11 = happySpecReduce_0  10 happyReduction_11
happyReduction_11  =  HappyAbsSyn10
		 ([]
	)

happyReduce_12 = happySpecReduce_1  11 happyReduction_12
happyReduction_12 (HappyAbsSyn12  happy_var_1)
	 =  HappyAbsSyn11
		 ([happy_var_1]
	)
happyReduction_12 _  = notHappyAtAll 

happyReduce_13 = happySpecReduce_2  11 happyReduction_13
happyReduction_13 (HappyAbsSyn12  happy_var_2)
	(HappyAbsSyn11  happy_var_1)
	 =  HappyAbsSyn11
		 (happy_var_1 ++ [happy_var_2]
	)
happyReduction_13 _ _  = notHappyAtAll 

happyReduce_14 = happySpecReduce_1  12 happyReduction_14
happyReduction_14 (HappyAbsSyn13  happy_var_1)
	 =  HappyAbsSyn12
		 (ProcedureDecl happy_var_1
	)
happyReduction_14 _  = notHappyAtAll 

happyReduce_15 = happyReduce 4 12 happyReduction_15
happyReduction_15 ((HappyAbsSyn45  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QTName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn12
		 (TypeDecl happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_16 = happyReduce 7 13 happyReduction_16
happyReduction_16 ((HappyAbsSyn16  happy_var_7) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn14  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn13
		 (Procedure happy_var_2 happy_var_4 happy_var_7
	) `HappyStk` happyRest

happyReduce_17 = happySpecReduce_1  14 happyReduction_17
happyReduction_17 (HappyAbsSyn15  happy_var_1)
	 =  HappyAbsSyn14
		 ([happy_var_1]
	)
happyReduction_17 _  = notHappyAtAll 

happyReduce_18 = happySpecReduce_3  14 happyReduction_18
happyReduction_18 (HappyAbsSyn15  happy_var_3)
	_
	(HappyAbsSyn14  happy_var_1)
	 =  HappyAbsSyn14
		 (happy_var_1 ++ [happy_var_3]
	)
happyReduction_18 _ _ _  = notHappyAtAll 

happyReduce_19 = happySpecReduce_0  14 happyReduction_19
happyReduction_19  =  HappyAbsSyn14
		 ([]
	)

happyReduce_20 = happyReduce 4 15 happyReduction_20
happyReduction_20 ((HappyAbsSyn45  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QVar happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn15
		 ((ProcSVar happy_var_2, happy_var_4)
	) `HappyStk` happyRest

happyReduce_21 = happyReduce 4 15 happyReduction_21
happyReduction_21 ((HappyAbsSyn45  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QVar happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn15
		 ((ProcVVar happy_var_2, happy_var_4)
	) `HappyStk` happyRest

happyReduce_22 = happySpecReduce_3  15 happyReduction_22
happyReduction_22 (HappyAbsSyn45  happy_var_3)
	_
	(HappyTerminal (QVar happy_var_1))
	 =  HappyAbsSyn15
		 ((ProcEVar happy_var_1, happy_var_3)
	)
happyReduction_22 _ _ _  = notHappyAtAll 

happyReduce_23 = happySpecReduce_1  16 happyReduction_23
happyReduction_23 (HappyAbsSyn18  happy_var_1)
	 =  HappyAbsSyn16
		 ([happy_var_1]
	)
happyReduction_23 _  = notHappyAtAll 

happyReduce_24 = happySpecReduce_3  16 happyReduction_24
happyReduction_24 (HappyAbsSyn18  happy_var_3)
	_
	(HappyAbsSyn16  happy_var_1)
	 =  HappyAbsSyn16
		 (happy_var_1 ++ [happy_var_3]
	)
happyReduction_24 _ _ _  = notHappyAtAll 

happyReduce_25 = happySpecReduce_3  17 happyReduction_25
happyReduction_25 _
	(HappyAbsSyn16  happy_var_2)
	_
	 =  HappyAbsSyn16
		 (happy_var_2
	)
happyReduction_25 _ _ _  = notHappyAtAll 

happyReduce_26 = happySpecReduce_1  17 happyReduction_26
happyReduction_26 (HappyAbsSyn16  happy_var_1)
	 =  HappyAbsSyn16
		 (happy_var_1
	)
happyReduction_26 _  = notHappyAtAll 

happyReduce_27 = happySpecReduce_2  18 happyReduction_27
happyReduction_27 (HappyAbsSyn21  happy_var_2)
	(HappyAbsSyn24  happy_var_1)
	 =  HappyAbsSyn18
		 (StmtUpd happy_var_1 happy_var_2
	)
happyReduction_27 _ _  = notHappyAtAll 

happyReduce_28 = happyReduce 6 18 happyReduction_28
happyReduction_28 ((HappyAbsSyn16  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn16  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn23  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn18
		 (StmtIF  happy_var_2 happy_var_4  happy_var_6
	) `HappyStk` happyRest

happyReduce_29 = happyReduce 6 18 happyReduction_29
happyReduction_29 ((HappyAbsSyn16  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn31  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn43  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn18
		 (StmtLet happy_var_2 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_30 = happyReduce 4 18 happyReduction_30
happyReduction_30 (_ `HappyStk`
	(HappyAbsSyn10  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn18
		 (StmtP   happy_var_1 happy_var_3
	) `HappyStk` happyRest

happyReduce_31 = happyReduce 6 18 happyReduction_31
happyReduction_31 (_ `HappyStk`
	(HappyAbsSyn19  happy_var_5) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn31  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn18
		 (StmtCase happy_var_2 happy_var_5
	) `HappyStk` happyRest

happyReduce_32 = happySpecReduce_1  19 happyReduction_32
happyReduction_32 (HappyAbsSyn20  happy_var_1)
	 =  HappyAbsSyn19
		 ([happy_var_1]
	)
happyReduction_32 _  = notHappyAtAll 

happyReduce_33 = happySpecReduce_3  19 happyReduction_33
happyReduction_33 (HappyAbsSyn20  happy_var_3)
	_
	(HappyAbsSyn19  happy_var_1)
	 =  HappyAbsSyn19
		 (happy_var_1 ++ [happy_var_3]
	)
happyReduction_33 _ _ _  = notHappyAtAll 

happyReduce_34 = happySpecReduce_3  20 happyReduction_34
happyReduction_34 (HappyAbsSyn16  happy_var_3)
	_
	(HappyAbsSyn43  happy_var_1)
	 =  HappyAbsSyn20
		 ((happy_var_1, happy_var_3)
	)
happyReduction_34 _ _ _  = notHappyAtAll 

happyReduce_35 = happySpecReduce_1  21 happyReduction_35
happyReduction_35 (HappyAbsSyn22  happy_var_1)
	 =  HappyAbsSyn21
		 ([happy_var_1]
	)
happyReduction_35 _  = notHappyAtAll 

happyReduce_36 = happySpecReduce_2  21 happyReduction_36
happyReduction_36 (HappyAbsSyn22  happy_var_2)
	(HappyAbsSyn21  happy_var_1)
	 =  HappyAbsSyn21
		 (happy_var_1 ++ [happy_var_2]
	)
happyReduction_36 _ _  = notHappyAtAll 

happyReduce_37 = happySpecReduce_0  21 happyReduction_37
happyReduction_37  =  HappyAbsSyn21
		 ([]
	)

happyReduce_38 = happySpecReduce_2  22 happyReduction_38
happyReduction_38 (HappyAbsSyn23  happy_var_2)
	_
	 =  HappyAbsSyn22
		 (WhereBool happy_var_2
	)
happyReduction_38 _ _  = notHappyAtAll 

happyReduce_39 = happyReduce 4 22 happyReduction_39
happyReduction_39 ((HappyAbsSyn31  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QVar happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn22
		 (WhereBind happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_40 = happySpecReduce_1  23 happyReduction_40
happyReduction_40 (HappyAbsSyn31  happy_var_1)
	 =  HappyAbsSyn23
		 (happy_var_1
	)
happyReduction_40 _  = notHappyAtAll 

happyReduce_41 = happyReduce 6 24 happyReduction_41
happyReduction_41 ((HappyAbsSyn31  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_4) `HappyStk`
	(HappyAbsSyn25  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (SingleInsertion UBEFORE happy_var_3 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_42 = happyReduce 5 24 happyReduction_42
happyReduction_42 ((HappyAbsSyn31  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (SingleInsertion UBEFORE Nothing happy_var_3 happy_var_5
	) `HappyStk` happyRest

happyReduce_43 = happyReduce 6 24 happyReduction_43
happyReduction_43 ((HappyAbsSyn31  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_4) `HappyStk`
	(HappyAbsSyn25  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (SingleInsertion UAFTER  happy_var_3 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_44 = happyReduce 5 24 happyReduction_44
happyReduction_44 ((HappyAbsSyn31  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (SingleInsertion UAFTER  Nothing happy_var_3 happy_var_5
	) `HappyStk` happyRest

happyReduce_45 = happyReduce 8 24 happyReduction_45
happyReduction_45 ((HappyAbsSyn31  happy_var_8) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_6) `HappyStk`
	(HappyAbsSyn25  happy_var_5) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (PluralInsertion UFIRST  happy_var_5 happy_var_6 happy_var_8
	) `HappyStk` happyRest

happyReduce_46 = happyReduce 7 24 happyReduction_46
happyReduction_46 ((HappyAbsSyn31  happy_var_7) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_5) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (PluralInsertion UFIRST  Nothing happy_var_5 happy_var_7
	) `HappyStk` happyRest

happyReduce_47 = happyReduce 8 24 happyReduction_47
happyReduction_47 ((HappyAbsSyn31  happy_var_8) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_6) `HappyStk`
	(HappyAbsSyn25  happy_var_5) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (PluralInsertion ULAST   happy_var_5 happy_var_6 happy_var_8
	) `HappyStk` happyRest

happyReduce_48 = happyReduce 7 24 happyReduction_48
happyReduction_48 ((HappyAbsSyn31  happy_var_7) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_5) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (PluralInsertion ULAST   Nothing happy_var_5 happy_var_7
	) `HappyStk` happyRest

happyReduce_49 = happySpecReduce_3  24 happyReduction_49
happyReduction_49 (HappyAbsSyn40  happy_var_3)
	(HappyAbsSyn25  happy_var_2)
	_
	 =  HappyAbsSyn24
		 (SingleDeletion          happy_var_2 happy_var_3
	)
happyReduction_49 _ _ _  = notHappyAtAll 

happyReduce_50 = happySpecReduce_2  24 happyReduction_50
happyReduction_50 (HappyAbsSyn40  happy_var_2)
	_
	 =  HappyAbsSyn24
		 (SingleDeletion          Nothing happy_var_2
	)
happyReduction_50 _ _  = notHappyAtAll 

happyReduce_51 = happyReduce 4 24 happyReduction_51
happyReduction_51 ((HappyAbsSyn40  happy_var_4) `HappyStk`
	(HappyAbsSyn25  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (PluralDeletion          happy_var_3 happy_var_4
	) `HappyStk` happyRest

happyReduce_52 = happySpecReduce_3  24 happyReduction_52
happyReduction_52 (HappyAbsSyn40  happy_var_3)
	_
	_
	 =  HappyAbsSyn24
		 (PluralDeletion          Nothing  happy_var_3
	)
happyReduction_52 _ _ _  = notHappyAtAll 

happyReduce_53 = happyReduce 5 24 happyReduction_53
happyReduction_53 ((HappyAbsSyn31  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_3) `HappyStk`
	(HappyAbsSyn25  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (SingleReplace           happy_var_2 happy_var_3 happy_var_5
	) `HappyStk` happyRest

happyReduce_54 = happyReduce 4 24 happyReduction_54
happyReduction_54 ((HappyAbsSyn31  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (SingleReplace           Nothing happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_55 = happyReduce 6 24 happyReduction_55
happyReduction_55 ((HappyAbsSyn31  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_4) `HappyStk`
	(HappyAbsSyn25  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (PluralReplace           happy_var_3 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_56 = happyReduce 5 24 happyReduction_56
happyReduction_56 ((HappyAbsSyn31  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (PluralReplace           Nothing happy_var_3 happy_var_5
	) `HappyStk` happyRest

happyReduce_57 = happyReduce 9 24 happyReduction_57
happyReduction_57 ((HappyAbsSyn26  happy_var_9) `HappyStk`
	(HappyAbsSyn40  happy_var_8) `HappyStk`
	(HappyAbsSyn25  happy_var_7) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn27  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_3) `HappyStk`
	(HappyAbsSyn25  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (UpdateView happy_var_2 happy_var_3 happy_var_5 happy_var_7 happy_var_8 happy_var_9
	) `HappyStk` happyRest

happyReduce_58 = happyReduce 8 24 happyReduction_58
happyReduction_58 ((HappyAbsSyn26  happy_var_8) `HappyStk`
	(HappyAbsSyn40  happy_var_7) `HappyStk`
	(HappyAbsSyn25  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn27  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (UpdateView Nothing happy_var_2 happy_var_4 happy_var_6 happy_var_7 happy_var_8
	) `HappyStk` happyRest

happyReduce_59 = happyReduce 7 24 happyReduction_59
happyReduction_59 ((HappyAbsSyn26  happy_var_7) `HappyStk`
	(HappyAbsSyn40  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn27  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (UpdateView Nothing happy_var_2 happy_var_4 Nothing happy_var_6 happy_var_7
	) `HappyStk` happyRest

happyReduce_60 = happyReduce 8 24 happyReduction_60
happyReduction_60 ((HappyAbsSyn26  happy_var_8) `HappyStk`
	(HappyAbsSyn40  happy_var_7) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn27  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_3) `HappyStk`
	(HappyAbsSyn25  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (UpdateView happy_var_2 happy_var_3 happy_var_5 Nothing happy_var_7 happy_var_8
	) `HappyStk` happyRest

happyReduce_61 = happySpecReduce_2  24 happyReduction_61
happyReduction_61 (HappyAbsSyn40  happy_var_2)
	_
	 =  HappyAbsSyn24
		 (UpdateKeep                happy_var_2
	)
happyReduction_61 _ _  = notHappyAtAll 

happyReduce_62 = happySpecReduce_3  24 happyReduction_62
happyReduction_62 (HappyAbsSyn31  happy_var_3)
	_
	_
	 =  HappyAbsSyn24
		 (UpdateCreate              happy_var_3
	)
happyReduction_62 _ _ _  = notHappyAtAll 

happyReduce_63 = happyReduce 7 24 happyReduction_63
happyReduction_63 (_ `HappyStk`
	(HappyAbsSyn16  happy_var_6) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_3) `HappyStk`
	(HappyAbsSyn25  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (UpdateSource        happy_var_2 happy_var_3 happy_var_6
	) `HappyStk` happyRest

happyReduce_64 = happyReduce 6 24 happyReduction_64
happyReduction_64 (_ `HappyStk`
	(HappyAbsSyn16  happy_var_5) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn24
		 (UpdateSource        Nothing happy_var_2 happy_var_5
	) `HappyStk` happyRest

happyReduce_65 = happySpecReduce_2  25 happyReduction_65
happyReduction_65 _
	(HappyAbsSyn43  happy_var_1)
	 =  HappyAbsSyn25
		 (Just happy_var_1
	)
happyReduction_65 _ _  = notHappyAtAll 

happyReduce_66 = happySpecReduce_1  26 happyReduction_66
happyReduction_66 (HappyAbsSyn30  happy_var_1)
	 =  HappyAbsSyn26
		 (Just happy_var_1
	)
happyReduction_66 _  = notHappyAtAll 

happyReduce_67 = happySpecReduce_0  26 happyReduction_67
happyReduction_67  =  HappyAbsSyn26
		 (Nothing
	)

happyReduce_68 = happySpecReduce_1  27 happyReduction_68
happyReduction_68 (HappyAbsSyn27  happy_var_1)
	 =  HappyAbsSyn27
		 (happy_var_1
	)
happyReduction_68 _  = notHappyAtAll 

happyReduce_69 = happySpecReduce_1  28 happyReduction_69
happyReduction_69 (HappyAbsSyn29  happy_var_1)
	 =  HappyAbsSyn27
		 ([happy_var_1]
	)
happyReduction_69 _  = notHappyAtAll 

happyReduce_70 = happySpecReduce_3  28 happyReduction_70
happyReduction_70 (HappyAbsSyn27  happy_var_3)
	_
	(HappyAbsSyn27  happy_var_1)
	 =  HappyAbsSyn27
		 (happy_var_1 ++ happy_var_3
	)
happyReduction_70 _ _ _  = notHappyAtAll 

happyReduce_71 = happySpecReduce_3  29 happyReduction_71
happyReduction_71 (HappyAbsSyn16  happy_var_3)
	_
	_
	 =  HappyAbsSyn29
		 (ViewStmtMatch happy_var_3
	)
happyReduction_71 _ _ _  = notHappyAtAll 

happyReduce_72 = happySpecReduce_3  29 happyReduction_72
happyReduction_72 (HappyAbsSyn16  happy_var_3)
	_
	_
	 =  HappyAbsSyn29
		 (ViewStmtUMV   happy_var_3
	)
happyReduction_72 _ _ _  = notHappyAtAll 

happyReduce_73 = happySpecReduce_3  29 happyReduction_73
happyReduction_73 (HappyAbsSyn16  happy_var_3)
	_
	_
	 =  HappyAbsSyn29
		 (ViewStmtUMS   happy_var_3
	)
happyReduction_73 _ _ _  = notHappyAtAll 

happyReduce_74 = happySpecReduce_1  29 happyReduction_74
happyReduction_74 (HappyAbsSyn16  happy_var_1)
	 =  HappyAbsSyn29
		 (ViewStmtMatch happy_var_1
	)
happyReduction_74 _  = notHappyAtAll 

happyReduce_75 = happySpecReduce_3  30 happyReduction_75
happyReduction_75 (HappyAbsSyn40  happy_var_3)
	_
	_
	 =  HappyAbsSyn30
		 (MatchBY happy_var_3
	)
happyReduction_75 _ _ _  = notHappyAtAll 

happyReduce_76 = happyReduce 7 30 happyReduction_76
happyReduction_76 ((HappyAbsSyn40  happy_var_7) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_4) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn30
		 (MatchSV happy_var_4 happy_var_7
	) `HappyStk` happyRest

happyReduce_77 = happySpecReduce_1  31 happyReduction_77
happyReduction_77 (HappyAbsSyn31  happy_var_1)
	 =  HappyAbsSyn31
		 (happy_var_1
	)
happyReduction_77 _  = notHappyAtAll 

happyReduce_78 = happySpecReduce_2  31 happyReduction_78
happyReduction_78 (HappyAbsSyn31  happy_var_2)
	(HappyAbsSyn31  happy_var_1)
	 =  HappyAbsSyn31
		 (XQProd happy_var_1 happy_var_2
	)
happyReduction_78 _ _  = notHappyAtAll 

happyReduce_79 = happySpecReduce_1  32 happyReduction_79
happyReduction_79 (HappyAbsSyn31  happy_var_1)
	 =  HappyAbsSyn31
		 (happy_var_1
	)
happyReduction_79 _  = notHappyAtAll 

happyReduce_80 = happyReduce 6 32 happyReduction_80
happyReduction_80 ((HappyAbsSyn31  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn31  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn43  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn31
		 (XQLet happy_var_2 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_81 = happyReduce 6 32 happyReduction_81
happyReduction_81 ((HappyAbsSyn31  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn31  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn31  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn31
		 (XQIf happy_var_2 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_82 = happyReduce 6 32 happyReduction_82
happyReduction_82 ((HappyAbsSyn31  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn31  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QVar happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn31
		 (XQFor happy_var_2 happy_var_4 happy_var_6
	) `HappyStk` happyRest

happyReduce_83 = happySpecReduce_1  32 happyReduction_83
happyReduction_83 (HappyAbsSyn31  happy_var_1)
	 =  HappyAbsSyn31
		 (happy_var_1
	)
happyReduction_83 _  = notHappyAtAll 

happyReduce_84 = happyReduce 8 33 happyReduction_84
happyReduction_84 (_ `HappyStk`
	(HappyTerminal (QName happy_var_7)) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn31  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn31  happy_var_3) `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn31
		 (if happy_var_2 == happy_var_7 
                    then XQElem happy_var_2  (XQProd happy_var_3 happy_var_5)
                                                              else parseError [(QError("Element: unmatched tag name"))]
	) `HappyStk` happyRest

happyReduce_85 = happyReduce 7 33 happyReduction_85
happyReduction_85 (_ `HappyStk`
	(HappyTerminal (QName happy_var_6)) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn31  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn31
		 (if happy_var_2 == happy_var_6 
                    then XQElem happy_var_2 happy_var_4
                                                              else parseError [(QError("Element: unmatched tag name"))]
	) `HappyStk` happyRest

happyReduce_86 = happyReduce 7 33 happyReduction_86
happyReduction_86 (_ `HappyStk`
	(HappyTerminal (QName happy_var_6)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn31  happy_var_3) `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn31
		 (if happy_var_2 == happy_var_6 
                    then XQElem happy_var_2  happy_var_3
                                                              else parseError [(QError("Element: unmatched tag name"))]
	) `HappyStk` happyRest

happyReduce_87 = happyReduce 6 33 happyReduction_87
happyReduction_87 (_ `HappyStk`
	(HappyTerminal (QName happy_var_5)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn31
		 (if happy_var_2 == happy_var_5
                    then XQElem happy_var_2 XQEmpty        
                                                              else parseError [(QError("Element: unmatched tag name"))]
	) `HappyStk` happyRest

happyReduce_88 = happySpecReduce_3  33 happyReduction_88
happyReduction_88 _
	(HappyTerminal (QName happy_var_2))
	_
	 =  HappyAbsSyn31
		 (XQElem happy_var_2 XQEmpty
	)
happyReduction_88 _ _ _  = notHappyAtAll 

happyReduce_89 = happyReduce 4 33 happyReduction_89
happyReduction_89 (_ `HappyStk`
	(HappyAbsSyn31  happy_var_3) `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn31
		 (XQElem happy_var_2 happy_var_3
	) `HappyStk` happyRest

happyReduce_90 = happySpecReduce_3  33 happyReduction_90
happyReduction_90 _
	(HappyAbsSyn40  happy_var_2)
	_
	 =  HappyAbsSyn31
		 (XQPath   happy_var_2
	)
happyReduction_90 _ _ _  = notHappyAtAll 

happyReduce_91 = happySpecReduce_1  33 happyReduction_91
happyReduction_91 (HappyAbsSyn40  happy_var_1)
	 =  HappyAbsSyn31
		 (XQPath happy_var_1
	)
happyReduction_91 _  = notHappyAtAll 

happyReduce_92 = happySpecReduce_1  34 happyReduction_92
happyReduction_92 (HappyAbsSyn31  happy_var_1)
	 =  HappyAbsSyn31
		 (happy_var_1
	)
happyReduction_92 _  = notHappyAtAll 

happyReduce_93 = happySpecReduce_3  34 happyReduction_93
happyReduction_93 (HappyAbsSyn31  happy_var_3)
	(HappyAbsSyn35  happy_var_2)
	(HappyAbsSyn31  happy_var_1)
	 =  HappyAbsSyn31
		 (XQBinOp happy_var_2 happy_var_1 happy_var_3
	)
happyReduction_93 _ _ _  = notHappyAtAll 

happyReduce_94 = happySpecReduce_1  35 happyReduction_94
happyReduction_94 _
	 =  HappyAbsSyn35
		 (XPath.Or
	)

happyReduce_95 = happySpecReduce_1  35 happyReduction_95
happyReduction_95 _
	 =  HappyAbsSyn35
		 (XPath.And
	)

happyReduce_96 = happySpecReduce_3  36 happyReduction_96
happyReduction_96 (HappyAbsSyn31  happy_var_3)
	(HappyAbsSyn35  happy_var_2)
	(HappyAbsSyn31  happy_var_1)
	 =  HappyAbsSyn31
		 (XQBinOp happy_var_2 happy_var_1 happy_var_3
	)
happyReduction_96 _ _ _  = notHappyAtAll 

happyReduce_97 = happySpecReduce_1  37 happyReduction_97
happyReduction_97 _
	 =  HappyAbsSyn35
		 (XPath.Eq
	)

happyReduce_98 = happySpecReduce_1  37 happyReduction_98
happyReduction_98 _
	 =  HappyAbsSyn35
		 (XPath.NEq
	)

happyReduce_99 = happySpecReduce_1  37 happyReduction_99
happyReduction_99 _
	 =  HappyAbsSyn35
		 (XPath.Less
	)

happyReduce_100 = happySpecReduce_1  37 happyReduction_100
happyReduction_100 _
	 =  HappyAbsSyn35
		 (XPath.Greater
	)

happyReduce_101 = happySpecReduce_2  37 happyReduction_101
happyReduction_101 _
	_
	 =  HappyAbsSyn35
		 (XPath.LessEq
	)

happyReduce_102 = happySpecReduce_2  37 happyReduction_102
happyReduction_102 _
	_
	 =  HappyAbsSyn35
		 (XPath.GreaterEq
	)

happyReduce_103 = happySpecReduce_1  37 happyReduction_103
happyReduction_103 _
	 =  HappyAbsSyn35
		 (XPath.Plus
	)

happyReduce_104 = happySpecReduce_1  37 happyReduction_104
happyReduction_104 _
	 =  HappyAbsSyn35
		 (XPath.Minus
	)

happyReduce_105 = happySpecReduce_1  37 happyReduction_105
happyReduction_105 _
	 =  HappyAbsSyn35
		 (XPath.Mult
	)

happyReduce_106 = happySpecReduce_1  37 happyReduction_106
happyReduction_106 (HappyTerminal (QName happy_var_1))
	 =  HappyAbsSyn35
		 (if happy_var_1 == "and" then XPath.And
                                                           else if happy_var_1 == "or" then XPath.Or
							     else if happy_var_1 == "mod"  then XPath.Mod
							       else if happy_var_1 == "div" then XPath.Div
								 else parseError [(QError("Binary Operator wrong"))]
	)
happyReduction_106 _  = notHappyAtAll 

happyReduce_107 = happySpecReduce_2  38 happyReduction_107
happyReduction_107 (HappyAbsSyn31  happy_var_2)
	(HappyAbsSyn31  happy_var_1)
	 =  HappyAbsSyn31
		 (XQProd happy_var_1 happy_var_2
	)
happyReduction_107 _ _  = notHappyAtAll 

happyReduce_108 = happySpecReduce_1  38 happyReduction_108
happyReduction_108 (HappyAbsSyn31  happy_var_1)
	 =  HappyAbsSyn31
		 (happy_var_1
	)
happyReduction_108 _  = notHappyAtAll 

happyReduce_109 = happySpecReduce_3  39 happyReduction_109
happyReduction_109 (HappyAbsSyn31  happy_var_3)
	_
	(HappyTerminal (QAttrName happy_var_1))
	 =  HappyAbsSyn31
		 (XQAttr happy_var_1 happy_var_3
	)
happyReduction_109 _ _ _  = notHappyAtAll 

happyReduce_110 = happySpecReduce_1  40 happyReduction_110
happyReduction_110 _
	 =  HappyAbsSyn40
		 (CPathSelf
	)

happyReduce_111 = happySpecReduce_2  40 happyReduction_111
happyReduction_111 (HappyAbsSyn40  happy_var_2)
	_
	 =  HappyAbsSyn40
		 (CPathSlash CPathDoS happy_var_2
	)
happyReduction_111 _ _  = notHappyAtAll 

happyReduce_112 = happySpecReduce_3  40 happyReduction_112
happyReduction_112 (HappyAbsSyn40  happy_var_3)
	_
	(HappyAbsSyn40  happy_var_1)
	 =  HappyAbsSyn40
		 (CPathSlash happy_var_1  (CPathSlash CPathDoS happy_var_3)
	)
happyReduction_112 _ _ _  = notHappyAtAll 

happyReduce_113 = happySpecReduce_3  40 happyReduction_113
happyReduction_113 (HappyAbsSyn40  happy_var_3)
	_
	(HappyAbsSyn40  happy_var_1)
	 =  HappyAbsSyn40
		 (CPathSlash happy_var_1 happy_var_3
	)
happyReduction_113 _ _ _  = notHappyAtAll 

happyReduce_114 = happyReduce 4 40 happyReduction_114
happyReduction_114 (_ `HappyStk`
	(HappyAbsSyn31  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn40
		 (CPathSlash (CPathSlash CPathChild (CPathNodeTest (XPath.NameTest (HXTQN.mkName happy_var_1)))) (CPathFilter happy_var_3)
	) `HappyStk` happyRest

happyReduce_115 = happyReduce 4 40 happyReduction_115
happyReduction_115 (_ `HappyStk`
	(HappyAbsSyn31  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn40
		 (CPathSlash (CPathSlash CPathChild (CPathNodeTest (XPath.NameTest (HXTQN.mkName "if")))) (CPathFilter happy_var_3)
	) `HappyStk` happyRest

happyReduce_116 = happyReduce 4 40 happyReduction_116
happyReduction_116 (_ `HappyStk`
	(HappyAbsSyn31  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_1) `HappyStk`
	happyRest)
	 = HappyAbsSyn40
		 (CPathSlash happy_var_1 (CPathFilter happy_var_3)
	) `HappyStk` happyRest

happyReduce_117 = happySpecReduce_1  40 happyReduction_117
happyReduction_117 (HappyTerminal (QVar happy_var_1))
	 =  HappyAbsSyn40
		 (CPathVar happy_var_1
	)
happyReduction_117 _  = notHappyAtAll 

happyReduce_118 = happySpecReduce_1  40 happyReduction_118
happyReduction_118 (HappyTerminal (QString happy_var_1))
	 =  HappyAbsSyn40
		 (CPathString happy_var_1
	)
happyReduction_118 _  = notHappyAtAll 

happyReduce_119 = happySpecReduce_1  40 happyReduction_119
happyReduction_119 (HappyTerminal (QXmlText happy_var_1))
	 =  HappyAbsSyn40
		 (CPathString happy_var_1
	)
happyReduction_119 _  = notHappyAtAll 

happyReduce_120 = happySpecReduce_1  40 happyReduction_120
happyReduction_120 _
	 =  HappyAbsSyn40
		 (CPathBool True
	)

happyReduce_121 = happySpecReduce_1  40 happyReduction_121
happyReduction_121 _
	 =  HappyAbsSyn40
		 (CPathBool False
	)

happyReduce_122 = happySpecReduce_3  40 happyReduction_122
happyReduction_122 _
	_
	(HappyTerminal (QName happy_var_1))
	 =  HappyAbsSyn40
		 (if happy_var_1 == "node" then (CPathSlash (CPathSlash CPathSelf CPathChild) (CPathNodeTest (XPath.TypeTest XPath.XPNode))) 
                                               else if happy_var_1 == "comment" then (CPathSlash (CPathSlash CPathSelf CPathChild) (CPathNodeTest (XPath.TypeTest XPath.XPCommentNode))) 
						    else if happy_var_1 == "text" then (CPathSlash (CPathSlash CPathSelf CPathChild) (CPathNodeTest (XPath.TypeTest XPath.XPTextNode))) 
						         else if happy_var_1 == "processing-instruction" then (CPathSlash (CPathSlash CPathSelf CPathChild) (CPathNodeTest (XPath.TypeTest XPath.XPPINode))) 
							   else  if happy_var_1 == "string" then (CPathSlash (CPathSlash CPathSelf CPathChild) (CPathNodeTest (XPath.TypeTest XPString))) 
							     else parseError [(QError("XPath NodeTest wrong name()."))]
	)
happyReduction_122 _ _ _  = notHappyAtAll 

happyReduce_123 = happySpecReduce_3  40 happyReduction_123
happyReduction_123 _
	_
	_
	 =  HappyAbsSyn40
		 ((CPathSlash (CPathSlash CPathSelf CPathChild) (CPathNodeTest (XPath.TypeTest XPath.XPString)))
	)

happyReduce_124 = happyReduce 6 40 happyReduction_124
happyReduction_124 (_ `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_4)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_1) `HappyStk`
	happyRest)
	 = HappyAbsSyn40
		 (if happy_var_4 == "node" then CPathSlash happy_var_1 (CPathNodeTest (XPath.TypeTest XPath.XPNode))
                                                 else if happy_var_4 == "comment" then CPathSlash happy_var_1 (CPathNodeTest (XPath.TypeTest XPath.XPCommentNode))
						   else if happy_var_4 == "text" then CPathSlash happy_var_1 (CPathNodeTest (XPath.TypeTest XPath.XPTextNode)) 
						     else if happy_var_4 == "processing-instruction" then CPathSlash happy_var_1 (CPathNodeTest (XPath.TypeTest XPath.XPPINode))
                                                       else if happy_var_4 == "string" then CPathSlash happy_var_1 (CPathNodeTest (XPath.TypeTest XPString)) 
							     else parseError [(QError("XPath NodeTest wrong name()."))]
	) `HappyStk` happyRest

happyReduce_125 = happyReduce 7 40 happyReduction_125
happyReduction_125 (_ `HappyStk`
	(HappyTerminal (QString happy_var_6)) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_4)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_1) `HappyStk`
	happyRest)
	 = HappyAbsSyn40
		 (if happy_var_4 == "processing-instruction" then CPathSlash happy_var_1 (CPathNodeTest (XPath.PI happy_var_6))
                                                   else parseError [(QError("XPath NodeTest wrong processing-instruction(str)."))]
	) `HappyStk` happyRest

happyReduce_126 = happyReduce 4 40 happyReduction_126
happyReduction_126 ((HappyTerminal (QName happy_var_4)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn40  happy_var_1) `HappyStk`
	happyRest)
	 = HappyAbsSyn40
		 (CPathSlash happy_var_1 ((CPathNodeTest (XPath.NameTest (HXTQN.mkName happy_var_4))))
	) `HappyStk` happyRest

happyReduce_127 = happySpecReduce_2  40 happyReduction_127
happyReduction_127 (HappyTerminal (QName happy_var_2))
	_
	 =  HappyAbsSyn40
		 (CPathSlash (CPathSlash CPathSelf CPathAttribute) (CPathNodeTest (XPath.NameTest (HXTQN.mkName happy_var_2)))
	)
happyReduction_127 _ _  = notHappyAtAll 

happyReduce_128 = happySpecReduce_3  40 happyReduction_128
happyReduction_128 _
	_
	(HappyAbsSyn40  happy_var_1)
	 =  HappyAbsSyn40
		 (CPathSlash happy_var_1 (CPathSlash CPathChild (CPathNodeTest (XPath.TypeTest XPath.XPNode)))
	)
happyReduction_128 _ _ _  = notHappyAtAll 

happyReduce_129 = happySpecReduce_3  40 happyReduction_129
happyReduction_129 _
	_
	_
	 =  HappyAbsSyn40
		 (CPathSlash (CPathSlash CPathChild (CPathNodeTest (XPath.NameTest (HXTQN.mkName "if")))) (CPathSlash CPathChild (CPathNodeTest (XPath.TypeTest XPath.XPNode)))
	)

happyReduce_130 = happyReduce 4 40 happyReduction_130
happyReduction_130 (_ `HappyStk`
	(HappyAbsSyn10  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn40
		 (CPathFct happy_var_1 happy_var_3
	) `HappyStk` happyRest

happyReduce_131 = happySpecReduce_1  40 happyReduction_131
happyReduction_131 (HappyTerminal (QName happy_var_1))
	 =  HappyAbsSyn40
		 (CPathSlash (CPathSlash CPathSelf CPathChild) (CPathNodeTest (XPath.NameTest (HXTQN.mkName happy_var_1)))
	)
happyReduction_131 _  = notHappyAtAll 

happyReduce_132 = happySpecReduce_3  40 happyReduction_132
happyReduction_132 (HappyAbsSyn40  happy_var_3)
	_
	_
	 =  HappyAbsSyn40
		 (CPathSlash (CPathSlash CPathChild ((CPathNodeTest (XPath.NameTest (HXTQN.mkName "if"))))) happy_var_3
	)
happyReduction_132 _ _ _  = notHappyAtAll 

happyReduce_133 = happySpecReduce_3  40 happyReduction_133
happyReduction_133 _
	_
	(HappyAbsSyn40  happy_var_1)
	 =  HappyAbsSyn40
		 (CPathSlash  happy_var_1 (CPathSlash CPathChild (CPathNodeTest (XPath.NameTest (HXTQN.mkName "if"))))
	)
happyReduction_133 _ _ _  = notHappyAtAll 

happyReduce_134 = happySpecReduce_1  41 happyReduction_134
happyReduction_134 (HappyTerminal (QName happy_var_1))
	 =  HappyAbsSyn40
		 (if happy_var_1 == "self" then CPathSelf
                                                  else if happy_var_1 == "child" then CPathSlash CPathSelf CPathChild
						    else if happy_var_1 == "attribute" then (CPathSlash CPathSelf CPathAttribute)
                                                      else if happy_var_1 == "descendant-or-self" then CPathDoS
							else parseError [(QError("unsupported xpath axis."))]
	)
happyReduction_134 _  = notHappyAtAll 

happyReduce_135 = happySpecReduce_1  42 happyReduction_135
happyReduction_135 (HappyAbsSyn43  happy_var_1)
	 =  HappyAbsSyn42
		 ([happy_var_1]
	)
happyReduction_135 _  = notHappyAtAll 

happyReduce_136 = happySpecReduce_3  42 happyReduction_136
happyReduction_136 (HappyAbsSyn42  happy_var_3)
	_
	(HappyAbsSyn43  happy_var_1)
	 =  HappyAbsSyn42
		 ([happy_var_1] ++ happy_var_3
	)
happyReduction_136 _ _ _  = notHappyAtAll 

happyReduce_137 = happySpecReduce_3  42 happyReduction_137
happyReduction_137 (HappyAbsSyn42  happy_var_3)
	_
	(HappyAbsSyn45  happy_var_1)
	 =  HappyAbsSyn42
		 ([VarPat (VarTP happy_var_1)] ++ happy_var_3
	)
happyReduction_137 _ _ _  = notHappyAtAll 

happyReduce_138 = happyReduce 4 43 happyReduction_138
happyReduction_138 (_ `HappyStk`
	(HappyAbsSyn42  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn43
		 (ElementPat happy_var_1  happy_var_3
	) `HappyStk` happyRest

happyReduce_139 = happyReduce 5 43 happyReduction_139
happyReduction_139 (_ `HappyStk`
	(HappyAbsSyn44  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn43
		 (AttributePat happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_140 = happySpecReduce_1  43 happyReduction_140
happyReduction_140 (HappyAbsSyn44  happy_var_1)
	 =  HappyAbsSyn43
		 (VarPat     happy_var_1
	)
happyReduction_140 _  = notHappyAtAll 

happyReduce_141 = happySpecReduce_3  43 happyReduction_141
happyReduction_141 _
	(HappyAbsSyn42  happy_var_2)
	_
	 =  HappyAbsSyn43
		 (SequencePat happy_var_2
	)
happyReduction_141 _ _ _  = notHappyAtAll 

happyReduce_142 = happySpecReduce_3  44 happyReduction_142
happyReduction_142 (HappyAbsSyn45  happy_var_3)
	_
	(HappyTerminal (QVar happy_var_1))
	 =  HappyAbsSyn44
		 (VarT happy_var_1 happy_var_3
	)
happyReduction_142 _ _ _  = notHappyAtAll 

happyReduce_143 = happySpecReduce_1  44 happyReduction_143
happyReduction_143 (HappyTerminal (QVar happy_var_1))
	 =  HappyAbsSyn44
		 (VarV happy_var_1
	)
happyReduction_143 _  = notHappyAtAll 

happyReduce_144 = happySpecReduce_1  44 happyReduction_144
happyReduction_144 (HappyAbsSyn45  happy_var_1)
	 =  HappyAbsSyn44
		 (VarTP happy_var_1
	)
happyReduction_144 _  = notHappyAtAll 

happyReduce_145 = happySpecReduce_3  45 happyReduction_145
happyReduction_145 (HappyTerminal (QName happy_var_3))
	_
	(HappyTerminal (QName happy_var_1))
	 =  HappyAbsSyn45
		 (NameT (happy_var_1 ++ ":" ++ happy_var_3)
	)
happyReduction_145 _ _ _  = notHappyAtAll 

happyReduce_146 = happySpecReduce_3  45 happyReduction_146
happyReduction_146 _
	_
	(HappyTerminal (QName happy_var_1))
	 =  HappyAbsSyn45
		 (NameT (happy_var_1 ++ ":if"  )
	)
happyReduction_146 _ _ _  = notHappyAtAll 

happyReduce_147 = happySpecReduce_1  45 happyReduction_147
happyReduction_147 (HappyTerminal (QTName happy_var_1))
	 =  HappyAbsSyn45
		 (if happy_var_1 == "String" then StringT else NameT happy_var_1
	)
happyReduction_147 _  = notHappyAtAll 

happyReduce_148 = happySpecReduce_2  45 happyReduction_148
happyReduction_148 _
	(HappyAbsSyn45  happy_var_1)
	 =  HappyAbsSyn45
		 (StarT happy_var_1
	)
happyReduction_148 _ _  = notHappyAtAll 

happyReduce_149 = happySpecReduce_3  45 happyReduction_149
happyReduction_149 (HappyAbsSyn45  happy_var_3)
	_
	(HappyAbsSyn45  happy_var_1)
	 =  HappyAbsSyn45
		 (ChoiceT happy_var_1 happy_var_3
	)
happyReduction_149 _ _ _  = notHappyAtAll 

happyReduce_150 = happySpecReduce_3  45 happyReduction_150
happyReduction_150 _
	(HappyAbsSyn45  happy_var_2)
	_
	 =  HappyAbsSyn45
		 (happy_var_2
	)
happyReduction_150 _ _ _  = notHappyAtAll 

happyReduce_151 = happyReduce 5 45 happyReduction_151
happyReduction_151 (_ `HappyStk`
	(HappyAbsSyn45  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn45  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn45
		 (SequenceT happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_152 = happySpecReduce_2  45 happyReduction_152
happyReduction_152 _
	_
	 =  HappyAbsSyn45
		 (EmptyT
	)

happyReduce_153 = happyReduce 4 45 happyReduction_153
happyReduction_153 (_ `HappyStk`
	(HappyAbsSyn45  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn45
		 (ElementT happy_var_1 happy_var_3
	) `HappyStk` happyRest

happyReduce_154 = happyReduce 4 45 happyReduction_154
happyReduction_154 (_ `HappyStk`
	(HappyAbsSyn45  happy_var_3) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn45
		 (ElementT "if" happy_var_3
	) `HappyStk` happyRest

happyReduce_155 = happyReduce 5 45 happyReduction_155
happyReduction_155 (_ `HappyStk`
	(HappyAbsSyn45  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (QName happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn45
		 (AttributeT happy_var_2 happy_var_4
	) `HappyStk` happyRest

happyReduce_156 = happySpecReduce_2  45 happyReduction_156
happyReduction_156 _
	(HappyAbsSyn45  happy_var_1)
	 =  HappyAbsSyn45
		 (ChoiceT happy_var_1 EmptyT
	)
happyReduction_156 _ _  = notHappyAtAll 

happyReduce_157 = happySpecReduce_2  45 happyReduction_157
happyReduction_157 _
	(HappyAbsSyn45  happy_var_1)
	 =  HappyAbsSyn45
		 (SequenceT happy_var_1 (StarT happy_var_1)
	)
happyReduction_157 _ _  = notHappyAtAll 

happyNewToken action sts stk [] =
	action 122 122 notHappyAtAll (HappyState action) sts stk []

happyNewToken action sts stk (tk:tks) =
	let cont i = action i i tk (HappyState action) sts stk tks in
	case tk of {
	IMPORT -> cont 46;
	TYPE -> cont 47;
	START -> cont 48;
	DOC -> cont 49;
	PROCEDURE -> cont 50;
	UPDATE -> cont 51;
	BY -> cont 52;
	FORVIEW -> cont 53;
	FOR -> cont 54;
	VIEW -> cont 55;
	MATCHING -> cont 56;
	SOURCE -> cont 57;
	INSERT -> cont 58;
	BEFORE -> cont 59;
	AFTER -> cont 60;
	VALUE -> cont 61;
	AS -> cont 62;
	LAST -> cont 63;
	FIRST -> cont 64;
	INTO -> cont 65;
	DELETE -> cont 66;
	FROM -> cont 67;
	REPLACE -> cont 68;
	WITH -> cont 69;
	CREATE -> cont 70;
	KEEP -> cont 71;
	EITHER -> cont 72;
	MATCH -> cont 73;
	UNMATCHV -> cont 74;
	UNMATCHS -> cont 75;
	ARROW -> cont 76;
	CASE -> cont 77;
	OF -> cont 78;
	WHERE -> cont 79;
	IF -> cont 80;
	THEN -> cont 81;
	ELSE -> cont 82;
	LET -> cont 83;
	ASSIGN -> cont 84;
	IN -> cont 85;
	STAG -> cont 86;
	ETAG -> cont 87;
	ATSIGN -> cont 88;
	TLT -> cont 89;
	TGT -> cont 90;
	LSB -> cont 91;
	RSB -> cont 92;
	LP -> cont 93;
	RP -> cont 94;
	LB -> cont 95;
	RB -> cont 96;
	QEQ -> cont 97;
	QNEQ -> cont 98;
	STAR -> cont 99;
	OPT -> cont 100;
	PLUS -> cont 101;
	COMMA -> cont 102;
	COLON -> cont 103;
	SEMI -> cont 104;
	QDSLASH -> cont 105;
	QSLASH -> cont 106;
	QDOT -> cont 107;
	QMinus -> cont 108;
	QName happy_dollar_dollar -> cont 109;
	QAttrName happy_dollar_dollar -> cont 110;
	QString happy_dollar_dollar -> cont 111;
	QXmlText happy_dollar_dollar -> cont 112;
	QTName happy_dollar_dollar -> cont 113;
	QVar happy_dollar_dollar -> cont 114;
	QReturn -> cont 115;
	QTrue -> cont 116;
	QFalse -> cont 117;
	TST -> cont 118;
	TET -> cont 119;
	OR -> cont 120;
	AND -> cont 121;
	_ -> happyError' (tk:tks)
	}

happyError_ 122 tk tks = happyError' tks
happyError_ _ tk tks = happyError' (tk:tks)

newtype HappyIdentity a = HappyIdentity a
happyIdentity = HappyIdentity
happyRunIdentity (HappyIdentity a) = a

instance Monad HappyIdentity where
    return = HappyIdentity
    (HappyIdentity p) >>= q = q p

happyThen :: () => HappyIdentity a -> (a -> HappyIdentity b) -> HappyIdentity b
happyThen = (>>=)
happyReturn :: () => a -> HappyIdentity a
happyReturn = (return)
happyThen1 m k tks = (>>=) m (\a -> k a tks)
happyReturn1 :: () => a -> b -> HappyIdentity a
happyReturn1 = \a tks -> (return) a
happyError' :: () => [(Token)] -> HappyIdentity a
happyError' = HappyIdentity . parseError

nParser tks = happyRunIdentity happySomeParser where
  happySomeParser = happyThen (happyParse action_0 tks) (\x -> case x of {HappyAbsSyn4 z -> happyReturn z; _other -> notHappyAtAll })

happySeq = happyDontSeq


parseError tk = error(
 case tk of
  ((QError s) : _) -> "Parse error: " ++ s
  (TokenEOF: _)    -> "Parse error:  Unexpected end of file"
  _                -> "Parse error: " ++ (foldr (\a r -> (show a)++ " "  ++ r ) "" (take 10 tk))

		      )
{-# LINE 1 "templates/GenericTemplate.hs" #-}
{-# LINE 1 "templates/GenericTemplate.hs" #-}
{-# LINE 1 "<built-in>" #-}
{-# LINE 1 "<command-line>" #-}
{-# LINE 1 "templates/GenericTemplate.hs" #-}
-- Id: GenericTemplate.hs,v 1.26 2005/01/14 14:47:22 simonmar Exp 

{-# LINE 30 "templates/GenericTemplate.hs" #-}








{-# LINE 51 "templates/GenericTemplate.hs" #-}

{-# LINE 61 "templates/GenericTemplate.hs" #-}

{-# LINE 70 "templates/GenericTemplate.hs" #-}

infixr 9 `HappyStk`
data HappyStk a = HappyStk a (HappyStk a)

-----------------------------------------------------------------------------
-- starting the parse

happyParse start_state = happyNewToken start_state notHappyAtAll notHappyAtAll

-----------------------------------------------------------------------------
-- Accepting the parse

-- If the current token is (1), it means we've just accepted a partial
-- parse (a %partial parser).  We must ignore the saved token on the top of
-- the stack in this case.
happyAccept (1) tk st sts (_ `HappyStk` ans `HappyStk` _) =
	happyReturn1 ans
happyAccept j tk st sts (HappyStk ans _) = 
	 (happyReturn1 ans)

-----------------------------------------------------------------------------
-- Arrays only: do the next action

{-# LINE 148 "templates/GenericTemplate.hs" #-}

-----------------------------------------------------------------------------
-- HappyState data type (not arrays)



newtype HappyState b c = HappyState
        (Int ->                    -- token number
         Int ->                    -- token number (yes, again)
         b ->                           -- token semantic value
         HappyState b c ->              -- current state
         [HappyState b c] ->            -- state stack
         c)



-----------------------------------------------------------------------------
-- Shifting a token

happyShift new_state (1) tk st sts stk@(x `HappyStk` _) =
     let (i) = (case x of { HappyErrorToken (i) -> i }) in
--     trace "shifting the error token" $
     new_state i i tk (HappyState (new_state)) ((st):(sts)) (stk)

happyShift new_state i tk st sts stk =
     happyNewToken new_state ((st):(sts)) ((HappyTerminal (tk))`HappyStk`stk)

-- happyReduce is specialised for the common cases.

happySpecReduce_0 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_0 nt fn j tk st@((HappyState (action))) sts stk
     = action nt j tk st ((st):(sts)) (fn `HappyStk` stk)

happySpecReduce_1 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_1 nt fn j tk _ sts@(((st@(HappyState (action))):(_))) (v1`HappyStk`stk')
     = let r = fn v1 in
       happySeq r (action nt j tk st sts (r `HappyStk` stk'))

happySpecReduce_2 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_2 nt fn j tk _ ((_):(sts@(((st@(HappyState (action))):(_))))) (v1`HappyStk`v2`HappyStk`stk')
     = let r = fn v1 v2 in
       happySeq r (action nt j tk st sts (r `HappyStk` stk'))

happySpecReduce_3 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_3 nt fn j tk _ ((_):(((_):(sts@(((st@(HappyState (action))):(_))))))) (v1`HappyStk`v2`HappyStk`v3`HappyStk`stk')
     = let r = fn v1 v2 v3 in
       happySeq r (action nt j tk st sts (r `HappyStk` stk'))

happyReduce k i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happyReduce k nt fn j tk st sts stk
     = case happyDrop (k - ((1) :: Int)) sts of
	 sts1@(((st1@(HappyState (action))):(_))) ->
        	let r = fn stk in  -- it doesn't hurt to always seq here...
       		happyDoSeq r (action nt j tk st1 sts1 r)

happyMonadReduce k nt fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happyMonadReduce k nt fn j tk st sts stk =
        happyThen1 (fn stk tk) (\r -> action nt j tk st1 sts1 (r `HappyStk` drop_stk))
       where (sts1@(((st1@(HappyState (action))):(_)))) = happyDrop k ((st):(sts))
             drop_stk = happyDropStk k stk

happyMonad2Reduce k nt fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happyMonad2Reduce k nt fn j tk st sts stk =
       happyThen1 (fn stk tk) (\r -> happyNewToken new_state sts1 (r `HappyStk` drop_stk))
       where (sts1@(((st1@(HappyState (action))):(_)))) = happyDrop k ((st):(sts))
             drop_stk = happyDropStk k stk





             new_state = action


happyDrop (0) l = l
happyDrop n ((_):(t)) = happyDrop (n - ((1) :: Int)) t

happyDropStk (0) l = l
happyDropStk n (x `HappyStk` xs) = happyDropStk (n - ((1)::Int)) xs

-----------------------------------------------------------------------------
-- Moving to a new state after a reduction

{-# LINE 246 "templates/GenericTemplate.hs" #-}
happyGoto action j tk st = action j j tk (HappyState action)


-----------------------------------------------------------------------------
-- Error recovery ((1) is the error token)

-- parse error if we are in recovery and we fail again
happyFail (1) tk old_st _ stk@(x `HappyStk` _) =
     let (i) = (case x of { HappyErrorToken (i) -> i }) in
--	trace "failing" $ 
        happyError_ i tk

{-  We don't need state discarding for our restricted implementation of
    "error".  In fact, it can cause some bogus parses, so I've disabled it
    for now --SDM

-- discard a state
happyFail  (1) tk old_st (((HappyState (action))):(sts)) 
						(saved_tok `HappyStk` _ `HappyStk` stk) =
--	trace ("discarding state, depth " ++ show (length stk))  $
	action (1) (1) tk (HappyState (action)) sts ((saved_tok`HappyStk`stk))
-}

-- Enter error recovery: generate an error token,
--                       save the old token and carry on.
happyFail  i tk (HappyState (action)) sts stk =
--      trace "entering error recovery" $
	action (1) (1) tk (HappyState (action)) sts ( (HappyErrorToken (i)) `HappyStk` stk)

-- Internal happy errors:

notHappyAtAll :: a
notHappyAtAll = error "Internal Happy error\n"

-----------------------------------------------------------------------------
-- Hack to get the typechecker to accept our action functions







-----------------------------------------------------------------------------
-- Seq-ing.  If the --strict flag is given, then Happy emits 
--	happySeq = happyDoSeq
-- otherwise it emits
-- 	happySeq = happyDontSeq

happyDoSeq, happyDontSeq :: a -> b -> b
happyDoSeq   a b = a `seq` b
happyDontSeq a b = b

-----------------------------------------------------------------------------
-- Don't inline any functions from the template.  GHC has a nasty habit
-- of deciding to inline happyGoto everywhere, which increases the size of
-- the generated parser quite a bit.

{-# LINE 312 "templates/GenericTemplate.hs" #-}
{-# NOINLINE happyShift #-}
{-# NOINLINE happySpecReduce_0 #-}
{-# NOINLINE happySpecReduce_1 #-}
{-# NOINLINE happySpecReduce_2 #-}
{-# NOINLINE happySpecReduce_3 #-}
{-# NOINLINE happyReduce #-}
{-# NOINLINE happyMonadReduce #-}
{-# NOINLINE happyGoto #-}
{-# NOINLINE happyFail #-}

-- end of Happy Template.
