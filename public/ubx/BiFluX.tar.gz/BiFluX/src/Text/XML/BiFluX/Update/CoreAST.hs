module Text.XML.BiFluX.Update.CoreAST where

import Text.XML.BiFluX.XQuery.UXQ
import Text.XML.BiFluX.Update.AST
import Data.Set (Set(..))
import Text.XML.BiFluX.DTD.Type
import Data.Generics.TH

data CProgram = CProgram CStart [CProcedure] deriving (Eq,Show)

data CStart = CStart Name [CPath] [XQExpr] [XQExpr] deriving (Eq,Show)

data CProcedure = CProcedure Name DynType DynType [(Var,DynType)] CStmt -- source type (with variables), view type (with variables), environment
	deriving (Eq,Show)

data CStmt = CStmtFail
           | CStmtSkip
		   | CStmtComp CStmt (Set Var) CStmt (Set Var) -- disjoint source paths (this should be a condition in the semantics) focus(S,s) inter focus(S,s') = empty
		   | CStmtBindV Var XQExpr CStmt
		   | CStmtIf XQExpr CStmt CStmt
		   | CStmtIfS XQExpr CStmt CStmt
		   | CStmtIfV XQExpr CStmt CStmt
		   | CStmtReplace			-- not in-place: replaces the actual source by the view expression
		   | CStmtPathS CPath CStmt
		   | CStmtExprV XQExpr CStmt
		   | CStmtIter CStmt
		   | CStmtAlign XQExpr (Maybe (CPath,CPath)) CStmt (Maybe CRule) CRecover -- not in-place: wheres (matchs,matchv) um uv us
		   | CStmtProc Name [CPath] [XQExpr] [XQExpr] -- source arguments, view arguments, environment arguments
		   | CStmtCase XQExpr [(Pat,CStmt)]
		   | CStmtCaseS CPath [(Pat,CStmt)]
		   | CStmtCaseV XQExpr [(Pat,CStmt)]
--		   | CStmtRule CRule -- not in-place: rewrite rules (as points, so the target type must be a subtype of the source type)
		deriving (Eq,Show)     

data CRecover = CRecoverIf XQExpr CRecover CRecover
			  | CRecoverCase XQExpr [(Pat,CRecover)]
			  | CRecoverKeepSource CRule -- left/right
			  | CRecoverDeleteSource
		deriving (Eq,Show)

-- original Flux semantics as rewrite rules (in-place updates)
data CRule = CRulePath CPath CRule	-- direction
           | CRuleLeft CRule		-- direction
           | CRuleRight CRule		-- direction
           | CRuleChildren CRule	-- direction
--           | CRuleIter CRule		-- direction
           | CRuleInsert XQExpr		-- statement
           | CRuleDelete			-- statement
           | CRuleComp CRule CRule	-- statement
           | CRuleSkip				-- statement
           | CRuleIf XQExpr CRule CRule	-- statement
           | CRuleCase XQExpr [(Pat,CRule)]
		deriving (Eq,Show)

-- collects the top-level source paths of a statement
focus :: CStmt -> [CPath]
focus CStmtFail = []
focus (CStmtComp stmt1 _ stmt2 _) = focus stmt1 ++ focus stmt2
focus (CStmtBindV v e stmt) = focus stmt
focus (CStmtIf e stmt1 stmt2) = focus stmt1 ++ focus stmt2
focus (CStmtIfS e stmt1 stmt2) = focus stmt1 ++ focus stmt2
focus (CStmtIfV e stmt1 stmt2) = focus stmt1 ++ focus stmt2
--focus (CStmtChildren stmt) = focus cstmt
focus (CStmtReplace) = [CPathSelf]
focus (CStmtPathS path stmt) = [path]
focus (CStmtExprV expr stmt) = focus stmt
focus (CStmtIter cstmt) = [CPathSelf]
focus (CStmtAlign e m stmt create rcv) = [CPathSelf]
focus (CStmtProc e sargs vargs eargs) = sargs
focus (CStmtCase e cs) = concatMap (focus . snd) cs
focus (CStmtCaseS e cs) = concatMap (focus . snd) cs
focus (CStmtCaseV e cs) = concatMap (focus . snd) cs
--focus (CStmtRule r) = [CPathSelf]

