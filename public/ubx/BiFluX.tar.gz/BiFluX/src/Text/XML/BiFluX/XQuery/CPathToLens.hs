module Text.XML.BiFluX.XQuery.CPathToLens where
	
import Text.XML.BiFluX.DTD.Normalize
import Text.XML.BiFluX.Lenses.Default
import Text.XML.BiFluX.DTD.Type
import Text.XML.BiFluX.Lenses.Pf
import Text.XML.BiFluX.XQuery.UXQ
import Text.XML.BiFluX.Lenses.View
import Text.XML.BiFluX.Lenses.ViewPf
import Control.Monad.Reader (Reader(..),ReaderT(..),MonadReader(..))
import qualified Control.Monad.Reader as Reader
import Control.Monad.State (State(..),StateT(..),MonadState(..))
import Text.XML.BiFluX.XPath.HXT.XPathDataTypes as XPath hiding (Name(..),Env(..))
import qualified Control.Monad.State as State
import Control.Monad
import Control.Monad.Trans
import Text.XML.HXT.DOM.QualifiedName
import Text.XML.BiFluX.XQuery.UXQToVal
import Text.XML.BiFluX.Generic.Rewrite
import Data.Map (Map(..))
import qualified Data.Map as Map
import Text.XML.BiFluX.Lenses.Lib
import {-# SOURCE #-} Text.XML.BiFluX.Update.CoreToLenses
import Text.XML.BiFluX.Update.Patterns
import Generics.Putlenses.Language
import Generics.Putlenses.Putlens
import Generics.Putlenses.Examples.Examples

import Debug.Trace

type EnvRuleEnvPfT m s = forall s . Eq s => RuleEnvPf (CPathM m) (Reader Env) (EnvM) s
	
-- variables (constant variables passed as arguments)
type CPathM m = StateT Prevs (ReaderT TypeEnv (StateT EnvT m))
	
cpath2lens :: MonadPlus m => CPath -> EnvRuleEnvPfT m s
cpath2lens CPathSelf = liftViewEnvPf nopPf
cpath2lens CPathChild = liftViewEnvPf ((untagPf >>>> gmapPfT keepElement))
    where keepElement a@(Data n t) = nopPf a									-- keep elements
          keepElement a@(Tag n _) = if isAtt n then cutPf a else nopPf a		-- delete attributes
          keepElement a = nopPf a												-- keep text, etc elements
cpath2lens CPathAttribute = liftViewEnvPf ((untagPf >>>> gmapPfT keepAttribute))
    where keepAttribute a@(Tag n t) = if isAtt n then nopPf a else cutPf a		-- keep attributes
          keepAttribute a = cutPf a												-- delete otherwise
cpath2lens CPathDoS = error "descendant lens unsupported"
cpath2lens (CPathNodeTest nt) = nodetest2lens nt
cpath2lens (CPathSlash p1 p2) = \a -> do
	ViewEnvPf f l <- cpath2lens p1 a
	ViewEnvPf g b <- gmapEnvPfT rule l -- we just apply the second query to each top-level element
	return $ ViewEnvPf (compMPutPf l f g) b
  where rule :: MonadPlus m => RuleEnvPfT (CPathM m) (Reader Env) (EnvM)
        rule s = do
			ViewEnvPf f a <- cpath2lens p2 s
			return $ ViewEnvPf f a
cpath2lens (CPathFilter expr) = filterexpr2lens expr
cpath2lens (CPathVar n) = \a -> do
	evars <- lift State.get
--	case Map.lookup n svars of
--		Just (ViewPf f b) -> return $ ViewEnvPf (return f) b
--		Nothing ->
	case Map.lookup n evars of
		Just (DynT t) -> constant2lens t (unDyn t . lookupEnv n)
		Nothing -> error $ "varexpr2lens: source variable " ++ mkVar n ++ " not in scope of " ++ show evars			
cpath2lens (CPathString s) = \a -> constant2lens String (const $ Str s)
cpath2lens (CPathBool b) = \a -> constant2lens Bool (const b)
cpath2lens (CPathSnapshot pat path) = \a -> do
	ViewPf f p <- matchsourceputWithDecls (envM) pat a
	vars <- listPatVariablesPf (envM) p
	updEnv <- addLensSrcVars a p vars f
	ViewEnvPf g b <- cpath2lens path a
--	let newenv env v = liftM (updEnv env) Reader.ask
	let lns = Reader.reader $ \env -> CompPut (Prod Env a) (RemfstPut (updEnv env)) (ParamfstGet (\v -> return Map.empty) $ Reader.runReader g)
	return $ ViewEnvPf lns b
cpath2lens (CPathFct n args) = function2lens n args

function2lens :: MonadPlus m => String -> [XQExpr] -> EnvRuleEnvPfT m s
function2lens = error "currently no function as lens"

filterexpr2lens :: MonadPlus m => XQExpr -> EnvRuleEnvPfT m s
filterexpr2lens expr a = do
	Rewrite f t <- runCQuery (uXQ2valWithRoot expr a)
	if isEmptyType t -- if the element never satisfies the condition, then the result of filter is empty
		then return $ ViewEnvPf (return IdPut) (Cut a)
		else do -- filters the elements of a source schema by making all of them optional
			let p env x = boolean t (Reader.runReader f env x)
			return $ ViewEnvPf (Reader.asks $ \env -> EitherSPut (p env) IdPut IdPut) (Either a (Cut a))

runCQuery :: MonadPlus m => QueryM m a -> CPathM m a
runCQuery m = do
	tenv <- Reader.ask
	(evars) <- lift State.get
	lift $ lift $ lift $ runXQ tenv Nothing evars m

constant2lens ::  (Eq a,Eq b,MonadPlus m,Monad lensm) => Type b -> (Env -> b) -> CPathM m (ViewEnvPf (Reader Env) lensm a)
constant2lens t f = return $ ViewEnvPf (Reader.asks $ \env -> CompPut One KeepDefPut $ IgnorePut $ f env) t

-- | Filter only nodes that satisfy a particular node test and deletes the remaining
-- assumes that we are already focused on elements
nodetest2lens :: MonadPlus m => NodeTest -> EnvRuleEnvPfT m s
nodetest2lens (NameTest n) = liftViewEnvPf keepName
    where keepName :: (MonadPlus m,Monad st) => RulePfT m st
          keepName a | localPart n == "*" || getXName a == localPart n = nopPf a
                     | otherwise = cutPf a
nodetest2lens (PI s) = error "processing units not supported"
nodetest2lens (TypeTest XPNode) = liftViewEnvPf nodePf
    where nodePf a@(Tag (isAtt -> True) _) = cutPf a
          nodePf a = nopPf a
nodetest2lens (TypeTest XPCommentNode) = error "comment nodes unsupported"
nodetest2lens (TypeTest XPPINode) = error "pi nodes unsupported"
nodetest2lens (TypeTest XPTextNode) = liftViewEnvPf keepText
    where keepText a = if isLiteral a then nopPf a else cutPf a
nodetest2lens (TypeTest XPString) = \a -> return $ ViewEnvPf (return $ ToStringPut a) String

-- resets the lens environment
--changeLensFocus :: MonadPlus m => Type s' -> CPathM m s' r -> CPathM m s r
--changeLensFocus s' = State.mapStateT $ Reader.mapReaderT (changeLensFocus' s')
--changeLensFocus' s' m = do
--	(evars,svars) <- State.get
--	lift $ State.evalStateT m (evars,Map.empty)

addLensSrcVar :: (Eq a,Eq e,MonadPlus m) => String -> Type e -> Type a -> Pf (EnvPutlensM e a) -> CPathM m (Env -> e -> Env)
addLensSrcVar n e a f = do
	evars <- lift State.get
	lift $ State.put (Map.insert n (DynT a) evars) --,Map.insert n (ViewPf f a) svars)
	lns <- evalUpdPutlnsM (envM) e a f
	return $ \env x -> Map.insert n (Dyn a $ get' lns x) env

addLensSrcVars :: (MonadPlus m,Eq vars,Eq e) => Type e -> Type vars -> [(EnvViewPf vars)] -> Pf (EnvPutlensM e vars) -> CPathM m (Env -> e -> Env)
addLensSrcVars e vars [] slns = return $ \env x -> env
addLensSrcVars e vars (ViewPf f (Tag (varName -> n) x):xs) slns = do
	fenv <- addLensSrcVar n e x (CompPut vars slns f) -- this is only used for patterns, that we do not support as rewrites because they are not paths
	fenvs <- addLensSrcVars e vars xs slns
	return $ \env x -> fenvs (fenv env x) x




