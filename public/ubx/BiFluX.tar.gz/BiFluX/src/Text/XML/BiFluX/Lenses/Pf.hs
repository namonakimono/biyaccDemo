module Text.XML.BiFluX.Lenses.Pf where

import Text.XML.BiFluX.Lenses.Default
import Text.XML.BiFluX.Lenses.View hiding (Ref)
import Text.XML.BiFluX.DTD.Type as T
import Generics.Putlenses.Putlens
import Generics.Putlenses.Language
import Text.XML.HaXml.DtdToHaskell.TypeDef hiding (List,List1,Any)
import GHC.InOut
import Control.Monad
import Control.Monad.Trans
import Text.PrettyPrint.HughesPJ
import Control.Monad.State (State(..),MonadState(..),StateT(..))
import qualified Control.Monad.State as State
import Data.Map (Map(..))
import qualified Data.Map as Map
import Text.XML.BiFluX.Lenses.Lib
import Generics.Putlenses.Examples.Examples
import Data.Maybe
import Control.Monad.Reader (Reader(..),MonadReader(..),ReaderT(..))
import qualified Control.Monad.Reader as Reader

import Debug.Trace

-- | Ignores the current state and initializes a new state monad with a new state
resetReaderStatePut :: Monad m => (Maybe s -> v -> r -> st -> m st') -> PutlensReaderM (StateT st' m) r s v -> PutlensReaderM (StateT st m) r s v
resetReaderStatePut f l = withMonadPut (reinitialize f) l
	where reinitialize :: Monad m => (Maybe s -> v -> r -> st -> m st') -> Maybe s -> v -> ReaderT r (StateT st' m) a -> ReaderT r (StateT st m) a
	      reinitialize f s v m = do
			r <- Reader.ask
			Reader.mapReaderT (\n -> State.get >>= \st -> lift (f s v (error "resetReaderStatePut") st) >>= lift . State.evalStateT n) m

unzipPutPf :: (Monad m,Eq a,Eq b) => Type a -> Type b -> Pf (PutlensM m ([a],[b]) [(a,b)])
unzipPutPf a b = CompPut x (InnPut `ProdPut` InnPut) $ CompPut y UndistsPut $ CompPut z CoassocrPut $ CompPut w (NewPut c `SumPut` CompPut v DistpPut (IdPut `ProdPut` unzipPutPf a b)) OutPut
	where c = Left $ Left ((),())
	      x = Prod (Either One (Prod a (List a))) (Either One (Prod b (List b)))
	      y = Either (Either (Prod One One) (Prod One (Prod b (List b)))) (Either (Prod (Prod a (List a)) One) (Prod (Prod a (List a)) (Prod  b (List b))))
	      z = Either (Either (Either (Prod One One) (Prod One (Prod b (List b)))) (Prod (Prod a (List a)) One)) (Prod (Prod a (List a)) (Prod  b (List b)))
	      w = Either One (Prod (Prod a b) (List (Prod a b)))
	      v = Prod (Prod a b) (Prod (List a) (List b))

data Pf a where
	RunReaderPutS :: Monad m => Pf (PutlensReaderM m s s v) -> Pf (PutlensM m s v)
	WithReaderPut :: Monad m => Type e' -> (Maybe s -> v -> e -> m e') -> Pf (PutlensReaderM m e' s v) -> Pf (PutlensReaderM m e s v)
	WithS :: Monad m => Pf (PutlensReaderM m s s v) -> Pf (PutlensReaderM m e s v)
	WithMbS :: Monad m => Pf (PutlensReaderM m (Maybe s) s v) -> Pf (PutlensReaderM m e s v)
	WithV :: Monad m => Pf (PutlensReaderM m v s v) -> Pf (PutlensReaderM m e s v)
	WithV' :: Monad m => Pf (PutlensReaderM m v s v) -> Pf (PutlensReaderM m e s v)
	InitSt :: Monad m => Type st -> (Maybe s -> v -> m st) -> Pf (PutlensStateM m st s v) -> Pf (PutlensM m s v)
	ResetUpdSt :: Monad m => Type st' -> (Maybe s -> v -> r -> st -> m st') -> Pf (PutlensReaderM (StateT st' m) r s v) -> Pf (PutlensReaderM (StateT st m) r s v)
	ResetStatePut :: Monad m => Type st' -> (Maybe s -> v -> st -> m st') -> Pf (PutlensStateM m st' s v) -> Pf (PutlensStateM m st s v)
	ModifySt :: MonadState st m => (Maybe s -> v -> st -> m st) -> Pf (PutlensM m s v) -> Pf (PutlensM m s v)
	UpdateSt :: MonadState st m => (Maybe s -> s -> st -> m st) -> Pf (PutlensM m s v) -> Pf (PutlensM m s v)
	UnforkPut :: Monad m => Pf (PutlensM m s v1) -> Pf (PutlensM m s v2) -> Pf (PutlensM m s (v1,v2))
	IdPut :: Monad m => Pf (PutlensM m s s)
	CompPut :: (Monad m,Eq u) => Type u -> Pf (PutlensM m s u) -> Pf (PutlensM m u v) -> Pf (PutlensM m s v)
	PhiPut :: Monad m => (v -> Bool) -> Pf (PutlensM m v v)
	PhiSourcePut :: Monad m => (s -> Bool) -> Pf (PutlensM m s v) -> Pf (PutlensM m s v)
	BotPut :: Monad m => Pf (PutlensM m a b)
	AddfstPut :: Monad m => (Maybe (s1,v) -> v -> m s1) -> Pf (PutlensM m (s1,v) v)
	AddsndPut :: Monad m => (Maybe (v,s2) -> v -> m s2) -> Pf (PutlensM m (v,s2) v)
	DupPut :: (Monad m,Eq v) => Pf (PutlensM m (v,v) v)
	KeepfstPut :: (Monad m,Eq v) => Pf (PutlensM m (s1,v) v)
	KeepsndPut :: (Monad m,Eq v) => Pf (PutlensM m (v,s2) v)
	KeepfstDefPut :: (Monad m,Eq v) => Pf (PutlensM m (s1,v) v)
	KeepsndDefPut :: (Monad m,Eq v) => Pf (PutlensM m (v,s2) v)
	RemfstPut :: (Monad m,Eq v1) => (v -> v1) -> Pf (PutlensM m v (v1,v))
	RemsndPut :: (Monad m,Eq v2) => (v -> v2) -> Pf (PutlensM m v (v,v2))
	ProdPut :: Monad m => Pf (PutlensM m s1 v1) -> Pf (PutlensM m s2 v2) -> Pf (PutlensM m (s1,s2) (v1,v2))
	IgnorePut :: (Monad m,Eq v) => v -> Pf (PutlensM m () v)
	KeepPut :: Monad m => Pf (PutlensM m s ())
	KeepDefPut :: Monad m => Pf (PutlensM m s ())
	NewPut :: Monad m => s -> Pf (PutlensM m s ())
	PntPut :: Monad m => (Maybe a -> m a) -> Pf (PutlensM m a ())
	AddfstOnePut :: (Monad m,Eq v) => Pf (PutlensM m ((),v) v)
	AddsndOnePut :: (Monad m,Eq v) => Pf (PutlensM m (v,()) v)
	RemfstOnePut :: (Monad m,Eq a) => Pf (PutlensM m a ((),a))
	RemsndOnePut :: (Monad m,Eq a) => Pf (PutlensM m a (a,()))
	InjPut :: (Monad m,Eq v) => (Maybe (Either v v) -> v -> m Bool) -> Pf (PutlensM m (Either v v) v)
	InjSPut :: (Monad m,Eq v) => Pf (PutlensM m (Either v v) v)
	InjlSPut :: (Monad m,Eq v) => Pf (PutlensM m (Either v v) v)
	InjrSPut :: (Monad m,Eq v) => Pf (PutlensM m (Either v v) v)
	EitherPut :: (Monad m,Eq s) => Pf (PutlensM m s v1) -> Pf (PutlensM m s v2) -> Pf (PutlensM m s (Either v1 v2))
	EitherSPut :: (Monad m,Eq s) => (s -> Bool) -> Pf (PutlensM m s v1) -> Pf (PutlensM m s v2) -> Pf (PutlensM m s (Either v1 v2))
	EitherLPut :: (Monad m,Eq s) => Pf (PutlensM m s v1) -> Pf (PutlensM m s v2) -> Pf (PutlensM m s (Either v1 v2))
	EitherRPut :: (Monad m,Eq s) => Pf (PutlensM m s v1) -> Pf (PutlensM m s v2) -> Pf (PutlensM m s (Either v1 v2))
	SumPut :: Monad m => Pf (PutlensM m s1 v1) -> Pf (PutlensM m s2 v2) -> Pf (PutlensM m (Either s1 s2) (Either v1 v2))
	InjlPut :: Monad m => Pf (PutlensM m (Either v v2) v)
	InjrPut :: Monad m => Pf (PutlensM m (Either v1 v) v)
	UninjlPut :: Monad m => Pf (PutlensM m v (Either v v2))
	UninjrPut :: Monad m => Pf (PutlensM m v (Either v1 v))
	IfthenelsePut :: (Monad m,Eq v) => (Maybe s -> v -> m Bool) -> Pf (PutlensM m s v) -> Pf (PutlensM m s v) -> Pf (PutlensM m s v)
	IfVthenelsePut :: (Monad m,Eq v) => (v -> Bool) -> Pf (PutlensM m s v) -> Pf (PutlensM m s v) -> Pf (PutlensM m s v)
	IfSthenelsePut :: (Monad m,Eq v) => (s -> Bool) -> Pf (PutlensM m s v) -> Pf (PutlensM m s v) -> Pf (PutlensM m s v)
	CustomPut :: (Monad m,Eq s,Eq v) => (Either () s -> v -> m s) -> (s -> v) -> Pf (PutlensM m s v)
	InnPut :: (Monad m,InOut a) => Pf (PutlensM m a (F a))
	OutPut :: (Monad m,InOut a) => Pf (PutlensM m (F a) a)
	
	NilPut :: Monad m => Pf (PutlensM m [a] ())
	UnnilPut :: Monad m => Pf (PutlensM m () [a])
	ConsPut :: Monad m => Pf (PutlensM m [a] (a,[a]))
	UnconsPut :: Monad m => Pf (PutlensM m (a,[a]) [a])
	MapPut :: Monad m => Pf (PutlensM m s v) -> Pf (PutlensM m [s] [v])
	UnfoldrsPut :: (Monad m,Eq a,Eq b) => Pf (PutlensM m (b,a) a) -> a -> Pf (PutlensM m [b] a)
	
	FilterWithPosPut :: (Monad m,Eq a) => (Last -> (Pos,a) -> Bool) -> Pf (PutlensM m [a] [a])
	AlignKeyPut :: (Eq a,Eq b) => (Env -> a -> k1) -> (Env -> b -> k2) -> (k1 -> k2 -> Bool) -> (a -> Bool) -> (Env -> a -> Maybe a)
	            -> Maybe (Env -> b -> a) -> Pf (EnvPutlensM a b) -> Pf (EnvPutlensM [a] [b])
	AlignPosPut :: (Eq a,Eq b) => (a -> Bool) -> (Env -> a -> Maybe a)
                -> Maybe (Env -> b -> a) -> Pf (EnvPutlensM a b) -> Pf (EnvPutlensM [a] [b])
	ListOneEqPut :: Monad m => Pf (PutlensM m [()] ())
	ListEqPut :: (Monad m,Eq a) => Pf (PutlensM m [a] a)
	FilterrightPut :: (Monad m,Eq a,Eq b) => Pf (PutlensM m [Either a b] [b])
	FilterleftPut :: (Monad m,Eq a,Eq b) => Pf (PutlensM m [Either a b] [a])
	ConcatPut :: (Monad m,Eq a) => Pf (PutlensM m [[a]] [a])
	ConcatBiasPut :: (Monad m,Eq a) => Int -> Maybe Int -> Int -> Maybe Int -> Pf (PutlensM m [[a]] [a])
	ConcatPosPut :: (Monad m,Eq a) => Int -> Pf (PutlensM m [[a]] [a])
	JoinBiasPut :: (Monad m,Eq a) => Bool -> Pf (PutlensM m (Either [a] [a]) [a])
	JoinByPut :: (Monad m,Eq a) => (a -> Bool) -> Pf (PutlensM m (Either [a] [a]) [a])
	AppendByPut :: (Monad m,Eq a) => (a -> Bool) -> Pf (PutlensM m ([a],[a]) [a])
	AppendLeftPut :: (Monad m,Eq a) => Int -> Pf (PutlensM m ([a],[a]) [a])
	AppendRightPut :: (Monad m,Eq a) => Int -> Pf (PutlensM m ([a],[a]) [a])
	AppendBiasPut :: (Monad m,Eq a) => Int -> Int -> Maybe Int -> Maybe Int -> Pf (PutlensM m ([a],[a]) [a])
	
	AssoclPut :: Monad m => Pf (PutlensM m ((a,b),c) (a,(b,c)))
	AssocrPut :: Monad m => Pf (PutlensM m (a,(b,c)) ((a,b),c))
	SwapPut :: Monad m => Pf (PutlensM m (b,a) (a,b))
	SublPut :: Monad m => Pf (PutlensM m ((a,c),b) ((a,b),c))
	SubrPut :: Monad m => Pf (PutlensM m (b,(a,c)) (a,(b,c)))
	CoassoclPut :: Monad m => Pf (PutlensM m (Either (Either a b) c) (Either a (Either b c)))
	CoassocrPut :: Monad m => Pf (PutlensM m (Either a (Either b c)) (Either (Either a b) c))
	CoswapPut :: Monad m => Pf (PutlensM m (Either b a) (Either a b))
	CosublPut :: Monad m => Pf (PutlensM m (Either (Either a c) b) (Either (Either a b) c))
	CosubrPut :: Monad m => Pf (PutlensM m (Either b (Either a c)) (Either a (Either b c)))
	DistlPut :: Monad m => Pf (PutlensM m (Either (a,c) (b,c)) (Either a b,c))
	UndistlPut :: Monad m => Pf (PutlensM m (Either a b,c) (Either (a,c) (b,c)))
	DistrPut :: Monad m => Pf (PutlensM m (Either (a,b) (a,c)) (a,Either b c))
	UndistrPut :: Monad m => Pf (PutlensM m (a,Either b c) (Either (a,b) (a,c)))
	DistpPut :: Monad m => Pf (PutlensM m ((a,c),(b,d)) ((a,b),(c,d)))
	DistsPut :: Monad m => Pf (PutlensM m (Either (Either (a,c) (a,d)) (Either (b,c) (b,d))) (Either a b,Either c d))
	UndistsPut :: Monad m => Pf (PutlensM m (Either a b,Either c d) (Either (Either (a,c) (a,d)) (Either (b,c) (b,d))))
	
	DynPut :: (Monad m,Eq a) => Type a -> Pf (PutlensM m Dynamic a)
	UndynPut :: (Monad m,Eq a) => Type a -> Pf (PutlensM m a Dynamic)
	ToStringPut :: (Monad m,Eq a) => Type a -> Pf (PutlensM m a Str)
	FromStringPut :: (Monad m,Eq a) => Type a -> Pf (PutlensM m Str a)
	
	Val :: Type a -> a -> Pf a							-- constant value that can only be evaluated but not inspected
	Variable :: String -> Type a -> Pf a									-- reference
	Put2Lens :: Eq v => Pf (Putlens s v) -> Pf (Lens s v)
	Put2Create :: (Monad m,Eq v) => Pf (PutlensM m s v) -> Pf (PutlensM m s v)
	
	UnsafeInvPut :: (Monad m,Eq a,Eq b) => String -> Pf (Putlens a b) -> Pf (PutlensM m b a)
	EitherREPut :: (Monad m,Eq s) => Pf (PutlensM m (Either s s) v) -> Pf (PutlensM m s v)
	ListOneREPut :: Monad m => Pf (PutlensM m () [()])
	
	Dom :: (Monad m,Eq v) => TypeM m -> Type v -> Pf (PutlensM m s v) -> Pf (s -> Bool) -- domain of a putlens
	
	ParamfstGet :: (Eq v,Monad m) => (v -> m k) -> (k -> Pf (PutlensM m s v)) -> Pf (PutlensM m (k,s) v)

wrapPutPf :: (Monad m,Eq a) => Type a -> Pf (PutlensM m [a] a)
wrapPutPf a = CompPut (Prod a $ List a) ConsPut $ CompPut (Prod a One) (IdPut `ProdPut` NilPut) AddsndOnePut

unwrapPutPf :: (Monad m,Eq a) => Type a -> Pf (PutlensM m a [a])
unwrapPutPf a = CompPut (Prod a One) RemsndOnePut $ CompPut (Prod a (List a)) (IdPut `ProdPut` UnnilPut) UnconsPut

evalget' :: (Monad m,Eq s,Eq v) => TypeM m -> Type s -> Type v -> Pf (PutlensM m s v) -> (s -> v)
evalget' st s v lns = get' (eval Map.empty (PutlnsM st s v) lns)

data PfWithDecls a = PfWithDecls { root :: Pf a, decls :: Map String DynPf }

instance Typeable a => Show (PfWithDecls a) where
	show = render . pprintPfWithDecls typeof

data DynPf where
	DynPf :: Type a -> Pf a -> DynPf

instance Show DynPf where
	show (DynPf t pf) = render (pprintPf t pf)

-- invert an isomorphism
inv :: (MonadPlus m,Monad lensm) => Type (PutlensM lensm a b) -> Pf (PutlensM lensm a b) -> m (Pf (PutlensM lensm b a))
inv t InnPut = return OutPut
inv t OutPut = return InnPut
inv t IdPut = return IdPut
inv t BotPut = return BotPut
inv (PutlnsM st s v) (CompPut u f g) = do
	f' <- inv (PutlnsM st s u) f
	g' <- inv (PutlnsM st u v) g
	return $ CompPut u g' f'
inv (PutlnsM st (Prod s1 s2) (Prod v1 v2)) (ProdPut f g) = do
	f' <- inv (PutlnsM st s1 v1) f
	g' <- inv (PutlnsM st s2 v2) g
	return $ ProdPut f' g'
inv t AddfstOnePut = return RemfstOnePut
inv t AddsndOnePut = return RemsndOnePut
inv t RemfstOnePut = return AddfstOnePut
inv t RemsndOnePut = return AddsndOnePut
inv t SwapPut = return SwapPut
inv t SubrPut = return SubrPut
inv t AssoclPut = return AssocrPut
inv t AssocrPut = return AssoclPut
inv (PutlnsM st (Either s1 s2) (Either v1 v2)) (SumPut f g) = do
	f' <- inv (PutlnsM st s1 v1) f
	g' <- inv (PutlnsM st s2 v2) g
	return $ SumPut f' g'
inv t InjlPut = return UninjlPut
inv t InjrPut = return UninjrPut
inv t UninjlPut = return InjlPut
inv t UninjrPut = return InjrPut
inv t CoswapPut = return CoswapPut
inv t CosubrPut = return CosubrPut
inv t CoassoclPut = return CoassocrPut
inv t CoassocrPut = return CoassoclPut
inv t DistlPut = return UndistlPut
inv t DistrPut = return UndistrPut
inv t UndistlPut = return DistlPut
inv t UndistrPut = return DistrPut
inv t NilPut = return UnnilPut
inv t ConsPut = return UnconsPut
inv t UnnilPut = return NilPut
inv t UnconsPut = return ConsPut
inv (PutlnsM st (List s) (List v)) (MapPut f) = do
	f' <- inv (PutlnsM st s v) f
	return $ MapPut f'
inv (PutlnsM st s (Either v1 v2)) (EitherLPut f g) = do
	f' <- inv (PutlnsM st s v1) f
	g' <- inv (PutlnsM st s v2) g
	return $ IfVthenelsePut (dom $ evalPutlnsM Map.empty st s v1 f) (CompPut v1 InjlPut f') (CompPut v2 InjrPut g')
inv (PutlnsM st (Tag n s) v) f = inv (PutlnsM st s v) f
inv (PutlnsM st s (Tag n v)) f = inv (PutlnsM st s v) f
inv t f = error $ show t ++ " unsupported inversion: " ++ render (pprintPf t f)

-- * Show point-free representations

instance Typeable a => Show (Pf a) where
	show = render . pprintPf typeof

pprintPfWithDecls :: Type a -> PfWithDecls a -> Doc
pprintPfWithDecls a (PfWithDecls root decls) = pprintPf a root <+> text "where" $$ nest 4 (Map.foldrWithKey (\k d doc -> pprintDynPf k d $$ doc) empty decls)

pprintDynPf :: String -> DynPf -> Doc
pprintDynPf k (DynPf t v) = {- text k <+> text "::" <+> pprintType t $$ -} text k <+> text "=" <+> pprintPf t v

pprintType :: Type a -> Doc
pprintType (PutlnsM st s v) = text "Putlens" <+> text (show st) <+> text (show s) <+> text (show v)

pprintCompPut :: Type a -> Pf a -> Doc
pprintCompPut (PutlnsM st s v) (CompPut u f g) = x <+> text ".<" <+> y
    where x = pprintCompPut (PutlnsM st s u) f
          y = pprintCompPut (PutlnsM st u v) g
pprintCompPut a f = pprintPf a f

pprintPf :: Type a -> Pf a -> Doc
pprintPf (PutlnsM m s v) (RunReaderPutS f) = pretty1 "runReaderPutS" (PutlnsM (T.ReaderT s m) s v) f
pprintPf (PutlnsM (T.ReaderT e m) s v) (WithReaderPut e' g f) = pretty1 "withReaderPut" (PutlnsM (T.ReaderT e' m) s v) f
pprintPf (PutlnsM (T.ReaderT e m) s v) (WithS f) = pretty1 "withS" (PutlnsM (T.ReaderT s m) s v) f
pprintPf (PutlnsM (T.ReaderT e m) s v) (WithMbS f) = pretty1 "withMbS" (PutlnsM (T.ReaderT (maybeT s) m) s v) f
pprintPf (PutlnsM (T.ReaderT e m) s v) (WithV f) = pretty1 "withV" (PutlnsM (T.ReaderT v m) s v) f
pprintPf (PutlnsM (T.ReaderT e m) s v) (WithV' f) = pretty1 "withV'" (PutlnsM (T.ReaderT v m) s v) f
pprintPf (PutlnsM m s v) (InitSt st f g) = pretty1 "initSt f" (PutlnsM (T.StateT st m) s v) g
pprintPf (PutlnsM (T.ReaderT r (T.StateT st m)) s v) (ResetUpdSt st' f g) = pretty1 "resetSt f" (PutlnsM (T.ReaderT r (T.StateT st' m)) s v) g
pprintPf (PutlnsM ((T.StateT st m)) s v) (ResetStatePut st' f g) = pretty1 "resetState f" (PutlnsM ((T.StateT st' m)) s v) g
pprintPf (PutlnsM (T.StateT st m) s v) (ModifySt f g) = pretty1 "modifySt f" (PutlnsM (T.StateT st m) s v) g
pprintPf (PutlnsM (T.StateT st m) s v) (UpdateSt f g) = pretty1 "updateSt f" (PutlnsM (T.StateT st m) s v) g
pprintPf (PutlnsM st s (Prod v1 v2)) (UnforkPut f g) = pretty2 "unforkPut" (PutlnsM st s v1) f (PutlnsM st s v2) g
pprintPf (PutlnsM st s v) IdPut = pretty0 "idPut"
pprintPf (PutlnsM st s v) (CompPut u f g) = parens $ pprintCompPut (PutlnsM st s v) (CompPut u f g)
pprintPf (PutlnsM st s v) (PhiPut f) = pretty0 "phiPut p"
pprintPf (PutlnsM st s v) (PhiSourcePut p f) = pretty0 "phiPut p f"
pprintPf (PutlnsM st s v) BotPut = pretty0 "botPut"
pprintPf (PutlnsM m (Prod s1 _) v) (AddfstPut f) = pretty0 "addfstPut f"
pprintPf (PutlnsM m (Prod _ s2) v) (AddsndPut f) = pretty0 "addsndPut f"
pprintPf (PutlnsM st s v) KeepfstPut = pretty0 "keepfstPut"
pprintPf (PutlnsM st s v) KeepsndPut = pretty0 "keepsndPut"
pprintPf (PutlnsM st (Prod s1 v) _) (KeepfstDefPut) = parens $ text "keepfstDefPut" <+> text (show s1)
pprintPf (PutlnsM st (Prod v s2) _) KeepsndDefPut = parens $ text "keepsndDefPut" <+> text (show s2)
pprintPf (PutlnsM st s (Prod v1 v)) (RemfstPut f) = pretty0 "remfstPut f" 
pprintPf (PutlnsM st s (Prod v v2)) (RemsndPut f) = pretty0 "remsndPut f" 
pprintPf (PutlnsM st (Prod s1 s2) (Prod v1 v2)) (ProdPut f g) = ipretty2 "><<" (PutlnsM st s1 v1) f (PutlnsM st s2 v2) g
pprintPf (PutlnsM st (Tag n (Prod s1 s2)) (Prod v1 v2)) (ProdPut f g) = ipretty2 "><<" (PutlnsM st s1 v1) f (PutlnsM st s2 v2) g
pprintPf (PutlnsM st One v) (IgnorePut x) = pretty0 "ignorePut x"
pprintPf (PutlnsM st s v) KeepPut = pretty0 "keepPut"
pprintPf (PutlnsM st s v) KeepDefPut = pretty0 "keepDefPut"
pprintPf (PutlnsM st s One) (NewPut x) = pretty0 "newPut x"
pprintPf (PutlnsM m a One) (PntPut f) = pretty0 "pntPut ..."
pprintPf (PutlnsM st s v) AddfstOnePut = pretty0 "addfstOnePut"
pprintPf (PutlnsM st s v) AddsndOnePut = pretty0 "addsndOnePut"
pprintPf (PutlnsM st s v) RemfstOnePut = pretty0 "remfstOnePut"
pprintPf (PutlnsM st s v) RemsndOnePut = pretty0 "remsndOnePut"
pprintPf (PutlnsM m _ v) (InjPut f) = pretty0 "injPut f"
pprintPf (PutlnsM st s v) InjSPut = pretty0 "injSPut"
pprintPf (PutlnsM st s v) InjlSPut = pretty0 "injlSPut"
pprintPf (PutlnsM st s v) InjrSPut = pretty0 "injrSPut"
pprintPf (PutlnsM st s (Either v1 v2)) (EitherPut f g) = ipretty2 "\\/<" (PutlnsM st s v1) f (PutlnsM st s v2) g
pprintPf (PutlnsM st s (Either v1 v2)) (EitherSPut f g h) = pretty2 "eitherSPut f" (PutlnsM st s v1) g (PutlnsM st s v2) h
pprintPf (PutlnsM st s (Either v1 v2)) (EitherLPut f g) = ipretty2 ".\\/<" (PutlnsM st s v1) f (PutlnsM st s v2) g
pprintPf (PutlnsM st s (Either v1 v2)) (EitherRPut f g) = ipretty2 "\\/.<" (PutlnsM st s v1) f (PutlnsM st s v2) g
pprintPf (PutlnsM st (Either s1 s2) (Either v1 v2)) (SumPut f g) = ipretty2 "-|-<" (PutlnsM st s1 v1) f (PutlnsM st s2 v2) g
pprintPf (PutlnsM st s v) InjlPut = pretty0 "injlPut"
pprintPf (PutlnsM st s v) InjrPut = pretty0 "injrPut"
pprintPf (PutlnsM st s v) UninjlPut = pretty0 "uninjlPut"
pprintPf (PutlnsM st s v) UninjrPut = pretty0 "uninjrPut"
pprintPf (PutlnsM m s v) (IfthenelsePut f g h) = pretty2 "ifthenelsePut p" (PutlnsM m s v) g (PutlnsM m s v) h
pprintPf (PutlnsM st s v) (IfVthenelsePut f g h) = pretty2 "ifVthenelsePut p" (PutlnsM st s v) g (PutlnsM st s v) h
pprintPf (PutlnsM st s v) (IfSthenelsePut f g h) = pretty2 "ifVthenelsePut p" (PutlnsM st s v) g (PutlnsM st s v) h
pprintPf (PutlnsM m s v) (CustomPut f g) = pretty0 "customPut f g"
pprintPf (PutlnsM st s v) InnPut = pretty0 "innPut"
pprintPf (PutlnsM st s v) OutPut = pretty0 "outPut"
pprintPf (PutlnsM st s v) NilPut = pretty0 "nilPut"
pprintPf (PutlnsM st s v) UnnilPut = pretty0 "unnilPut"
pprintPf (PutlnsM st s v) ConsPut = pretty0 "consPut"
pprintPf (PutlnsM st s v) UnconsPut = pretty0 "unconsPut"
pprintPf (PutlnsM st (List s) (List v)) (MapPut f) = pretty1 "mapPut" (PutlnsM st s v) f
pprintPf (PutlnsM st (List b) a) (UnfoldrsPut f c) = pretty1 "unfoldrsPut" (PutlnsM st (Prod b a) a) f
pprintPf (PutlnsM st (XList _ _ _) (List v)) (MapPut f) = pretty1 "mapPut" (PutlnsM st Any v) f
pprintPf (PutlnsM st s v) AssoclPut = pretty0 "assoclPut"
pprintPf (PutlnsM st s v) AssocrPut = pretty0 "assocrPut"
pprintPf (PutlnsM st s v) SwapPut = pretty0 "swapPut"
pprintPf (PutlnsM st s v) SublPut = pretty0 "sublPut"
pprintPf (PutlnsM st s v) SubrPut = pretty0 "subrPut"
pprintPf (PutlnsM st s v) CoassoclPut = pretty0 "coassoclPut"
pprintPf (PutlnsM st s v) CoassocrPut = pretty0 "coassoclPut"
pprintPf (PutlnsM st s v) CoswapPut = pretty0 "coswapPut"
pprintPf (PutlnsM st s v) CosublPut = pretty0 "cosublPut"
pprintPf (PutlnsM st s v) CosubrPut = pretty0 "cosubrPut"
pprintPf (PutlnsM st s v) DistlPut = pretty0 "distlPut"
pprintPf (PutlnsM st s v) UndistlPut = pretty0 "undistlPut"
pprintPf (PutlnsM st s v) DistrPut = pretty0 "distrPut"
pprintPf (PutlnsM st s v) UndistrPut = pretty0 "undistrPut"
pprintPf (PutlnsM st s v) (DynPut t) = parens $ text "dynPut" <+> text (show t)
pprintPf (PutlnsM st s v) (UndynPut t) = parens $ text "undynPut" <+> text (show t)
pprintPf _ (Val t v) = pretty0 (gshow t v)
pprintPf (_) (Variable s t) = pretty0 s
pprintPf (LnsM T.Identity s v) (Put2Lens f) = pretty1 "put2lens" (PutlnsM Identity s v) f
pprintPf (PutlnsM st s v) (Put2Create f) = pretty1 "put2create" (PutlnsM st s v) f
pprintPf (PutlnsM st s v) (UnsafeInvPut err f) = pretty1 "unsafeInvPut" (PutlnsM Identity v s) f
pprintPf (PutlnsM st s v) (EitherREPut f) = pretty1 "eitherREPut" (PutlnsM st (Either s s) v) f
pprintPf (PutlnsM st s v) ListOneREPut = pretty0 "listOneREPut"
pprintPf (Fun s Bool) (Dom st v f) = pretty1 "dom" (PutlnsM st s v) f
pprintPf _ (ToStringPut a) = pretty0 "toXPathStringPut"
pprintPf _ (FromStringPut a) = pretty0 "fromXPathStringPut"
pprintPf _ (FilterWithPosPut p) = pretty0 "filterWithPosPut ..."
pprintPf (PutlnsM ((T.StateT Env T.Identity)) (List s) (List v)) (AlignKeyPut skey vkey eqk p recover create f) = pretty1 "alignKeyPut ..." (PutlnsM (envM) s v) f
pprintPf (PutlnsM ((T.StateT Env T.Identity)) (List s) (List v)) (AlignPosPut p recover create f) = pretty1 "alignKeyPut ..." (PutlnsM (envM) s v) f
pprintPf _ ListOneEqPut = pretty0 "listOneEqPut"
pprintPf _ ListEqPut = pretty0 "listEqPut"
pprintPf _ FilterrightPut = pretty0 "filterrightPut"
pprintPf _ FilterleftPut = pretty0 "filterleftPut"
pprintPf _ ConcatPut = pretty0 "concatPut"
pprintPf _ (ConcatBiasPut a b c d) = pretty0 "concatPut ..."
pprintPf _ (ConcatPosPut i) = pretty0 "concatPosPut ..."
pprintPf _ (JoinBiasPut b) = pretty0 "joinBiasPut ..."
pprintPf _ (JoinByPut p) = pretty0 "joinByPut ..."
pprintPf _ (AppendByPut p) = pretty0 "appendByPut ..."
pprintPf _ (AppendLeftPut i) = pretty0 "appendLeftPut ..."
pprintPf _ (AppendRightPut i) = pretty0 "appendRightPut ..."
pprintPf _ (AppendBiasPut a b c d) = pretty0 "appendBiasPut ..."
pprintPf _ DupPut = pretty0 "dupPut"
pprintPf _ DistpPut = pretty0 "distpPut"
pprintPf _ DistsPut = pretty0 "distsPut"
pprintPf _ UndistsPut = pretty0 "undistsPut"
pprintPf _ (ParamfstGet _ f) = pretty0 "paramfstGet f"
pprintPf t v = error $ "pprintPf " ++ show t

pretty0 :: String -> Doc
pretty0 n = text n
pretty1 :: String -> Type a -> Pf a -> Doc
pretty1 n a f = let x = pprintPf a f in parens (text n <+> x)
pretty2 :: String -> Type a -> Pf a -> Type b -> Pf b -> Doc
pretty2 n a f b g = let x = pprintPf a f
                        y = pprintPf b g
                    in parens (text n <+> x <+> y)
pretty3 :: String -> Type a -> Pf a -> Type b -> Pf b -> Type c -> Pf c -> Doc
pretty3 n a f b g c h = let x = pprintPf a f
                            y = pprintPf b g
                            z = pprintPf c h
                        in parens (text n <+> x <+> y <+> z)
ipretty2 :: String -> Type a -> Pf a -> Type b -> Pf b -> Doc
ipretty2 n a f b g = let x = pprintPf a f
                         y = pprintPf b g
                     in parens (x <+> text n <+> y)

ipretty2NoParens :: String -> Type a -> Pf a -> Type b -> Pf b -> Doc
ipretty2NoParens n a f b g = let x = pprintPf a f
                                 y = pprintPf b g
                             in x <+> text n <+> y

-- * Interpret point-free expressions

evalPfWithDecls :: Type a -> PfWithDecls a -> a
evalPfWithDecls t wd = eval (decls wd) t (root wd)

evalLns :: (Eq s,Eq v) => Map String DynPf -> Type s -> Type v -> Pf (Lens s v) -> Lens s v
evalLns decls s v f = eval decls (LnsM T.Identity s v) f

evalPutlnsM :: (Eq s,Eq v) => Map String DynPf -> TypeM m -> Type s -> Type v -> Pf (PutlensM m s v) -> PutlensM m s v
evalPutlnsM decls m  s v f = eval decls (PutlnsM m s v) f

eval :: Map String DynPf -> Type a -> Pf a -> a
eval decls (PutlnsM m s v) (RunReaderPutS f) = runReaderPutS (eval decls (PutlnsM (T.ReaderT s m) s v) f)
eval decls (PutlnsM (T.ReaderT e m) s v) (WithReaderPut e' g f) = withReaderPut g (eval decls (PutlnsM (T.ReaderT e' m) s v) f)
eval decls (PutlnsM (T.ReaderT e m) s v) (WithS f) = withS (eval decls (PutlnsM (T.ReaderT s m) s v) f)
eval decls (PutlnsM (T.ReaderT e m) s v) (WithMbS f) = withMbS (eval decls (PutlnsM (T.ReaderT (maybeT s) m) s v) f)
eval decls (PutlnsM (T.ReaderT e m) s v) (WithV f) = withV (eval decls (PutlnsM (T.ReaderT v m) s v) f)
eval decls (PutlnsM (T.ReaderT e m) s v) (WithV' f) = withV' (eval decls (PutlnsM (T.ReaderT v m) s v) f)
eval decls (PutlnsM m s v) (InitSt st f g) = runStatePut f (eval decls (PutlnsM (T.StateT st m) s v) g)
eval decls (PutlnsM (T.ReaderT r (T.StateT st m)) s v) (ResetUpdSt st' f g) = resetReaderStatePut f (eval decls (PutlnsM (T.ReaderT r (T.StateT st' m)) s v) g)
eval decls (PutlnsM ((T.StateT st m)) s v) (ResetStatePut st' f g) = resetStatePut f (eval decls (PutlnsM ((T.StateT st' m)) s v) g)
eval decls (PutlnsM m s v) (ModifySt f g) = withStatePut f (eval decls (PutlnsM m s v) g)
eval decls (PutlnsM m s v) (UpdateSt f g) = updateStatePut f (eval decls (PutlnsM m s v) g)
eval decls (PutlnsM m s (Prod v1 v2)) (UnforkPut f g) = unforkPut (eval decls (PutlnsM m s v1) f) (eval decls (PutlnsM m s v2) g)
eval decls (PutlnsM st s v) IdPut = idPut
eval decls (PutlnsM st s v) (CompPut u f g) = (eval decls (PutlnsM st s u) f) .< (eval decls (PutlnsM st u v) g)
eval decls (PutlnsM st s v) (PhiPut f) = phiPut f
eval decls (PutlnsM st s v) (PhiSourcePut p f) = phiSourcePut p (eval decls (PutlnsM st s v) f)
eval decls (PutlnsM st s v) BotPut = botPut
eval decls (PutlnsM m (Prod s1 _) v) (AddfstPut f) = addfstPut f
eval decls (PutlnsM m (Prod _ s2) v) (AddsndPut f) = addsndPut f
eval decls (PutlnsM st s v) KeepfstPut = keepfstPut
eval decls (PutlnsM st s v) KeepsndPut = keepsndPut
eval decls (PutlnsM st (Prod s _) v) KeepfstDefPut = keepfstDefPut s
eval decls (PutlnsM st (Prod _ s) v) KeepsndDefPut = keepsndDefPut s
eval decls (PutlnsM st s (Prod v1 v)) (RemfstPut f) = remfstPut f
eval decls (PutlnsM st s (Prod v v2)) (RemsndPut f) = remsndPut f
eval decls (PutlnsM st (Prod s1 s2) (Prod v1 v2)) (ProdPut f g) = (eval decls (PutlnsM st s1 v1) f) ><< (eval decls (PutlnsM st s2 v2) g)
eval decls (PutlnsM st s v) (IgnorePut x) = ignorePut x
eval decls (PutlnsM st s v) KeepPut = keepPut
eval decls (PutlnsM st s v) KeepDefPut = keepDefPut s
eval decls (PutlnsM st s v) (NewPut x) = newPut x
eval decls (PutlnsM m s v) (PntPut f) = pntPut f
eval decls (PutlnsM st s v) AddfstOnePut = addfstOnePut
eval decls (PutlnsM st s v) AddsndOnePut = addsndOnePut
eval decls (PutlnsM st s v) RemfstOnePut = remfstOnePut
eval decls (PutlnsM st s v) RemsndOnePut = remsndOnePut
eval decls (PutlnsM m s v) (InjPut f) = injPut f
eval decls (PutlnsM st s v) InjSPut = injsOrPut (\v -> fail "injsPut")
eval decls (PutlnsM st s v) InjlSPut = injlsPut
eval decls (PutlnsM st s v) InjrSPut = injrsPut
eval decls (PutlnsM st s (Either v1 v2)) (EitherPut f g) = (eval decls (PutlnsM st s v1) f) \/< (eval decls (PutlnsM st s v2) g)
eval decls (PutlnsM st s (Either v1 v2)) (EitherSPut f g h) = eitherSPut f (eval decls (PutlnsM st s v1) g) (eval decls (PutlnsM st s v2) h)
eval decls (PutlnsM st s (Either v1 v2)) (EitherLPut f g) = (eval decls (PutlnsM st s v1) f) .\/< (eval decls (PutlnsM st s v2) g)
eval decls (PutlnsM st s (Either v1 v2)) (EitherRPut f g) = (eval decls (PutlnsM st s v1) f) \/.< (eval decls (PutlnsM st s v2) g)
eval decls (PutlnsM st (Either s1 s2) (Either v1 v2)) (SumPut f g) = (eval decls (PutlnsM st s1 v1) f) -|-< (eval decls (PutlnsM st s2 v2) g)
eval decls (PutlnsM st s v) InjlPut = injlPut
eval decls (PutlnsM st s v) InjrPut = injrPut
eval decls (PutlnsM st s v) UninjlPut = uninjlPut
eval decls (PutlnsM st s v) UninjrPut = uninjrPut
eval decls (PutlnsM m s v) (IfthenelsePut p f g) = ifthenelsePut p (eval decls (PutlnsM m s v) f) (eval decls (PutlnsM m s v) g)
eval decls (PutlnsM st s v) (IfVthenelsePut p f g) = ifVthenelsePut p (eval decls (PutlnsM st s v) f) (eval decls (PutlnsM st s v) g)
eval decls (PutlnsM st s v) (IfSthenelsePut p f g) = ifSthenelsePut p (eval decls (PutlnsM st s v) f) (eval decls (PutlnsM st s v) g)
eval decls (PutlnsM m s v) (CustomPut f g) = customPut f' g
    where f' Nothing vx = f (Left ()) vx
          f' (Just sx) vx = f (Right sx) vx
eval decls (PutlnsM st s v) InnPut = innPut
eval decls (PutlnsM st s v) OutPut = outPut
eval decls (PutlnsM st s v) NilPut = nilPut
eval decls (PutlnsM st s v) UnnilPut = unnilPut
eval decls (PutlnsM st s v) ConsPut = consPut
eval decls (PutlnsM st s v) UnconsPut = unconsPut
eval decls (PutlnsM st (List s) (List v)) (MapPut f) = mapPut (eval decls (PutlnsM st s v) f)
eval decls (PutlnsM st (XList _ _ _) (List v)) (MapPut f) = mapPut (eval decls (PutlnsM st Any v) f)
eval decls (PutlnsM st (List b) a) (UnfoldrsPut f c) = unfoldrsPut (eval decls (PutlnsM st (Prod b a) a) f) c
eval decls (PutlnsM st s v) AssoclPut = assoclPut
eval decls (PutlnsM st s v) AssocrPut = assocrPut
eval decls (PutlnsM st s v) SwapPut = swapPut
eval decls (PutlnsM st s v) SublPut = sublPut
eval decls (PutlnsM st s v) SubrPut = subrPut
eval decls (PutlnsM st s v) CoassoclPut = coassoclPut
eval decls (PutlnsM st s v) CoassocrPut = coassocrPut
eval decls (PutlnsM st s v) CoswapPut = coswapPut
eval decls (PutlnsM st s v) CosublPut = cosublPut
eval decls (PutlnsM st s v) CosubrPut = cosubrPut
eval decls (PutlnsM st s v) DistlPut = distlPut
eval decls (PutlnsM st s v) UndistlPut = undistlPut
eval decls (PutlnsM st s v) DistrPut = distrPut
eval decls (PutlnsM st s v) UndistrPut = undistrPut
eval decls (PutlnsM st Any v) (DynPut t) = dynPut t
eval decls (PutlnsM st s Any) (UndynPut t) = undynPut t
eval decls a (Val t x) = x
eval decls a (Variable name t) = case Map.lookup name decls of
	Just (DynPf t' f) -> case teq t t' of
		Just Eq -> eval decls t f
		Nothing -> error $ "pf refence type " ++ show t' ++ " does not match expected type " ++ show t
	Nothing -> error "unknown pf reference"
eval decls (LnsM T.Identity s v) (Put2Lens f) = put2lens (eval decls (PutlnsM T.Identity s v) f)
eval decls (PutlnsM st s v) (Put2Create f) = put2create (eval decls (PutlnsM st s v) f)
eval decls (PutlnsM st s v) (UnsafeInvPut err f) = unsafeInvPut err (eval decls (PutlnsM T.Identity v s) f)
eval decls (PutlnsM st s v) (EitherREPut f) = eitherREPut (eval decls (PutlnsM st (Either s s) v) f)
eval decls (PutlnsM st s v) ListOneREPut = listOneREPut
eval decls (Fun s Bool) (Dom st v f) = dom (eval decls (PutlnsM st s v) f)
eval decls _ (ToStringPut a) = toXPathStringPut a .< unStrPut
eval decls _ (FromStringPut a) = strPut .< fromXPathStringPut a
eval decls (PutlnsM m s v) (FilterWithPosPut f) = filterWithPosPut f
eval decls  (PutlnsM ((T.StateT Env T.Identity)) (List s) (List v)) (AlignKeyPut skey vkey eqk p recover create f) = alignKeyPut s v skey vkey eqk p recover create (eval decls (PutlnsM (envM) s v) f)
eval decls  (PutlnsM ((T.StateT Env T.Identity)) (List s) (List v)) (AlignPosPut p recover create f) = alignPosPut s v p recover create (eval decls (PutlnsM (envM) s v) f)
eval decls _ ListOneEqPut = listOneEqPut
eval decls _ ListEqPut = listEqPut
eval decls _ FilterrightPut = filterrightPut
eval decls _ FilterleftPut = filterleftPut
eval decls _ ConcatPut = concatPut
eval decls _ (ConcatBiasPut a b c d) = concatBiasPut a b c d
eval decls _ (ConcatPosPut i) = concatPosPut i
eval decls _ (JoinBiasPut b) = joinBiasPut b
eval decls _ (JoinByPut p) = joinByPut p
eval decls _ (AppendByPut p) = appendByPut p
eval decls _ (AppendLeftPut i) = appendLeftPut i
eval decls _ (AppendRightPut i) = appendRightPut i
eval decls _ (AppendBiasPut a b c d) = appendBiasPut a b c d
eval decls _ DupPut = dupPut
eval decls _ DistpPut = distpPut
eval decls _ DistsPut = distsPut
eval decls _ UndistsPut = undistsPut
eval decls (PutlnsM st (Prod k s) v) (ParamfstGet g f) = paramfstGet g $ eval decls (PutlnsM st s v) . f
eval decls (PutlnsM st (Tag n s) v) f = eval decls (PutlnsM st s v) f
eval decls (PutlnsM st s (Tag n v)) f = eval decls (PutlnsM st s v) f
eval decls t v = error $ "eval " ++ render (pprintPf t v)

withS1 :: Monad m => Type s -> Type v -> Type e -> PutlensReaderM m s s v -> PutlensReaderM m e s v
withS1 s v e = withReaderPut (\x y z -> maybe (return $ defvalue s) return x)
	--withReaderPut (\x y z -> maybe (fail $ "withS" ++ show s ++"\n"++ show v++"\n"++ show e ++ "\n" ++ gshow v y ++ "\n" ++ gshow e z) return x)

type DeclNames = [DeclName]
type DeclName = String
type PrevRules = Map String DynPf
type Prevs = (DeclNames,Map String DynPf)

evalUpdPutlnsM :: (Monad m,MonadState Prevs m,Eq v,Eq s) => TypeM lensm -> Type s -> Type v -> Pf (PutlensM lensm s v) -> m (PutlensM lensm s v)
evalUpdPutlnsM st s v f = State.get >>= \(_,decls) -> return $ evalPutlnsM decls st s v f

evalUpdPutlnsM' :: (Eq v,Eq s) => Prevs -> TypeM lensm -> Type s -> Type v -> Pf (PutlensM lensm s v) -> PutlensM lensm s v
evalUpdPutlnsM' (_,decls) st s v f = evalPutlnsM decls st s v f

envM :: TypeM (State Env)
envM = T.StateT Env T.Identity

updM :: Type e -> TypeM (ReaderT e (State Env))
updM e = T.ReaderT e $ T.StateT Env T.Identity







