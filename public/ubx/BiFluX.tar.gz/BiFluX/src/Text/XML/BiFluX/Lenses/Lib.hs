module Text.XML.BiFluX.Lenses.Lib where

import Generics.Putlenses.Putlens as Putlens
import Generics.Putlenses.Language
import Generics.Putlenses.Examples.Examples
import Data.Maybe
import Data.List
import Text.XML.BiFluX.DTD.Type --hiding (Putlens)
import Text.XML.BiFluX.Lenses.Default
import Control.Monad.Reader
import Text.XML.BiFluX.Update.AST
import Data.Map (Map(..))
import qualified Data.Map as Map
import Safe
import Data.List.Split
import Control.Monad.Identity
import Control.Monad.State (State(..),StateT(..),MonadState(..))
import qualified Control.Monad.State as State
import Control.Monad.Trans.Maybe

import Debug.Trace

type UpdPutlensM e s v = PutlensM (UpdM e) s v
type EnvPutlensM s v = PutlensM EnvM s v
type UpdM e = ReaderT e (State Env)
type EnvM = (State Env)

strPut :: Monad m => PutlensM m Str String
strPut = isoPut Str unStr

unStrPut :: Monad m => PutlensM m String Str
unStrPut = isoPut unStr Str

alignPosPut :: (Eq a,Eq b) => Type a -> Type b -> (a -> Bool) -> (Env -> a -> Maybe a)
            -> Maybe (Env -> b -> a) -> EnvPutlensM a b -> EnvPutlensM [a] [b]
alignPosPut a b p rcv create put = alignPut a b (\i env a -> i) (\i env b -> i) (==) p rcv create put

alignKeyPut :: (Eq a,Eq b) => Type a -> Type b -> (Env -> a -> k1) -> (Env -> b -> k2) -> (k1 -> k2 -> Bool) -> (a -> Bool) -> (Env -> a -> Maybe a)
            -> Maybe (Env -> b -> a) -> EnvPutlensM a b -> EnvPutlensM [a] [b]
alignKeyPut a b ka kb eqk p rcv create put = alignPut a b (const ka) (const kb) eqk p rcv create put

alignPut :: (Eq a,Eq b) => Type a -> Type b -> (Int -> Env -> a -> k1) -> (Int -> Env -> b -> k2) -> (k1 -> k2 -> Bool) -> (a -> Bool) -> (Env -> a -> Maybe a)
         -> Maybe (Env -> b -> a) -> EnvPutlensM a b -> EnvPutlensM [a] [b]
alignPut a b ka kb eqk p rcv create put = runStatePut recoverOld (filterWithPut p .< mapAlignPut a b ka kb eqk rcv create put)
	where recoverOld Nothing v = recoverOld (Just []) v
	      recoverOld (Just s) v = return $ recoverOld' s v
	      recoverOld' (s@(p -> True):ss) (v:vs) = Nothing : recoverOld' ss vs
	      recoverOld' (s@(p -> False):ss) vs = Just s : recoverOld' ss vs
	      recoverOld' ss [] = map Just (filter (not . p) ss)
	      recoverOld' [] vs = replicate (length vs) Nothing

-- the state has a pattern with 'holes' for the new source
filterWithPut :: (Monad m,Eq a) => (a -> Bool) -> PutlensStateM m [Maybe a] [a] [a]
filterWithPut p = ifthenelsePut (\s v -> liftM hasSome State.get) (phiPut hasHead .< consPut .< (idPut ><< filterWithPut p) .< recoverPut) iteratePut
	where
	hasHead (s:ss) = not (p s)
	hasHead _ = False
	hasSome (Just s:ss) = True
	hasSome _ = False
	recoverPut = addfstPut (\s v -> State.get >>= \(Just s:ss) -> State.put ss >> return s)
	iteratePut = withStatePut (\s v st -> return $ tailSafe st) (innPut .< (idPut -|-< idPut ><< filterWithPut p) .< outPut)

-- matching conditions take the current position and the current element and return some result
mapAlignPut :: (Eq a,Eq b) => Type a -> Type b -> (Int -> Env -> a -> k1) -> (Int -> Env -> b -> k2) -> (k1 -> k2 -> Bool) -> (Env -> a -> Maybe a)
            -> Maybe (Env -> b -> a) -> EnvPutlensM a b -> PutlensStateM EnvM [Maybe a] [a] [b]
mapAlignPut a b ka kb eqk rcv create put = runReaderPut matchSV (mapPut (modifyS alignedS $ liftPutlensM $ liftPutlensM put))
	where alignedS s v = ask >>= \ms -> return $ lookup v ms
	      matchSV Nothing v = matchSV (Just []) v
	      matchSV (Just s) v = matchSV' (zip [1..] s) (zip [1..] v)
	      matchSV' ss [] = do -- try to recover unmatched source list
			env <- lift State.get
			recs <- State.get
			State.put $ foldr (\(i,s) l -> case rcv env s of { Just s' -> Just s':l; Nothing -> l }) [] ss ++ recs
			return []
	      matchSV' ss ((iv,v):vs) = do
			env <- lift State.get
			case find (\(is,s) -> ka is env s `eqk` kb iv env v) ss of
				Nothing -> do -- view does not have a source match
					rs <- matchSV' ss vs
					case create of -- if we don't have a create function, there is no binding
						Nothing -> return $ rs
						Just cr -> return $ (v,cr env v):rs
				Just (is,s) -> do -- view has a source match
					rs <- matchSV' (delete (is,s) ss) vs
					return $ (v,s):rs

listOneEqPut :: Monad m => PutlensM m [()] ()
listOneEqPut = innPut .< (idPut -|-< (idPut ><< listOneEqPut) .< addsndOnePut) .< injlsPut

listEqPut :: (Monad m,Eq a) => PutlensM m [a] a
listEqPut = consPut .< listEqPut'
	where listEqPut' = (idPut ><< innPut) .< undistrPut .< (addsndOnePut -|-< (idPut ><< listEqPut') .< addsndPut (\e v -> return v)) .< injlsPut

-- monoid append for non-empty lists
mappend1Put :: (Monad m,Eq a) => PutlensM m (a,a) a -> PutlensM m [a] a
mappend1Put plus = consPut .< listEqPut'
	where listEqPut' = (idPut ><< innPut) .< undistrPut .< (addsndOnePut -|-< (idPut ><< listEqPut') .< plus) .< injlsPut

-- | reverses a putlens by using its create and get functions, although this might be HIGHLY unsafe.
-- only used for one of the steps of the subtyping algorithm for which the authors prove to be OK
unsafeInvPut :: (Monad m,Eq s,Eq v) => String -> Putlens s v -> PutlensM m v s
unsafeInvPut err f = customPut (\s -> return . Putlens.get l) (simplecreate l)
    where l = put2quicklensNoGetPutErr ("unsafeInvPut: "++err) f

-- this is not a real lens on Haskell datatypes, but it is for regular expressions: "()" has the same elements as "()*", although [()] in Haskell represents naturals and () a unit type
listOneREPut :: Monad m => PutlensM m () [()]
listOneREPut = PutlensM getput' create'
    where getput' s = (Just [],create')    
          create' v' = onPutGet $ return ()

-- this is not a real lens on Haskell datatypes, but it is for regular expressions: "r" has the same elements as "r|r", although Either r r in Haskell represents choices and r a single choice
eitherREPut :: Monad m => PutlensM m (Either s s) v -> PutlensM m s v
eitherREPut f = PutlensM getput' (create' (createM f))
    where getput' s | dom f (Left s) = let (v1,put1) = getputM f (Left s) in (v1,create' put1)
                    | dom f (Right s) = let (v1,put1) = getputM f (Right s) in (v1,create' put1)
                    | otherwise = (Nothing,create' (createM f))
          create' put' v = onPutGet $ liftM (either id id) (put' v)

keepDefPut :: Monad m => Type a -> PutlensM m a ()
keepDefPut t = pntPut f
    where f Nothing = return $ defvalue t
          f (Just s) = return s

keepfstDefPut :: (Monad m,Eq b) => Type a -> PutlensM m (a,b) b
keepfstDefPut t = addfstPut f
    where f Nothing v = return $ defvalue t
          f (Just (a,b)) v = return a
	
keepsndDefPut :: (Monad m,Eq a) => Type b -> PutlensM m (a,b) a
keepsndDefPut t = addsndPut f
    where f Nothing v = return $ defvalue t
          f (Just (a,b)) v = return b

castToInt :: Type a -> (a -> Int)
castToInt Int = id
castToInt Float = fromEnum
castToInt Bool = \b -> if b then 1 else 0
castToInt String = read . unStr
castToInt _ = error "unsupported cast to Int"

uncastFromInt :: Type a -> (Int -> a)
uncastFromInt Int = id
uncastFromInt Float = toEnum
uncastFromInt Bool = (==0)
uncastFromInt String = Str . show
uncastFromInt _ = error "unsupported cast to Int"

castToFloat :: Type a -> (a -> Float)
castToFloat Int = toEnum
castToFloat Float = id
castToFloat Bool = \b -> if b then 1 else 0
castToFloat String = read . unStr
castToFloat _ = error "unsupported cast to Float"

uncastFromFloat :: Type a -> (Float -> a)
uncastFromFloat Int = fromEnum
uncastFromFloat Float = id
uncastFromFloat Bool = (==0)
uncastFromFloat String = Str . show
uncastFromFloat _ = error "unsupported uncast from Float"

undynPut :: (Monad m,Eq a) => Type a -> PutlensM m a Dynamic
undynPut t = customPut put get
    where put s d = return $ unDyn t d
          get s = mkDyn t s

dynPut :: (Monad m,Eq a) => Type a -> PutlensM m Dynamic a
dynPut t = customPut put get
    where put s v = return $ mkDyn t v
          get d = unDyn t d

castStringPut :: (Monad m,Eq a,Read a,Show a) => PutlensM m String a
castStringPut = customPut put get
    where put s a = return $ show a
          get s = read s

uncastStringMaybePut :: (MonadPlus m,Read a,Show a) => PutlensM m a String
uncastStringMaybePut = PutlensM getputM createM
    where createM v = case readMay v of { Just s -> return s; Nothing -> fail "failed to cast string" }
          getputM s = (Just $ show s,createM)

joinBiasPut :: (Monad m,Eq a) => Bool -> PutlensM m (Either [a] [a]) [a]
joinBiasPut bias = if bias then injlsPut else injrsPut

joinByPut :: (Monad m,Eq a) => (a -> Bool) -> PutlensM m (Either [a] [a]) [a]
joinByPut p = runReaderPutMbS $ ifthenelsePut (\s v -> ask >>= \e -> return $ tag e v) (injlPut .< phiPut (tag Nothing)) injrPut
    where tag Nothing [] = True
          tag (Just s) [] = isLeft s
          tag _ (x:xs) = p x

isLeft = either (const True) (const False)
isRight = either (const False) (const True)

concatStringWithSepPut :: Monad m => String -> PutlensM m [String] String
concatStringWithSepPut sep = unfoldrPut (appendStringWithSepPut sep) ""

appendStringWithSepPut :: Monad m => String -> PutlensM m (String,String) String
appendStringWithSepPut sep = customPut put get
    where get (s1,s2) = s1 ++ sep ++ s2
          put _ v = maybe (fail "appendStringWithSep") return $ do
          	let toks = splitOn sep v
          	xs <- initMay toks
          	x <- lastMay toks
          	return (concat xs,x)

appendLeftPut i = appendPutN (\e v -> i)
appendRightPut i = appendPutN (\e v -> length v - i)

appendPutN :: (Monad m,Eq a) => (Maybe ([a],[a]) -> [a] -> Int) -> PutlensM m ([a],[a]) [a]
appendPutN f = runStatePut (\s v -> return $ f s v) appendPutN'
appendPutN' :: (Monad m,Eq a) => PutlensStateM m Int ([a],[a]) [a]
appendPutN' = (innPut ><< idPut) .< undistlPut .< (addfstOnePut -|-< rec) .< ifVthenelsePut null injlPut (injPut (\_ _ -> liftM (==0) State.get))
	where rec = withStatePut (\_ _ st -> return $ pred st) (assoclPut .< (idPut ><< appendPutN') .< unconsPut)

appendBiasPut :: (Monad m,Eq a) => Int -> Int -> Maybe Int -> Maybe Int -> PutlensM m ([a],[a]) [a]
appendBiasPut minleft minright maxleft maxright = appendPutN split
    where split Nothing v = ensureBounds v (length v `div` 2)
          split (Just (xs,ys)) v | geqMaxs maxleft maxright = ensureBounds v (length xs)
	                             | otherwise = ensureBounds v (length v - length ys)
          ensureMins v x = if x < minleft then minleft else if x > length v - minright then length v - minright else x
          ensureMaxs v x = if isJust maxleft && x > maxl then maxl else if isJust maxright && x < length v - maxr then length v - maxr else x
             where  maxl = fromJust maxleft
                    maxr = fromJust maxright
          ensureBounds v x = ensureMaxs v (ensureMins v x)

appendByPut :: (Monad m,Eq a) => (a -> Bool) -> PutlensM m ([a],[a]) [a]
appendByPut p = catPutP (\x -> return . p)

appendPut :: (Monad m,Eq a) => PutlensM m ([a],[a]) [a]
appendPut = (innPut ><< idPut) .< undistlPut .< (addfstOnePut -|-< assoclPut .< (idPut ><< appendPut) .< unconsPut) .< choiceNil
	where choiceNil = ifVthenelsePut null injlPut injrsPut

concatPut :: (Monad m,Eq a) => PutlensM m [[a]] [a]
concatPut = concatWithPut appendPut

concatPosPut :: (Monad m,Eq a) => Int -> PutlensM m [[a]] [a]
concatPosPut i = concatWithPut (appendLeftPut i)

-- ranges of the list, ranges of sub-list elements
concatBiasPut :: (Monad m,Eq a) => Int -> Maybe Int -> Int -> Maybe Int -> PutlensM m [[a]] [a]
concatBiasPut ymin ymax xmin xmax = runStatePut split $ concatWithPut (appendConcatBiasPut xmin xmax)
    where split Nothing v = return $ ensureMinMax 1
          split (Just s) v = return $ ensureMinMax (length s)
          ensureMinMax x = if x < ymin then ymin else if isJust ymax && x > fromJust ymax then fromJust ymax else x

appendConcatBiasPut :: (Monad m,Eq a) => Int -> Maybe Int -> PutlensStateM m Int ([a],[a]) [a]
appendConcatBiasPut xmin xmax = withStatePut (\_ _ st -> return (pred st)) $ ifthenelsePut (\e v -> liftM (==0) State.get) (phiPut (null . snd) .< addsndPut (\e v -> return [])) (appendBiasPut xmin 0 xmax Nothing)

concatWithPut :: (Monad m,Eq a) => PutlensM m ([a],[a]) [a] -> PutlensM m [[a]] [a]
concatWithPut cat = innPut .< (unnilPut -|-< (idPut ><< concatWithPut cat) .< cat) .< ifVthenelsePut null injlPut injrsPut

type Last = Pos

filterWithPosPut :: (Monad m,Eq a) => (Last -> (Pos,a) -> Bool) -> PutlensM m [a] [a]
filterWithPosPut p = insertPositionsPut .< runReaderPutS (runStatePut firstSt $ paramsndPut (\li -> filterPositionsPut li p .< deletePositionsPut li p) .< addsndPut updateLast)
    where firstSt (Just (s,li)) v = return (0,Nothing,filter (not . p li) s)
          updateLast s v = State.get >>= \(_,_,rs) -> return $ length v + length rs

filterPositionsPut :: (Monad m,Eq a) => Last -> (Last -> (Pos,a) -> Bool) -> PutlensStateM m (Pos,Maybe a,[(Pos,a)]) [(Pos,a)] [(Pos,a)]
filterPositionsPut li p = withStatePut updSt (ifthenelsePut (\_ _ -> State.get >>= \(_,x,_) -> return $ isJust x) recover it)
    where recover = consPut .< phiPut cond .< (idPut ><< filterPositionsPut li p) .< addfstPut (\_ _ -> State.get >>= \(i,Just x,_) -> return (i,x))
          it = innPut .< (idPut -|-< idPut ><< filterPositionsPut li p) .< outPut
          cond ((i,x),xs) = not (p li (i,x))
          updSt _ vs (i,_,xs) = return $ recoverEntry i xs vs

recoverEntry :: Pos -> [(Pos,a)] -> [(Pos,a)] -> (Pos,Maybe a,[(Pos,a)])
recoverEntry p [] _ = (succ p,Nothing,[])				-- empty state
recoverEntry p ((i,x):xs) [] = (succ p,Just x,xs)		-- when the view is empty
recoverEntry p s@((i,x):xs) ((j,v):vs)
	| j == succ p = (j,Nothing,s)
	| i == succ p = (i,Just x,xs)
	| otherwise = (succ p,Just x,xs)

insertPositionsPut :: (Monad m,Eq a) => PutlensM m [a] ([(Pos,a)],Last)
insertPositionsPut = remsndPut (const 1) .< insertPositionsPut' .< (idPut ><< succPut)

insertPositionsPut' :: (Monad m,Eq a) => PutlensM m ([a],Pos) ([(Pos,a)],Last)
insertPositionsPut' = (innPut ><< idPut) .< undistlPut .< (idPut -|-< it) .< distlPut .< (outPut ><< idPut)
    where it = (idPut ><< remsndPut succ) .< distpPut .< (swapPut ><< insertPositionsPut') .< assocrPut

deletePositionsPut :: (Monad m,Eq a) => Last -> (Last -> (Pos,a) -> Bool) -> PutlensStateM m (Pos,Maybe a,[(Pos,a)]) [(Pos,a)] [a]
deletePositionsPut li p = runStatePut firstSt (deletePositionsPut' li p)
    where firstSt e v = State.get >>= \(_,_,rs) -> return (0,rs)

deletePositionsPut' :: (Monad m,Eq a) => Last -> (Last -> (Pos,a) -> Bool) -> PutlensStateM m (Pos,[(Pos,a)]) [(Pos,a)] [a]
deletePositionsPut' li p = innPut .< (idPut -|-< withStatePut newPos (addfstPut getPos) ><< deletePositionsPut' li p) .< outPut
    where newPos e v (i,[]) = return (succ i,[])
          newPos e v (i,(r,x):rs) = let j = succ i in if j == r && not (p li (r,x)) then newPos e v (j,rs) else return (j,(r,x):rs)
          getPos e v = liftM fst State.get

addMaxs Nothing Nothing = Nothing
addMaxs Nothing (Just y) = Nothing
addMaxs (Just x) Nothing = Nothing
addMaxs (Just x) (Just y) = Just (x + y)

geqMaxs Nothing _ = True
geqMaxs (Just x) Nothing = False
geqMaxs (Just x) (Just y) = x >= y

multMaxs Nothing Nothing = Nothing
multMaxs Nothing (Just y) = Nothing
multMaxs (Just x) Nothing = Nothing
multMaxs (Just x) (Just y) = Just (x * y)

















