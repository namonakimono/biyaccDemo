module Text.XML.BiFluX.Generic.Rewrite where
	
import Text.XML.HaXml.DtdToHaskell.TypeDef hiding (List)
import Text.XML.BiFluX.DTD.Type
import Control.Monad
import Control.Monad.Identity
import Control.Monad.State (State,MonadState,StateT)
import qualified Control.Monad.State as State
import Control.Monad.Reader (Reader,MonadReader,ReaderT)
import qualified Control.Monad.Reader as Reader
import Text.XML.BiFluX.Lenses.View
import Generics.Putlenses.Putlens
import GHC.InOut
	
data Rewrite rwm a where
	Rewrite :: (Monad rwm,Eq b) => rwm (a -> b) -> Type b -> Rewrite rwm a

type Rewrite' a = Rewrite Identity a

type RRule m rwm a = Type a -> m (Rewrite rwm a)
type RRuleT m rwm = forall a . Eq a => RRule m rwm a

nopR :: (MonadPlus m,Monad rwm) => RRuleT m rwm
nopR a = return $ Rewrite (return id) a

delR :: (MonadPlus m,Monad rwm) => RRuleT m rwm
delR a = return $ Rewrite (return $ const ()) One

childrenR :: (MonadPlus m,Monad rwm) => RRuleT m rwm -> RRuleT m rwm
childrenR r (Data (Name n _) a) = do
	Rewrite g b <- r a
	return $ Rewrite (liftM2 (.) g (return out)) (Tag n b)
childrenR r (Tag n@(isAtt -> False) a) = do
	Rewrite g b <- r a
	return $ Rewrite g (Tag n b)
childrenR r a = nopR a

untagR :: (MonadPlus m,Monad rwm) => RRuleT m rwm
untagR (getVAttEl' -> Just (_,View' lns a)) = return $ Rewrite (return $ get lns) a

-- iterates over a child list
gmapR :: (MonadPlus m,Monad rwm) => RRuleT m rwm -> RRuleT m rwm
gmapR r (getLiteral -> Just a) = r a
gmapR r One = nopR One
gmapR r a@(isAttEl -> True) = r a
gmapR r (Prod a b) = do
	Rewrite f a' <- gmapR r a
	Rewrite g b' <- gmapR r b
	return $ Rewrite (liftM2 (><) f g) (Prod a' b')
gmapR r (Either a b) = do
	Rewrite f a' <- gmapR r a
	Rewrite g b' <- gmapR r b
	return $ Rewrite (liftM2 (-|-) f g) (Either a' b')
gmapR r (List a) = do
	Rewrite f a' <- gmapR r a
	return $ Rewrite (liftM map f) (List a')
gmapR r a = error $ "gmapR undefined for" ++ show a

seqR :: (MonadPlus m,Monad rwm) => RRuleT m rwm -> RRuleT m rwm -> RRuleT m rwm
seqR r s a = do
	Rewrite f b <- r a
	Rewrite g c <- s b
	return $ Rewrite (liftM2 (.) g f) c

infix 7  ><
(f >< g) (x,y) = (f x,g y)
infix 5 -|-
f -|- g = either (Left . f) (Right . g)
