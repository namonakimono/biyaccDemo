{-# LANGUAGE DeriveGeneric #-}
module Books where

import Text.XML.HaXml.XmlContent hiding (List1)
import Text.XML.HaXml.Types
import Text.XML.PutXML.DTD.TypeDef
import Text.XML.PutXML.DTD.Type
import Text.XML.HaXml.DtdToHaskell.TypeDef (Name(..))
import GHC.Generics


newtype Books = Books [Vbook] 		deriving (Eq,Show,Generic)
data Vbook = Vbook Vtitle Vprice
           deriving (Eq,Show,Generic)
newtype Vtitle = Vtitle String 		deriving (Eq,Show,Generic)
newtype Vprice = Vprice String 		deriving (Eq,Show,Generic)
instance HTypeable Books where
    toHType x = Defined "books" [] []
instance XmlContent Books where
    toContents (Books a) =
        [CElem (Elem (N "books") [] (concatMap toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["books"]
        ; interior e $ return (Books) `apply` many parseContents
        } `adjustErr` ("in <books>, "++)
instance HTypeable Vbook where
    toHType x = Defined "vbook" [] []
instance XmlContent Vbook where
    toContents (Vbook a b) =
        [CElem (Elem (N "vbook") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["vbook"]
        ; interior e $ return (Vbook) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <vbook>, "++)
instance HTypeable Vtitle where
    toHType x = Defined "vtitle" [] []
instance XmlContent Vtitle where
    toContents (Vtitle a) =
        [CElem (Elem (N "vtitle") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["vtitle"]
        ; interior e $ return (Vtitle) `apply` (text `onFail` return "")
        } `adjustErr` ("in <vtitle>, "++)
instance HTypeable Vprice where
    toHType x = Defined "vprice" [] []
instance XmlContent Vprice where
    toContents (Vprice a) =
        [CElem (Elem (N "vprice") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["vprice"]
        ; interior e $ return (Vprice) `apply` (text `onFail` return "")
        } `adjustErr` ("in <vprice>, "++)
instance Typeable Books where
    typeof = Data (Name "books" "Books") typeof
instance Typeable Vbook where
    typeof = Data (Name "vbook" "Vbook") typeof
instance Typeable Vtitle where
    typeof = Data (Name "vtitle" "Vtitle") typeof
instance Typeable Vprice where
    typeof = Data (Name "vprice" "Vprice") typeof
