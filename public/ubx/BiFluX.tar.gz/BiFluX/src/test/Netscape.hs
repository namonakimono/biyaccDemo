{-# LANGUAGE DeriveGeneric #-}
module Netscape where

import Text.XML.HaXml.XmlContent hiding (List1)
import Text.XML.HaXml.Types
import Text.XML.PutXML.DTD.HaXml.TypeDef
import Text.XML.PutXML.DTD.Type
import Text.XML.HaXml.DtdToHaskell.TypeDef (Name(..))
import GHC.Generics


data Html = Html Head Body
          deriving (Eq,Show,Generic)
newtype Head = Head String 		deriving (Eq,Show,Generic)
data Body = Body H1 Dl
          deriving (Eq,Show,Generic)
newtype H1 = H1 String 		deriving (Eq,Show,Generic)
newtype H3 = H3 String 		deriving (Eq,Show,Generic)
newtype Dl = Dl [(Either Dt Dd)] 		deriving (Eq,Show,Generic)
newtype Dl1 = Dl1 [(Either Dt Dd1)] 		deriving (Eq,Show,Generic)
newtype Dt = Dt A 		deriving (Eq,Show,Generic)
data A = A A_Attrs String
       deriving (Eq,Show,Generic)
data A_Attrs = A_Attrs
    { aHref :: String
    } deriving (Eq,Show,Generic)
data Dd = Dd H3 Dl deriving (Eq,Show,Generic)
data Dd1 = Dd1 H3 Dl1 deriving (Eq,Show,Generic)
instance HTypeable Html where
    toHType x = Defined "html" [] []
instance XmlContent Html where
    toContents (Html a b) =
        [CElem (Elem (N "html") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["html"]
        ; interior e $ return (Html) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <html>, "++)
instance HTypeable Head where
    toHType x = Defined "head" [] []
instance XmlContent Head where
    toContents (Head a) =
        [CElem (Elem (N "head") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["head"]
        ; interior e $ return (Head) `apply` (text `onFail` return "")
        } `adjustErr` ("in <head>, "++)
instance HTypeable Body where
    toHType x = Defined "body" [] []
instance XmlContent Body where
    toContents (Body a b) =
        [CElem (Elem (N "body") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["body"]
        ; interior e $ return (Body) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <body>, "++)
instance HTypeable H1 where
    toHType x = Defined "h1" [] []
instance XmlContent H1 where
    toContents (H1 a) =
        [CElem (Elem (N "h1") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["h1"]
        ; interior e $ return (H1) `apply` (text `onFail` return "")
        } `adjustErr` ("in <h1>, "++)
instance HTypeable H3 where
    toHType x = Defined "h3" [] []
instance XmlContent H3 where
    toContents (H3 a) =
        [CElem (Elem (N "h3") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["h3"]
        ; interior e $ return (H3) `apply` (text `onFail` return "")
        } `adjustErr` ("in <h3>, "++)
instance HTypeable Dl where
    toHType x = Defined "dl" [] []
instance XmlContent Dl where
    toContents (Dl a) =
        [CElem (Elem (N "dl") [] (concatMap toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["dl"]
        ; interior e $ return (Dl) `apply` many parseContents
        } `adjustErr` ("in <dl>, "++)
instance HTypeable Dt where
    toHType x = Defined "dt" [] []
instance XmlContent Dt where
    toContents (Dt a) =
        [CElem (Elem (N "dt") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["dt"]
        ; interior e $ return (Dt) `apply` parseContents
        } `adjustErr` ("in <dt>, "++)
instance HTypeable A where
    toHType x = Defined "a" [] []
instance XmlContent A where
    toContents (A as a) =
        [CElem (Elem (N "a") (toAttrs as) (toText a)) ()]
    parseContents = do
        { e@(Elem _ as _) <- element ["a"]
        ; interior e $ return (A (fromAttrs as))
                       `apply` (text `onFail` return "")
        } `adjustErr` ("in <a>, "++)
instance XmlAttributes A_Attrs where
    fromAttrs as =
        A_Attrs
          { aHref = definiteA fromAttrToStr "a" "href" as
          }
    toAttrs v = catMaybes 
        [ toAttrFrStr "href" (aHref v)
        ]
instance HTypeable Dd where
    toHType x = Defined "dd" [] []
instance XmlContent Dd where
    toContents (Dd a b) =
        [CElem (Elem (N "dd") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["dd"]
        ; interior e $ return (Dd) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <dd>, "++)
instance Typeable Html where
    typeof = Data (Name "html" "Html") typeof
instance Typeable Head where
    typeof = Data (Name "head" "Head") typeof
instance Typeable Body where
    typeof = Data (Name "body" "Body") typeof
instance Typeable H1 where
    typeof = Data (Name "h1" "H1") typeof
instance Typeable H3 where
    typeof = Data (Name "h3" "H3") typeof
instance Typeable Dl where
    typeof = Data (Name "dl" "Dl") typeof
instance Typeable Dl1 where
    typeof = Data (Name "dl" "Dl1") typeof
instance Typeable Dt where
    typeof = Data (Name "dt" "Dt") typeof
instance Typeable A where
    typeof = Data (Name "a" "A") typeof
instance Typeable A_Attrs where
    typeof = Data (Name "@" "A_Attrs") (Tag "@href" typeof)
instance Typeable Dd where
    typeof = Data (Name "dd" "Dd") typeof
instance Typeable Dd1 where
    typeof = Data (Name "dd" "Dd1") typeof
