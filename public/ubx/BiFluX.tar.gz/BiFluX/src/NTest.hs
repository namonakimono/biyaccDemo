module NTest where
import System.IO
import System.Environment
import Text.XML.BiFluX.Update.Parser
import Text.ParserCombinators.Parsec
import Text.XML.BiFluX.Update.Token

main = do
--  args <- getArgs
--  file <- readFile (args !! 1)
--  program <- readFile "../Test/bookmark/bookmark.upd"
--  program <- readFile "../Test/people/people.upd"
--  program <- readFile "../Test/people/people2.upd"
--  program <- readFile "../Test/nestedsections/sections.upd"
--  program <- readFile "../Test/nestedsections/sections2.upd"
--  program <- readFile "../Test/addrbook/addrbook.upd"
--  program <- readFile "../Test/constructor/uC.upd"
--  program <- readFile "../Test/delta/uDelta.upd"
  program <- readFile "../Test/bookstore/bookstore.upd"
  let tokenLst = parse t "" program
  putStrLn $ show tokenLst
  putStrLn "------------------------------"
  case tokenLst of
    Left err -> putStrLn "token err"
    Right tokLst ->  putStrLn $ show (nParser (tokLst))
