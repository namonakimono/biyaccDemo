module UI.BiFluX.GenHaskell where

import UI.BiFluX.Menu
import Text.XML.BiFluX.Update.AST
import Text.XML.HaXml.Parse
import Text.XML.HaXml.DtdToHaskell.TypeDef hiding (ppTypeDef,mangle)
import Text.XML.BiFluX.DTD.HaXml.TypeDef
import Text.XML.HaXml.DtdToHaskell.Convert
import Text.XML.HaXml.Types hiding (Name)
import Data.List
import GHC.Generics
import GHC.InOut
import Control.Monad
import Unsafe.Coerce
import Text.PrettyPrint.HughesPJ
import System.IO
import Data.Maybe
import Text.XML.HaXml.Namespaces
import Data.Generics.TH
import Text.XML.BiFluX.DTD.TypeDecl

-- | DTD file, Haskell file to be generate
generateHaskellDTD :: FilePath -> FilePath -> IO ()
generateHaskellDTD dtd hs = do
    content <- readFile dtd
    DTD name _ markup <- run "No DTD in this document" (dtdParse dtd content)
    out <- openFile hs WriteMode
    -- Write Headers
    let realname = mangle (trim hs)
    hPutStrLn out (
      "{-# LANGUAGE DeriveGeneric #-}\n"++
      "module "++realname++" where\n\n"++
      "import Data.Map (Map(..))\n"++
      "import qualified Data.Map as Map\n"++
      "import Text.XML.HaXml.XmlContent hiding (List1)\n"++
      "import Text.XML.HaXml.Types\n"++
      "import Text.XML.BiFluX.DTD.HaXml.TypeDef\n"++
      "import Text.XML.BiFluX.DTD.Type\n"++
      "import Text.XML.HaXml.DtdToHaskell.TypeDef (Name(..))\n"++
      "import Control.Monad\n"++
      "import GHC.Generics as Generics\n\n"++
	  "type EMPTY = ()\n\n") -- declares the special DTD empty type
    let dtdDecls = (sortAtts . nub . dtd2TypeDef) markup
    -- Write datatype definitions
    let hsDefs = map (ppTypeDef realname) dtdDecls
    mapM (hPutStrLn out . render) hsDefs
    -- Write instances
    mapM (hPutStrLn out . render . mkInstance realname) dtdDecls
    mapM (hPutStrLn out . render . mkTypeable realname) dtdDecls
    hPutStrLn out ""
    hPutStrLn out $ render $ mkTypeEnv realname dtdDecls
    hClose out

-- ensures that attribute lists are sorted
sortAtts :: [TypeDef] -> [TypeDef]
sortAtts xs = $(everywhere (mkT 'f) [t| [TypeDef] |]) xs
    where f :: AttrFields -> AttrFields
          f = sortBy (\(Name x1 h1,_) (Name x2 h2,_) -> compare x1 x2)

-- | Takes a BiFluX program and generates an Haskell file with type declarations
generateHaskellBX :: Program -> FilePath -> IO ()
generateHaskellBX prog@(Program imps _ _ _) hs = do
	let realname = mangle (trim hs)
	out <- openFile hs WriteMode
	hPutStrLn out (
	  "module Main where\n\n"++
	  "import Data.Map (Map(..))\n"++
	  "import qualified Data.Map as Map\n"++
	  "import Text.XML.HaXml.XmlContent hiding (List,List1,String)\n"++
	  "import Text.XML.HaXml.Types\n"++
	  "import Text.XML.BiFluX.DTD.HaXml.TypeDef\n"++
	  "import Text.XML.HaXml.DtdToHaskell.TypeDef (Name(..))\n"++
	  "import Control.Monad\n"++
	  "import UI.BiFluX.LensMenu\n"++
	  "import Generics.Putlenses.Putlens\n"++
	  "import Text.XML.BiFluX.DTD.Type hiding (Equal(..))\n"++
	  "import Text.XML.BiFluX.Update.AST\n"++
	  "import Text.XML.BiFluX.Update.UpdateToCore\n"++
	  "import Text.XML.BiFluX.Update.CoreToLenses\n"++
	  "import Text.XML.HaXml.DtdToHaskell.TypeDef hiding (ppTypeDef,mangle,List,Any,String)\n"++
	  "import Text.XML.HaXml.ShowXmlLazy\n"++
	  "import Text.XML.HaXml.Namespaces\n"++
	  "import Text.XML.HaXml.DtdToHaskell.Convert\n"++
	  "import Text.XML.BiFluX.XQuery.UXQ\n"++
	  "import Text.XML.BiFluX.XPath.HXT.XPathDataTypes\n"++
	  "import Text.XML.HXT.DOM.QualifiedName\n"++
	  "\n") -- declares the special DTD empty type
	hPutStrLn out (render $ generateImports imps)
	hPutStrLn out ""
	hPutStrLn out (render $ mkBXTypeEnv prog)
	hPutStrLn out ""
	generateSourceViewTypes out prog
	hPutStrLn out ""
	hPutStrLn out (render $ text "ast" <+> text "=" <+> text (show prog))
	hPutStrLn out ""
	hPutStrLn out (render $ text "main" <+> text "=" <+> text "lensmenu" <+> text "sourceType" <+> text "viewType" <+> text "Main.typeEnv" <+> text "ast")
	hClose out

generateImports :: [ImportSchema] -> Doc
generateImports [] = text ""
generateImports (Import hs n:xs) = text "import" <+> text (mangle (trim hs)) <> text "\n" <> generateImports xs

generateSourceViewTypes :: Handle -> Program -> IO ()
generateSourceViewTypes out (Program imps _ (Start top _) decls) = do
	let modnames = impschemas2modnames imps
	(Procedure _ vars _) <- run "no top-level procedure?" $ findProcedureDecl top decls
	let ([(svar,stype)],[(vvar,vtype)],[]) = splitProcVars vars -- the top-level procedure must exactly have one source argument and one view argument
	hPutStrLn out (render $ generateSourceType modnames stype)
	hPutStrLn out (render $ generateViewType modnames vtype)
	
generateSourceType :: ModNames -> AstType -> Doc
generateSourceType names t = text "sourceType" <+> text "=" <+> astType2doc names t
generateViewType :: ModNames -> AstType -> Doc
generateViewType names t = text "viewType" <+> text "=" <+> astType2doc names t


