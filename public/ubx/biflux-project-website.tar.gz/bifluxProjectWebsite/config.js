
module.exports = {
    biflux : '/home/stefanzan/.cabal/bin/BiFluX',
    ghc : '/usr/local/bin/ghc',
}