    var peopleSourceXML = "<people>\n	<person>\n		<name>Hugo</name>\n		<city>Tokyo</city>\n	</person>\n	<person>\n		<name>Sebastian</name>\n		<city>Kiel</city>\n	</person>\n	<person>\n		<name>Zhenjiang</name>\n		<city>Tokyo</city>\n	</person>\n</people>";
    var peopleTargetXML = "<fromtokyo>\n	<name>Zan</name>\n	<name>Zhenjiang</name>\n</fromtokyo>";

    var bookmarkSourceXML = "<html>\n     <head>My Bookmarks</head>\n     <body>\n	<h1>my bookmarks</h1>\n	<dl>\n	  <dt><a href=\"foo.com\">Foo\'s</a></dt>\n	  <dd><h3>my folder</h3>\n	      <dl>\n		<dt><a href=\"stefanzan.com\">stefanzan</a></dt>\n	      </dl>\n	  </dd>\n	  <dt><a href=\"bar.edu\">Bar\'s</a></dt>\n	</dl>\n     </body>\n</html>";
    var bookmarkTargetXML = "<xbel>\n  <title>NII bookmarks</title>\n  <folder><title>National Institute of Informatics</title>\n     <bookmark href=\"http://www.nii.ac.jp/en\"><title>English</title></bookmark>\n	 <bookmark href=\"http://www.nii.ac.jp\"><title>Japanese</title></bookmark>\n  </folder>\n  <folder><title>my folder</title>\n  	 <bookmark href=\"stefanzan.com\"><title>stefanzan</title></bookmark>\n  </folder>\n  <bookmark href=\"bar.edu\"><title>Bar\'s</title></bookmark>\n</xbel>";

    var nestedSourceXML = "<sections>\n	<section>\n		<title>Grand Tours</title>\n		<paragraph>The grand tours are major cycling races...</paragraph>\n		<subsection>\n			<title>Giro dItalia</title>\n			<paragraph>The Giro is usually held in May and June...</paragraph>\n		</subsection>\n	</section>\n	<section>\n		<title>Classics</title>\n		<paragraph>The classics are one-day cycling races...</paragraph>\n		<subsection>\n			<title>Milan-San Remo</title>\n			<paragraph>The Spring classic is held in March...</paragraph>\n		</subsection>\n	</section>\n</sections>";
    var nestedTargetXML = "<secs>\n	<sec title='Classics'>\n		<subsec title='Paris-Roubaix'/>\n	</sec>\n	<sec title='Olympic Competitions'>\n		<subsec title='2008 Summer Olympics'/>\n		<subsec title='2012 Summer Olympics'/>\n	</sec>\n	<sec title='Grand Tours'>\n		<subsec title='Milan-San Remo'/>\n		<subsec title='Giro dItalia'/>\n		<subsec title='Tour de France'/>\n	</sec>\n</secs>";


    var addrSourceXML = "<addrbook>\n	<person>\n  		<name>Masato Takeichi</name>\n		<email>takeichi@acm.org</email>\n		<email>takeichi@i.u-tokyo.ac.jp</email>\n		<tel>+81-3-5841-7430</tel>\n	</person>\n	<person>\n		<name>Zhenjiang Hu</name>\n		<email>hu@mist.i.u-tokyo.ac.jp</email>\n		<email>hu@ipl.t.u-tokyo.ac.jp</email>\n		<tel>+81-3-5841-7411</tel>\n    </person>\n    <person>\n		<name>Shin-Cheng Mu</name>\n		<email>scm@mist.i.u-tokyo.ac.jp</email>\n		<email>scm@sinica.cl</email>\n		<tel>+81-3-5841-7411</tel>\n    </person>\n</addrbook>";
    var addrTargetXML = "<addrbook>\n	<index>\n		<name>Zhenjiang Hu</name>\n		<name>Hugo Pacheco</name>\n		<name>Masato Takeichi</name>\n	</index>\n	<person>\n		<name>Zhenjiang Hu</name>\n		<email>hu@nii.ac.jp</email>\n	</person>\n	<person>\n		<name>Hugo Pacheco</name>\n		<email>hpacheco@nii.ac.jp</email>\n	</person>\n	<person>\n		<name>Masato Takeichi</name>\n		<email>takeichi@acm.org</email>\n	</person>\n</addrbook>";

    var bstoreSourceXML = "<bookstore>\n <book category='Food'>\n   <title >Everyday Italian</title>\n   <author>Giada De Laurentiis</author>\n   <year>2005</year>\n   <price>30.00</price>\n </book>\n <book>\n   <title >Harry Potter</title>\n   <author>J K. Rowling</author>\n   <year>2005</year>\n   <price>29.99</price>\n </book>\n <book category='Programming'>\n   <title >XQuery Kick Start</title>\n   <author>James McGovern</author>\n   <author>Per Bothner</author>\n   <author>Kurt Cagle</author>\n   <author>James Linn</author>\n   <author>Vaidyanathan Nagarajan</author>\n   <year>2003</year>\n   <price>49.99</price>\n </book>\n <book category='Programming'>\n   <title >Learning XML</title>\n   <author>Erik T. Ray</author>\n   <year>2003</year>\n   <price>39.95</price>\n </book>\n</bookstore>\n";
    var bstoreTargetXML = "<books>\n <book>\n  <title>Harry Potter</title>\n  <price>19.99</price>\n </book>\n <book>\n  <title>XQuery Kick Start</title>\n  <price>29.99</price>\n </book>\n <book>\n  <title>XPath for Dummies</title>\n  <price>10.00</price>\n </book>\n <book>\n  <title>Everyday Italian</title>\n  <price>20.00</price>\n </book>\n <book>\n  <title>Learning XML</title>\n  <price>19.95</price>\n </book>\n</books>";


function exeUpdate() {
    console.log("execute the update query.");
    var sourceDTD = document.getElementById("sourceDTD").value;
    var targetDTD = document.getElementById("targetDTD").value;
    var uQuery    = document.getElementById("updateQuery").value;
    //    console.log("show all the data before sending: ");
    //    console.log(sourceDTD);
    //    console.log(sourceXML);
    //    console.log(targetDTD);
    //    console.log(targetXML);
    //    console.log(uQuery);
    
    //If some filed is empty.
    //Then alert error.
    if(!sourceDTD || !targetDTD  || !uQuery){
	alert("Please check whether DTD,  Update Query are all filled in.");
	return;
    }
    
    //when do compilation, remove this part.
    $('#step5').remove();
    $.ajax({
	url: "/compile",
	type: 'get',

	data: {
	    sourceDTD: sourceDTD,
	    targetDTD: targetDTD,
	    uQuery   : uQuery,
	},
	success: function(data){
	    data = JSON.parse(data);
	    console.log(data);
	    console.log(data.success);
	    if(data.success  == "success"){
		console.log("success");
		$('#step5').remove();
		//this one is for un-successful situation added.
		$('#consoleLog0').remove();
		//add a new sec
		$('<li style="float:left" id="step5">Execution of Bidirectional Transformation<p class="NotGood">You can execute either forward transformation or backward transformation. Note: changes only can be propagated from one side to another side. Changes on both sides cannot be preserved at the same time.</p> </li>').insertAfter('#step4');
		$('<div class="ResultSource" id="updatedSource"> <p>Source</p>  <textarea id="sourceText"> </textarea> </div>').insertAfter("#step5 > p");

		$('<div class="Target" id="target"> <p>Target</p>  <textarea id="targetText"> </textarea> </div>').insertAfter('#updatedSource');
		$('<hr id="hrline" style="height:10px; width=800px; display:none">').insertAfter('#target')
		$('<div class="FBButton" id="fbButton""><input style="float:left" type="submit" value="Forward Transformation" onclick="forward()"/><input style="float:left" type="submit" value="Backward Transformation" onclick="backward()"/></div>').insertAfter('#hrline');
		//todo: add Console info
		$('<hr id="conhrline" style="height:10px; width=800px; display:none">').insertAfter('#fbButton');
		$('<div class="ConsoleLog" id="consoleLog"><p>Console:</p> <textarea id="consoleText"></textarea></div>').insertAfter('#conhrline');
//		$('<div class="bnav" id="mybnav"> Jump back for checking: <ul><li><a href="#step1">Step 1</a></li><li><a href="#step2">Step 2</a></li><li><a href="#step3">Step 3</a></li><li><a href="#step4">Step 4</a></li> </ul> </div>').insertAfter('#consoleLog');

		
		//according to the seleced option to get the data;
		if ($('select option[value="people"]').attr('selected')){
		    console.log("output people xml");
		    document.getElementById("targetText").value= peopleTargetXML;
		    document.getElementById("sourceText").value= peopleSourceXML;
		}
		else if ($('select option[value="bookmark"]').attr('selected')){
		    console.log("output bookmark xml");
		    document.getElementById("targetText").value= bookmarkTargetXML;
		    document.getElementById("sourceText").value= bookmarkSourceXML;
		}
		else if ($('select option[value="nestedsections"]').attr('selected')){
		    console.log("output nested sections xml");
		    document.getElementById("targetText").value= nestedTargetXML;
		    document.getElementById("sourceText").value= nestedSourceXML;
		}
		else if ($('select option[value="addressbook"]').attr('selected')){
		    console.log("output addressbook xml");
		    document.getElementById("targetText").value= addrTargetXML;
		    document.getElementById("sourceText").value= addrSourceXML;
		}
		else if ($('select option[value="bookstore"]').attr('selected')){
		    console.log("output bookstore xml");
		    document.getElementById("targetText").value= bstoreTargetXML;
		    document.getElementById("sourceText").value= bstoreSourceXML;
		}

		else if ($('select option[value="upload"]').attr('selected')){
		    console.log("upload xml");
		    $('<div id="r2"><br/><input type="file" id="sxml" onchange="handleFiles2(this.files)"  multiple/> <br /></div>').appendTo('div[id="updatedSource"] > p')
		    $('<div id="r4"><br/><input type="file" id="sxml" onchange="handleFiles4(this.files)"  multiple/> <br /></div>').appendTo('div[id="target"] > p')
		    document.getElementById("targetText").value= "";
		    document.getElementById("sourceText").value= "";
		}
		else {//if ($('select option[value="please"]')){
		    console.log("output empty");
		    document.getElementById("targetText").value= "";
		    document.getElementById("sourceText").value= "";
		}
		document.getElementById('consoleText').value = document.getElementById('consoleText').value  +"\n" + data.error;
	    }
	    else {
		$('#consoleLog0').remove();
		$('<div class="ConsoleLog0" id="consoleLog0" style="float:right; width:500px; margin-right: 20px"><p>Console:</p> <textarea id="consoleText"></textarea></div>').insertAfter('#compileSubmit');
		document.getElementById('consoleText').value = data.error;
	    }
	} 
    });
}



function forward() {
    var sourceXML = document.getElementById("sourceText").value;
    var targetXML = document.getElementById("targetText").value;
    if(!sourceXML || !targetXML){
	alert("Please check whether DTD, XML, Update Query are all filled in.");
	return;
    }

    $.ajax({
	url: "/bx",
	type: 'get',
	data: {
	    sourceXML: sourceXML,
	    targetXML: targetXML,
	    flag: "f"
	},
	success: function(data){
	    //split the data into log and data
	    data = JSON.parse(data);
	    document.getElementById('consoleText').value = document.getElementById('consoleText').value + "\n" +data.error;
	    if(data.success == "success"){
		document.getElementById("targetText").value = data.resultXML;
	    } else {
		document.getElementById("targetText").value = targetXML;
	    }
	}
    });

}


function backward() {
     var sourceXML = document.getElementById("sourceText").value;
    var targetXML = document.getElementById("targetText").value;
    if(!sourceXML || !targetXML){
	alert("Please check whether DTD, XML, Update Query are all filled in.");
	return;
    }

    $.ajax({
	url: "/bx",
	type: 'get',
	data: {
	    sourceXML: sourceXML,
	    targetXML: targetXML,
	    flag: "b"
	},
	success: function(data){
	    data = JSON.parse(data);
	    document.getElementById('consoleText').value = document.getElementById('consoleText').value + "\n"+ data.error;
	    if (data.success == "success"){
		document.getElementById("sourceText").value = data.resultXML;		
	    }else {
		document.getElementById("sourceText").value = sourceXML;
	    }
	}
    });

}
