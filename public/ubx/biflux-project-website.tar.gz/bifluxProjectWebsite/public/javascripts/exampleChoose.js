function chooseExample(value) {

    var peopleSourceDTD = "<!DOCTYPE people [ \n<!ELEMENT people (person*)> \n<!ELEMENT person (name,city)> \n<!ELEMENT name (#PCDATA)> \n<!ELEMENT city (#PCDATA)> \n]> ";
    var peopleSourceXML = "<people>\n	<person>\n		<name>Hugo</name>\n		<city>Tokyo</city>\n	</person>\n	<person>\n		<name>Sebastian</name>\n		<city>Kiel</city>\n	</person>\n	<person>\n		<name>Zhenjiang</name>\n		<city>Tokyo</city>\n	</person>\n</people>";
    var peopleTargetDTD = "<!DOCTYPE fromtokyo [\n<!ELEMENT fromtokyo (name*)>\n<!ELEMENT name (#PCDATA)>\n]>";
    var peopleTargetXML = "<fromtokyo>\n	<name>Zan</name>\n	<name>Zhenjiang</name>\n</fromtokyo>";
    var peopleQuery1 = "import \"s.dtd\" as s\nimport \"v.dtd\" as v\n\n$source = doc(\"s.xml\")\n$view   = doc(\"v.xml\")\n\nSTART = updatePeople($source/people, $view/fromtokyo)\n\nPROCEDURE updatePeople(source $source AS s:people, view $view AS v:fromtokyo) =\nUPDATE $sperson IN $source/person BY\n	MATCH    ->  {}\n |	UNMATCHV ->  CREATE VALUE <person> <name/> <city>Tokyo</city> </person>\nFOR VIEW $vname IN $view/name\nMATCHING SOURCE BY name VIEW BY $vname\nWHERE city/text() = 'Tokyo'";
    var peopleQuery2 = "import \"s.dtd\" as s\nimport \"v.dtd\" as v\n\n$source = doc(\"s.xml\")\n$view   = doc(\"v.xml\")\n\nSTART = updatePeople($source/people, $view/fromtokyo)\n\nPROCEDURE updatePeople(source $source AS s:people, view $view AS v:fromtokyo) =\nUPDATE $sperson IN $source/person BY\n	MATCH    ->  {}\n |	UNMATCHV ->  CREATE VALUE <person> <name/> <city>Tokyo</city> </person>\n |	UNMATCHS ->  KEEP . ; REPLACE IN city WITH 'Kyoto'\nFOR VIEW $vname IN $view/name\nMATCHING SOURCE BY name VIEW BY $vname\nWHERE city/text() = 'Tokyo'";


    var bookmarkSourceDTD = "<!DOCTYPE html [\n\n<!ELEMENT html (head,body)>\n<!ELEMENT head (#PCDATA)>\n<!ELEMENT body (h1,dl)>\n<!ELEMENT h1 (#PCDATA)>\n<!ELEMENT dl ((dt|dd)*)>\n<!ELEMENT dt (a)>\n<!ELEMENT a (#PCDATA)>\n<!ELEMENT dd (h3,dl)>\n<!ELEMENT h3 (#PCDATA)>\n\n<!ATTLIST a href CDATA #REQUIRED>\n\n]>";
    var bookmarkSourceXML = "<html>\n     <head>My Bookmarks</head>\n     <body>\n	<h1>my bookmarks</h1>\n	<dl>\n	  <dt><a href=\"foo.com\">Foo\'s</a></dt>\n	  <dd><h3>my folder</h3>\n	      <dl>\n		<dt><a href=\"stefanzan.com\">stefanzan</a></dt>\n	      </dl>\n	  </dd>\n	  <dt><a href=\"bar.edu\">Bar\'s</a></dt>\n	</dl>\n     </body>\n</html>";
    var bookmarkTargetDTD = "<!DOCTYPE xbel [\n\n<!ELEMENT xbel (title,(bookmark|folder)*)>\n<!ELEMENT title (#PCDATA)>\n<!ELEMENT bookmark (title)>\n<!ELEMENT folder (title,(bookmark|folder)*)>\n<!ELEMENT title (#PCDATA)>\n\n<!ATTLIST bookmark href CDATA #REQUIRED>\n\n]>";
    var bookmarkTargetXML = "<xbel>\n  <title>NII bookmarks</title>\n  <folder><title>National Institute of Informatics</title>\n     <bookmark href=\"http://www.nii.ac.jp/en\"><title>English</title></bookmark>\n	 <bookmark href=\"http://www.nii.ac.jp\"><title>Japanese</title></bookmark>\n  </folder>\n  <folder><title>my folder</title>\n  	 <bookmark href=\"stefanzan.com\"><title>stefanzan</title></bookmark>\n  </folder>\n  <bookmark href=\"bar.edu\"><title>Bar\'s</title></bookmark>\n</xbel>";
    var bookmarkQuery = "import \"s.dtd\" as s\nimport \"v.dtd\" as v\n\n$source = doc(\"netscape.xml\") \n$view   = doc(\"xbel.xml\") \n\nSTART = top($source/html,$view/xbel) \n\nPROCEDURE top(source $html AS s:html, view $xbel AS v:xbel) =\nUPDATE html[$h AS head[String], body[$h1 AS s:h1, dl[$nc AS Nc]]] IN $html BY\n	 REPLACE IN $h1 WITH $t ; contents($nc,$xc) \nFOR VIEW xbel[title[$t AS String], $xc AS Xc] IN $xbel\n\ntype Nc = (s:dt|s:dd)*\ntype Xc = (v:bookmark|v:folder)*\n\nPROCEDURE contents(source $nc AS Nc, view $xc AS Xc) =\nUPDATE $nc BY	\n	CASE $v OF\n	{	bookmark[@href[$url AS String], title[$title AS String]]    -> REPLACE . WITH <dt> <a href={$url}>{$title}</a> </dt>\n	|	folder[title[$title AS String], $fxc AS Xc]                 -> REPLACE IN h3 WITH $title ; contents(dl/*,$fxc)\n	}\nFOR VIEW $v IN $xc\n\n";

    var nestedSourceDTD = "<!DOCTYPE sections [\n\n<!ELEMENT sections (section*)>\n<!ELEMENT section (title,paragraph?,subsection*)>\n<!ELEMENT title (#PCDATA)>\n<!ELEMENT paragraph (#PCDATA)>\n<!ELEMENT subsection (title,paragraph?)>\n\n]>";
    var nestedSourceXML = "<sections>\n	<section>\n		<title>Grand Tours</title>\n		<paragraph>The grand tours are major cycling races...</paragraph>\n		<subsection>\n			<title>Giro dItalia</title>\n			<paragraph>The Giro is usually held in May and June...</paragraph>\n		</subsection>\n	</section>\n	<section>\n		<title>Classics</title>\n		<paragraph>The classics are one-day cycling races...</paragraph>\n		<subsection>\n			<title>Milan-San Remo</title>\n			<paragraph>The Spring classic is held in March...</paragraph>\n		</subsection>\n	</section>\n</sections>";
    var nestedTargetDTD = "<!DOCTYPE secs [\n\n<!ELEMENT secs (sec*)>\n<!ELEMENT sec (subsec*)>\n<!ELEMENT subsec (EMPTY)>\n\n<!ATTLIST sec title CDATA #REQUIRED>\n<!ATTLIST subsec title CDATA #REQUIRED>\n\n]>";
    var nestedTargetXML = "<secs>\n	<sec title='Classics'>\n		<subsec title='Paris-Roubaix'/>\n	</sec>\n	<sec title='Olympic Competitions'>\n		<subsec title='2008 Summer Olympics'/>\n		<subsec title='2012 Summer Olympics'/>\n	</sec>\n	<sec title='Grand Tours'>\n		<subsec title='Milan-San Remo'/>\n		<subsec title='Giro dItalia'/>\n		<subsec title='Tour de France'/>\n	</sec>\n</secs>";
    var nestedQuery1 = "import \"s.dtd\" as s\nimport \"v.dtd\" as v\n\n$source = doc(\"s.xml\")\n$view   = doc(\"v.xml\")\nSTART   = sections($source/sections, $view/secs)\n\nPROCEDURE sections(source $source AS s:sections, view $view AS v:secs) =\nUPDATE $section IN $source/section BY\n	MATCH    -> subsections($section/subsection,$subsecs)\n |	UNMATCHV -> CREATE VALUE <section> <title/> <paragraph>this section is new</paragraph> </section>\nFOR VIEW sec[$title AS @title[String], $subsecs AS v:subsec*] IN $view/sec\nMATCHING SOURCE BY title/text() VIEW BY $title/string()\n\nPROCEDURE subsections(source $subsections AS s:subsection*, view $subsecs AS v:subsec*) =\nUPDATE $subsection IN $subsections BY\n	MATCH    -> {}\n |	UNMATCHV -> CREATE VALUE <subsection>\n							 	<title/>\n							    <paragraph>this subsection is new</paragraph>\n					 	     </subsection>\nFOR VIEW $subsec IN $subsecs\nMATCHING SOURCE BY title/text() VIEW BY @title/string()\n\n";

    var nestedQuery2 = "import \"s.dtd\" as s\nimport \"v.dtd\" as v\n\n$source = doc(\"s.xml\")\n$view   = doc(\"v.xml\")\nSTART   = sections($source/sections, $view/secs)\n\nPROCEDURE sections(source $source AS s:sections, view $view AS v:secs) =\nUPDATE $section IN $source/section BY\n	MATCH    -> subsections($section/subsection, $subsecs, $source)\n |	UNMATCHV -> CREATE VALUE <section> <title/> <paragraph>this section is new</paragraph> </section>\nFOR VIEW sec[$title AS @title[String], $subsecs AS v:subsec*] IN $view/sec\nMATCHING SOURCE BY title/text() VIEW BY $title/text()\n\nPROCEDURE subsections(source $subsections AS s:subsection*, view $subsecs AS v:subsec*, $source AS s:sections) =\nUPDATE $subsection IN $subsections BY\n	MATCH    -> {}\n |	UNMATCHV -> LET $subs := $source//subsection[title/text() = $subsec/@title/string()] IN\n                CREATE VALUE <subsection> <title/> <paragraph> {string-join($subs/paragraph,' ')} </paragraph> </subsection>\nFOR VIEW $subsec IN $subsecs\nMATCHING SOURCE BY title/text() VIEW BY @title/text()";

    var addrSourceDTD = "<!DOCTYPE addrbook [\n\n<!ELEMENT addrbook (person*)>\n<!ELEMENT person (name,email+,tel)>\n<!ELEMENT name (#PCDATA)>\n<!ELEMENT email (#PCDATA)>\n<!ELEMENT tel (#PCDATA)>\n]>";
    var addrSourceXML = "<addrbook>\n	<person>\n  		<name>Masato Takeichi</name>\n		<email>takeichi@acm.org</email>\n		<email>takeichi@i.u-tokyo.ac.jp</email>\n		<tel>+81-3-5841-7430</tel>\n	</person>\n	<person>\n		<name>Zhenjiang Hu</name>\n		<email>hu@mist.i.u-tokyo.ac.jp</email>\n		<email>hu@ipl.t.u-tokyo.ac.jp</email>\n		<tel>+81-3-5841-7411</tel>\n    </person>\n    <person>\n		<name>Shin-Cheng Mu</name>\n		<email>scm@mist.i.u-tokyo.ac.jp</email>\n		<email>scm@sinica.cl</email>\n		<tel>+81-3-5841-7411</tel>\n    </person>\n</addrbook>";
    var addrTargetDTD = "<!DOCTYPE addrbook [\n\n<!ELEMENT addrbook (index,person*)>\n<!ELEMENT index (name*)>\n<!ELEMENT person (name,email)>\n<!ELEMENT name (#PCDATA)>\n<!ELEMENT email (#PCDATA)>\n<!ELEMENT tel (#PCDATA)>\n\n]>";
    var addrTargetXML = "<addrbook>\n	<index>\n		<name>Zhenjiang Hu</name>\n		<name>Hugo Pacheco</name>\n		<name>Masato Takeichi</name>\n	</index>\n	<person>\n		<name>Zhenjiang Hu</name>\n		<email>hu@nii.ac.jp</email>\n	</person>\n	<person>\n		<name>Hugo Pacheco</name>\n		<email>hpacheco@nii.ac.jp</email>\n	</person>\n	<person>\n		<name>Masato Takeichi</name>\n		<email>takeichi@acm.org</email>\n	</person>\n</addrbook>";
    var addrQuery = "(: Given a sequence of people with name, email* and tel :)\n(: Return a view with an index of names and people only :)\n(: with their first email address :)\n(: Lexer has a bug need to be fixed. inside UExpr, <a> {Path} {Path} </a> :) \n\nimport \"s.dtd\" as s\nimport \"v.dtd\" as v\n$source = doc(\"s.xml\")\n$view   = doc(\"v.xml\")\nSTART = updateAddrbook($source/addrbook,$view/addrbook)\n\nPROCEDURE updateAddrbook(source $src AS s:addrbook, view $vw AS v:addrbook) =\nUPDATE $s IN $src BY\n MATCH -> UPDATE $sperson IN $s/person BY\n         MATCH    -> LET ($e AS s:email,$es AS s:email*) := email IN REPLACE $e WITH $email\n      |  UNMATCHV -> CREATE VALUE <person> <name/> <email/> <email>foo@default.com</email> <tel>+81 0000000</tel> </person>\n      |  UNMATCHS -> DELETE .\n      FOR VIEW person[$name AS v:name, $email AS v:email] IN $people\n      MATCHING SOURCE BY $sperson/name VIEW BY $name	\nFOR VIEW addrbook[index[$index AS v:name*],$people AS v:person*] IN $vw\nWHERE $index := $people/name\n";

    var bstoreSourceDTD = "<!DOCTYPE bookstore [\n\n<!ELEMENT bookstore (book*)>\n<!ELEMENT book (title,author+,year,price)>\n<!ELEMENT title (#PCDATA)>\n<!ELEMENT author (#PCDATA)>\n<!ELEMENT year (#PCDATA)>\n<!ELEMENT price (#PCDATA)>\n\n<!ATTLIST book category CDATA #IMPLIED>\n\n]>";
    
    var bstoreSourceXML = "<bookstore>\n <book category='Food'>\n   <title >Everyday Italian</title>\n   <author>Giada De Laurentiis</author>\n   <year>2005</year>\n   <price>30.00</price>\n </book>\n <book>\n   <title >Harry Potter</title>\n   <author>J K. Rowling</author>\n   <year>2005</year>\n   <price>29.99</price>\n </book>\n <book category='Programming'>\n   <title >XQuery Kick Start</title>\n   <author>James McGovern</author>\n   <author>Per Bothner</author>\n   <author>Kurt Cagle</author>\n   <author>James Linn</author>\n   <author>Vaidyanathan Nagarajan</author>\n   <year>2003</year>\n   <price>49.99</price>\n </book>\n <book category='Programming'>\n   <title >Learning XML</title>\n   <author>Erik T. Ray</author>\n   <year>2003</year>\n   <price>39.95</price>\n </book>\n</bookstore>\n";
    
    var bstoreTargetDTD = "<!DOCTYPE books [\n\n<!ELEMENT books (book*)>\n<!ELEMENT book (title,price)>\n<!ELEMENT title (#PCDATA)>\n<!ELEMENT price (#PCDATA)>\n\n]>";
    var bstoreTargetXML = "<books>\n <book>\n  <title>Harry Potter</title>\n  <price>19.99</price>\n </book>\n <book>\n  <title>XQuery Kick Start</title>\n  <price>29.99</price>\n </book>\n <book>\n  <title>XPath for Dummies</title>\n  <price>10.00</price>\n </book>\n <book>\n  <title>Everyday Italian</title>\n  <price>20.00</price>\n </book>\n <book>\n  <title>Learning XML</title>\n  <price>19.95</price>\n </book>\n</books>";
    var bstoreQuery="import \"s.dtd\" as s\nimport \"v.dtd\" as v\n\n$source = doc(\"s.xml\")\n$view   = doc(\"v.xml\")\nSTART = updateBookStore($source/bookstore, $view/books)\n\nPROCEDURE updateBookStore(source $source AS s:bookstore, view $view AS v:books) =\nUPDATE $book IN $source/book BY\n	MATCH    -> REPLACE price WITH $price\n |	UNMATCHV -> CREATE VALUE <book category='undefined'>\n                           		<title/>\n                           		<author>??</author>\n                           		<year>??</year>\n                           		<price/>\n                             </book>\nFOR VIEW book[$title  AS v:title, $price AS v:price] IN $view/*\nMATCHING SOURCE BY $book/title VIEW BY $title";

    if(value =="people"){
	console.log("people DTD");
	console.log(document.getElementById("sourceDTD").value);
	$('select option[value="people"]').attr("selected", "selected");
	$('select option[value="bookmark"]').attr("selected", false);
	$('select option[value="nestedsections"]').attr("selected", false);
	$('select option[value="addressbook"]').attr("selected", false);
	$('select option[value="bookstore"]').attr("selected", false);
	$('select option[value="upload"]').attr("selected", false);
	$('select option[value="please"]').attr("selected", false);
	//remove upload dialog
	$('#r1').remove();
	$('#r3').remove();
	$('#r5').remove();
	//remove update query slector.
	$('#mulNQ').remove();
	$('#mulQ').remove();
	$('#step5').remove();
	document.getElementById("sourceDTD").value = peopleSourceDTD;
	document.getElementById("targetDTD").value = peopleTargetDTD;
	document.getElementById("updateQuery").value= peopleQuery1;
	/* add selection for query*/
	$('<div id="mulQ"> You can choose another update. <div class="styled-select"><select name="exampleChoice" onchange="chooseQuery(value)"><option value="q1">U1</option><option value="q2">U2</option> </select> </div></div>').appendTo('#selectQuery');
    }
  else if(value =="bookmark"){
      console.log("bookmark DTD");
      console.log(document.getElementById("sourceDTD").value);
	$('select option[value="people"]').attr("selected", false);
	$('select option[value="bookmark"]').attr("selected", "selected");
	$('select option[value="nestedsections"]').attr("selected", false);
	$('select option[value="addressbook"]').attr("selected", false);
	$('select option[value="bookstore"]').attr("selected", false);
	$('select option[value="upload"]').attr("selected", false);
	$('select option[value="please"]').attr("selected", false);
      //remove upload dialog
      $('#r1').remove();
      $('#r3').remove();
      $('#r5').remove();
      //remove update query slector.
      $('#mulNQ').remove();
      $('#mulQ').remove();
      $('#step5').remove();
      document.getElementById("sourceDTD").value = bookmarkSourceDTD;
      document.getElementById("targetDTD").value = bookmarkTargetDTD;
      document.getElementById("updateQuery").value= bookmarkQuery;
  }

  else if(value =="nestedsections"){
      console.log("nestedsections");
	$('select option[value="people"]').attr("selected", false);
	$('select option[value="bookmark"]').attr("selected", false);
	$('select option[value="nestedsections"]').attr("selected", "selected");
	$('select option[value="addressbook"]').attr("selected", false);
	$('select option[value="bookstore"]').attr("selected", false);
	$('select option[value="upload"]').attr("selected", false);
	$('select option[value="please"]').attr("selected", false);

      //remove upload dialog
      $('#r1').remove();
      $('#r3').remove();
      $('#r5').remove();
      //remove update query slector.
      $('#mulNQ').remove();
      $('#mulQ').remove();
      //when choose, remove the step 5
      $('#step5').remove();
      document.getElementById("sourceDTD").value = nestedSourceDTD;
      document.getElementById("targetDTD").value = nestedTargetDTD;
      document.getElementById("updateQuery").value= nestedQuery1;
      $('<div id="mulNQ"> You can another update. <div class="styled-select"><select name="exampleChoice" onchange="chooseNestedQuery(value)"><option value="q1">U1</option><option value="q2">U2</option> </select> </div></div>').appendTo('#selectQuery');
  }
  else if(value =="addressbook"){
      console.log("addressbook");
	$('select option[value="people"]').attr("selected", false);
	$('select option[value="bookmark"]').attr("selected", false);
	$('select option[value="nestedsections"]').attr("selected", false);
	$('select option[value="addressbook"]').attr("selected", "selected");
	$('select option[value="bookstore"]').attr("selected", false);
	$('select option[value="upload"]').attr("selected", false);
	$('select option[value="please"]').attr("selected", false);

      //remove upload dialog
      $('#r1').remove();
      $('#r3').remove();
      $('#r5').remove();
      //remove update query slector.
      $('#mulNQ').remove();
      $('#mulQ').remove();
      $('#step5').remove();
      document.getElementById("sourceDTD").value = addrSourceDTD;
      document.getElementById("targetDTD").value = addrTargetDTD;
      document.getElementById("updateQuery").value= addrQuery;
  }
  else if(value =="bookstore"){
      console.log("bookstore");
	$('select option[value="people"]').attr("selected", false);
	$('select option[value="bookmark"]').attr("selected", false);
	$('select option[value="nestedsections"]').attr("selected", false);
	$('select option[value="addressbook"]').attr("selected", false);
	$('select option[value="bookstore"]').attr("selected", "selected");
	$('select option[value="upload"]').attr("selected", false);
	$('select option[value="please"]').attr("selected", false);

      //remove upload dialog
      $('#r1').remove();
      $('#r3').remove();
      $('#r5').remove();
      //remove update query slector.
      $('#mulNQ').remove();
      $('#mulQ').remove();
      $('#step5').remove();
      document.getElementById("sourceDTD").value = bstoreSourceDTD;
      document.getElementById("targetDTD").value = bstoreTargetDTD;
      document.getElementById("updateQuery").value= bstoreQuery;
  }

  else if(value =="please"){
      console.log("please");
	$('select option[value="people"]').attr("selected", false);
	$('select option[value="bookmark"]').attr("selected", false);
	$('select option[value="nestedsections"]').attr("selected", false);
	$('select option[value="addressbook"]').attr("selected", false);
	$('select option[value="bookstore"]').attr("selected", false);
	$('select option[value="upload"]').attr("selected", false);
	$('select option[value="please"]').attr("selected", "selected");

      //remove upload dialog
      $('#r1').remove();
      $('#r3').remove();
      $('#r5').remove();
      //remove update query slector.
      $('#mulNQ').remove();
      $('#mulQ').remove();
      $('#step5').remove();
      document.getElementById("sourceDTD").value = "";
      document.getElementById("targetDTD").value = "";
      document.getElementById("updateQuery").value= "";
  }
  else if(value =="upload"){
      console.log("upload");
	$('select option[value="people"]').attr("selected", false);
	$('select option[value="bookmark"]').attr("selected", false);
	$('select option[value="nestedsections"]').attr("selected", false);
	$('select option[value="addressbook"]').attr("selected", false);
	$('select option[value="bookstore"]').attr("selected", false);
	$('select option[value="upload"]').attr("selected", "selected");
	$('select option[value="please"]').attr("selected", false);

      window.alert("Please upload source, target DTDs and update.");
      $('#mulNQ').remove();
      $('#mulQ').remove();
      $('#step5').remove();
      document.getElementById("sourceDTD").value = "";
      document.getElementById("targetDTD").value = "";
      document.getElementById("updateQuery").value= "";
      $('<div id="r1"><br/><input type="file" id="sdtd" onchange="handleFiles1(this.files)"  multiple/> <br /></div>').appendTo('div[id="sdtd"] > p')
      $('<div id="r3"><br/><input type="file" id="tdtd" onchange="handleFiles3(this.files)" multiple/> <br /></div>').appendTo('div[id="tdtd"] > p')
      $('<div id="r5"><br/><input type="file" id="uq"   onchange="handleFiles5(this.files)" multiple/> <br /></div>').appendTo('div[id="uQuery"] > p')
  }

}


function handleFiles1(files) {
    console.log("handle file 01");
    if (files.length) {
	var file= files[0];
	var reader = new FileReader();
	if (true) {
	    console.log("correct");
            reader.onload = function() {
		console.log(this.result);
		document.getElementById("sourceDTD").value = this.result;
            }
            reader.readAsText(file);
        }	
    }
}

function handleFiles2(files) {
    console.log("handle file 02");
    if (files.length) {
	var file= files[0];
	var reader = new FileReader();
//	if (/text\/\w+/.test(file.type)) {
	if (true) {
            reader.onload = function() {
		document.getElementById("sourceText").value = this.result;
            }
            reader.readAsText(file);
        }	
    }
}
function handleFiles3(files) {
    console.log("handle file 03");
    if (files.length) {
	var file= files[0];
	var reader = new FileReader();
//	if (/text\/\w+/.test(file.type)) {
  	if (true) {
            reader.onload = function() {
		document.getElementById("targetDTD").value = this.result;
            }
            reader.readAsText(file);
        }	
    }
}
function handleFiles4(files) {
    console.log("handle file 04");
    if (files.length) {
	var file= files[0];
	var reader = new FileReader();
//	if (/text\/\w+/.test(file.type)) {
  	if (true) {
          reader.onload = function() {
		document.getElementById("targetText").value = this.result;

            }
            reader.readAsText(file);
        }	
    }
}
function handleFiles5(files) {
    console.log("handle file 05");
    if (files.length) {
	var file= files[0];
	var reader = new FileReader();
	if (true) {
//	if (/text\/\w+/.test(file.type)) {
            reader.onload = function() {
		document.getElementById("updateQuery").value= this.result;
            }
            reader.readAsText(file);
        }	
    }
}


function chooseQuery(value) {
    //dupllication of people
        var peopleQuery1 = "import \"s.dtd\" as s\nimport \"v.dtd\" as v\n\n$source = doc(\"s.xml\")\n$view   = doc(\"v.xml\")\n\nSTART = updatePeople($source/people, $view/fromtokyo)\n\nPROCEDURE updatePeople(source $source AS s:people, view $view AS v:fromtokyo) =\nUPDATE $sperson IN $source/person BY\n  MATCH    ->  {}\n | UNMATCHV ->  CREATE VALUE <person> <name/> <city>Tokyo</city> </person>\nFOR VIEW $vname IN $view/name\nMATCHING SOURCE BY name VIEW BY $vname\nWHERE city/text() = 'Tokyo'";
    var peopleQuery2 = "import \"s.dtd\" as s\nimport \"v.dtd\" as v\n\n$source = doc(\"s.xml\")\n$view   = doc(\"v.xml\")\n\nSTART = updatePeople($source/people, $view/fromtokyo)\n\nPROCEDURE updatePeople(source $source AS s:people, view $view AS v:fromtokyo) =\nUPDATE $sperson IN $source/person BY\n   MATCH    ->  {}\n | UNMATCHV ->  CREATE VALUE <person> <name/> <city>Tokyo</city> </person>\n | UNMATCHS ->  KEEP . ; REPLACE IN city WITH 'Kyoto'\nFOR VIEW $vname IN $view/name\nMATCHING SOURCE BY name VIEW BY $vname\nWHERE city/text() = 'Tokyo'";

    // when change query, step5 need tobe deleted.
    $('#step5').remove();
    if (value == "q1"){
	document.getElementById("updateQuery").value= peopleQuery1;	
    }
    else if (value == "q2") {
	document.getElementById("updateQuery").value= peopleQuery2;	
    }
}

function chooseNestedQuery(value) {
    console.log("fda");
       var nestedQuery1 = "import \"s.dtd\" as s\nimport \"v.dtd\" as v\n\n$source = doc(\"s.xml\")\n$view   = doc(\"v.xml\")\nSTART   = sections($source/sections, $view/secs)\n\nPROCEDURE sections(source $source AS s:sections, view $view AS v:secs) =\nUPDATE $section IN $source/section BY\n  MATCH    -> subsections($section/subsection,$subsecs)\n | UNMATCHV -> CREATE VALUE <section> <title/> <paragraph>this section is new</paragraph> </section>\nFOR VIEW sec[$title AS @title[String], $subsecs AS v:subsec*] IN $view/sec\nMATCHING SOURCE BY title/text() VIEW BY $title/string()\n\nPROCEDURE subsections(source $subsections AS s:subsection*, view $subsecs AS v:subsec*) =\nUPDATE $subsection IN $subsections BY\n  MATCH    -> {}\n |  UNMATCHV -> CREATE VALUE <subsection>\n               <title/>\n                  <paragraph>this subsection is new</paragraph>\n                </subsection>\nFOR VIEW $subsec IN $subsecs\nMATCHING SOURCE BY title/text() VIEW BY @title/string()\n\n";

    var nestedQuery2 = "import \"s.dtd\" as s\nimport \"v.dtd\" as v\n\n$source = doc(\"s.xml\")\n$view   = doc(\"v.xml\")\nSTART   = sections($source/sections, $view/secs)\n\nPROCEDURE sections(source $source AS s:sections, view $view AS v:secs) =\nUPDATE $section IN $source/section BY\n  MATCH    -> subsections($section/subsection, $subsecs, $source)\n | UNMATCHV -> CREATE VALUE <section> <title/> <paragraph>this section is new</paragraph> </section>\nFOR VIEW sec[$title AS @title[String], $subsecs AS v:subsec*] IN $view/sec\nMATCHING SOURCE BY title/text() VIEW BY $title/text()\n\nPROCEDURE subsections(source $subsections AS s:subsection*, view $subsecs AS v:subsec*, $source AS s:sections) =\nUPDATE $subsection IN $subsections BY\n  MATCH    -> {}\n |  UNMATCHV -> LET $subs := $source//subsection[title/text() = $subsec/@title/string()] IN\n                CREATE VALUE <subsection> <title/> <paragraph> {string-join($subs/paragraph,' ')} </paragraph> </subsection>\nFOR VIEW $subsec IN $subsecs\nMATCHING SOURCE BY title/text() VIEW BY @title/text()";

    
    //no matter choose what, remove step 5
    $('#step5').remove();
    if (value == "q1"){
	document.getElementById("updateQuery").value= nestedQuery1 ;
    }
    else if (value == "q2") {
	document.getElementById("updateQuery").value= nestedQuery2;
    }

}
