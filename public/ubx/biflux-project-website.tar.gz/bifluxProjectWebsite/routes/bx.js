var fs = require('fs');
var sys = require('sys');
var exec = require('child_process').exec;
var pretty = require('../helper/pretty').pretty;

exports.bx = function (req, res){
    console.log("give back data");
    //console.log(req.query);
    var sourceXML = req.query.sourceXML;
    var targetXML = req.query.targetXML;
    var flag = req.query.flag;




   fs.writeFile("/tmp/s.xml", sourceXML, function(err){
       if(err){console.log("s.xml err"); console.log(err);}
       else {
	   console.log("s.xml saved");
	   fs.writeFile("/tmp/v.xml", targetXML, function(err){
	       if(err){console.log("v.xml err"); console.log(err);}
	       else {
		   console.log("v.xml saved");
		   if (flag == "f") {
		       exec("/tmp/out -s /tmp/s.xml  -t /tmp/v.xml -o /tmp/result.xml -f", 
			    function(err){ if(err){console.log(err);
						   res.contentType('json');
						   res.send({resultXML : "", success: "falied", error : err.toString()  });
						  }
					   else {
					       console.log("generated result target xml file");
					       fs.readFile("/tmp/result.xml", 'utf-8', function(err, data){
						   if(err){console.log("read result xml file err"); 
							   console.log(err);
							   res.contentType('json');
							   res.send({resultXML : "", success: "falied", error : err.toString()  });
							  }
						   else { 
						       console.log("send updated source to client");
						       //console.log(data);
						       //console.log(pretty(data));
						       res.contentType('json');
						       res.send({resultXML : pretty(data), success: "success", error : "Forward transformation successfully done!\n" });
						   }//else
					       });//readFile
					   }
					 });
		       
		   }
		   else if (flag == 'b'){
		       exec("/tmp/out -s /tmp/s.xml  -t /tmp/v.xml -o /tmp/result.xml -b", 
			    function(err){ if(err){console.log(err);
						   res.contentType('json');
						   res.send({resultXML : "", success: "falied", error : err.toString()  });
						  }//if
					   else {
					       console.log("generated result source xml file");
					       fs.readFile("/tmp/result.xml", 'utf-8', function(err, data){
						   if(err){console.log("read result xml file err"); 
							   console.log(err);
							   res.contentType('json');
							   res.send({resultXML : "", success: "falied", error : err.toString()  });
							  }
						   else { 
						       console.log("send updated source to client");
						       //console.log(data);
						       //console.log(pretty(data));
						       res.contentType('json');
						       res.send({resultXML : pretty(data), success: "success", error : "Backward transformation successfully done!\n" });
						   }//else
					       });//readFile
					   }//else
					 }//err func
			   );//exec
		   };//elseif
	       }
	   });
       }
   });
}
	  