module TestTranslation where

import BiFlux.Trans.Translation

