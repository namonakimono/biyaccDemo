# What is this repository for? #

* BiYacc - a tool for generating a reflective printer and its parser in a single program.

----

#Installation#
1. Install GHC(Glasgow Haskell Compiler) or Haskell Platform.
2. Install Happy (run `cabal install happy` in the command line)
3. Install BiGUL (run `cabal install bigul` in the terminal)
4. Change your directory to the root of biyacc and run `cabal install`.
   Cabal will automatically generate you the executable file somewhere in your computer.
   In mac, the location usually is: `/Users/AccountName/Library/Haskell/bin/biyacc`
   In ubuntu, the location usually is: `/home/AccountName/.cabal/bin/biyacc`
   It depends on the system as well as the *version of the cabal and GHC*.

----

#Usage#
1) generate the executable: type "biyacc BiYaccFile OutputExecutableFile"
2) run the transformations.
for parsing:  type "OutPutExecutableFile get InputFile(code) OutputFile(AST)"
for printing: type "OutPutExecutableFile put InputFile1(code) InputFile2(AST) OutputFile(updated code)"
If "OutputFile(updated code)" is ommitted, the "InputFile1" file will be updated.

----

#Try it on the website#
Go to
http://www.prg.nii.ac.jp/project/biyacc.html or
http://biyacc.yozora.moe
to try the examples online.
***Also, you can install this website on your own computer.***

