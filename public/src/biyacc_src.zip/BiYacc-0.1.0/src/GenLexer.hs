module GenLexer where

import ByParser
import System.IO
import System.Environment
import Data.List
import Data.Char
import Data.Map.Strict (Map)
import qualified Data.Map.Strict as Map
import LanguageDef
import ConcretePart
import BiYaccUtils

import Debug.Trace

extract :: [ByToken] -> [String]
extract (ByTokenCommLine : toks)  = extract (drop 1 toks)
extract (ByTokenCommBlock : toks) = extract (drop 2 toks)
extract (ByTokenT s : toks) = s : extract toks
extract (tok : toks) = extract toks
extract [] = []

unique :: [String] -> [String]
unique (x:y:rest) = if (x == y) then unique (x:rest) else x : unique (y:rest)
unique [x] = [x]
unique [] = []

prtHeader :: (Bool, Bool, Bool) -> String
prtHeader (strFlag, nameFlag, intFlag) =
  "{\n" ++
  "module Parser where\n\n" ++
  "import Data.Char\n" ++
  "import YourLangDef\n" ++
  "}\n\n" ++
  "%name parser\n" ++
  "%tokentype { Token }\n" ++
  "%error { parseError }\n\n" ++
  "%token\n" ++
  (if strFlag  then "    str     { TokenStr $$ }\n" else "") ++
  (if nameFlag then "    name    { TokenName $$ }\n" else "") ++
  (if intFlag  then "    int     { TokenInt $$ }" else "")

markPrim :: [ByToken] -> (Bool, Bool, Bool)
markPrim []                         = (False, False, False)
markPrim (ByTokenNT "String" :toks) = let (fs, fn, fi) = markPrim toks in (True, fn, fi)
markPrim (ByTokenNT "Name"   :toks) = let (fs, fn, fi) = markPrim toks in (fs, True, fi)
markPrim (ByTokenNT "Int"    :toks) = let (fs, fn, fi) = markPrim toks in (fs, fn, True)
markPrim (tok:toks)                 = markPrim toks

prtLexRule :: Map String String -> String -> String
prtLexRule toks s = let Just tok = Map.lookup s toks in
  "lexer (" ++ expand s ++ "cs) = " ++ tok ++ " \"\" : lexer cs\n"

prtLexCase :: Map String String -> String -> String
prtLexCase toks s = let Just tok = Map.lookup s toks in
  "            \"" ++ s ++ "\" -> " ++ tok ++ " \"\" : lexer rest\n"

expand :: String -> String
expand [] = []
expand (c:cs) = '\'':(mkEscape [c]) ++ ('\'':':':(expand cs))

prtLexer :: Map String String -> [String] -> (String, (String, String)) -> String
prtLexer toks cs sym =
  "isWhiteSpace :: Char -> Bool\n" ++
  "isWhiteSpace c = elem c \" \\n\\t\\r\"\n\n" ++
  "isValidName :: Char -> Bool\n" ++
  "isValidName c = isAlphaNum c || c == '_'\n\n" ++
  "lexer :: String -> [Token]\n" ++
  "lexer [] = []\n" ++
  "lexer (" ++ expand (fst sym) ++ "cs) = lexerComment1 \"" ++ mkEscape (reverse (fst sym)) ++ "\" cs\n" ++
  "lexer (" ++ expand (fst (snd sym)) ++ "cs) = lexerComment2 \"" ++ mkEscape (reverse (fst (snd sym))) ++ "\" cs\n" ++
  "lexer ('\\\"':cs) = lexerString \"\" cs\n" ++
  concat (fmap (prtLexRule toks) (Data.List.filter (not . isAlpha . head) cs)) ++
  "lexer (c:cs)\n" ++
  "    | isAlpha c = let (var, rest) = span isValidName (c:cs)\n" ++
  "        in case var of\n" ++
  concat (fmap (prtLexCase toks) (Data.List.filter (isAlpha . head) cs)) ++
  "            _ -> TokenName (var, \"\") : lexer rest\n" ++
  "    | isDigit c = let (var, rest) = span isDigit (c:cs)\n" ++
  "        in TokenInt (read var :: Int, \"\") : lexer rest\n" ++
  "    | isWhiteSpace c = let (ws, rest) = span isWhiteSpace (c:cs)\n" ++
  "        in TokenWS  ws  : lexer rest\n\n" ++
  "lexerComment1 :: String -> String -> [Token]\n" ++
  "lexerComment1 res [] = [TokenWS (reverse res)]\n" ++
  "lexerComment1 res ('\\n':cs) = TokenWS (reverse ('\\n':res)) : lexer cs\n" ++
  "lexerComment1 res (c:cs) = lexerComment1 (c:res) cs\n\n" ++
  "lexerComment2 :: String -> String -> [Token]\n" ++
  "lexerComment2 res [] = [TokenWS (reverse res)]\n" ++
  "lexerComment2 res (" ++ expand (snd (snd sym)) ++ "cs) = TokenWS (reverse (" ++ expand (reverse (snd (snd sym))) ++ "res)) : lexer cs\n" ++
  "lexerComment2 res (c:cs) = lexerComment2 (c:res) cs\n\n" ++
  "lexerString :: String -> String -> [Token]\n" ++
  "lexerString res [] = [TokenStr (reverse res, \"\")]\n" ++
  "lexerString res ('\\\"':cs) = TokenStr (reverse res, \"\") : lexer cs\n" ++
  "lexerString res (c:cs) = lexerString (c:res) cs\n"

mkEscape :: String -> String
mkEscape = foldr (\e es -> f e ++ es) []
  where f '\"' = "\\\""
        f '\\' = "\\\\"
        f c    = [c]

getToks :: Int -> [String] -> Map String String
getToks _ [] = Map.empty
getToks n (c:cs) = Map.insert c ("Token" ++ (show n)) (getToks (n + 1) cs)

prtToks :: Int -> String
prtToks 0 = ""
prtToks n = prtToks (n - 1) ++ "    token" ++ show (n - 1) ++
  "    { Token" ++ show (n - 1) ++ " $$ }\n"

prtEachCon :: Map String String -> [String] -> String
prtEachCon toks [] = ""
prtEachCon toks (c:cs) = let Just tok = Map.lookup c toks in
  "    | " ++ tok ++ " String\n" ++ prtEachCon toks cs

prtData :: (Bool, Bool, Bool) -> Map String String -> [String] -> String
prtData (strFlag, nameFlag, intFlag) toks s =
  foldr (newlineS) ""
  [ "data Token ="
  , "      TokenWS  String"
  , "    | TokenStr (String, String)"
  , "    | TokenName (String, String)"
  , "    | TokenInt (Int, String)"
  , prtEachCon toks s]

prtEachShow :: Map String String -> [String] -> String
prtEachShow toks [] = ""
prtEachShow toks (c:cs) = let Just tok = Map.lookup c toks in
  "    show (" ++ tok ++ " _) = \"" ++ mkEscape c ++ "\"\n" ++ prtEachShow toks cs

prtShow :: (Bool, Bool, Bool) -> Map String String -> [String] -> String
prtShow (strFlag, nameFlag, intFlag) toks s =
  "instance Show Token where\n" ++
  prtEachShow toks s ++
  (if strFlag  then "    show (TokenStr (s, _)) = s\n" else "") ++
  (if nameFlag then "    show (TokenName (s, _)) = s\n" else "") ++
  (if intFlag  then "    show (TokenInt (s, _)) = show s\n" else "") ++
  "    show (TokenWS s) = s\n"

prtEachDef :: [EitherTNT] -> String
prtEachDef (Left  x : xs) = "String " ++ prtEachDef xs -- terminal
prtEachDef (Right "String" : xs) = "(String, String) " ++ prtEachDef xs
prtEachDef (Right "Name" : xs) = "(String, String) " ++ prtEachDef xs
prtEachDef (Right "Int" : xs) = "(Int, String) " ++ prtEachDef xs
prtEachDef (Right x : xs) = x ++ " " ++ prtEachDef xs
prtEachDef [] = ""

lowerTok :: String -> String
lowerTok (c:cs) = 't' : cs

prtEachDef2 :: Map String String -> [EitherTNT] -> String
prtEachDef2 toks (Left  x : xs) = let Just tok = Map.lookup x toks in
  lowerTok tok ++ " " ++ prtEachDef2 toks xs
prtEachDef2 toks (Right "String" : xs) = "str "  ++ prtEachDef2 toks xs
prtEachDef2 toks (Right "Name" : xs) = "name " ++ prtEachDef2 toks xs
prtEachDef2 toks (Right "Int" : xs) = "int "  ++ prtEachDef2 toks xs
prtEachDef2 toks (Right x : xs) = x ++ " " ++ prtEachDef2 toks xs
prtEachDef2 toks [] = ""

prtEachDef3 :: Int -> [EitherTNT] -> String
prtEachDef3 n (x : xs) = "$" ++ show n ++ " " ++ prtEachDef3 (n + 1) xs
prtEachDef3 n [] = ""

prtDefs :: [CTypeDef] -> String
prtDefs ((CTypeDef con es):[]) = con ++ " " ++ prtEachDef es ++ "\n"
prtDefs ((CTypeDef con es):xs) = con ++ " " ++ prtEachDef es ++ "\n    | " ++ prtDefs xs

prtDefs2 :: Map String String -> [CTypeDef] -> String
prtDefs2 toks ((CTypeDef con es):[]) = prtEachDef2 toks es ++
  " { " ++ con ++ " " ++ prtEachDef3 1 es ++ "}"
prtDefs2 toks ((CTypeDef con es):xs) = prtEachDef2 toks es ++
  " { " ++ con ++ " " ++ prtEachDef3 1 es ++ "}\n    | " ++ prtDefs2 toks xs

prtEachCst :: CDataType -> String
prtEachCst (CDataType dataName defs) =
  "data " ++ dataName ++ " =\n      " ++ prtDefs defs ++
  "    deriving Show\n\n"

prtEachRule :: Map String String -> CDataType -> String
prtEachRule toks (CDataType dataName defs) =
  dataName ++ " : " ++ prtDefs2 toks defs ++ "\n\n"

prtParseErr :: String
prtParseErr =
  "parseError :: [Token] -> a\n" ++
  "parseError _ = error \"Parse error\"\n"

prtCst :: CAST -> String
prtCst (CAST _ dts) = concat (fmap prtEachCst dts)

prtRules :: Map String String -> CAST -> String
prtRules toks (CAST _ dts) = let (CDataType dataName _) = (dts !! 0) in
  "%%\n\n" ++
  "Prog : " ++ dataName ++ " { $1 }\n" ++
  "     | { " ++ dataName ++ "Null0 }\n\n" ++
  concat (fmap (prtEachRule toks) dts)

prtPrtRes :: Int -> [EitherTNT] -> String
prtPrtRes n (Left  x : xs) = " \"" ++ x ++ "\" ++ s" ++ show n ++ " ++" ++ prtPrtRes (n + 1) xs
prtPrtRes n (Right x : xs) = (
  if (x == "(Int, String)")
    then " show (fst s" ++ show n ++ ") ++ snd s"
    else if (x == "(NameX9or2c81, String)")
      then " fst s" ++ show n ++ " ++ snd s"
      else if (x == "(String, String)")
        then "\"\\\"\" ++ fst s" ++ show n ++ " ++ \"\\\"\" ++ snd s"
        else " show s") ++ show n ++ " ++" ++ prtPrtRes (n + 1) xs
prtPrtRes n [] = " \"\""

prtPrtPatt :: Int -> [EitherTNT] -> String
prtPrtPatt n (x:xs) = " s" ++ show n ++ prtPrtPatt (n + 1) xs
prtPrtPatt n [] = ""

prtPrts :: [CTypeDef] -> String
prtPrts ((CTypeDef con es):[]) =
  "    show (" ++ con ++ prtPrtPatt 0 es ++ ") =" ++ prtPrtRes 0 es ++ "\n"
prtPrts ((CTypeDef con es):xs) =
  "    show (" ++ con ++ prtPrtPatt 0 es ++ ") =" ++ prtPrtRes 0 es ++ "\n" ++ prtPrts xs

prtEachPrinter :: CDataType -> String
prtEachPrinter (CDataType dataName defs) =
  "instance Show " ++ dataName ++ " where\n" ++ prtPrts defs ++ "\n"

prtPrinter :: CAST -> String
prtPrinter (CAST _ dts) = concat (fmap prtEachPrinter dts)

prtEachCmd :: Map String String -> [EitherTNT] -> String
prtEachCmd toks [] = ""
prtEachCmd toks (Left x : cs) = let Just tok = Map.lookup x toks in
  " " ++ lowerTok tok ++ prtEachCmd toks cs

disamb :: [Cmd] -> [Cmd]
disamb [] = []
disamb ((CmdL x):xs) = (CmdL x) : disamb xs
disamb ((CmdR x):xs) = (CmdR x) : disamb xs
disamb ((CmdN x):xs) = (CmdN x) : disamb xs
disamb (x:xs) = disamb xs

comment :: [Cmd] -> (String, (String, String))
comment [] = ("//", ("/*", "*/"))
comment ((CommLine s):xs) = (s, snd (comment xs))
comment ((CommBlock sl sr):xs) = (fst (comment xs), (sl, sr))
comment (x:xs) = comment xs

prtCmds :: Map String String -> [Cmd] -> String
prtCmds toks [] = []
prtCmds toks ((CmdL lst):cs) = "%left" ++ prtEachCmd toks lst ++ "\n" ++ prtCmds toks cs
prtCmds toks ((CmdR lst):cs) = "%right" ++ prtEachCmd toks lst ++ "\n" ++ prtCmds toks cs
prtCmds toks ((CmdN lst):cs) = "%nonassoc" ++ prtEachCmd toks lst ++ "\n" ++ prtCmds toks cs

prtWrapEach :: Map String String -> [String] -> String
prtWrapEach toks [] = ""
prtWrapEach toks (c:cs) = let Just tok = Map.lookup c toks in
  "wrap (" ++ tok ++ " c) ws = " ++ tok ++ " (c ++ ws)\n" ++ prtWrapEach toks cs

prtWrap :: Map String String -> [String] -> String
prtWrap toks cs =
  (foldr (newlineS) ""
      ["wrap :: Token -> String -> Token"
      ,"wrap (TokenStr (s, c)) ws = TokenStr (s, c ++ ws)"
      ,"wrap (TokenName (s, c)) ws = TokenName (s, c ++ ws)"
      ,"wrap (TokenInt (s, c)) ws = TokenInt (s, c ++ ws)"
      ,"wrap (TokenWS c) ws = TokenWS (c ++ ws)"])
  `newlineS` prtWrapEach toks cs `newlineS`
  (foldr (newlineS) ""
      ["mergeWS :: [Token] -> [Token]"
      ,"mergeWS [] = []"
      ,"mergeWS (tok : TokenWS ws : toks) = mergeWS (wrap tok ws : toks)"
      ,"mergeWS (tok : toks) = tok : mergeWS toks\n"
      ,"parser2 prog = (show (head toks), parser (tail toks))"
      ,"  where"
      ,"    toks = mergeWS (TokenWS \"\" : lexer prog)"])

main :: IO ()
main = do
  args <- getArgs
  --inp <- readFile (args !! 0)
  let inp = args !! 0
      progToks = byLexer inp
      primFlags = markPrim progToks
      strs = unique . reverse . sort . extract $ progToks
      toks = getToks (0::Int) strs
      (cmds, cst) = byParser . byLexer $ inp
      prog = addTopLevelDataype (addConsName cst)
  -- putStrLn "import Data.Char\n"
  --traceM (show primFlags)
  putStrLn $ prtHeader primFlags
  putStrLn $ prtToks (length strs)
  putStrLn $ prtCmds toks (disamb cmds)
  putStrLn $ prtRules toks prog
  putStrLn $ "{"
  putStrLn $ prtParseErr
  putStrLn $ prtData primFlags toks strs

  putStrLn $ str2CST prog
  --putStrLn $ prtCst prog
  --putStrLn $ prtPrinter prog

  putStrLn $ prtShow primFlags toks strs
  putStrLn $ prtLexer toks strs (comment cmds)
  putStrLn $ prtWrap toks strs
  putStrLn $ "}"


str2CST :: CAST -> String
str2CST (CAST _ _) = "str2CST s = parser (tail (mergeWS (TokenWS \"\" : lexer s)))\n"
--str2CST :: CAST -> String
--str2CST (CAST t _) =  ("str2CST :: String -> " ++ t) ++ "\n" ++
--  "str2CST s = parser (tail (mergeWS (TokenWS \"\" : lexer s)))\n"

