{-# Language DeriveDataTypeable #-}

module ActionPart where

import LanguageDef
import BiYaccUtils

import Text.Parsec.Token hiding (symbol)
import Text.Parsec
import Text.Parsec.Prim
import Text.Parsec.Combinator
import Control.Monad

import Text.PrettyPrint as TPP

import Data.List (intersperse, map, (\\), sort, nub)
import Data.Char (toLower)
import Data.Maybe (catMaybes, fromJust)
import Data.Map.Strict as Map (Map, lookup, adjust, singleton, unions, union, empty, fromList, toList, insert)

import Debug.Trace


-- string literal. will change char literal to string literal
strLit :: Parsec String () LitPat
strLit = byLexeme $ (byCharLit >>= \s -> return (LitStrPattern s)) <|> (byStrLit  >>= \s -> return (LitStrPattern s))

numbersLit :: Parsec String () LitPat
numbersLit = byLexeme (do
  choice [ try byInteger >>= \i -> return (LitIntegerPattern i)
         , try byInt     >>= \i -> return (LitIntPattern (fromInteger i))
         ,     byFloat   >>= \f -> return (LitFloatPattern f)
         ])

boolLit :: Parsec String () LitPat
boolLit = byLexeme $ (string "True"  >> return (LitBoolPattern True)) <|> (string "False" >> return (LitBoolPattern False))

tTerminal = byCharLit


---------------actions parser ----------------
program :: SourcePos -> ParsecU Program
program srcPos = do
  setPosition srcPos
  byLexeme (string "Actions" <?> "expecting keyword Actions")
  grps <- many1 group
  eof
  let (Group entranceTydec _) = grps !! 0
  return $ Program entranceTydec grps

group :: ParsecU Group
group = do
  t@(TypeDecl vt st) <- typeDecl
  rules_ <- many1 (try rule)
  return $ Group t rules_

typeDecl :: ParsecU TypeDecl
typeDecl = do
  vt <- vType
  eatEmbed
  st <-tConstructor
  return $ TypeDecl vt st


-- parse a single type (type field, type constructor ...)
vType :: Parsec String () ASTDataTypeDef
vType = (simpleType <?> "expecting a constructor") <|> (maybeType vType <?> "expecting Maybe type") <|>
             (listType vType <?> "expecting List type") <|>
             try (tupleType vType <?> "expecting tuple syntax") <|>
             try (withParen vType) <|> try (generalType vType)
------------------


rule :: ParsecU Rule
rule = try (do
  lhs_ <- lhs
  eatEmbed
  rhs_ <- rhs
  eatLineEnd
  return (NormalRule lhs_ rhs_))

lhs = liftM LHS lhsPattern

-- overlapped pattern: [var@(...)] and [var]
-- listPat can overlap any other patterns... shall first try it
lhsPattern :: ParsecU LHSPattern
lhsPattern = try listPat <|> wildPat <|> try asPat <|> varPat <|>
             try lhsTupleDataSyntax <|> try normalPat <|> primitiveTypes <|> lhsWithParen



-- aspattern
asPat :: ParsecU LHSPattern
asPat = do
  aswhat <- tVariable
  eatAs
  eatLParen
  pattern <- lhsPattern
  eatRParen
  return (ASPattern aswhat pattern) -- ad hoc strategy. insert ASPattern into a parentheses to easily distinguish from other patterns

-- Constructor var1 (Just var2) ...
normalPat :: ParsecU LHSPattern
normalPat = liftM2 NormalP tConstructor (many (constructorArgs <?> "hehe"))

-- just a variable, match anything
varPat :: ParsecU LHSPattern
varPat = do
  v <- tVariable
  notFollowedBy eatAs
  return (UpdVar v)

wildPat :: ParsecU LHSPattern
wildPat = eatWildCard >> return WildcardP

lhsWithParen :: ParsecU LHSPattern
lhsWithParen = do
  eatLParen
  innerpatterns <- lhsPattern
  eatRParen
  return innerpatterns


constructorArgs :: ParsecU LHSPattern
constructorArgs = try listPat <|> wildPat <|> try asPat <|> varPat <|>
  (tConstructor >>= \con -> return (NormalP con []) <?> "expecting a constructor") <|>
  primitiveTypes <|> try lhsTupleDataSyntax <|> lhsWithParen
  <?> "constructorArgs"

primitiveTypes :: ParsecU LHSPattern
primitiveTypes = liftM LitPat strLit <|> liftM LitPat numbersLit <|> liftM LitPat boolLit

--------
listPat = try lhsEmptyList <|> lhsSingletonList <|> try lhsConsList2 <|> try lhsConsList
lhsTupleDataSyntax = try lhsTriple <|> lhsTuple

lhsEmptyList :: ParsecU LHSPattern
lhsEmptyList = eatLBrack >> eatRBrack >> return (NormalP "EmptyList" [])

lhsSingletonList :: ParsecU LHSPattern
lhsSingletonList = do
  eatLBrack
  inner <- lhsPattern
  eatRBrack
  return $ NormalP "Singleton" [inner]

lhsConsList :: ParsecU LHSPattern
lhsConsList = do
  -- avoid implicit left recursion for ConsList. divide the lhsPattern to two: (x:xs) or Constructor:xs
  elem <- oneLayerOnly
  eatListCons    -- :
  elems <- try asPat <|> varPat <|> wildPat
  return $ NormalP "ConsList" [elem, elems]

oneLayerOnly = wildPat <|> primitiveTypes <|> try asPat <|> varPat  <|> normalPat <|> try lhsTupleDataSyntax <|> lhsWithParen <?> "list cons pattern"
-- two layer.
lhsConsList2 :: ParsecU LHSPattern
lhsConsList2 = do
  -- avoid implicit left recursion for ConsList. divide the lhsPattern to two: (x:xs) or Constructor:xs
  elem1 <- oneLayerOnly
  eatListCons    -- :
  elem2 <- oneLayerOnly
  eatListCons
  elems <- try asPat <|> varPat <|> wildPat
  return $ NormalP "ConsList" [elem1, elem2, elems]

lhsTuple :: ParsecU LHSPattern
lhsTuple = do
  eatLParen
  l <- lhsPattern
  eatComma
  r <- lhsPattern
  eatRParen
  return $ NormalP "Tuple" [l, r]

lhsTriple :: ParsecU LHSPattern
lhsTriple = do
  eatLParen
  l <- lhsPattern
  eatComma
  m <- lhsPattern
  eatComma
  r <- lhsPattern
  eatRParen
  return $ NormalP "Triple" [l, m, r]


---------------------------------
rhs :: ParsecU RHS
rhs = liftM RHS prodrulePlus

prodrulePlus :: ParsecU ProdrulePlus
prodrulePlus = many1 update >>= \upd -> return $ ProdrulePlus "EMPTY" upd

-- update2ProdrulePlus

update :: ParsecU (Either Unchanged Update)
update = try (do
  -- normal update 1
  eatLParen
  var <- tVariable
  eatEmbed
  sub <- tConstructor
  eatRParen
  -- here the primitive type is changed, to hold the layouts/comments fields
  -- eg. Int is changed to (Int, String) to contain layout. it is somehow not good...
  return $ Right $ NUpdate var (addLayoutFieldIfPrimitive sub)) <|>

  try (liftM (Left . Terminal) tTerminal) <|> -- terminal
  -- deep pattern
  try (update_deepPat) <|>

  -- normal update 2: the updated part is expanded to a deep pattern
  -- but since you cannot update both the whole deep pattern part and also some of its inner parts
  -- so here we skip the whole deep pattern part and treat it as a normal update.
  try (do
  eatLParen
  var <- tVariable
  eatEmbed
  Right (DUpdate con _) <- update_deepPat
  eatRParen
  -- here the primitive type is changed. eg Int is changed to (Int, String) to contain layout. it is somehow not good...
  return $ Right $ NUpdate var (addLayoutFieldIfPrimitive con)) <|>

  -- non update
  (liftM (Left . Nonterminal) tConstructor)

-- deep pattern
update_deepPat :: ParsecU (Either Unchanged Update)
update_deepPat = do
  eatLParen
  con <- tConstructor
  eatTo
  deep <- prodrulePlus -- if we go deep, the type of the deep expressions is the name (aka nonterminal) of their parent
  eatRParen
  return $ Right (DUpdate con deep)
  <?> "error in RHS, deep pattern. possibly missing ';' in previous right hand side"



---------------------------------------------------
-- check whether the RHS of an action exists. If it exists, add the production rule name.
addProdRuleName :: EigenNameEnv -> Program -> Program
addProdRuleName env (Program t grps) = Program t (map upd1 grps)
  where
    upd1 :: Group -> Group
    upd1 (Group (TypeDecl vt st) rules) = Group (TypeDecl vt st) (map (upd2 st) rules)
    upd2 :: SourceType -> Rule -> Rule
    upd2 st (NormalRule lhs (RHS (ProdrulePlus _ tnts))) = NormalRule lhs (RHS (update2ProdrulePlus st env tnts))

update2ProdrulePlus :: SourceType -> EigenNameEnv -> [Either Unchanged Update] -> ProdrulePlus
update2ProdrulePlus st env eitherupds =
  let pat = getProdrulePat eitherupds
      maybeProdrulename = Map.lookup (pat,st) env
  in  case maybeProdrulename of
        Nothing -> error $ "cannot find pattern in concrete data type (no such production rule):" ++ "(" ++ show pat ++ ", " ++ show st ++ ")"
        Just prodrulename -> ProdrulePlus prodrulename (map mdDeepPat eitherupds)
  where mdDeepPat :: Either Unchanged Update -> Either Unchanged Update
        mdDeepPat (Right (DUpdate st (ProdrulePlus _ tnts))) = Right $ DUpdate st $ update2ProdrulePlus st env tnts
        mdDeepPat other                                      = other
getProdrulePat :: [Either Unchanged Update] -> ProdRuleEigen
getProdrulePat = map getUpdPat
  where getUpdPat :: Either Unchanged Update -> Either String String
        getUpdPat (Left (Nonterminal st)) = Right st
        getUpdPat (Left (Terminal t)) = Left t
        getUpdPat (Right upd) = case upd of
                                  NUpdate _ st -> Right st
                                  DUpdate st _ -> Right st
---------------------------------------------------------------




---------------- RHS exhaustiveness check ---------------
-- check whether a group of actions use all the production rules.
simpleExhaustCheck :: Program -> TypeNameEnv -> NameEigenEnv -> Maybe String
simpleExhaustCheck (Program _ grps) tenv nenv =
  case catMaybes (map (checkGrp tenv nenv) grps) of
    [] -> Nothing
    errMsgs -> Just $ "warning: (however, the program may still be correct)\n" ++ foldr1c (id) (\e es -> e `newlineS` es) errMsgs

-- Maybe (error message)
checkGrp :: TypeNameEnv -> NameEigenEnv -> Group -> Maybe String
checkGrp tenv nenv (Group (TypeDecl (ASTDataTypeDef vtCon vtts) st) rules) =
  case Map.lookup st tenv of
    Nothing -> error $ "non-terminal " ++ st ++ " not found. maybe a wrong type is written?"
    Just conNames' ->
      let conNames  = sort conNames'
          namesWrt  = nubSortedList . sort. map extPrdRName $ rules
          lack      = map (\e -> "In group: " ++ produceVarType vtCon vtts ++ "+> " ++ st ++ "," `newlineS`
                           "the production rule not found: " ++ st ++ " -> " ++
                           (concatSpace . map (delLayoutFieldIfPrimitive . either (\s -> "'" ++ s ++ "'") id) . fst . fromJust . Map.lookup e) nenv)
                      (conNames \\ namesWrt)
      in  if null lack
            then Nothing
            else Just $ foldr1c (id) (\e es -> e `newlineS` es) lack

nubSortedList :: Eq a => [a] -> [a]
nubSortedList [] = []
nubSortedList [x] = [x]
nubSortedList (x:y:z) = if x == y then nubSortedList (y:z) else x: nubSortedList (y:z)

extPrdRName :: Rule -> String
extPrdRName (NormalRule _ (RHS (ProdrulePlus n _))) = n
----------------------------------------------------------------


---------- automatically extract production rules from actions --------
extProdRules :: Program -> String
extProdRules (Program entTy grps) =
  toString . rearrEntrance entTy . Map.toList . rebuild (Map.empty) . nubSortedList . sort . concat . map (concat. map Map.toList . extGrp) $ grps
  where
    toString :: [(String, [[String]])] -> String
    toString [] = ""
    toString ((nont,prds):xs) =
      let abc = map (foldr1c id (\e es -> e ++ " " ++ es)) prds
          hdSpaces = replicate (length nont + 2) ' ' -- just for pretty-printed results
      in  (nont ++ " -> " ++ foldr1c (\e -> e ++ " ;") (\e es -> e `newlineS` hdSpaces ++  "| " ++ es) abc) `newlineSS` toString xs

    rebuild :: Map String [[String]] -> [(String, [String])] -> Map String [[String]]
    rebuild acc [] = acc
    rebuild acc ((k,prds):xs) = rebuild (case Map.lookup k acc of Nothing -> Map.insert k [prds] acc; Just _  -> Map.adjust (\p -> prds:p) k acc) xs
    rearrEntrance :: TypeDecl -> [(String, [[String]])] -> [(String, [[String]])]
    rearrEntrance (TypeDecl _ entSt) l =
      case filter (\(ty, _) -> ty == entSt) l of
      [ent]   -> ent : filter (\(ty, _) -> ty /= entSt) l
      (_:_:_) -> error "should not be here. please contact the developer."

extGrp :: Group -> [Map String [String]]
extGrp (Group (TypeDecl _ st) rules) = map (collectPrdRule st) rules
  where
    collectPrdRule :: SourceType -> Rule -> Map String [String]
    collectPrdRule st (NormalRule _ (RHS prdp)) = collectPrdp prdp st
    collectPrdRule _ _ = Map.empty

    collectPrdp :: ProdrulePlus -> SourceType -> Map String [String]
    collectPrdp (ProdrulePlus _ tnts) st = collectTNTs tnts [] Map.empty
      --foldr1c collectTNTs (\e es -> (collectTNTs e) ++ " " ++ es) tnts
      where
        collectTNTs :: [Either Unchanged Update] -> [String] -> Map String [String] -> Map String [String]
        collectTNTs []                             acc deep = Map.singleton st acc `union` deep -- safe to use union
        collectTNTs (Left  (Nonterminal nont):xs)  acc deep = collectTNTs xs (acc ++ [delLayoutFieldIfPrimitive nont]) deep
        collectTNTs (Left  (Terminal     t  ):xs)  acc deep = collectTNTs xs (acc ++ ["'" ++ t ++ "'"]) deep
        collectTNTs (Right (NUpdate _ nont  ):xs)  acc deep = collectTNTs xs (acc ++ [delLayoutFieldIfPrimitive nont]) deep
        collectTNTs (Right (DUpdate nont prdp):xs) acc deep = collectTNTs xs (acc ++ [delLayoutFieldIfPrimitive nont]) (collectPrdp prdp nont)
---------------------------------------------------------



--
{-
The file provide functions for generating AST of "Actions" part in a BiYacc file.
Like what we do when dealing with the production rules in "Concrete" part, we first generate a temporary AST with holes.
The holes are then filled up with the help of environment.
But this time these two procedures are called mutually recursively.

-}


