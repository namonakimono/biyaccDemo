module AbstractPart (pAbstractC, pAbstractA, prtAbsDTs, buildConToFieldTypeEnv) where

import LanguageDef
import BiYaccUtils
import Text.Parsec.Token (whiteSpace, identifier)

import Text.Parsec
import Data.List.Utils (replace)
import Data.Map (singleton, unions, Map)


typeVar = tVariable

-- the next part is "Concrete" syntax
pAbstractC :: Parsec String () String
pAbstractC = byLexeme (do
  byWhiteSpace
  byLexeme (string "Abstract" <?> "need the keyword \"Abstract\"")
  decls <- manyTill anyChar (try (string "Concrete" <?> "expecting keyword Concrete"))
  inp <- getInput              -- ad hoc part. removed if implemented using template haskell
  setInput ("Concrete" ++ inp) -- just now we consume an additional "Concrete" string. Set it back.
  return decls)

-- the next part is "Actions"
pAbstractA :: Parsec String () String
pAbstractA = byLexeme (do
  byWhiteSpace
  byLexeme (string "Abstract" <?> "need the keyword \"Abstract\"")
  decls <- manyTill anyChar (try (string "Actions" <?> "expecting keyword Actions"))
  inp <- getInput              -- ad hoc part. removed if implemented using template haskell
  setInput ("Actions" ++ inp) -- just now we consume an additional "Concrete" string. Set it back.
  return decls)


--   "data X=Y ... data A=B... type Y = Z ... data ... type B = C ..."
-- lines it! ==> [[String]] by lines! something like type Y = Z should appear at the front of a line.
-- filter (\s "type " == take 5 s) can extract the lines starting with "type Y = Z" only
-- then we have the type synonyms. we can use global substitution to replace the type synonyms with the original type...
findTypeSynonyms :: String -> [String]
findTypeSynonyms = map (\s -> s ++ "\0") . filter (\s -> "type " == take 5 s) . lines
-- add a borderline ("\0") for type declaration for simplicity.

--               [(old, new)]         acc
replaceIter :: [(String, String)] -> String -> ASTDataTypes
replaceIter []             acc = read acc
replaceIter ((old,new):xs) acc = replaceIter xs (replace old new acc)

replaceTypeSynonyms :: [(String, String)] -> ASTDataTypes -> ASTDataTypes
replaceTypeSynonyms synPairs = replaceIter synPairs . show


----  parse type synonyms definitions,eg: type NewEither a b = Either Int Char
--                              [(old, new)]
pTypeSyno :: Parsec String () (String, String)
pTypeSyno = do
  byLexeme $ string "type"
  tname <- byLexeme (identifier generatedParser)
  tVar <- many typeVar
  byLexeme $ char '='
  oldType <- manyTill anyChar (try (string "--") <|> string "\0" )
  return $ if length tVar == 0
             then (tname, oldType)
             else (tname ++ " " ++ (foldr1 (\x xs -> x ++ " " ++ xs) tVar) , oldType)


pDatatypes :: Parsec String () ASTDataTypes
pDatatypes = do
  datatypes <- many1 $ try pEachDataType
  return $ ASTDataTypes "" datatypes

pEachDataType :: Parsec String () ASTDataType
pEachDataType = do
  byWhiteSpace
  byLexeme (string "data")
  datatype <- byLexeme (identifier generatedParser)
  linedata <- many1 pLines
  ignoreDerivingPart
  return $ ASTDataType datatype linedata

pLines :: Parsec String () ASTDataTypeDef
pLines = do
  byLexeme ((string "=") <|> (string "|"))
  (ASTDataTypeDef con _) <- simpleType
  datatypes <- many singleType
  byWhiteSpace
  return $ ASTDataTypeDef con datatypes

-- parse a single type (type field, type constructor ...)
singleType :: Parsec String () ASTDataTypeDef
singleType = simpleType <|> try (tupleType singleType) <|> maybeType singleType <|> listType singleType <|>
             eitherType singleType <|> try (withParen singleType) <|> try generalTypeInParen

generalTypeInParen = byLexeme $ char '(' >> (generalType singleType) >>= \res -> byLexeme $ char ')' >> return res


ignoreDerivingPart :: Parsec String () ()
ignoreDerivingPart = do
  byWhiteSpace
  string "deriving"
  manyTill anyChar (try (string "data"))
  inp <- getInput
  setInput ("data" ++ inp)


pAbstractSyntax :: String -> ASTDataTypes
pAbstractSyntax decls =
  let typeSynPairs  = map (either (error . show) id . parse pTypeSyno "abstrac syntax part 1") (findTypeSynonyms decls)
      astDataTypes' = either (error . show) id (parse pDatatypes "abstrac syntax part 2" (decls ++ " data"))
  in  replaceTypeSynonyms typeSynPairs astDataTypes'

genDrvBiGULGenericAST :: ASTDataTypes -> String
genDrvBiGULGenericAST (ASTDataTypes _ types) =
  foldr1c (\(ASTDataType t _)    -> "deriveBiGULGeneric ''" ++ t)
          (\(ASTDataType t _) ts -> "deriveBiGULGeneric ''" ++ t `newlineS` ts)
          types


--                                      Add ---> [Arith, Arith]
buildConToFieldTypeEnv :: String -> Map String [ASTDataTypeDef]
buildConToFieldTypeEnv = buildConToFieldTypeEnv_ . pAbstractSyntax

-- build env from constructors to their type fields  Add ---> [Arith, Arith]
buildConToFieldTypeEnv_ :: ASTDataTypes -> Map String [ASTDataTypeDef]
buildConToFieldTypeEnv_ (ASTDataTypes _ datatypes) = unions $ map refine1 datatypes
  where refine1 (ASTDataType _ typedefs) = unions $ map refine2 typedefs
        refine2 (ASTDataTypeDef  cons subtreetypes) = singleton cons subtreetypes

-- print abstract syntax data types
prtAbsDTs :: String -> String
prtAbsDTs decls = decls `newlineSS` genDrvBiGULGenericAST (pAbstractSyntax decls)