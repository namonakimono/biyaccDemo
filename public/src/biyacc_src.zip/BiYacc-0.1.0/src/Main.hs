module Main where

import LanguageDef
import BiYaccUtils
import AbstractPart
import ConcretePart
import ActionPart
import ProgramTrans
import qualified GenLexer as GL (prtPrinter)

import Text.Parsec (Parsec, getInput, setInput, runParser, getPosition, setPosition, SourcePos, string, lookAhead, try, (<|>), anyChar)
import Text.PrettyPrint as TPP

import System.Environment (getArgs)
import System.Process (readProcess, callCommand)

import Debug.Trace

-- preprocess a biyacc program. Return the (abstract abstract part, Temp CAST of Concrete part, unconsumed Action part and its position, ALL part)
-- In addition, if the user does not write the "Concrete" sytnax part, we will generate it from "Action" groups.
-- Then re-generate and process a new biyacc file with "Concrete" syntax part.
preProcess :: Parsec String () (String, CAST, (String, SourcePos), String)
preProcess = do
  absTypeDecls <- try pAbstractC <|> pAbstractA
  cOrA <- lookAhead (byLexeme (string "Concrete" <|> string "Actions"))
  case cOrA of
    "Concrete" -> do
      srcPos   <- getPosition
      concSrc1 <- getInput
      confs    <- pConfigs -- additional rules (eg disambiguation rules) starting with %
      pOrA     <- lookAhead ((try (string "Actions")) <|> (anyChar >> return ['\0']))
      case pOrA of
        "Actions" -> do
          srcPos1    <- getPosition -- for error reporting
          actionSrc1 <- getInput
          let prdRulesStr = extProdRules $ either (error . show) id (runParser (program srcPos1) () "" actionSrc1)
          setInput (confs `newlineSS` prdRulesStr `newlineSS` actionSrc1)
        "\0"      -> setInput concSrc1 >> setPosition srcPos
    "Actions"  -> do
      srcPos     <- getPosition
      actionSrc1 <- getInput
      let prdRulesStr = extProdRules $ either (error . show) id (runParser (program srcPos) () "" actionSrc1)
      setInput ("Concrete" `newlineSS` prdRulesStr `newlineSS` actionSrc1)
  rem        <- getInput    -- input maybe rearranged by setInput above
  srcTmpCAST <- buildTmpCAST
  srcPos     <- getPosition
  actionSrc  <- getInput
  return (absTypeDecls, srcTmpCAST, (actionSrc,srcPos), absTypeDecls ++ rem)


main :: IO ()
main  = do
  args <- getArgs
  if length args < 2
    then error "please give input. usage: biyacc biyaccFileName outputExecutableName"
    else do
      putStrLn "compiling process may take to half a minute for a comparative big language."
      let byFileName    = args !! 0
          exeFileName   = args !! 1
          exeFileNameHS =  exeFileName ++ ".hs"
      stream <- readFile byFileName
      let (hsDeclsStr, srcTmpCAST, (progStr, srcPos), allStream) = either (error . show) id (runParser preProcess () byFileName stream)
          (srcTypeCAST, srcTypeEnv)    = (toCAST srcTmpCAST, buildEnv srcTmpCAST)
          (eigenNameEnv, nameEigenEnv, nullEnv, similarProdruleEnv, tyNameEnv) = srcTypeEnv
          consToSubtreeTypeEnv = buildConToFieldTypeEnv hsDeclsStr
          progCAST = addProdRuleName eigenNameEnv $ either (error . show) id (runParser (program srcPos) () "" progStr)

          sssprogstring   = genBiGUL nameEigenEnv nullEnv similarProdruleEnv consToSubtreeTypeEnv progCAST
          entranceStr     = getEntrance progCAST
          bigulProgramStr = importStr `newlineSS` entranceStr  `newlineSS` sssprogstring `newlineSS` mainStr
          srcDeclsStr     = prtConcDTs srcTypeCAST
          absDeclsStr     = prtAbsDTs hsDeclsStr
          cstInstanceShowStr = GL.prtPrinter srcTypeCAST

      -- check whether a group of actions use all the production rules. If Concrete part is not given. results are always true.
      maybe (return ()) (putStrLn) (simpleExhaustCheck progCAST tyNameEnv nameEigenEnv)

      writeFile "YourLangDef.hs" (defFileString absDeclsStr srcDeclsStr cstInstanceShowStr)
      writeFile exeFileNameHS bigulProgramStr

      biyaccprog <- readProcess "byStr2CST" [allStream] ""
      writeFile "Parser.y" biyaccprog
      readProcess "happy" ["Parser.y"] ""
      readProcess "ghc" ["Parser.hs"] ""
      readProcess "ghc" ["YourLangDef.hs"] ""
      readProcess "ghc" [exeFileNameHS, "-o", exeFileName] ""

      -- some cleaning work
      let removeStr = ["rm"
                      ,"YourLangDef.dyn_o","YourLangDef.dyn_hi","YourLangDef.o","YourLangDef.hi","YourLangDef.hs"
                      ,"Parser.dyn_o","Parser.dyn_hi","Parser.o","Parser.hi","Parser.y", "Parser.hs"
                      ,exeFileName++".dyn_o",exeFileName++".dyn_hi",exeFileName++".o",exeFileName++".hi",exeFileNameHS]
      putStrLn "nothing serious if the callCommand fails... it just make some cleaning work"
      callCommand $ foldl1 (\xs x -> xs ++ " " ++ x) removeStr
      putStrLn $ "successfully generated " ++ exeFileName
      return ()


-- put abstract datatypes, concrete datatypes into a separate file.
defFileString :: String -> String -> String -> String
defFileString absDef concDef cstInstanceShowStr =
  (foldr (\x xs -> x ++ "\n" ++ xs )
        ""
        ["{-# Language TemplateHaskell, TypeFamilies #-}"
        ,"module YourLangDef where"
        ,"import GHC.Generics"
        ,"import Generics.BiGUL.TH"
        ,""
        , "type NameX9or2c81 = String"
        ])
  `newlineSS` absDef `newlineSS` concDef `newlineSS` cstInstanceShowStr

