{-# LANGUAGE TemplateHaskell, FlexibleInstances #-}

module ProgramTrans (genBiGUL, getEntrance, importStr, mainStr) where

import LanguageDef
import BiYaccUtils
import ConcretePart
import ActionPart

import Data.List (foldl')
import Data.List.Utils (replace)
import Data.Map as Map (Map, lookup)
import Data.Maybe (catMaybes)
import Text.PrettyPrint as TPP

import Debug.Trace


genBiGUL :: NameEigenEnv -> NullEnv -> SimilarProdruleEnv -> ConsSubtreeEnv -> Program -> String
genBiGUL env nullEnv similarProdruleEnv consSubtreeEnv (Program _ groups) = render . vcat2 . map (genGroup env nullEnv similarProdruleEnv consSubtreeEnv) $ groups

-- each group of actions will generate one (bigul m s v)
genGroup :: NameEigenEnv -> NullEnv -> SimilarProdruleEnv -> ConsSubtreeEnv -> Group -> Doc
genGroup env nullEnv similarProdruleEnv consSubtreeEnv (Group (TypeDecl vt st) rules) =
      -- name of the function is bigul ++ viewtype ++ source type. eg bigulArithExpr.
  let

      signame  = text "bigul" <> genViewFunName vt <> text st
      sigtype  = text "BiGUL" <+> text st <+> genViewFunTyName vt
      funname  = signame
      -- in a group. each rule will generate a "normal update" ($normalSV), and an "adaptive update" ($adaptive)
      -- we put the two rules in a tuple and then collect them in order: first normal rules, then adaptive rules.
      -- eg (n1,a1) (n2,a2) (n3,a3) ----> ([n1,n2,n3],[a1,a2,a3]) ----> [n1,n2,n3,a1,a2,a3]
      -- each call of "genClauses" will generate a $normal and an $adaptive clause. all the results will be combined by the "clauses"
      (normalbs, adaptbs) = foldr1 (\(n, a) (ns, as) -> (n $$ nestn1 (comma <> ns), a $$ nestn1 (comma <> as)))
                                  --(TPP.empty,TPP.empty)
                                  (map (genClauses st vt) rules)
      --(normalbs, adaptbs) = foldr (\(n, a) (ns, as) -> (n $$ ns, a $$ as)) (TPP.empty,TPP.empty) $
      --map (genClauses vt) rules
      signature = signame <+> text "::" <+> sigtype
      funcbody  = funname <+> equals $$ nest2 (text "Case" <+> brackets (normalbs $$ nestn2 (comma <> adaptbs)))
  in  signature $$ funcbody
  where
    genClauses :: SourceType -> ViewType -> Rule -> (Doc, Doc)
    genClauses _ vt (UserAdaptiveRule str) = (text str, TPP.empty)
    genClauses st vt (NormalRule lhs rhs)   = (genBody st lhs rhs) -- (normal clause , adaptive clause)
      where
        genBody :: SourceType -> LHS -> RHS -> (Doc, Doc)
        genBody st lhs rhs =
          let viewPat          = genLHSWildP lhs
              sourcePat        = genRHSWildP rhs
              exitPat          = sourcePat
              adapt            = genAdaptive lhs rhs nullEnv similarProdruleEnv
              (vp_, sp_, upd_) = genUpdate consSubtreeEnv vt (NormalRule lhs rhs)
              normalbPat       = text "$" <> parens (text "normalSV" <+> wrapPatQ sourcePat <+> wrapPatQ viewPat <+> wrapPatQ exitPat)
              normalbUpd       = nest2 (text "$" <> parens (text "update" <+> sp_ <+> vp_ <+> upd_))
              normalb          = normalbPat $$ normalbUpd
              adaptb           = adapt
          in  (normalb, adaptb)

genViewFunName :: ASTDataTypeDef -> Doc
genViewFunName (ASTDataTypeDef "Singleton" [t]) = text "List" <> genViewFunName t
genViewFunName (ASTDataTypeDef "Tuple" [t1,t2]) = text "Tuple" <> genViewFunName t1 <> genViewFunName t2
genViewFunName (ASTDataTypeDef "Triple" [t1,t2,t3]) = text "Triple" <> genViewFunName t1 <> genViewFunName t2 <> genViewFunName t3
genViewFunName (ASTDataTypeDef n ts) = text n <> hcat (map genViewFunName ts)

genViewFunTyName :: ASTDataTypeDef -> Doc
genViewFunTyName (ASTDataTypeDef "List" [t]) = brackets $ genViewFunTyName t
genViewFunTyName (ASTDataTypeDef "Tuple" [t1,t2]) = parens $ genViewFunTyName t1 <> comma <+> genViewFunTyName t2
genViewFunTyName (ASTDataTypeDef "Triple" [t1,t2,t3]) = parens $ genViewFunTyName t1 <> comma <+> genViewFunTyName t2 <> comma <+> genViewFunTyName t3
genViewFunTyName (ASTDataTypeDef n ts) = text n <+> hsep (map genViewFunTyName ts)


-- eg. want to generate sth. like $(adaptiveV [p| Sub _ _|]) (\_ _ -> ESub ENull TNull)
--  matchpat === [p|Sub _ _|]  :: Q Exp
--  adaptive === (\_ _ -> ESub ENull TNull) (it is a function)
genAdaptive :: LHS -> RHS -> NullEnv -> SimilarProdruleEnv -> Doc
genAdaptive lhs rhs nullEnv similarProdruleEnv =
  let matchpat    = genLHSWildP lhs
      adaptFun    = genAdaptive_ rhs nullEnv similarProdruleEnv
      matchpatDoc = text "$" <> parens (text "adaptiveSV" <+> wrapPatQ (text "_") <+> wrapPatQ matchpat)
      adaptFunDoc = adaptFun
  in  matchpatDoc <+> adaptFunDoc
  where
    genAdaptive_ :: RHS -> NullEnv -> SimilarProdruleEnv -> Doc
    genAdaptive_ (RHS prodp@(ProdrulePlus prodrulename _)) nullEnv similarProdruleEnv =
      let pat = case Map.lookup prodrulename similarProdruleEnv of
                  Nothing          -> text "\\ _ _ -> " <+> genDefaultPat prodp nullEnv
                  Just similarpats ->
                    let similarpatsDoc = vcat $ map (genSimilarPat prodp nullEnv) similarpats
                        defaultpatDoc  = text "_ ->" <+> genDefaultPat prodp nullEnv <+> text ";"
                    in  text "\\ s _ -> case s of" $$ (similarpatsDoc $$ defaultpatDoc)
      in  parens pat
      where
        genDefaultPat :: ProdrulePlus -> NullEnv -> Doc
        genDefaultPat (ProdrulePlus prodrulename eitherupdates) nullEnv =
          foldl'  (\xs x -> xs <+> x)
                  (text prodrulename)
                  (map (\x -> case x of
                          Left  (Terminal st)     -> text $ genDefaultVal "String_kjd24592x" nullEnv
                          Left  (Nonterminal st)  -> text $ genDefaultVal st nullEnv
                          Right (NUpdate _ st)    -> text $ genDefaultVal st nullEnv
                          Right (DUpdate _ deep ) -> parens (genDefaultPat deep nullEnv)
                       )
                  eitherupdates)
        genDefaultVal :: String -> NullEnv -> String
        genDefaultVal st nullEnv =
          if isPrimitiveWithLayout st
            then "(undefined, \" \")" -- in bigul, the default value will be overridden when rerun the case branch
            else case st of
              "String_kjd24592x" -> "\" \""
              _                  -> maybe (error $ "production rule: " ++ show st ++ " not found (in genAdaptive_)") id
                                          (Map.lookup st nullEnv)
        -- for simiplicity, current version does not handle "deep update" case (which will also generate exponential number of case analises)
        -- just call teh genDefaultPat to generate the default value for the "deep update" case
        genSimilarPat :: ProdrulePlus -> NullEnv -> [String] -> Doc
        genSimilarPat (ProdrulePlus prodrulename eitherupdates) nullenv similar =
          let patlist = zipWith (\x subtree -> case x of
                                  Right (DUpdate _ deep ) -> parens (genDefaultPat deep nullEnv)
                                  -- subtree or layout. ad-hoc handle with the primitive datatype case
                                  _                       -> text $ replace "(undefined, " "(_, " subtree)
                                eitherupdates (tail similar)
              lhs     = foldl'  (\xs x -> xs <+> x) (text (head similar)) patlist
              -- replace the constructor (the head element of the list "similar") of similar production rule with the one should be created
              -- eg suppose here we should adaptive source to Sub. if the list "similar" is:[Add, l, layouts, r], it should be changed to: [Sub, l, layouts, r]
              rhs     = foldl'  (\xs x -> xs <+> text x) (TPP.empty) (prodrulename: tail similar)
          in  lhs <+> text "->" <+> rhs <> semi


-- generate patterns consisting of only Constructor and Wildcard.
-- used for pattern matching on view
genLHSWildP :: LHS -> Doc
genLHSWildP (LHS lhspats) = genLHSWildP_ lhspats
  where
    genLHSWildP_ :: LHSPattern -> Doc
    genLHSWildP_ pat =
      case pat of
        (NormalP "EmptyList" [] )       -> brackets TPP.empty
        (NormalP "ConsList" [e,es])     -> parens $ genLHSWildP_ e <> colon <> genLHSWildP_ es -- in fact elems are restricted to a variable pattern
        (NormalP "ConsList" [e1,e2,es]) -> parens $ genLHSWildP_ e1 <> colon <> genLHSWildP_ e2 <> colon <> genLHSWildP_ es
        (NormalP "Singleton" [e])       -> brackets $ genLHSWildP_ e
        (NormalP "Tuple"  [p1,p2])      -> parens $ genLHSWildP_ p1 <> comma <+> genLHSWildP_ p2
        (NormalP "Triple" [p1,p2,p3])   -> parens $ genLHSWildP_ p1 <> comma <+> genLHSWildP_ p2 <> comma <+> genLHSWildP_ p3
        (NormalP vc lhspats)            -> parens $ text vc <+> (hsep . map genLHSWildP_) lhspats
        (UpdVar _)             -> wildcardDoc
        (WildcardP)            -> wildcardDoc
        (ASPattern _ p)        -> genLHSWildP_ p
        (LitPat (LitStrPattern s))      -> doubleQuotes (text s)       -- or doubleQuotes s
        (LitPat (LitIntegerPattern i))  -> text (show i)
        (LitPat (LitFloatPattern   f))  -> text (show f)
        (LitPat (LitBoolPattern    b))  -> text (show b)
        a                      -> error $ "Non-exhaustive patterns in genLHSWildP: " ++ show a

-- generate patterns consisting of only Constructor and Wildcard.
-- used for pattern matching on source
genRHSWildP :: RHS -> Doc
genRHSWildP (RHS prodruleplus) = genProdrulepat prodruleplus
  where
    genProdrulepat :: ProdrulePlus -> Doc
    genProdrulepat (ProdrulePlus prodruleName maybeupdates) = parens $ (text prodruleName) <+> hsep (map genEitherUpdatespat maybeupdates)
    genEitherUpdatespat :: Either Unchanged Update -> Doc
    genEitherUpdatespat (Left _ ) = wildcardDoc
    genEitherUpdatespat (Right (NUpdate _ _ )) = wildcardDoc
    genEitherUpdatespat (Right (DUpdate st prodruleplus)) = genProdrulepat prodruleplus



-- generate patterns consisting of Constructor and variables.
-- (The variables (aka sub-parts) are used in RHS to update corresponding parts in source data)
-- used for rearrangeAndUpdate
genLHSUpdatePat :: LHS -> Doc
genLHSUpdatePat (LHS lhspats) = genLHSUpdatePat_ lhspats
  where
    genLHSUpdatePat_ :: LHSPattern -> Doc
    genLHSUpdatePat_ pat =
      case pat of
        (NormalP "EmptyList" [])        -> brackets TPP.empty
        (NormalP "Singleton" [e])       -> brackets (genLHSUpdatePat_ e)
        (NormalP "ConsList" [e,es])     -> parens $ genLHSUpdatePat_ e  <> colon <> genLHSUpdatePat_ es
        (NormalP "ConsList" [e1,e2,es]) -> parens $ genLHSUpdatePat_ e1 <> colon <> genLHSUpdatePat_ e2 <> colon <> genLHSUpdatePat_ es
        (NormalP "Tuple" [p1,p2])       -> parens $ genLHSUpdatePat_ p1 <> comma <+> genLHSUpdatePat_ p2
        (NormalP "Triple" [p1,p2,p3])   -> parens $ genLHSUpdatePat_ p1 <> comma <+> genLHSUpdatePat_ p2 <> comma <+> genLHSUpdatePat_ p3
        (NormalP vc lhspats)            -> parens $ text vc <+> hsep (map genLHSUpdatePat_ lhspats)
        (UpdVar uv)            -> text uv
        (WildcardP)            -> wildcardDoc
        (LitPat (LitStrPattern s))      -> doubleQuotes (text s)       -- or doubleQuotes s
        (LitPat (LitIntegerPattern i))  -> text (show i)
        (LitPat (LitFloatPattern   f))  -> text (show f)
        (LitPat (LitBoolPattern    b))  -> text (show b)
        (ASPattern n p)        -> text n -- problematic
        a                      -> error $ "Non-exhaustive patterns in genLHSUpdatePat: " ++ show a


genRHSUpdatePat :: RHS -> Doc
genRHSUpdatePat (RHS prodruleplus) = genProdruleUpdate prodruleplus
  where
    genProdruleUpdate :: ProdrulePlus -> Doc
    genProdruleUpdate (ProdrulePlus prodruleName maybeupdates) = (text prodruleName) <+> hsep (map genEitherUpdatespat maybeupdates)

    genEitherUpdatespat :: Either Unchanged Update -> Doc
    genEitherUpdatespat (Left _ ) = wildcardDoc
    genEitherUpdatespat (Right (NUpdate vv st) ) = text $ if isPrimitiveWithLayout st then addLayoutFieldForPrimitive_SkipUpd vv else vv
    genEitherUpdatespat (Right (DUpdate st prodruleplus)) = parens . genProdruleUpdate $ prodruleplus


genUpdate :: ConsSubtreeEnv -> ViewType -> Rule -> (Doc, Doc, Doc)
genUpdate consSubtreeEnv groupVT (NormalRule lhs rhs) =
  let sDecompose = genRHSUpdatePat rhs
      vDecompose = genLHSUpdatePat lhs
      upd        = genUpd lhs rhs
  in  (wrapPatQ vDecompose, wrapPatQ sDecompose, wrapDecQ upd)
  where
    genUpd :: LHS -> RHS -> Doc
    genUpd (LHS lhsPat) (RHS pp) = foldr (\x xs -> x <> semi <+> xs) TPP.empty (genUpd1 pp)
      where
        -- eg: [Right (NUpdate "lhs" (SourceType "Expr")), Right (NUpdate "rhs" (SourceType "Term"))]
        -- will give: [d| lhs = ruleArithExpr; rhs = ruleArithTerm |].
        -- The "Arith" is found by the "ViewType" which is not mutable in a group.
        genUpd1 :: ProdrulePlus -> [Doc]
        genUpd1 (ProdrulePlus _ eitherupdates) = foldl' genUpd2 [] eitherupdates
          where
            genUpd2 :: [Doc] -> Either Unchanged Update -> [Doc]
            genUpd2 decs (Left _) = decs -- decs is the accumulative parameter
            genUpd2 decs (Right (NUpdate uv st)) =
              case borderlineCases lhsPat uv groupVT of
                  -- first handle the cases where LHS has no constructors. We need to use the ViewType from the definition of this action group
                  -- Cases such as: (e +> (e +> Exp)) ( e@(...) +> ... ) ( (e:es) +> ... ) ([e] +> ... ) ((e1,e2) +> ...)
                  Just vt -> decs ++ [text uv <+> equals <+> text "bigul" <> vt <> text st]
                  Nothing   ->
                    case findVarType uv lhsPat groupVT consSubtreeEnv 0 of
                      Nothing     -> (error $ "cannot find the update variable " ++ uv ++ " in the view pattern (LHS)"
                                      ++ "\nLHS pattern: " ++ show lhsPat)
                      Just uvType ->
                        case primitiveTyDoc decs uv st of
                          Just decs' -> decs'
                          Nothing    -> decs ++ [text uv <+> equals <+> text "bigul" <> text (eliminateSpace uvType) <> text st]
            genUpd2 decs (Right (DUpdate st prodruleplus)) = decs ++ genUpd1 prodruleplus

primitiveTyDoc :: [Doc] -> UVar -> SourceType -> Maybe [Doc]
primitiveTyDoc accDoc uv st = if isPrimitiveWithLayout st then Just (accDoc ++ [text uv <+> equals <+> text "Replace"]) else Nothing

--------------
-- cases where the type of the variable is determined by the view type of the group of actions.
-- they are all some special syntax rather than a alplaNum constructor.
-- eg: LHSpattern: (e:es) ; viewtype: [Maybe Int].
--                LHSpat -> update var -> view type -> Maybe Doc
borderlineCases :: LHSPattern -> String -> ViewType -> Maybe Doc
borderlineCases pp@(NormalP "ConsList" [v1, v2, vs]) uv cc@(ASTDataTypeDef "List" [t]) =
  --maybe (maybe (borderlineCases vs uv cc) Just (borderlineCases v2 uv t)) Just (borderlineCases v1 uv t)
  trace ("\nnima zhale " ++ show pp) $
  case (borderlineCases v1 uv t) of
    Just path -> Just path
    Nothing   -> case (borderlineCases v2 uv t) of
      Just path -> Just path
      Nothing   -> borderlineCases vs uv cc
borderlineCases (NormalP "ConsList" [v, vs]) uv cc@(ASTDataTypeDef "List" [t]) =
  maybe (borderlineCases vs uv cc) Just (borderlineCases v uv t)
borderlineCases (NormalP "Singleton" [v]) uv (ASTDataTypeDef "List" [t]) = borderlineCases v uv t
borderlineCases (NormalP "Tuple"  [v1,v2]) uv (ASTDataTypeDef "Tuple" [t1,t2]) =
  maybe (borderlineCases v2 uv t2) Just (borderlineCases v1 uv t1)
borderlineCases (NormalP "Triple" [v1,v2,v3]) uv (ASTDataTypeDef "Triple" [t1,t2,t3]) =
  case borderlineCases v1 uv t1 of
    Nothing   -> maybe (borderlineCases v3 uv t3) Just (borderlineCases v2 uv t2)
    doc      -> doc
borderlineCases ((ASPattern uv' _)) uv (ASTDataTypeDef vt ts) = if uv == uv' then Just $ text (eliminateSpace (produceVarType vt ts)) else Nothing
borderlineCases (UpdVar uv') uv (ASTDataTypeDef vt ts)        = if uv' == uv then Just $ text (eliminateSpace (produceVarType vt ts)) else Nothing
borderlineCases pat uv vt  = Nothing


-- get the type of the updating variable (uv) in RHS. Locate the variable (uv) in LHS and return its type.
--              var name -> pattern -> (constructor + type fields) -> Env -> counter -> Maybe (var type)
findVarType :: String -> LHSPattern -> ASTDataTypeDef -> ConsSubtreeEnv -> Int -> Maybe String
findVarType var (NormalP _ []) (ASTDataTypeDef conName []) _ _ = Nothing
findVarType var (NormalP "Just" [p])   (ASTDataTypeDef "Maybe" [t]) env pos = findVarType var p t env pos
findVarType _   (NormalP "Nothing" []) (ASTDataTypeDef "Maybe" _) env pos = Nothing
findVarType _   (NormalP "EmptyList" []) _ _ _ = Nothing
findVarType var (NormalP "Singleton" [p]) (ASTDataTypeDef "List" [t]) env pos = findVarType var p t env pos
findVarType var (NormalP "ConsList" [p1,p2,ps]) cc@(ASTDataTypeDef "List" [t]) env pos =
  maybe (maybe (findVarType var ps cc env pos) Just (findVarType var p2 t env pos)) Just (findVarType var p1 t env pos)
findVarType var (NormalP "ConsList" [p,ps]) cc@(ASTDataTypeDef "List" [t]) env pos = maybe (findVarType var ps cc env pos) Just (findVarType var p t env pos)
  -- ps is restricted to be a single var pattern. but its type is still [list] type
findVarType var (NormalP "Tuple" [p1,p2]) (ASTDataTypeDef "Tuple" [t1,t2]) env pos = maybe (findVarType var p2 t2 env pos) Just (findVarType var p1 t1 env pos)
findVarType var (NormalP "Triple" [p1,p2,p3]) (ASTDataTypeDef "Triple" [t1,t2,t3]) env pos =
  case findVarType var p1 t1 env pos of
    Nothing ->  maybe (findVarType var p3 t3 env pos) Just (findVarType var p2 t2 env pos)
    path    -> path
findVarType var (NormalP "Left"  [p]) (ASTDataTypeDef "Either" [t1,t2]) env pos = findVarType var p t1 env pos
findVarType var (NormalP "Right" [p]) (ASTDataTypeDef "Either" [t1,t2]) env pos = findVarType var p t2 env pos
findVarType var cc@(NormalP vc (p:ps)) _ env pos =
  case Map.lookup vc env of
    Nothing     -> error $ "the constructor " ++ vc ++ " is not defined in the abstract data type."
                            ++ "does the view type for the group of actions matches the patterns?"
    Just tts -> case findVarType var p (tts !! pos) env 0 of
                  Nothing -> findVarType var (NormalP vc ps) (ASTDataTypeDef vc (drop (pos+1) tts)) env (pos+1) -- index starts from 0. but we need to use (pos+1)
                  path    -> path
    --Just tts  -> case catMaybes $ zipWith (\p t -> findVarType var p t env) (p:ps) tts of
    --              [] -> error "SB."
    --              [path]    -> trace ("\npath: " ++ show path) $ Just path
findVarType var (ASPattern var' _) (ASTDataTypeDef conName ts) env _ = if var /= var' then Nothing else Just (produceVarType conName ts)
findVarType var (UpdVar var') (ASTDataTypeDef conName ts) env _     = if var /= var' then Nothing else Just (produceVarType conName ts)
findVarType _ (LitPat _) _ _ _ = Nothing
findVarType _ WildcardP _ _ _  = Nothing
findVarType var pat ty env pos =
  error $ "Non-exhaustive pattern in findVarType.\n" ++ "variable name: " ++ var ++
          "\nlhspat: " ++ show pat ++ "\ntype fields: " ++ show ty


getEntrance :: Program -> String
getEntrance (Program (TypeDecl (ASTDataTypeDef vt ts) st) _) = "entrance = " ++ "bigul" ++ eliminateSpace (produceVarType vt ts) ++ st

eliminateSpace :: String -> String
eliminateSpace = filter (/= ' ')


importStr :: String
importStr =
  render  (foldr (\x xs -> text x $$ xs )
          TPP.empty
          ["{-# Language TemplateHaskell, QuasiQuotes #-}"
          ,"import GHC.Generics"
          ,"import Data.Typeable"
          ,"import Generics.BiGUL hiding (Expr, Pat, Var, Direction)"
          ,"import Generics.BiGUL.Interpreter"
          ,"import Generics.BiGUL.TH"
          ,"import Parser (parser2, str2CST)"
          ,"import Text.PrettyPrint (render)"
          ,"import YourLangDef"
          ,"import System.Environment (getArgs)"
          ,"import System.IO.Strict as IOS"
          ])

mainStr :: String
mainStr =
  render  (foldr (\x xs -> text x $$ xs )
          TPP.empty
          ["main :: IO ()"
          ,"main = do"
          ,"  args <- getArgs"
          ,"  if length args < 3"
          ,"    then error $ usageInfoGet ++ usageInfoPut"
          ,"    else do"
          ,"      let getOrPut      = args !! 0"
          ,"          srcCodeFName  = args !! 1"
          ,"          astFName      = args !! 2"
          ,"      srcCode <- IOS.readFile srcCodeFName"
          ,"      let (comm, cst) = parser2 srcCode"
          ,"      case getOrPut of"
          ,"        \"get\" -> do"
          ,"                   let ast = maybe (error $ \"get error\" ++ getErrTip) id (get entrance cst)"
          ,"                   writeFile astFName (show ast)"
          ,"        \"getTrace\" -> do"
          ,"                        let tr = (getTrace entrance cst)"
          ,"                        putStrLn (show tr)"
          ,"        \"put\" -> do"
          ,"                   let newSrcCodeName = if length args == 4 then args !! 3 else srcCodeFName"
          ,"                   srcCode <- IOS.readFile srcCodeFName"
          ,"                   ast <- IOS.readFile astFName"
          ,"                   let srcCode' = maybe (error $ \"put error\" ++ putErrTip) id (put entrance cst (read ast))"
          ,"                   writeFile newSrcCodeName (comm ++ show srcCode')"
          ,"        \"putTrace\" -> do"
          ,"                        let newSrcCodeName = if length args == 4 then args !! 3 else srcCodeFName"
          ,"                        srcCode <- IOS.readFile srcCodeFName"
          ,"                        ast <- IOS.readFile astFName"
          ,"                        let tr = (putTrace entrance cst (read ast))"
          ,"                        putStrLn (show tr)"
          ,"  where"
          ,"    usageInfoGet = \"usage - get: YourExecutable get CodeFileName ASTFileName\\n\""
          ,"    usageInfoPut = \"usage - put: YourExecutable put OldCodeFileName ASTFileName NewCodeFileName\\n\""
          ,"    getErrTip    = \"use getTrace instead of get to see tracing information.\""
          ,"    putErrTip    = \"use putTrace instead of put to see tracing information.\""
          ])
