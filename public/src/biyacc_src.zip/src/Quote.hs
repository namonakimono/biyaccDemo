module Quote where

import Data.Generics
import qualified Language.Haskell.TH as TH
import Language.Haskell.TH.Quote
import Language.Haskell.TH.Syntax

import LanguageDef
import ProgramTokenizer
import ProgramParser as PP
import SourceType as ST
import ProgramTrans as PT
import AbstractType as AT
import BiYaccUtils
import qualified GenLexer as GL (prtPrinter)

import Text.Parsec hiding (getPosition, newline)
import Text.PrettyPrint as TPP

import System.Process

import Debug.Trace


by  :: QuasiQuoter
by  =  QuasiQuoter
  { quoteExp = undefined
  , quotePat = undefined
  , quoteDec = quoteBiYaccDec
  , quoteType = undefined
  }


tokenizer_all :: Parsec String () ((AT.TokenPos,String), [ST.TokenPos], [PP.TokenPos])
tokenizer_all = do
  (absTypeDecls, rawinput) <- pAbstract
  srcTypeTokens <- tokenSrcType
  progTokens <- tokenProgram
  return ((absTypeDecls,rawinput), srcTypeTokens, progTokens)


tokenizer_Quosi :: Monad m => (String, Int, Int) -> String -> m ((AT.TokenPos,String), [ST.TokenPos], [PP.TokenPos])
tokenizer_Quosi (file, line, col) s = either (fail . show) return (runParser tokenizer_all () "" s)

-- do the tricks with this function
-- the problem that "qAddTopDecls" cannot add top level type declarations will be fixed soon.
-- so it is not economical to implement other main module for IO operations and throw them away in one month.
-- for the test usage, I will print the bigul program and read it use this function.
quoteBiYaccDec :: String -> TH.Q [TH.Dec]
quoteBiYaccDec s = do
  pos <- getPosition
  ((absDecls,rawinput), srcTypeTokens, progTokens) <- tokenizer_Quosi pos s
  let (AAnything absDeclsStr, _)            = absDecls
      srcTmpCAST                            = buildTmpCAST srcTypeTokens
      (srcTypeCAST, srcTypeEnv)             = (toCAST srcTmpCAST, buildEnv srcTmpCAST)
      (eigenNameEnv, nameEigenEnv, nullEnv, similarProdruleEnv) = srcTypeEnv
      consToSubtreeTypeEnv = buildConsToSubtreeTypeEnv $ either (error . show) id (parse pDatatypes "namonaki" (absDeclsStr ++ " data"))
      srcDeclsStr                           = prtSrcDatatypes srcTypeCAST
      cstInstanceShowStr                    = GL.prtPrinter srcTypeCAST
  progCAST <- either (fail . show) return (runParser (program eigenNameEnv) () "" progTokens)

  let sssprogstring = genBiGUL nameEigenEnv nullEnv similarProdruleEnv consToSubtreeTypeEnv progCAST
      entranceStr   = getEntrance progCAST
      hehehe = importStr `newlineS` entranceStr  `newlineS` sssprogstring `newlineS` mainStr
  runIO $ writeFile "YourLangDef.hs" (defFileString absDeclsStr srcDeclsStr cstInstanceShowStr)
  runIO $ writeFile "s1.bigul.program.hs" hehehe

  runIO $ writeFile "ByRawInput.txt" rawinput
  runIO $ readProcess "happy" ["-o","ByParser.hs","ByParser.y"] ""
  runIO $ readProcess "ghc" ["-O2","GenLexer.hs","-main-is", "GenLexer"] ""
  biyaccprog <- runIO $ readProcess "./GenLexer" ["ByRawInput.txt"] ""
  runIO $ writeFile "Parser.y" biyaccprog
  runIO $ readProcess "happy" ["Parser.y"] ""

  runIO $ readProcess "ghc" ["-O2","s1.bigul.program.hs"] ""
  -- dataToExpQ (const Nothing `extQ` antiExprExp) exp


  --traceM (show (srcTypeCAST))
  return emptyDec

emptyDec :: [TH.Dec]
emptyDec = TH.FunD (TH.mkName "zantaohehe") [TH.Clause [] (TH.NormalB . TH.LitE . TH.CharL $ 'h')  []] :[]


-- put abstract datatypes, concrete datatypes into a separate file.
defFileString :: String -> String -> String -> String
defFileString absDef concDef cstInstanceShowStr =
  (foldr (\x xs -> x ++ "\n" ++ xs )
        ""
        ["{-# Language TemplateHaskell, TypeFamilies #-}"
        ,"module YourLangDef where"
        ,"import GHC.Generics"
        ,"import Generics.BiGUL.TH"
        ,"import Data.Typeable"
        ,""
        , "type NameX9or2c81 = String"
        ])
  `newlineS` absDef `newlineS` concDef `newlineS` cstInstanceShowStr



-- quoteSrcExp :: String -> TH.ExpQ
-- quoteSrcExp s = do
--   pos <- getPosition
--   tokens <- tokenSrcType_ForQuasi pos s
--   dataToExpQ (const Nothing) (toCAST (buildTmpCAST tokens))


getPosition = fmap transPos TH.location where
  transPos loc = (TH.loc_filename loc,
                  fst (TH.loc_start loc),
                  snd (TH.loc_start loc))

by_f = quoteFile by
-- src_f = quoteFile src

