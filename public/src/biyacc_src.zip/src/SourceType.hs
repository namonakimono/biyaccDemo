{-# Language DeriveDataTypeable, TemplateHaskell, FlexibleContexts, OverloadedStrings #-}
module SourceType (prtSrcDatatypes, buildEnv, buildTmpCAST, toCAST, addTopLevelDataype, addNullConstructor, addConsName, tokenSrcType, TokenPos, CAST(CAST), CDataType(CDataType), CTypeDef(CTypeDef), EitherTNT) where

import LanguageDef
import BiYaccUtils

--import DeriveBiGULGenerics

import Text.Parsec as Parsec hiding (State, newline)
import Text.Parsec.Token

import Control.Monad.State.Lazy (MonadState, State, get, put, evalState, liftM, liftM2)

import qualified Data.Map as Map (map)
import Data.Map as Map (singleton, union, unions, insert, empty)
import Data.List (foldl1)

import Language.Haskell.TH

import Text.PrettyPrint as PTT

import Debug.Trace

type TokenPos = (ConcreteToken, SourcePos)


type TokenType = Parsec String () TokenPos
type TokenTypes = Parsec String () [TokenPos]


keyword :: TokenType
keyword = byLexeme ( do
  pos <- getPosition
  choice [try (string "Concrete") >> return (CSourceType, pos)])
  <?> "error in keyword"

-- drop the priority operator: %Right ...;
dropPriorityOpt :: Parsec String () [TokenPos]
dropPriorityOpt = byLexeme (do
  pos <- getPosition
  string "%"
  manyTill p0 (try (string ";"))
  return []
  )
  where p0 = (( try (string "';'")  <|> try (string "\";\"")) >> return ' ') <|> anyChar

--string literal
--will change char literal to string literal
terminal :: TokenType
terminal = byLexeme (do
  pos <- getPosition
  choice [try (stringLiteral generatedParser) >>= \str -> return (CTerminal str, pos)
         ,try byCharLit                       >>= \str -> return (CTerminal str, pos)])
  <?> "error in string literal tokenizer"

nonterminal :: TokenType
nonterminal = byLexeme (do
  pos <- getPosition
  nont <- identifier generatedParser
  return (CNonterminal nont, pos))
  <?> "error in nonterminal"


--userdata :: TokenType
--userdata = byLexeme $ do
--  pos <- getPosition
--  string "String"
--  return (CNonterminal "String", pos) -- treat all the user data (float, int, bool, ...) as string


ruleStart :: TokenType
ruleStart = byLexeme (do
  pos <- getPosition
  choice [try (string "->") >> return (CIs, pos)
         ,try (string "|")  >> return (COr, pos)])
  <?> "error in symbol tokenizer"

ruleEnd :: TokenType
ruleEnd = byLexeme (do
  pos <- getPosition
  string ";"
  return (CSemi, pos)
  )
  <?> "error in ruleEnd, expect semicolon ';'"

-- each line of the production rule. eg | Expr '-' Term
ruleLine :: TokenTypes
ruleLine = do
  split <- ruleStart
  rhs <- many1 (try terminal <|> try nonterminal)
  return (split : rhs)

productionRule :: TokenTypes
productionRule = do
  datatype <- nonterminal
  tmp <- many1 (try ruleLine)
  end <- ruleEnd
  let rhss = concat tmp
  return (datatype : (rhss ++ [end]))



tokenSrcType :: Parsec String () [TokenPos]
tokenSrcType = do
  whiteSpace generatedParser
  k <- keyword
  try (many dropPriorityOpt) -- skip priority definitions for operators
  prules <- many1 productionRule
  return (k : concat prules)

tokenSrcType_ForQuasi :: Monad m => (String, Int, Int) -> String -> m [TokenPos]
tokenSrcType_ForQuasi (file, line, col) s =
  case runParser tokenSrcType () "" s of
    Left err  -> fail $ show err
    Right tokens   -> return tokens



t1 = do
  let fname = "s1.txt"
  stream <- readFile fname
  case (parse tokenSrcType fname stream) of
    Left err -> print err
    Right xs -> print (map fst xs)


--------------tokenizer     end-----------------


---------------- parser -------------------
type ParserU = Parsec [TokenPos] ()

isToken :: ConcreteToken -> Parsec [TokenPos] () ConcreteToken
isToken tok = token show snd (\t -> if fst t == tok then Just (fst t) else Nothing)

data CAST = CAST String [CDataType] deriving (Show, Eq) -- CAST (top level datatype) [datatypes]
data CDataType = CDataType String [CTypeDef] deriving (Show, Eq) -- CDataType type definitions. CDataType "Expr" [...]
data CTypeDef = CTypeDef String [EitherTNT] deriving (Show, Eq) -- CTypeDef constructor [types]

type EitherTNT = Either String String -- either it is a string terminal or datatypes. nonterminal is reserved when finishing parsing and used when building the env. It is deleted later.
-- Left: string Terminal. Right: others

extractTerminal :: Parsec [TokenPos] () String
extractTerminal = token show snd (\t -> case fst t of CTerminal s -> Just s; _ -> Nothing)

extractNonTerminal :: Parsec [TokenPos] () String
extractNonTerminal = token show snd (\t -> case fst t of CNonterminal s -> Just s; _ -> Nothing)



cdatatypes :: ParserU CAST
cdatatypes = isToken CSourceType >> liftM2 CAST (return "") (many1 datatype)

datatype :: ParserU CDataType
datatype = do
  t <- extractNonTerminal
  first <- firstline
  following <- many followingline
  isToken CSemi
  return $ CDataType t (first:following)
  where
    firstline = do
      isToken CIs
      eithers_ <- many ( (extractTerminal >>= return . Left) <|> (extractNonTerminal >>= return  . Right) )
      return $ CTypeDef "" eithers_

    followingline = try (do
      isToken COr
      eithers_ <- many1 (try (extractTerminal >>= return . Left ) <|> try (extractNonTerminal >>= return . Right))
      return $ CTypeDef "" eithers_)

-- tempCAST is used to build environment. after that. we use toCAST to transform it into a "real" CAST (does not contain terminals)
buildTmpCAST :: [TokenPos] -> CAST
buildTmpCAST tokenpos = either (error . show) (id) (parse cdatatypes "" tokenpos)

-- transform tempCAST to CAST
toCAST :: CAST -> CAST
toCAST tmpcast = addNullConstructor . addTopLevelDataype . addLayoutField . addConsName $ tmpcast

addTopLevelDataype (CAST _ defs) = let (CDataType t _) = head defs in CAST t defs



removeTerminal :: CAST -> CAST
removeTerminal (CAST topt cdatatypes) = CAST topt (map remove1 cdatatypes)
  where remove1 :: CDataType -> CDataType
        remove1 (CDataType t ctypedefs) = CDataType t (map remove2 ctypedefs)
        remove2 :: CTypeDef -> CTypeDef
        remove2 (CTypeDef con tnts) = CTypeDef con (filter (either (const False) (const True)) tnts)

-- add the constructor name to CAST in a state monad. generate a unique constructor name for each CTypeDef
addConsName :: CAST -> CAST
addConsName (CAST topt cdatatypes) = CAST topt (map refine1 cdatatypes)
  where
    refine1 :: CDataType -> CDataType
    refine1 (CDataType prefix ctypedefs) = CDataType prefix (evalState (mapM refine2 ctypedefs) (genNameList prefix))
    refine2 :: MonadState [String] m => CTypeDef -> m CTypeDef
    refine2 (CTypeDef _ tnts) = do
      nameList <- get
      put $ tail nameList
      return $ CTypeDef (head nameList) tnts

addLayoutField :: CAST -> CAST
addLayoutField (CAST topt cdatatypes) = CAST topt (map refine1 cdatatypes)
  where
  refine1 (CDataType prefix ctypedefs) = CDataType prefix (map refine2 ctypedefs)
  refine2 (CTypeDef t tnts) = CTypeDef t (map (either (Left) (Right . addLayoutFieldIfPrimitive)) tnts)





addNullConstructor :: CAST -> CAST
addNullConstructor (CAST topt cdatatypes) = CAST topt $ evalState (mapM refine1 cdatatypes) (genNameList "Null")
  where
    refine1 :: MonadState [String] m => CDataType -> m CDataType
    refine1 (CDataType prefix ctypedefs) = do
      nameList <- get
      put $ tail nameList
      return $ CDataType prefix (ctypedefs ++ [CTypeDef (prefix ++ head nameList) [] ])


-- the parameter is tempCAST
buildEnv :: CAST -> (EigenNameEnv, NameEigenEnv, NullEnv, SimilarProdruleEnv)
buildEnv tmpCAST =
  let (CAST topt cdatatypes) = addLayoutField (addConsName tmpCAST)
      envs                      = map build1 cdatatypes
      nullenv                   = null1 (addConsName tmpCAST)
      similarProdruleEnv        = unions $ map similar1 cdatatypes
  in  (unions $ map fst envs, unions $ map snd envs, nullenv, similarProdruleEnv)
  where
    build1 :: CDataType -> (EigenNameEnv,NameEigenEnv)
    build1 (CDataType t ctypedefs) = let envs = (map (build2 t) ctypedefs)
                                     in (unions $ map fst envs, unions $ map snd envs)
    build2 :: String -> CTypeDef -> (EigenNameEnv, NameEigenEnv)
    build2 t (CTypeDef key patterns) = (singleton (patterns,t) key , singleton key (patterns,t))
    -- build the NullEnv. use the same strategy (state monad) when adding the Null constructor.
    -- but this time we build the env rather than refine the CAST.
    null1 :: CAST -> NullEnv
    null1 (CAST _ cdatatypes) = unions $ evalState (mapM null2 cdatatypes) (genNameList "Null")
    null2 :: MonadState [String] m => CDataType -> m NullEnv
    null2 (CDataType prefix ctypedefs) = do
      nameList <- get
      put $ tail nameList
      return $ singleton prefix (prefix ++ head nameList)
    similar1 :: CDataType -> SimilarProdruleEnv
    similar1 all@(CDataType _ ctypedefs) = unions $ map (similar2 all) ctypedefs
    similar2 :: CDataType -> CTypeDef -> SimilarProdruleEnv
    similar2 (CDataType _ ctypedefs) theTypeDef = similar3 theTypeDef ctypedefs
    similar3 :: CTypeDef -> [CTypeDef] -> SimilarProdruleEnv
    similar3 a b = similar3_ a b []
    similar3_ :: CTypeDef -> [CTypeDef] -> [[String]] -> SimilarProdruleEnv
    similar3_ (CTypeDef key _)           []                           [] = Map.empty
    similar3_ (CTypeDef key _)           []                           ss = singleton key (reverse ss) -- reverse or not does not mater
    similar3_ pa@(CTypeDef key thePats) ((CTypeDef key' pats'): defs) ss =
      if key /= key' -- similar production rules does not contain itself
        then  if isMatched thePats pats'
                then similar3_ pa defs ( (key' : mkWithFreshName pats') : ss)
                else similar3_ pa defs ss
        else  similar3_ pa defs ss


    -- mkWithFreshName [Right Expr, Left '+', Right Term] ---> [subExpr0, layouts1, subTerm2]
    mkWithFreshName :: [EitherTNT] -> [String]
    mkWithFreshName ps = mkWithFreshName_ ps [] (map show [0,1..])
    mkWithFreshName_      []       acc _       = reverse acc
    mkWithFreshName_ (Left _  :xs) acc nseries = mkWithFreshName_ xs (("layouts" ++  head nseries) : acc) (tail nseries)
    mkWithFreshName_ (Right t :xs) acc nseries =
      let subtree = if isPrimitiveWithLayout t
                      then "(undefined, layouts" ++ head nseries ++ ")"
                      else "sub" ++ t ++ head nseries
      in  mkWithFreshName_ xs (subtree : acc) (tail nseries)

    isMatched :: [EitherTNT] -> [EitherTNT] -> Bool
    isMatched [] [] = True
    isMatched (x:xs) (y:ys) = if isMatchedSingle x y then isMatched xs ys else False
    isMatched _ _   = False
    isMatchedSingle :: EitherTNT -> EitherTNT -> Bool
    isMatchedSingle (Left _) (Left _)   = True -- both are terminals
    isMatchedSingle (Right x) (Right y) = x == y || isPrimitiveWithLayout x && isPrimitiveWithLayout y -- x and y are strings. just compare them.
    isMatchedSingle _ _                 = False


getConName :: State [String] String
getConName = do n <- get; put $ tail n; return $ head n

genNameList :: String -> [String]
genNameList name = zipWith (\a b -> a ++ b) (repeat name) (map show [0,1..])

------------- parser ends -------

------------- generate Haskell datatypes-------
prtSrcDatatypes :: CAST -> String
prtSrcDatatypes (CAST topt defs) = render $ vcat2 (map prtSrcDatatype defs) `newlineD` (genDrvBiGULGeneric (CAST topt defs))

prtSrcDatatype :: CDataType -> Doc
prtSrcDatatype (CDataType dName defs) =
  ((datadec_head <+> text dName <+> equals) <+>
  foldl1 (\xs x -> xs $$ nestn2 (text "|" <+> x) ) (map prtSrcTypeDef defs))
  $$ nest2 datadec_drv

prtSrcTypeDef :: CTypeDef -> Doc
prtSrcTypeDef (CTypeDef dcons fields) = hsep (text dcons : map f fields)
  -- represent terminals as strings, with surrounding comments and layouts
  where f = either (const (text "String")) text
  --where f = either (error "data type should not contain terminals") text


datadec_head = "data"
datadec_drv  = "deriving Eq"


genDrvBiGULGeneric :: CAST -> Doc
genDrvBiGULGeneric (CAST _ defs) = vcat (map gen1 defs)
  where
    gen1 (CDataType dName defs) = gen2 dName
    gen2 name = "deriveBiGULGeneric ''" <> text name

--genDrvBiGULGeneric :: String -> Doc
--genDrvBiGULGeneric name = "deriveBiGULGeneric ''" <> text name



---------

{-
this file contains functions for tokenizing and parsing concrete datatypes (the part after "Concrete" keyword in a BiYacc file), meanwhile
generating the corresponding Haskell datatypes (declarations, Q [Dec]) and some environment for further usage.

The three Environment are
type EigenNameEnv   = Map (ProdRuleEigen,ProdRuleType) ProdruleName  eg (["Expr", "+", "Term"],"Expr") ---> A0
type NameEigenEnv   = Map ProdruleName (ProdRuleEigen,ProdRuleType)  eg A0   ---> (["Expr", "+", "Term"],"Expr")
type NullEnv        = Map String String                              eg Expr  ---> ExprNull0

The differences between first two are just some swaps between the key-value pair.

Users only write production rules, however, the tool will produce somehow refined datatypes according to the production rules.
1) generate a constructor for each production rule.
2) generate a "NULL" datatype for each block of production rule (block: production rules starting from the same nonterminal)

When the parser scans the Tokens for the first time, it will generate some temporary datatypes (concrete AST) with holes.
Then we pass the temporary CAST to some help functions to do 1) and 2). These are achieved by state monad.
-}

