import Parser
import System.IO
import System.Environment

main :: IO ()
main = do
  args <- getArgs
  prog <- readFile (args !! 0)
  let toks = lexer prog
  putStrLn $ show (mergeWS toks)
  putStrLn $ show (parser (tail (mergeWS (TokenWS "" : toks))))

