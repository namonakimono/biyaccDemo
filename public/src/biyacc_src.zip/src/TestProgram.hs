{-# Language TemplateHaskell, QuasiQuotes #-}

module TestProgram where

import Quote
import Language.Haskell.TH.Quote
import Language.Haskell.TH

import LanguageDef
import ProgramTokenizer
import SourceType


import GHC.Generics
import Generics.BiGUL.AST hiding (Expr, Pat)
import Generics.BiGUL.TH

-- t = print $ [by_f|action.txt|]


-- note: for simplicity, the beginning spaces between the part Abstract and the part Concrete is not handled.
-- please write this part left-most as if it were top-level haskell declarations.
-- also write the deriveBiGULGeneric for the Abstract datatypes.
[by|
Abstract

data Arith = Add Arith Arith
           | Sub Arith Arith
           | Mul Arith Arith
           | Div Arith Arith
           | Num Int
  deriving (Show, Eq, Read)

deriveBiGULGeneric ''Arith


Concrete

Expr   -> Expr '+' Term
        | Expr '-' Term
        | Term
        ;

Term   -> Term '*' Factor
        | Term '/' Factor
        | Factor
        ;

Factor -> '-' Factor
        | Int
        | '(' Expr ')'
        ;


Actions

Arith +> Expr
Add lhs       rhs  +> (lhs +> Expr) '+' (rhs +> Term);
Sub lhs       rhs  +> (lhs +> Expr) '-' (rhs +> Term);
arith              +> (arith +> Term);

Arith +> Term
Mul lhs rhs   +>  (lhs +> Term) '*' (rhs +> Factor);
Div lhs rhs   +>  (lhs +> Term) '/' (rhs +> Factor);
arith         +>  (arith +> Factor);

Arith +> Factor
Sub (Num #0) rhs  +> '-' (rhs +> Factor);
Num n             +> (n +> Int);
arith             +> '(' (arith +> Expr) ')';
  |] -- this bracket should be placed with some indentations, or else GHC will throw some errors.


--(\s v -> case v of
--                    Add (Sub l1 r1) r0 -> True
--                    _                  -> False;)
-- here is a potential way to write an adaptive function
-- if we do not provide constructors of concrete datatypes for users,
--Adaptive: (Source: Expr -> (Expr '-' Term) '+' Term)
--          (View: Add _ _)
--          (Fun: e0 -> (e1 '-' t1) '+' t0   ==>>  e0 -> (e1 '+' t0) '-' t1 );
