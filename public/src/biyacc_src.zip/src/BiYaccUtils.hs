module BiYaccUtils where

import Text.PrettyPrint as TPP

nest2 :: Doc -> Doc
nest2 = nest 2

nestn2 = nest (-2)

nestn1 = nest (-1)

wildcardDoc = text "_"

-- put something in  [p|]: [p| ...something... ]
wrapPatQ :: Doc -> Doc
wrapPatQ d = text "[p|" <+> d <+> text "|]"

wrapDecQ :: Doc -> Doc
wrapDecQ d = text "[d|" <+> d <+> text "|]"

vcat2 = vcat . punctuate (text "\n")

newlineD :: Doc -> Doc -> Doc
newlineD d1 d2 = d1 $$ text "\n" $$ d2

infixr 5 `newlineS`
newlineS :: String -> String -> String
newlineS s1 s2 = s1 ++ "\n\n" ++ s2



-- if the type t is primitive types, eg: Int, Bool, String, Float ...
-- make t into (t, String) to contain layouts/comments information
addLayoutFieldIfPrimitive :: String -> String
addLayoutFieldIfPrimitive t = if (isPrimitive t) then wrap t else t
  where wrap t = case t of
                   "Name" -> "(" ++ "NameX9or2c81" ++ ", String" ++ ")"
                   _      -> "(" ++ t ++ ", String" ++ ")"

-- Name is too commong in the libraries of Haskell. So I changed it to another name to avoid confilict...

isPrimitive t = elem t ["Name", "NameX9or2c81", "String", "Int", "Integer", "Bool", "Float", "Double"]

isPrimitiveWithLayout t =
  elem t [ "(Name, String)", "(NameX9or2c81, String)", "(String, String)", "(Int, String)", "(Integer, String)"
         , "(Bool, String)", "(Float, String)", "(Double, String)"]

addLayoutFieldIfPrimitive_SkipUpd :: String -> String
addLayoutFieldIfPrimitive_SkipUpd t = "(" ++ t ++ ", _" ++ ")"