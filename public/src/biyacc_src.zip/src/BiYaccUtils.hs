{-# Language ViewPatterns #-}

module BiYaccUtils where

import Text.PrettyPrint as TPP
import LanguageDef

nest2 :: Doc -> Doc
nest2 = nest 2

nest3 = nest 3

nestn2 = nest (-2)

nestn1 = nest (-1)


wildcardDoc = text "_"

-- put something in  [p|]: [p| ...something... ]
wrapPatQ :: Doc -> Doc
wrapPatQ p = text "[p|" <+> p <+> text "|]"

wrapDecQ :: Doc -> Doc
wrapDecQ d = text "[d|" <+> d <+> text "|]"

wrapExpQ :: Doc -> Doc
wrapExpQ e = text "[|" <+> e <+> text "|]"

vcat2 = vcat . punctuate (text "\n")

newlineD :: Doc -> Doc -> Doc
newlineD d1 d2 = d1 $$ text "\n" $$ d2

infixr 5 `newlineSS`
newlineSS :: String -> String -> String
newlineSS s1 s2 = s1 ++ "\n\n" ++ s2

infixr 5 `newlineS`
newlineS :: String -> String -> String
newlineS s1 s2 = s1 ++ "\n" ++ s2

foldr1c :: (a -> b) -> (a -> b -> b) -> [a] -> b
foldr1c c _ [e] = c e
foldr1c c h (e:es) = h e (foldr1c c h es)

--             constructor name -> type parameters -> env
produceVarType :: String -> [ASTDataTypeDef] -> String
produceVarType conName ts = " " ++ conName ++ " " ++ produceVarType' ts
  where
    produceVarType' :: [ASTDataTypeDef] -> String
    produceVarType' [] = ""
    produceVarType' (t:ts) =
      (case t of
              ASTDataTypeDef "List" [tts'] -> "[" ++ produceVarType' [tts'] ++ "]"
              ASTDataTypeDef "Tuple" tts -> "(" ++ foldr1 (\t ts -> t ++ ", " ++ ts) (map (\t -> produceVarType' [t]) tts) ++ ")"
              ASTDataTypeDef conName ts' -> produceVarType conName ts')
      ++ produceVarType' ts

concatSpace :: [String] -> String
concatSpace [] = []
concatSpace (x:xs) = x ++ " " ++ concatSpace xs

-- if the type t is primitive types, eg: Int, Bool, String, Float ...
-- make t into (t, String) to contain layouts/comments information
addLayoutFieldIfPrimitive :: String -> String
addLayoutFieldIfPrimitive t = if (isPrimitive t) then wrap t else t
  where wrap t = "(" ++ t ++ ", String" ++ ")"

delLayoutFieldIfPrimitive :: String -> String
delLayoutFieldIfPrimitive t = if (isPrimitiveWithLayout t) then unWrap t else t
  where unWrap t = case t of
                     --"(BiNameTy, String)" -> "Name"
                     --"(BiNumStrTy, String)"   -> "NumStrTy"
                     t1 -> drop 1 . take (length t1 - 9) $ t1

-- the "Name" is pervasive in the libraries of Haskell.
-- So I changed it to another name to avoid confilict...
isPrimitive :: String -> Bool
isPrimitive t = elem t ["BiNameTy", "String", "BiIntStrTy", "BiNatStrTy", "BiIntegerStrTy", "Bool", "BiFloatStrTy", "BiDoubleStrTy"]

isNumType :: String -> Bool
isNumType t = elem t ["Int", "Integer", "Float", "Double"]

isPrimitiveWithLayout t =
  elem t [ "(BiNameTy, String)", "(String, String)", "(BiIntStrTy, String)", "(BiIntegerStrTy, String)"
         , "(BiNatStrTy, String)", "(Bool, String)", "(BiFloatStrTy, String)", "(BiDoubleStrTy, String)"]

addLayoutFieldForPrimitive_SkipUpd :: String -> String
addLayoutFieldForPrimitive_SkipUpd t = "(" ++ t ++ ", _" ++ ")"

-- change primitive types such as Int, Float to String type to hold precisely all the information
numTyToStrTy :: String -> String
numTyToStrTy "Int"     = "BiIntStrTy"
--numTyToStrTy "Natural" = "BiNatStrTy"
numTyToStrTy "Integer" = "BiIntegerStrTy"
numTyToStrTy "Float"   = "BiFloatStrTy"
numTyToStrTy "Double"  = "BiDoubleStrTy"
numTyToStrTy t         = t

nameTytoBiNameTy :: String -> String
nameTytoBiNameTy "Name" = "BiNameTy"
nameTytoBiNameTy t = t

toBiYaccTy :: String -> String
toBiYaccTy = nameTytoBiNameTy . numTyToStrTy
