module TestFunctions where

import Data.Map (toList)
import Quote
import LanguageDef
import ProgramTokenizer
import ProgramParser as PP
import SourceType as ST
import ProgramTrans as PT
import AbstractType as AT
import BiYaccUtils
import qualified GenLexer as GL (prtPrinter)

import Text.Parsec hiding (getPosition, newline)
import Text.PrettyPrint as TPP

import System.Process

import Debug.Trace

testfunction :: String -> IO ()
testfunction byFileName = do
  stream <- readFile byFileName
  let ((absDecls, _), srcTypeTokens, progTokens) = either (error . show) id (runParser tokenizer_all () byFileName stream)
  let (AAnything absDeclsStr, _)            = absDecls
      srcTmpCAST                            = buildTmpCAST srcTypeTokens
      (srcTypeCAST, srcTypeEnv)             = (toCAST srcTmpCAST, buildEnv srcTmpCAST)
      (eigenNameEnv, nameEigenEnv, nullEnv, similarProdruleEnv) = srcTypeEnv
  let srcDeclsStr                           = prtSrcDatatypes srcTypeCAST
      cstInstanceShowStr                    = GL.prtPrinter srcTypeCAST
      consToSubtreeTypeEnv = buildConsToSubtreeTypeEnv $ either (error . show) id (parse pDatatypes "namonaki" (absDeclsStr ++ " data"))
      progCAST = either (error . show) id (runParser (program eigenNameEnv) () "" progTokens)

      sssprogstring = genBiGUL nameEigenEnv nullEnv similarProdruleEnv consToSubtreeTypeEnv progCAST
      entranceStr   = getEntrance progCAST
      bigulProgramStr = importStr `newlineS` entranceStr  `newlineS` sssprogstring `newlineS` mainStr

  writeFile "YourLangDef.hs" (defFileString absDeclsStr srcDeclsStr cstInstanceShowStr)
  writeFile "s1.bigul.program.hs" bigulProgramStr

  --writeFile "ByRawInput.txt" rawinput
  readProcess "happy" ["-o","ByParser.hs","ByParser.y"] ""
  readProcess "ghc" ["-O2","GenLexer.hs","-main-is", "GenLexer"] ""
  biyaccprog <- readProcess "./GenLexer" [byFileName] ""
  writeFile "Parser.y" biyaccprog
  readProcess "happy" ["Parser.y"] ""

  readProcess "ghc" ["-O2","s1.bigul.program.hs"] ""
  putStrLn "nothing serious if the callCommand fails... it just make some cleaning work"
  callCommand "rm *.hi *.o *.dyn_o *.dyn_hi"
  return ()