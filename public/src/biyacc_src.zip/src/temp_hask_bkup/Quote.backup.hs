module Quote where

import Data.Generics
import qualified Language.Haskell.TH as TH
import Language.Haskell.TH.Quote
import Language.Haskell.TH.Syntax

import LanguageDef
import ProgramTokenizer
import ProgramParser as PP
import SourceType as ST
import ProgramTrans as PT

import Text.Parsec hiding (getPosition)


import Debug.Trace


by  :: QuasiQuoter
by  =  QuasiQuoter
  { quoteExp = undefined
  , quotePat = undefined
  , quoteDec = quoteBiYaccDec
  , quoteType = undefined
  }


tokenizer_all :: Parsec String () ([ST.TokenPos], [PP.TokenPos])
tokenizer_all = do
  srcTypeTokens <- tokenSrcType
  progTokens <- tokenProgram
  return (srcTypeTokens, progTokens)


tokenizer_Quosi :: Monad m => (String, Int, Int) -> String -> m ([ST.TokenPos], [PP.TokenPos])
tokenizer_Quosi (file, line, col) s = either (fail . show) return (runParser tokenizer_all () "" s)

quoteBiYaccDec :: String -> TH.Q [TH.Dec]
quoteBiYaccDec s = do
  pos <- getPosition
  (srcTypeTokens, progTokens) <- tokenizer_Quosi pos s
  -- dataToExpQ (const Nothing `extQ` antiExprExp) exp
  let srcTmpCAST = buildTmpCAST srcTypeTokens
      (srcTypeCAST, srcTypeEnv)    = (toCAST srcTmpCAST, buildEnv srcTmpCAST)
      (eigenNameEnv, nameEigenEnv, nullEnv) = srcTypeEnv
  progCAST                     <- either (fail . show) return (runParser (program eigenNameEnv) () "" progTokens)
  traceM (show nullEnv)
  srcDatatypes <- genDataTypes srcTypeCAST
  deriveBiGULIns <- genDeriveBiGULGeneric srcDatatypes

  -- traceM (show progCAST)
  -- traceM $ show (genBiGUL nameEigenEnv nullEnv progCAST)
  bigulGenericTypes <- genDeriveBiGULGeneric srcDatatypes
  -- qAddTopDecls bigulGenericTypes
  biguls <- genBiGUL nameEigenEnv nullEnv progCAST
  -- return (srcDatatypes ++ deriveBiGULIns)
  return (srcDatatypes ++ biguls)
  -- dataToExpQ (const Nothing) srcTypeCAST
  -- dataToExpQ (const Nothing) (srcTypeTokens, progTokens)




-- quoteSrcExp :: String -> TH.ExpQ
-- quoteSrcExp s = do
--   pos <- getPosition
--   tokens <- tokenSrcType_ForQuasi pos s
--   dataToExpQ (const Nothing) (toCAST (buildTmpCAST tokens))


getPosition = fmap transPos TH.location where
  transPos loc = (TH.loc_filename loc,
                  fst (TH.loc_start loc),
                  snd (TH.loc_start loc))

by_f = quoteFile by
-- src_f = quoteFile src

