{-# LANGUAGE TemplateHaskell, OverloadedStrings, FlexibleInstances #-}

module ProgramTrans where

import LanguageDef

import GHC.Generics
import Generics.BiGUL hiding (Expr, Pat)
import Generics.BiGUL.AST hiding (Expr, Pat)
import Generics.BiGUL.TH

import ProgramParser
import SourceType

import Data.List (dropWhile, filter, length)
import Data.Char (toLower)
import Data.Map as Map (Map, fromList, lookup)

import Control.Monad

import Language.Haskell.TH


import Debug.Trace
import System.IO.Unsafe


mn = mkName

genBiGUL :: NameEigenEnv -> NullEnv -> Program -> Q [Dec]
genBiGUL env nullEnv (Program groups) = sequence . concat . map (genGroup env nullEnv) $ groups

-- each group of actions will generate one (bigul m s v)
genGroup :: NameEigenEnv -> NullEnv -> Group -> [Q Dec]
genGroup env nullEnv (Group (TypeDecl (ViewType vt) (SourceType st)) rules) =
  -- Clause [Pat] Body [Dec]
  [sigD signame sigtype_, funD funname clauses]
    where
      -- name of the function is bigul ++ viewtype ++ source type. eg bigulArithExpr.
      signame  = mn $ "bigul" ++ vt ++ st
      sigtype_ = forallT [] (return []) $ (conT ''BiGUL)                           `appT`
                                          (conT ''Either `appT` conT ''ErrorInfo)  `appT`
                                          (conT $ mn st)                           `appT`
                                          (conT $ mn vt)
      funname  = signame
      -- in a group. each rule will generate a "normal update" ($normalSV), and an "adaptive update" ($adaptive)
      -- we put the two rules in a tuple and then collect them in order: first normal rules, then adaptive rules.
      -- eg (n1,a1) (n2,a2) (n3,a3) ----> ([n1,n2,n3],[a1,a2,a3]) ----> [n1,n2,n3,a1,a2,a3]
      -- each call of "genClauses" will generate a $normal and an $adaptive clause. all the results will be combined by the "clauses"
      clauses :: [Q Clause]
      clauses  = let (normalbs, adaptbs) = foldr (\(n, a) (ns, as) -> (n : ns, a : as)) ([],[]) $
                                                 map (genClauses (ViewType vt)) rules
                 in  normalbs ++ adaptbs
      genClauses :: ViewType -> Rule -> (Q Clause, Q Clause)
      genClauses (ViewType vt) (Rule lhs rhs) = let (n,a) = (genBody lhs rhs) -- (normal clause , adaptive clause)
                                                in  (clause [] n [], clause [] a [])
        where
          genBody :: LHS -> RHS -> (Q Body, Q Body)
          genBody lhs rhs = let viewPat        = genLHSWildP lhs
                                sourcePat      = genRHSWildP rhs
                                adapt          = genAdaptive lhs rhs env nullEnv
                                reArrUpd       = genRearrangeAndUpdate (ViewType vt) (Rule lhs rhs)
                            in  (normalB [| $(normalSV sourcePat viewPat) $(reArrUpd) |], normalB adapt)


-- eg. want to generate sth. like $(adaptiveV [p| Sub _ _|]) (\_ _ -> ESub ENull TNull)
--  matchpat === [p|Sub _ _|]  :: Q Exp
--  adaptive === (\_ _ -> ESub ENull TNull) (it is a function)
genAdaptive :: LHS -> RHS -> NameEigenEnv -> NullEnv-> Q Exp
genAdaptive lhs rhs env nullEnv = let matchpat = genLHSWildP lhs
                                      adaptFun = genAdaptive_ rhs env nullEnv
                                  in  [| $(adaptiveV matchpat) $(adaptFun) |]
  where
    genAdaptive_ :: RHS -> NameEigenEnv -> NullEnv->  Q Exp
    genAdaptive_ (RHS (ProdrulePlus prodrulename eitherupdates)) env nullEnv =
      let (prodrulepats, prodruletype) = maybe (error "production rule not found (in genAdaptive)") id (Map.lookup prodrulename env)
          pat = foldl (\xs x -> xs `appE` conE (mn x) )
                (conE (mn prodruletype))
                (map (\x -> maybe (error "production rule not found (in genAdaptive_)") (id) (Map.lookup x nullEnv)) (filterRight prodrulepats) )
      in  [| \ _ _ -> $(pat) |]


-- reserve only elements with the "Right" constructor. (also drop the "Right" constructor)
filterRight :: [Either a a] -> [a]
filterRight = foldr (\x xs -> case x of Left _ -> xs; Right a -> a:xs ) []

-- drop the Left or the Right constructor.
filterOutEither :: [Either a a] -> [a]
filterOutEither = foldr (\x xs -> case x of Left a -> a:xs; Right a -> a:xs ) []


-- generate patterns consisting of only Constructor and Wildcast.
-- used for pattern matching on view
genLHSWildP :: LHS -> Q Pat
genLHSWildP (LHS lhspats) = genLHSWildP_ lhspats
  where
    genLHSWildP_ :: LHSPattern -> Q Pat
    genLHSWildP_ pat = case pat of
                         (NormalP (ViewCon vc) lhspats) -> conP (m vc) (map genLHSWildP_ lhspats)
                         (ViewVar _) -> wildP
                         Scope     -> wildP
                         (LitPattern s) -> litP (stringL s)
                         (ASPattern _ _) -> undefined

-- generate patterns consisting of only Constructor and Wildcast.
-- used for pattern matching on source
genRHSWildP :: RHS -> Q Pat
genRHSWildP (RHS prodruleplus) = genProdrulepat prodruleplus
  where
    genProdrulepat :: ProdrulePlus -> Q Pat
    genProdrulepat (ProdrulePlus prodruleName maybeupdates) = conP (m prodruleName) (map genEitherUpdatespat maybeupdates)

    genEitherUpdatespat :: Either Unchanged Update -> Q Pat
    genEitherUpdatespat (Left _ ) = wildP
    genEitherUpdatespat (Right (NUpdate _ _ )) = wildP
    genEitherUpdatespat (Right (DUpdate st prodruleplus)) = genProdrulepat prodruleplus



-- generate patterns consisting of Constructor and variables. (The variables (aka subparts) are used in RHS to update corresponding parts in source data)
-- used for rearrangeAndUpdate
genLHSUpdate :: LHS -> Q Pat
genLHSUpdate (LHS lhspats) = genLHSUpdate_ lhspats
  where
    genLHSUpdate_ :: LHSPattern -> Q Pat
    genLHSUpdate_ pat = case pat of
                          (NormalP (ViewCon vc) lhspats) -> conP (mn vc) (map genLHSUpdate_ lhspats)
                          (ViewVar vv) -> varP (mn vv)
                          Scope     -> wildP
                          (LitPattern s) -> litP (stringL s)
                          (ASPattern _ _) -> undefined

-- generate patterns consisting of only Constructor and Wildcast.
-- used for pattern matching on source
genRHSUpdate :: RHS -> Q Pat
genRHSUpdate (RHS prodruleplus) = genProdruleUpdate prodruleplus
  where
    genProdruleUpdate :: ProdrulePlus -> Q Pat
    genProdruleUpdate (ProdrulePlus prodruleName maybeupdates) = conP (mn prodruleName) (map genEitherUpdatespat maybeupdates)

    genEitherUpdatespat :: Either Unchanged Update -> Q Pat
    genEitherUpdatespat (Left _ ) = wildP
    genEitherUpdatespat (Right (NUpdate vv _ )) = varP (mn vv)
    genEitherUpdatespat (Right (DUpdate st prodruleplus)) = genProdruleUpdate prodruleplus

genRearrangeAndUpdate :: ViewType -> Rule -> Q Exp
genRearrangeAndUpdate (ViewType vt) (Rule lhs rhs) =
  let vDecompose = genLHSUpdate lhs
      sDecompose = genRHSUpdate rhs
      upd        = genUpd rhs
  in  [| $(update vDecompose sDecompose upd) |]
  where
    genUpd :: RHS -> Q [Dec]
    genUpd (RHS pp) = sequence $ genUpd1 pp
      where
        -- [Right (NUpdate "lhs" (SourceType "Expr")),Right (NUpdate "rhs" (SourceType "Term"))]
        -- will give: [d| lhs = ruleArithExpr; rhs = ruleArithTerm |].
        -- The "Arith" is found by the "ViewType" which is not mutable in a group.
        genUpd1 :: ProdrulePlus -> [Q Dec]
        genUpd1 (ProdrulePlus _ eitherupdates) = foldl genUpd2 [] eitherupdates
          where
            genUpd2 :: [Q Dec] -> Either Unchanged Update -> [Q Dec]
            genUpd2 decs (Left _) = decs
            genUpd2 decs (Right (NUpdate vv (SourceType st))) = decs ++ [valD (varP (mn vv)) (normalB (varE $ mn $ "bigul" ++ vt ++ st )) []]
            genUpd2 decs (Right (DUpdate st prodruleplus)) = decs ++ genUpd1 prodruleplus



 -- [
 -- Rule (LHS (NormalP (ViewCon "ADD") [ViewVar "lhs",ViewVar "rhs"]))
 --      (RHS (ProdrulePlus "Expr0" [Right (NUpdate "lhs" (SourceType "Expr")),Right (NUpdate "rhs" (SourceType "Term"))])),
 -- Rule (LHS (NormalP (ViewCon "SUB") [ViewVar "lhs",ViewVar "rhs"]))
 --      (RHS (ProdrulePlus "Expr1" [Right (NUpdate "lhs" (SourceType "Expr")),Right (NUpdate "rhs" (SourceType "Term"))])),
 -- Rule (LHS (ViewVar "arith"))
 --      (RHS (ProdrulePlus "Expr2" [Right (NUpdate "arith" (SourceType "Term"))]))
 -- ],


 --   Case [ $(normalSV [p| EAdd _ _ |] [p| Add _ _ |] )
 --           $(rearrAndUpdate [p| Add l r |] [p| EAdd l r |]
 --                            [d| l = ruleExprArith0; r = ruleTermArith0 |])
 --       , $(normalSV [p| ESub _ _ |] [p| Sub _ _ |] )
 --           $(rearrAndUpdate [p| Sub l r |] [p| ESub l r |]
 --                            [d| l = ruleExprArith0; r = ruleTermArith0 |])
 --       , $(normalSV [p| ETerm _ |] [p|  _ |] )
 --           $(rearrAndUpdate [p| a  |] [p| ETerm a |]
 --                            [d| a = ruleTermArith0 |])
 --       , $(adaptiveV [p| Add _ _|]) (\_ _ -> EAdd ENull TNull)
 --       , $(adaptiveV [p| Sub _ _|]) (\_ _ -> ESub ENull TNull)
 --       , $(adaptiveV [p| _ |])      (\_ _ -> ETerm TNull)
 --       ]



