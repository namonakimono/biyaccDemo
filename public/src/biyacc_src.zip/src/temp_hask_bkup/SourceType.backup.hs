{-# Language DeriveDataTypeable, TemplateHaskell, FlexibleContexts #-}
module SourceType (buildEnv, buildTmpCAST, toCAST, addConsName, tokenSrcType, TokenPos, genDataTypes, genDeriveBiGULGeneric, CAST(CAST), CDataType(CDataType), CTypeDef(CTypeDef), EitherTNT, hehe) where

import LanguageDef

import Data.Typeable
import Data.Data
import DeriveBiGULGenerics

-- import GHC.Generics
-- import Generics.BiGUL hiding (Expr, Pat)
-- import Generics.BiGUL.AST hiding (Expr, Pat)
-- import Generics.BiGUL.TH (deriveBiGULGeneric)

import Text.Parsec hiding (State)
import Text.Parsec.Token

import Control.Monad.State.Lazy (MonadState, State, get, put, evalState, liftM)

import qualified Data.Map as Map (map)
import Data.Map as Map (singleton, union, unions)

import Language.Haskell.TH

import Debug.Trace

type TokenPos = (ConcreteToken, SourcePos)


type TokenType = Parsec String () TokenPos
type TokenTypes = Parsec String () [TokenPos]


hehe = CAST [CDataType "Expr" [CTypeDef "Expr0" [Right "Expr",Right "Term"],CTypeDef "Expr1" [Right "Expr",Right "Term"],CTypeDef "Expr2" [Right "Term"],CTypeDef "ExprNull0" []],CDataType "Term" [CTypeDef "Term0" [Right "Term",Right "Factor"],CTypeDef "Term1" [Right "Term",Right "Factor"],CTypeDef "Term2" [Right "Factor"],CTypeDef "TermNull1" []],CDataType "Factor" [CTypeDef "Factor0" [Right "Factor"],CTypeDef "Factor1" [Right "String"],CTypeDef "Factor2" [Right "Expr"],CTypeDef "FactorNull2" []]]


keyword :: TokenType
keyword = byLexeme ( do
  pos <- getPosition
  choice [try (string "Concrete") >> return (CSourceType, pos)])
  <?> "error in keyword"

--string literal
--will change char literal to string literal
terminal :: TokenType
terminal = byLexeme (do
  pos <- getPosition
  choice [try (stringLiteral generatedParser) >>= \str -> return (CTerminal str, pos)
         ,try (charLiteral generatedParser) >>= \chr   -> return (CTerminal [chr], pos)])
  <?> "error in string literal tokenizer"

nonterminal :: TokenType
nonterminal = byLexeme (do
  pos <- getPosition
  nont <- identifier generatedParser
  return (CNonterminal nont, pos))
  <?> "error in nonterminal"


userdata :: TokenType
userdata = byLexeme $ do
  pos <- getPosition
  string "String"
  return (CNonterminal "String", pos) -- treat all the user data (float, int, bool, ...) as string


ruleStart :: TokenType
ruleStart = byLexeme (do
  pos <- getPosition
  choice [try (string "->") >> return (CIs, pos)
         ,try (string "|")  >> return (COr, pos)])
  <?> "error in symbol tokenizer"

ruleEnd :: TokenType
ruleEnd = byLexeme (do
  pos <- getPosition
  string ";"
  return (CSemi, pos)
  )
  <?> "error in ruleEnd, expect semicolon ';'"

-- each line of the production rule. eg | Expr '-' Term
ruleLine :: TokenTypes
ruleLine = do
  split <- ruleStart
  rhs <- many1 (try terminal <|> try userdata <|> try nonterminal)
  -- traceM $ show rhs
  return (split : rhs)

productionRule :: TokenTypes
productionRule = do
  datatype <- nonterminal
  tmp <- many1 (try ruleLine)
  end <- ruleEnd
  let rhss = concat tmp
  return (datatype : (rhss ++ [end]))



tokenSrcType :: Parsec String () [TokenPos]
tokenSrcType = do
  whiteSpace generatedParser
  k <- keyword
  prules <- many1 productionRule
  return (k : concat prules)

tokenSrcType_ForQuasi :: Monad m => (String, Int, Int) -> String -> m [TokenPos]
tokenSrcType_ForQuasi (file, line, col) s =
  case runParser tokenSrcType () "" s of
    Left err  -> fail $ show err
    Right tokens   -> return tokens



t1 = do
  let fname = "s1.txt"
  stream <- readFile fname
  case (parse tokenSrcType fname stream) of
    Left err -> print err
    Right xs -> print (map fst xs)


--------------tokenizer     end-----------------


---------------- parser -------------------
type ParserU = Parsec [TokenPos] ()

isToken :: ConcreteToken -> Parsec [TokenPos] () ConcreteToken
isToken tok = token show snd (\t -> if fst t == tok then Just (fst t) else Nothing)

data CAST = CAST [CDataType] deriving (Show, Eq, Data)
data CDataType = CDataType String [CTypeDef] deriving (Show, Eq, Data) -- CDataType type definitions. CDataType "Expr" [...]
data CTypeDef = CTypeDef String [EitherTNT] deriving (Show, Eq, Data) -- CTypeDef constructor [types]

type EitherTNT = Either String String -- either it is a string terminal or datatypes. nonterminal is reserved when finishing parsing and used when building the env. It is deleted later.
-- Left: string Terminal. Right: others

extractTerminal :: Parsec [TokenPos] () String
extractTerminal = token show snd (\t -> case fst t of CTerminal s -> Just s; _ -> Nothing)

extractNonTerminal :: Parsec [TokenPos] () String
extractNonTerminal = token show snd (\t -> case fst t of CNonterminal s -> Just s; _ -> Nothing)




cdatatypes :: ParserU CAST
cdatatypes = isToken CSourceType >> liftM CAST (many1 datatype)

datatype :: ParserU CDataType
datatype = do
  t <- extractNonTerminal
  first <- firstline
  following <- many followingline
  isToken CSemi
  return $ CDataType t (first:following)
  where
    firstline = do
      isToken CIs
      eithers_ <- many ( (extractTerminal >>= return . Left) <|> (extractNonTerminal >>= return  . Right) )
      return $ CTypeDef "" eithers_

    followingline = try (do
      isToken COr
      eithers_ <- many1 (try (extractTerminal >>= return . Left ) <|> try (extractNonTerminal >>= return . Right))
      return $ CTypeDef "" eithers_)

-- tempCAST is used to build environment. after that. we use toCAST to transform it into a "real" CAST (does not contain terminals)
buildTmpCAST :: [TokenPos] -> CAST
buildTmpCAST tokenpos = either (error . show) (id) (parse cdatatypes "" tokenpos)

-- transform tempCAST to CAST
toCAST :: CAST -> CAST
toCAST tmpcast = removeTerminal . addNullConstructor . addConsName $ tmpcast

removeTerminal :: CAST -> CAST
removeTerminal (CAST cdatatypes) = CAST (map remove1 cdatatypes)
  where remove1 :: CDataType -> CDataType
        remove1 (CDataType t ctypedefs) = CDataType t (map remove2 ctypedefs)
        remove2 :: CTypeDef -> CTypeDef
        remove2 (CTypeDef con tnts) = CTypeDef con (filter (either (const False) (const True)) tnts)

-- add constructor name to cast in a state monad. generate unique constructor name for each CTypeDef
addConsName :: CAST -> CAST
addConsName (CAST cdatatypes) = CAST (map refine1 cdatatypes)
  where
    refine1 :: CDataType -> CDataType
    refine1 (CDataType prefix ctypedefs) = CDataType prefix (evalState (mapM refine2 ctypedefs) (genNameList prefix))
    refine2 :: MonadState [String] m => CTypeDef -> m CTypeDef
    refine2 (CTypeDef _ tnts) = do
      nameList <- get
      -- traceM $ show (head nameList)
      put $ tail nameList
      return $ CTypeDef (head nameList) tnts

addNullConstructor :: CAST -> CAST
addNullConstructor (CAST cdatatypes) = CAST $ evalState (mapM refine1 cdatatypes) (genNameList "Null")
  where
    refine1 :: MonadState [String] m => CDataType -> m CDataType
    refine1 (CDataType prefix ctypedefs) = do
      nameList <- get
      -- traceM $ show (head nameList)
      put $ tail nameList
      return $ CDataType prefix (ctypedefs ++ [CTypeDef (prefix ++ head nameList) [] ])


-- the parameter is tempCAST
buildEnv :: CAST -> (EigenNameEnv, NameEigenEnv, NullEnv)
buildEnv tmpCAST = let (CAST cdatatypes) = addConsName tmpCAST
                       envs = map build1 cdatatypes
                       nullenv = null1 (addConsName tmpCAST)
                   in  (unions $ map fst envs, unions $ map snd envs, nullenv)
  where
    build1 :: CDataType -> (EigenNameEnv,NameEigenEnv)
    build1 (CDataType t ctypedefs) = let envs = (map (build2 t) ctypedefs)
                                     in (unions $ map fst envs, unions $ map snd envs)
    build2 :: String -> CTypeDef -> (EigenNameEnv, NameEigenEnv)
    build2 t (CTypeDef key patterns) = let patterns_ = map (\ep -> case ep of Left p -> Left p; Right p -> Right p) patterns
                                       in (singleton patterns_ (key,t) , singleton key (patterns_,t))
    null1 :: CAST -> NullEnv -- build the NullEnv. use the same state monad when adding the Null constructor. but this time we build the env rather than refine the CAST.
    null1 (CAST cdatatypes) = unions $ evalState (mapM null2 cdatatypes) (genNameList "Null")
    null2 :: MonadState [String] m => CDataType -> m NullEnv
    null2 (CDataType prefix ctypedefs) = do
      nameList <- get
      put $ tail nameList
      return $ singleton prefix (head nameList)




getConName :: State [String] String
getConName = do
  n <- get
  put $ tail n
  return $ head n

genNameList :: String -> [String]
genNameList name = zipWith (\a b -> a ++ b) (repeat name) (map show [0,1..])



t2 = do
  let fname = "s1.txt"
  stream <- readFile fname
  case (parse tokenSrcType fname stream) of
    Left err -> print err
    Right xs -> print $ toCAST (buildTmpCAST xs)
    -- case (parse cdatatypes fname xs) of
    --               Left err -> print err
    --               Right ys -> print ys

t3 = do
  let fname = "s1.txt"
  stream <- readFile fname
  case (parse tokenSrcType fname stream) of
    Left err -> fail $ show err
    Right xs -> return $ genDataTypes $ toCAST (buildTmpCAST xs)
    -- case (parse cdatatypes fname xs) of
    --               Left err -> print err
    --               Right ys -> print ys
------------- parser ends -------

------------- Template Haskell to generate Haskell datatypes-------

mn = mkName

genDataTypes :: CAST -> Q [Dec]
genDataTypes (CAST cdatatypes) = sequence $ map genDataType cdatatypes
  where
    -- datatypes declaration
    genDataType :: CDataType -> Q Dec
    genDataType (CDataType dataname ctypedefs) = do
      dataD context name vars cons derives
        where
          context = return []
          name    = mn dataname
          vars    = []
          cons    = map genCon ctypedefs
          derives = [''Eq, ''Show]
          genCon :: CTypeDef -> Q Con
          genCon (CTypeDef conname followings) = normalC (mn conname) (map genFollowings followings)
          genFollowings (Right t) = strictType notStrict (conT $ mn t)
          genFollowings e         = error $ "error in genFollowings, the string here should be 'Right ...', but it is" ++ show e


-- deriveBiGULGeneric declaration
-- genDeriveBiGULGeneric :: CAST -> Q [Dec]
-- genDeriveBiGULGeneric (CAST cdatatypes) = fmap concat . mapM gen1 $ cdatatypes
--   where
--     gen1 :: CDataType -> Q [Dec]
--     gen1 (CDataType dataname ctypedefs) = deriveBiGULGeneric (mn dataname)
genDeriveBiGULGeneric :: [Dec] -> Q [Dec]
genDeriveBiGULGeneric = fmap concat . mapM (\(DataD _ name vars cons _) -> deriveBiGULGeneric_s2 name vars cons)
---------

{-
this file contains functions for tokenizing and parsing concrete datatypes (the part after "Concrete" keyword in a BiYacc file), meanwhile
generating the corresponding Haskell datatypes (declarations, Q [Dec]) and some environment for further usage.

The three Environment are
type EigenNameEnv   = Map ProdRuleEigen (ProdruleName, ProdRuleType)  eg  ["Expr", "+", "Term"] ---> (A0,"Expr")
type NameEigenEnv   = Map ProdruleName (ProdRuleEigen, ProdRuleType)  eg  A0   ---> (["Expr", "+", "Term"] ,"Expr")
type NullEnv        = Map ProdruleName String                         eg  A0   ---> ExprNull0

The differences between first two are just some swaps between the key-value pair.

Users only write production rules, however, the tool will produce somehow refined datatypes according to the production rules.
1) generate a constructor for each production rule.
2) generate a "NULL" datatype for each block of production rule (block: production rules starting from the same nonterminal)

When the parser scans the Tokens for the first time, it will generate some temporary datatypes (concrete AST) with holes.
Then we pass the temporary CAST to some help functions to do 1) and 2). These are achieved by state monad.
-}

