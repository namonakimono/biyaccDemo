{-# Language TemplateHaskell, QuasiQuotes #-}
import GHC.Generics
import Generics.BiGUL.AST hiding (Expr, Pat)
import Generics.BiGUL.Interpreter
import Generics.BiGUL.TH
import Generics.BiGUL.Error
import Parser (parser2, str2CST)
import YourLangDef
import System.Environment (getArgs)
import System.IO.Strict as IOS

entrance = bigulArithExpr

bigulArithExpr :: BiGUL Expr Arith
bigulArithExpr =
  Case [$(normalSV [p| (Expr0 _ _ _) |] [p| Add _ _ |])
          $(update [p| Add x y |] [p| Expr0 x _ y |] [d| x = bigulArithExpr; y = bigulArithTerm; |])
       ,$(normalSV [p| (Expr2 _) |] [p| (Sub (Num 0) _) |])
          $(update [p| (a) |] [p| Expr2 a |] [d| a = bigulArithTerm; |])
       ,$(normalSV [p| (Expr1 _ _ _) |] [p| Sub _ _ |])
          $(update [p| Sub x y |] [p| Expr1 x _ y |] [d| x = bigulArithExpr; y = bigulArithTerm; |])
       ,$(normalSV [p| (Expr2 _) |] [p| _ |])
          $(update [p| arith |] [p| Expr2 arith |] [d| arith = bigulArithTerm; |])
      ,$(adaptiveV [p| Add _ _ |]) (\ s _ -> case s of
                                    Expr1 subExpr0 layouts1 subTerm2 -> Expr0 subExpr0 layouts1 subTerm2;
                                    _ -> Expr0 ExprNull0 " " TermNull1 ;)
      ,$(adaptiveV [p| (Sub (Num 0) _) |]) (\ _ _ ->  Expr2 TermNull1)
      ,$(adaptiveV [p| Sub _ _ |]) (\ s _ -> case s of
                                    Expr0 subExpr0 layouts1 subTerm2 -> Expr1 subExpr0 layouts1 subTerm2;
                                    _ -> Expr1 ExprNull0 " " TermNull1 ;)
      ,$(adaptiveV [p| _ |]) (\ _ _ ->  Expr2 TermNull1)]

bigulArithTerm :: BiGUL Term Arith
bigulArithTerm =
  Case [$(normalSV [p| (Term0 _ _ _) |] [p| Mul _ _ |])
          $(update [p| Mul x y |] [p| Term0 x _ y |] [d| x = bigulArithTerm; y = bigulArithFactor; |])
       ,$(normalSV [p| (Term1 _ _ _) |] [p| Div _ _ |])
          $(update [p| Div x y |] [p| Term1 x _ y |] [d| x = bigulArithTerm; y = bigulArithFactor; |])
       ,$(normalSV [p| (Term2 _) |] [p| _ |])
          $(update [p| arith |] [p| Term2 arith |] [d| arith = bigulArithFactor; |])
      ,$(adaptiveV [p| Mul _ _ |]) (\ s _ -> case s of
                                    Term1 subTerm0 layouts1 subFactor2 -> Term0 subTerm0 layouts1 subFactor2;
                                    _ -> Term0 TermNull1 " " FactorNull2 ;)
      ,$(adaptiveV [p| Div _ _ |]) (\ s _ -> case s of
                                    Term0 subTerm0 layouts1 subFactor2 -> Term1 subTerm0 layouts1 subFactor2;
                                    _ -> Term1 TermNull1 " " FactorNull2 ;)
      ,$(adaptiveV [p| _ |]) (\ _ _ ->  Term2 FactorNull2)]

bigulArithFactor :: BiGUL Factor Arith
bigulArithFactor =
  Case [$(normalSV [p| (Factor0 _ _) |] [p| Sub (Num 0) _ |])
          $(update [p| Sub (Num 0) y |] [p| Factor0 _ y |] [d| y = bigulArithFactor; |])
       ,$(normalSV [p| (Factor1 _) |] [p| Num _ |])
          $(update [p| Num n |] [p| Factor1 (n, _) |] [d| n = Replace; |])
       ,$(normalSV [p| (Factor2 _) |] [p| ArithName _ |])
          $(update [p| ArithName n |] [p| Factor2 (n, _) |] [d| n = Replace; |])
       ,$(normalSV [p| (Factor3 _ _ _) |] [p| _ |])
          $(update [p| arith |] [p| Factor3 _ arith _ |] [d| arith = bigulArithExpr; |])
      ,$(adaptiveV [p| Sub (Num 0) _ |]) (\ _ _ ->  Factor0 " " FactorNull2)
      ,$(adaptiveV [p| Num _ |]) (\ s _ -> case s of
                                  Factor2 (_, layouts0) -> Factor1 (undefined, layouts0);
                                  _ -> Factor1 (undefined, " ") ;)
      ,$(adaptiveV [p| ArithName _ |]) (\ s _ -> case s of
                                        Factor1 (_, layouts0) -> Factor2 (undefined, layouts0);
                                        _ -> Factor2 (undefined, " ") ;)
      ,$(adaptiveV [p| _ |]) (\ _ _ ->  Factor3 " " ExprNull0 " ")]

main :: IO ()
main = do
  args <- getArgs
  if length args < 3
    then error $ usageInfoGet ++ usageInfoPut
    else do
      let getOrPut      = args !! 0
          srcCodeFName  = args !! 1
          astFName      = args !! 2
      srcCode <- IOS.readFile srcCodeFName
      let (comm, cst) = parser2 srcCode
      case getOrPut of
        "get" -> do
                   let ast = either (error "get error") id (get entrance cst)
                   writeFile astFName (show ast)
        "put" -> do
                   let newSrcCodeName = if length args == 4 then args !! 3 else srcCodeFName
                   srcCode <- IOS.readFile srcCodeFName
                   ast <- IOS.readFile astFName
                   let srcCode' = either (error "put error") id (put entrance cst (read ast))
                   writeFile newSrcCodeName (comm ++ show srcCode')
  where
    usageInfoGet = "usage - get: YourExecutable get CodeFileName ASTFileName\n"
    usageInfoPut = "usage - put: YourExecutable put OldCodeFileName ASTFileName NewCodeFileName\n"