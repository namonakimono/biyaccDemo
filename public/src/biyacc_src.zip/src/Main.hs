module Main where

import Quote
import Data.Map (toList)
import LanguageDef
import ProgramTokenizer
import ProgramParser
import SourceType
import ProgramTrans
import AbstractType
import BiYaccUtils
import qualified GenLexer as GL (prtPrinter)

import Text.Parsec hiding (getPosition, newline)
import Text.PrettyPrint as TPP

import System.Environment (getArgs)
import System.Process (readProcess, callCommand)

import Debug.Trace

main :: IO ()
main  = do
  args <- getArgs
  if length args < 2
    then error "please give input. usage: biyacc biyaccFileName outputExecutableName"
    else do
      putStrLn "building may take to half a minute for a comparatively big language like Tiger"
      let byFileName    = args !! 0
          exeFileName   = args !! 1
          exeFileNameHS =  exeFileName ++ ".hs"
      stream <- readFile byFileName
      let ((absDecls, _), srcTypeTokens, progTokens) = either (error . show) id (runParser tokenizer_all () byFileName stream)
          (AAnything absDeclsStr, _)                 = absDecls
          srcTmpCAST                                 = buildTmpCAST srcTypeTokens
          (srcTypeCAST, srcTypeEnv)                  = (toCAST srcTmpCAST, buildEnv srcTmpCAST)
          (eigenNameEnv, nameEigenEnv, nullEnv, similarProdruleEnv) = srcTypeEnv
          srcDeclsStr                                = prtSrcDatatypes srcTypeCAST
          cstInstanceShowStr                         = GL.prtPrinter srcTypeCAST
          progCAST = either (error . show) id (runParser (program eigenNameEnv) () "" progTokens)

          sssprogstring   = genBiGUL nameEigenEnv nullEnv similarProdruleEnv progCAST
          entranceStr     = getEntrance progCAST
          bigulProgramStr = importStr `newlineS` entranceStr  `newlineS` sssprogstring `newlineS` mainStr

      writeFile "YourLangDef.hs" (defFileString absDeclsStr srcDeclsStr cstInstanceShowStr)
      writeFile exeFileNameHS bigulProgramStr

      biyaccprog <- readProcess "byStr2CST" [byFileName] ""
      writeFile "Parser.y" biyaccprog
      readProcess "happy" ["Parser.y"] ""
      readProcess "ghc" ["-O2", exeFileNameHS, "-o", exeFileName] ""

      -- some cleaning work
      let removeStr = ["rm"
                      ,"YourLangDef.dyn_o","YourLangDef.dyn_hi","YourLangDef.o","YourLangDef.hi","YourLangDef.hs"
                      ,"Parser.dyn_o","Parser.dyn_hi","Parser.o","Parser.hi","Parser.y", "Parser.hs"
                      ,exeFileName++".dyn_o",exeFileName++".dyn_hi",exeFileName++".o",exeFileName++".hi",exeFileNameHS]
      putStrLn "nothing serious if the callCommand fails... it just make some cleaning work"
      callCommand $ foldl1 (\xs x -> xs ++ " " ++ x) removeStr
      putStrLn $ "successfully generated " ++ exeFileName
      return ()
