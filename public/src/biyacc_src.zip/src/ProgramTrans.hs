{-# LANGUAGE TemplateHaskell, FlexibleInstances #-}

module ProgramTrans where

import LanguageDef
import BiYaccUtils
import ProgramParser
import SourceType
import BiYaccUtils

import Data.List (dropWhile, filter, length,foldl')
import Data.List.Utils (replace)
import Data.Char (toLower)
import Data.Map as Map (Map, fromList, lookup)

import Control.Monad

--import Language.Haskell.TH
import Text.PrettyPrint as TPP


import Debug.Trace
import System.IO.Unsafe


genBiGUL :: NameEigenEnv -> NullEnv -> SimilarProdruleEnv -> Program -> String
genBiGUL env nullEnv similarProdruleEnv (Program groups) = render . vcat2 . map (genGroup env nullEnv similarProdruleEnv) $ groups

-- each group of actions will generate one (bigul m s v)
genGroup :: NameEigenEnv -> NullEnv -> SimilarProdruleEnv -> Group -> Doc
genGroup env nullEnv similarProdruleEnv (Group (TypeDecl (ViewType vt) (SourceType st)) rules) =
      -- name of the function is bigul ++ viewtype ++ source type. eg bigulArithExpr.
  let signame  = text "bigul" <> text vt <> text st
      sigtype  = text "BiGUL" <+> text st <+> text vt
      funname  = signame
      -- in a group. each rule will generate a "normal update" ($normalSV), and an "adaptive update" ($adaptive)
      -- we put the two rules in a tuple and then collect them in order: first normal rules, then adaptive rules.
      -- eg (n1,a1) (n2,a2) (n3,a3) ----> ([n1,n2,n3],[a1,a2,a3]) ----> [n1,n2,n3,a1,a2,a3]
      -- each call of "genClauses" will generate a $normal and an $adaptive clause. all the results will be combined by the "clauses"
      (normalbs, adaptbs) = foldr1 (\(n, a) (ns, as) -> (n $$ nestn1 (comma <> ns), a $$ nestn1 (comma <> as)))
                                  --(TPP.empty,TPP.empty)
                                  (map (genClauses (SourceType st) (ViewType vt)) rules)
      --(normalbs, adaptbs) = foldr (\(n, a) (ns, as) -> (n $$ ns, a $$ as)) (TPP.empty,TPP.empty) $
      --map (genClauses (ViewType vt)) rules
      signature = signame <+> text "::" <+> sigtype
      funcbody  = funname <+> equals $$ nest2 (text "Case" <+> brackets (normalbs $$ nestn2 (comma <> adaptbs)))
  in  signature $$ funcbody
  where
    genClauses :: SourceType -> ViewType -> Rule -> (Doc, Doc)
    genClauses _ (ViewType vt) (UserAdaptiveRule str) = (text str, TPP.empty)
    genClauses st (ViewType vt) (NormalRule lhs rhs)   = (genBody st lhs rhs) -- (normal clause , adaptive clause)
      where
        genBody :: SourceType -> LHS -> RHS -> (Doc, Doc)
        genBody st lhs rhs =
          let viewPat          = genLHSWildP lhs
              sourcePat        = genRHSWildP rhs
              adapt            = genAdaptive lhs rhs nullEnv similarProdruleEnv
              (vp_, sp_, upd_) = genRearrangeAndUpdate (ViewType vt) (NormalRule lhs rhs)
              normalbPat       = text "$" <> parens (text "normalSV" <+> wrapPatQ sourcePat  <+> wrapPatQ viewPat)
              normalbUpd       = nest2 (text "$" <> parens (text "update" <+> vp_ <+> sp_ <+> upd_))
              normalb          = normalbPat $$ normalbUpd
              adaptb           = adapt
          in  (normalb, adaptb)



-- eg. want to generate sth. like $(adaptiveV [p| Sub _ _|]) (\_ _ -> ESub ENull TNull)
--  matchpat === [p|Sub _ _|]  :: Q Exp
--  adaptive === (\_ _ -> ESub ENull TNull) (it is a function)
genAdaptive :: LHS -> RHS -> NullEnv -> SimilarProdruleEnv -> Doc
genAdaptive lhs rhs nullEnv similarProdruleEnv =
  let matchpat    = genLHSWildP lhs
      adaptFun    = genAdaptive_ rhs nullEnv similarProdruleEnv
      matchpatDoc = text "$" <> parens (text "adaptiveV" <+> wrapPatQ matchpat)
      adaptFunDoc = adaptFun
  in  matchpatDoc <+> adaptFunDoc
  where
    genAdaptive_ :: RHS -> NullEnv -> SimilarProdruleEnv -> Doc
    genAdaptive_ (RHS prodp@(ProdrulePlus prodrulename _)) nullEnv similarProdruleEnv =
      let pat = case Map.lookup prodrulename similarProdruleEnv of
                  Nothing          -> text "\\ _ _ -> " <+> genDefaultPat prodp nullEnv
                  Just similarpats ->
                    let similarpatsDoc = vcat $ map (genSimilarPat prodp nullEnv) similarpats
                        defaultpatDoc  = text "_ ->" <+> genDefaultPat prodp nullEnv <+> text ";"
                    in  text "\\ s _ -> case s of" $$ (similarpatsDoc $$ defaultpatDoc)
      in  parens pat
      where
        genDefaultPat :: ProdrulePlus -> NullEnv -> Doc
        genDefaultPat (ProdrulePlus prodrulename eitherupdates) nullEnv =
          foldl'  (\xs x -> xs <+> x)
                  (text prodrulename)
                  (map (\x -> case x of
                          Left  (Terminal st)                  -> text $ genDefaultVal "String_kjd24592x" nullEnv
                          Left  (Nonterminal (SourceType st))  -> text $ genDefaultVal st nullEnv
                          Right (NUpdate _ (SourceType st))    -> text $ genDefaultVal st nullEnv
                          Right (DUpdate (SourceType _) deep ) -> parens (genDefaultPat deep nullEnv)
                       )
                  eitherupdates)
        genDefaultVal :: String -> NullEnv -> String
        genDefaultVal st nullEnv = case st of
          "String_kjd24592x" -> "\" \""
          "(NameX9or2c81, String)"  -> "(undefined, \" \")"
          -- in bigul, the default value will be overridden when rerun the case branch
          "(String, String)"  -> "(undefined, \" \")" -- hard coded. shall improve here
          "(Int, String)"     -> "(undefined, \" \")"
          "(Integer, String)" -> "(undefined, \" \")"
          "(Bool, String)"    -> "(undefined, \" \")"
          "(Float, String)"   -> "(undefined, \" \")"
          "(Double, String)"  -> "(undefined, \" \")"
          _                   -> maybe (error $ "production rule: " ++ show st ++ " not found (in genAdaptive_)") id (Map.lookup st nullEnv)
        -- for simiplicity, current version does not handle "deep update" case (which will also generate exponential number of case analises)
        -- just call teh genDefaultPat to generate the default value for the "deep update" case
        genSimilarPat :: ProdrulePlus -> NullEnv -> [String] -> Doc
        genSimilarPat (ProdrulePlus prodrulename eitherupdates) nullenv similar =
          let patlist = zipWith (\x subtree -> case x of
                                  Right (DUpdate (SourceType _) deep ) -> parens (genDefaultPat deep nullEnv)
                                  -- subtree or layout. ad-hoc handle with the primitive datatype case
                                  _                                    -> text $ replace "(undefined, " "(_, " subtree)
                                eitherupdates (tail similar)
              lhs     = foldl'  (\xs x -> xs <+> x) (text (head similar)) patlist
              -- replace the constructor (the head element of the list "similar") of similar production rule with the one should be created
              -- eg suppose here we should adaptive source to Sub. if the list "similar" is:[Add, l, layouts, r], it should be changed to: [Sub, l, layouts, r]
              rhs     = foldl'  (\xs x -> xs <+> text x) (TPP.empty) (prodrulename: tail similar)
          in  lhs <+> text "->" <+> rhs <> text ";"


-- generate patterns consisting of only Constructor and Wildcard.
-- used for pattern matching on view
genLHSWildP :: LHS -> Doc
genLHSWildP (LHS lhspats) = genLHSWildP_ lhspats
  where
    genLHSWildP_ :: LHSPattern -> Doc
    genLHSWildP_ pat =
      case pat of
        (NormalP (ViewCon vc) lhspats) -> text vc <+> (hsep . map genLHSWildP_) lhspats
        (ViewVar _)            -> wildcardDoc
        (WildcardP)              -> wildcardDoc
        (LitStrPattern s)      -> doubleQuotes (text s)       -- or doubleQuotes s
        (LitIntegerPattern i)  -> text (show i)
        (LitFloatPattern   f)  -> text (show f)
        (LitBoolPattern    b)  -> text (show b)
        (ASPattern _ p)        -> genLHSWildP_ p
        (InParen lhs)          -> parens $ genLHSWildP_ lhs

-- generate patterns consisting of only Constructor and Wildcard.
-- used for pattern matching on source
genRHSWildP :: RHS -> Doc
genRHSWildP (RHS prodruleplus) = genProdrulepat prodruleplus
  where
    genProdrulepat :: ProdrulePlus -> Doc
    genProdrulepat (ProdrulePlus prodruleName maybeupdates) = parens $ (text prodruleName) <+> hsep (map genEitherUpdatespat maybeupdates)
    genEitherUpdatespat :: Either Unchanged Update -> Doc
    genEitherUpdatespat (Left _ ) = wildcardDoc
    genEitherUpdatespat (Right (NUpdate _ _ )) = wildcardDoc
    genEitherUpdatespat (Right (DUpdate st prodruleplus)) = genProdrulepat prodruleplus



-- generate patterns consisting of Constructor and variables.
-- (The variables (aka sub-parts) are used in RHS to update corresponding parts in source data)
-- used for rearrangeAndUpdate
genLHSUpdate :: LHS -> Doc
genLHSUpdate (LHS lhspats) = genLHSUpdate_ lhspats
  where
    genLHSUpdate_ :: LHSPattern -> Doc
    genLHSUpdate_ pat =
      case pat of
        (NormalP (ViewCon vc) lhspats) -> text vc <+> hsep (map genLHSUpdate_ lhspats)
        (ViewVar vv)           -> text vv
        (WildcardP)            -> wildcardDoc
        (LitStrPattern s)      -> doubleQuotes (text s)       -- or doubleQuotes s
        (LitIntegerPattern i)  -> text (show i)
        (LitFloatPattern   f)  -> text (show f)
        (LitBoolPattern    b)  -> text (show b)
        (ASPattern n p)        -> text n -- problematic
        (InParen lhs)          -> parens $ genLHSUpdate_ lhs


genRHSUpdate :: RHS -> Doc
genRHSUpdate (RHS prodruleplus) = genProdruleUpdate prodruleplus
  where
    genProdruleUpdate :: ProdrulePlus -> Doc
    genProdruleUpdate (ProdrulePlus prodruleName maybeupdates) = (text prodruleName) <+> hsep (map genEitherUpdatespat maybeupdates)

    genEitherUpdatespat :: Either Unchanged Update -> Doc
    genEitherUpdatespat (Left _ ) = wildcardDoc
    genEitherUpdatespat (Right (NUpdate vv (SourceType st) )) = text $ if isPrimitiveWithLayout st then addLayoutFieldIfPrimitive_SkipUpd vv else vv
    genEitherUpdatespat (Right (DUpdate st prodruleplus)) = parens . genProdruleUpdate $ prodruleplus


genRearrangeAndUpdate :: ViewType -> Rule -> (Doc, Doc, Doc)
genRearrangeAndUpdate (ViewType vt) (NormalRule lhs rhs) =
  let vDecompose = genLHSUpdate lhs
      sDecompose = genRHSUpdate rhs
      upd        = genUpd rhs
  in  (wrapPatQ vDecompose, wrapPatQ sDecompose, wrapDecQ upd)
  where
    genUpd :: RHS -> Doc
    genUpd (RHS pp) = foldr (\x xs -> x <> semi <+> xs) TPP.empty (genUpd1 pp)
      where
        -- [Right (NUpdate "lhs" (SourceType "Expr")),Right (NUpdate "rhs" (SourceType "Term"))]
        -- will give: [d| lhs = ruleArithExpr; rhs = ruleArithTerm |].
        -- The "Arith" is found by the "ViewType" which is not mutable in a group.
        genUpd1 :: ProdrulePlus -> [Doc]
        genUpd1 (ProdrulePlus _ eitherupdates) = foldl' genUpd2 [] eitherupdates
          where
            genUpd2 :: [Doc] -> Either Unchanged Update -> [Doc]
            genUpd2 decs (Left _) = decs -- decs is the accumulative parameter
            genUpd2 decs (Right (NUpdate vv (SourceType st))) =
              case st of -- ad hoc. shall improved later
                "(NameX9or2c81, String)"    -> decs ++ [text vv <+> equals <+> text "Replace"]
                "(String, String)" -> decs ++ [text vv <+> equals <+> text "Replace"]
                "(Int, String)"    -> decs ++ [text vv <+> equals <+> text "Replace"]
                "(Integer, String)"    -> decs ++ [text vv <+> equals <+> text "Replace"]
                "(Bool, String)"   -> decs ++ [text vv <+> equals <+> text "Replace"]
                "(Float, String)"  -> decs ++ [text vv <+> equals <+> text "Replace"]
                "(Double, String)"    -> decs ++ [text vv <+> equals <+> text "Replace"]
                _        -> decs ++ [text vv <+> equals <+> text "bigul" <> text vt <> text st]
            genUpd2 decs (Right (DUpdate st prodruleplus)) = decs ++ genUpd1 prodruleplus


-- set left value to a unique string... though ad hoc, it is hard to be captured
--changeLeftToString :: [Either Unchanged Update] -> [Either Unchanged Update]
--changeLeftToString = foldr (\x xs -> case x of Left  (Unchanged (SourceType st)) -> Left (Unchanged (SourceType "String_kjd24592x")) : xs; a@(Right _) -> a :xs ) []

importStr :: String
importStr =
  render  (foldr (\x xs -> text x $$ xs )
          TPP.empty
          ["{-# Language TemplateHaskell, QuasiQuotes #-}"
          ,"import GHC.Generics"
          ,"import Generics.BiGUL.AST hiding (Expr, Pat)"
          ,"import Generics.BiGUL.Interpreter"
          ,"import Generics.BiGUL.TH"
          ,"import Generics.BiGUL.Error"
          ,"import Parser (parser2, str2CST)"
          ,"import YourLangDef"
          ,"import System.Environment (getArgs)"
          ,"import System.IO.Strict as IOS"
          ])

mainStr :: String
mainStr =
  render  (foldr (\x xs -> text x $$ xs )
          TPP.empty
          ["main :: IO ()"
          ,"main = do"
          ,"  args <- getArgs"
          ,"  if length args < 3"
          ,"    then error $ usageInfoGet ++ usageInfoPut"
          ,"    else do"
          ,"      let getOrPut      = args !! 0"
          ,"          srcCodeFName  = args !! 1"
          ,"          astFName      = args !! 2"
          ,"      srcCode <- IOS.readFile srcCodeFName"
          ,"      let (comm, cst) = parser2 srcCode"
          ,"      case getOrPut of"
          ,"        \"get\" -> do"
          ,"                   let ast = either (error \"get error\") id (get entrance cst)"
          ,"                   writeFile astFName (show ast)"
          ,"        \"put\" -> do"
          ,"                   let newSrcCodeName = if length args == 4 then args !! 3 else srcCodeFName"
          ,"                   srcCode <- IOS.readFile srcCodeFName"
          ,"                   ast <- IOS.readFile astFName"
          ,"                   let srcCode' = either (error \"put error\") id (put entrance cst (read ast))"
          ,"                   writeFile newSrcCodeName (comm ++ show srcCode')"
          ,"  where"
          ,"    usageInfoGet = \"usage - get: YourExecutable get CodeFileName ASTFileName\\n\""
          ,"    usageInfoPut = \"usage - put: YourExecutable put OldCodeFileName ASTFileName NewCodeFileName\\n\""
          ])

getEntrance :: Program -> String
getEntrance (Program groups) =
  let Group (TypeDecl (ViewType vt) (SourceType st)) _  = head groups
  in  "entrance = " ++ "bigul" ++ vt ++ st
