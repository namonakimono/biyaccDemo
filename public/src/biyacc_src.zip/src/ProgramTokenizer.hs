{-# Language DeriveDataTypeable #-}
module ProgramTokenizer where

import Text.Parsec
import Text.Parsec.Token hiding (symbol)
import Control.Monad (liftM)
import Data.Typeable
import Data.Data

import LanguageDef

import Debug.Trace


type TokenPos = (ActionToken, SourcePos)

tokenProgram_ForQuasi :: Monad m => (String, Int, Int) -> String -> m [TokenPos]
tokenProgram_ForQuasi (file, line, col) s =
  case runParser tokenProgram () "" s of
    Left err  -> fail $ show err
    Right tokens   -> return tokens


-- program tokenizer.
tokenProgram :: Parsec String () [TokenPos]
tokenProgram = do
  whiteSpace generatedParser
  action_word <- keyword
  tmp   <- many1 actionGroup
  let acts_ = concat tmp
  eof
  return (action_word : acts_)

-- string literal. will change char literal to string literal
strLit :: Parsec String () TokenPos
strLit = byLexeme (do
  pos <- getPosition
  choice [ try (char '#' >> byStrLit) >>= \str -> return (StrLit str, pos)
         , (char '#' >> byStrLit) >>= \str -> return (StrLit str, pos)])
  <?> "error in strLit"

numbersLit :: Parsec String () TokenPos
numbersLit = byLexeme (do
  pos <- getPosition
  choice [ try (char '#' >> byInteger) >>= \i -> return (IntegerLit i, pos)
         , try (char '#' >> byInt)     >>= \i -> return (IntLit (fromInteger i), pos)
         , (char '#' >> byFloat)   >>= \f -> return (FloatLit f, pos)
         ])
  <?> "error in numbers"

boolLit :: Parsec String () TokenPos
boolLit = byLexeme (do
  pos <- getPosition
  choice [ try (char '#' >> string "True")  >> return (BoolLit True, pos)
         , (char '#' >> string "False") >> return (BoolLit False, pos)])
  <?> "error in numbers"

funOrVarName :: Parsec String () TokenPos
funOrVarName = byLexeme (do
  pos <- getPosition
  char '#'
  f <- lower
  t <- many (alphaNum)
  return (BName (f:t),pos))
  <?> "error in funOrVarName"


-- variable
variable :: Parsec String () TokenPos
variable = byLexeme (do
  pos <- getPosition
  fst <- lower
  s   <- many (alphaNum <|> char '_' )
  return (Var (fst:s), pos))
  <?> "error in variable"

-- built in operator
deepPatOpt :: Parsec String () TokenPos
deepPatOpt = byLexeme (getPosition >>= \p -> string "->" >> return (To, p) <?> "want ->")

embedOpt :: Parsec String () TokenPos
embedOpt = byLexeme (getPosition >>= \p -> string "+>" >> return (Embed, p) <?> "want +>")

lineEnd :: Parsec String () TokenPos
lineEnd = byLexeme (getPosition >>= \p -> string ";" >> return (LineEnd, p)) <?> "error in lineEnd"

keyword :: Parsec String () TokenPos
keyword = byLexeme (do
  pos <- getPosition
  choice [try (string "Actions")  >> return (Action, pos)]
  )
  <?> "keyword"

-- type constructor
constructor :: Parsec String () TokenPos
constructor = byLexeme (do
  pos <- getPosition
  f <- upper
  t <- many1 (alphaNum <|> char '_')
  return (Constructor (f:t), pos))
  <?> "error in constructor"

-- on rhs, we call it subtree
subtree = constructor

subtree' = constructor >>= \s -> return [s]

adaptiveToken :: Parsec String () [TokenPos]
adaptiveToken = byLexeme $ do
  pos <- getPosition
  try (string "Adaptive")
  --whiteSpace generatedParser
  string ":"
  --whiteSpace generatedParser
  adpdecls <- manyTill anyChar (try (string ";"))
  return [(AAdaptive adpdecls, pos), (LineEnd, pos)]

--, '(', ')', etc.
lparen :: Parsec String () TokenPos
lparen = byLexeme (getPosition >>= \p -> char '(' >> return (LParen, p)) <?> "lparen"

rparen :: Parsec String () TokenPos
rparen = byLexeme (getPosition >>= \p -> char ')' >> return (RParen, p)) <?> "rparen"


actionGroup :: Parsec String () [TokenPos]
actionGroup = byLexeme (do
  desc <- actionDesc
  actions_ <- many1 action
  return $ desc ++ concat actions_)
  <?> "error in actionGroup"

actionDesc :: Parsec String () [TokenPos]
actionDesc = byLexeme (do
  abs <- constructor
  embedSign <- (embedOpt <?> "want +>, in actionDesc")
  conc <- constructor
  return [abs,embedSign,conc])
  <?> "error in actionDecs"

action :: Parsec String () [TokenPos]
action = byLexeme (try (do
  l <- lhs
  embedSign <- (embedOpt <?> "want +>, in action tokeniser")
  r <- rhs
  lineend_  <- lineEnd
  return (l ++ [embedSign] ++ r ++ [lineend_])))
  <|> adaptiveToken
  <?> "error after actionDecs, error in action"

lhs :: Parsec String () [TokenPos]
lhs =
  try (do
    con <- constructor
    tmp <- many p0
    let following = concat tmp
    return (con : following)) <|>
  try  asp <|>
  try (variable >>= \any -> return [any]) <|>
  (twildCard   >>= \w -> return [w])
  <?> "lhs tokenizer error"
  where
    p0 =
          try asp <|>
          try (variable    >>= \any -> return [any]) <|>
          try (twildCard   >>= \w -> return [w]) <|>
          try (numbersLit  >>= \n -> return [n]) <|>
          try (boolLit     >>= \b -> return [b]) <|>
          try (strLit      >>= \s -> return [s]) <|>
          try (constructor >>= \c -> return [c]) <|>
          try (do lp <- lparen;
                  inner <- lhs;
                  rp <- rparen;
                  return ([lp] ++ inner ++ [rp]))
    asp = try (do
            aswhat <- variable
            as <- byLexeme (getPosition >>= \p -> char '@' >> return (As, p) <?> "want @")
            lp <- lparen
            inner <- lhs
            rp <- rparen
            return $ [aswhat,as,lp] ++ inner ++ [rp] )

twildCard :: Parsec String () TokenPos
twildCard = byLexeme (do
  p <- getPosition
  string "_"
  return (Wildcard, p))
  <?> "1 error in wild cast"

rhs :: Parsec String () [TokenPos]
rhs = do
  let p = try terminal <|> try deep <|> try update <|> nonUpdate
  r <- try (many1 p)
  return $ concat r

deep :: Parsec String () [TokenPos]
deep = do
  lp <- lparen
  np <- nonUpdate
  to <- (deepPatOpt <?> "error in deep pattern tokeniser") -- To (->)
  deeprhs <- rhs
  rp <- rparen
  return $ [lp] ++ np ++ [to] ++ deeprhs ++ [rp]
  <?> "error in deep"

update :: Parsec String () [TokenPos]
update = do
  lp <- lparen
  var <- variable
  embedSign <- (embedOpt <?> "want +>, in update tokeniser")
  subt <- try deep <|> subtree'
  rp <- rparen
  return $ [lp, var, embedSign] ++ subt ++ [rp]
  -- head subt means that you can either update the whole deep pattern, or update some inner parts of the deep pattern.
  -- but you cannot update both the whole deep patern and some of its inner part.
  -- legal: (t => InfixExp -> Exp '&' Exp);
  -- illegal (t => InfixExp -> ((e1 => Exp) '&' (e2 => Exp)) );
  <?> "update"

nonUpdate :: Parsec String () [TokenPos]
nonUpdate = subtree >>= \u -> return [u] <?> "non update"

terminal :: Parsec String () [TokenPos]
terminal = terminal' >>= \t -> (return [t])  <?> "terminal"
  where
    terminal' :: Parsec String () TokenPos
    terminal' = byLexeme (do
      pos <- getPosition
      choice [ try byStrLit  >>= \str -> return (TTerminal str, pos)
             , try byCharLit >>= \str -> return (TTerminal str, pos)] )
