module AbstractType where

import LanguageDef
import Text.Parsec.Token (whiteSpace)

import Text.Parsec
import Data.List.Utils (replace)

type TokenPos = (AbstractToken, SourcePos)

pAbstract :: Parsec String () (TokenPos, String)
pAbstract = byLexeme (do
  sss <- getInput
  whiteSpace generatedParser
  p <- getPosition
  string "Abstract"
  decls <- manyTill anyChar (try (string "Concrete"))

  inp <- getInput              -- ad hoc part. be removed if implemented using template haskell
  setInput ("Concrete" ++ inp) -- ad hoc part. be removed if implemented using template haskell
  return ((AAnything (replace' decls), p), replace' sss)
  <?> "pAbstract")

writeQuoteToAnotherFile :: String -> IO ()
writeQuoteToAnotherFile = writeFile "BySplittedProgram.txt"

replace' = replace " Name" "NameX9or2c81"  -- the SPACE before Name is necessary for producing correct replacement