module AbstractType where

import LanguageDef
import Text.Parsec.Token (whiteSpace, identifier)

import Text.Parsec
import Data.List.Utils (replace)
import Data.Map (singleton, unions, Map)

type TokenPos = (AbstractToken, SourcePos)

pAbstract :: Parsec String () (TokenPos, String)
pAbstract = byLexeme (do
  sss <- getInput
  whiteSpace generatedParser
  p <- getPosition
  string "Abstract"
  decls <- manyTill anyChar (try (string "Concrete"))

  inp <- getInput              -- ad hoc part. be removed if implemented using template haskell
  setInput ("Concrete" ++ inp) -- ad hoc part. be removed if implemented using template haskell
  return ((AAnything (replace' decls), p), replace' sss)
  <?> "pAbstract")

writeQuoteToAnotherFile :: String -> IO ()
writeQuoteToAnotherFile = writeFile "BySplittedProgram.txt"

replace' = replace " Name" " NameX9or2c81"  -- the SPACE before Name is necessary for producing correct replacement

pDatatypes :: Parsec String () AAST
pDatatypes = do
  datatypes <- many1 $ try pEachDataType
  return $ AAST "" datatypes

pEachDataType :: Parsec String () ADataType
pEachDataType = do
  byWhiteSpace
  byLexeme (string "data")
  datatype <- byLexeme (identifier generatedParser)
  linedata <- many1 pLines
  ignoreDerivingPart
  return $ ADataType datatype linedata
  where
    pLines = do
      byLexeme ((string "=") <|> (string "|"))
      con:datatypes <- byLexeme (many1 (identifier generatedParser))
      byWhiteSpace
      return $ ATypeDef con datatypes

ignoreDerivingPart :: Parsec String () ()
ignoreDerivingPart = do
  byWhiteSpace
  string "deriving"
  manyTill anyChar (try (string "data"))
  inp <- getInput
  setInput ("data" ++ inp)

buildConsToSubtreeTypeEnv :: AAST -> Map String [String] --   Add ---> [Arith, Arith]
buildConsToSubtreeTypeEnv (AAST _ datatypes) = unions $ map refine1 datatypes
  where refine1 (ADataType _ typedefs) = unions $ map refine2 typedefs
        refine2 (ATypeDef  cons subtreetypes) = singleton cons subtreetypes


data AAST      = AAST      String [ADataType] deriving (Show, Eq)  -- AAST (top level datatype) [datatypes]
data ADataType = ADataType String [ATypeDef] deriving (Show, Eq) -- CDataType type definitions. CDataType "Expr" [...]
data ATypeDef  = ATypeDef  String [String] deriving (Show, Eq) -- CTypeDef constructor [types]
