{-# Language DeriveDataTypeable #-}

module ProgramParser where

import LanguageDef
import BiYaccUtils

import Text.Parsec.Token hiding (symbol)
import Text.Parsec
import Text.Parsec.Prim
import Text.Parsec.Combinator
import Control.Monad

import Text.PrettyPrint as PPrint
import Data.List (intersperse, map)
import Data.Char (toLower)
import Data.Maybe (catMaybes)
import Data.Map.Strict as Map (Map, lookup)

import Data.Typeable
import Data.Data

import Debug.Trace


newtype Program  = Program [Group]              deriving (Data, Show, Eq)
data Group       = Group TypeDecl [Rule]        deriving (Data, Show, Eq)
data TypeDecl    = TypeDecl ViewType SourceType deriving (Data, Show, Eq)

-- data type for parser to return to build the AST.
newtype SourceType = SourceType String deriving (Data, Show, Eq)
newtype ViewType   = ViewType String   deriving (Data, Show, Eq)
newtype ViewCon    = ViewCon  String   deriving (Data, Show, Eq)

data Rule =  NormalRule LHS RHS
          |  UserAdaptiveRule String -- the adaptive rule specified by the user
  deriving (Data, Show, Eq)

data LHS = LHS LHSPattern deriving (Data, Show, Eq) -- the left hand side of a rule is just represented by a pattern (matching by patterns)

data LHSPattern = NormalP ViewCon [LHSPattern]   -- NormalP: normal pattern(I just do not know how to call it)
                | ASPattern String LHSPattern    -- ASPattern: @
                | ViewVar String
                | LitStrPattern String
                | LitIntegerPattern Integer
                | LitIntPattern Int
                | LitFloatPattern Double
                | LitBoolPattern Bool
                | WildcardP
                | InParen LHSPattern
  deriving (Data, Show, Eq)

-- the right hand side of a rule is merely a production rule plus some updates somewhere.
data RHS = RHS ProdrulePlus deriving (Data, Show, Eq)

data ProdrulePlus = ProdrulePlus ProdruleName [Either Unchanged Update] deriving (Data, Show, Eq)
data Unchanged    = Nonterminal  SourceType | Terminal String           deriving (Data, Show, Eq)
-- "SourceType" is not always a "SourceType". (in Unchanged "SourceType". )
data Update       = NUpdate      VVar SourceType
                  | DUpdate      SourceType ProdrulePlus                deriving (Data, Show, Eq)  -- deep update. deep pattern match


type TokenPos = (ActionToken, SourcePos)
type ParserU = Parsec [TokenPos] ()


isToken :: ActionToken -> Parsec [TokenPos] () ActionToken
isToken tok = token show snd (\t -> if fst t == tok then Just (fst t) else Nothing)

isAdaptive :: Parsec [TokenPos] () ActionToken
isAdaptive = token show snd
  (\t -> case fst t of
    AAdaptive _ -> Just (fst t)
    _           -> Nothing)

-- extract the string in the  Constructor
extractConstructorName :: Parsec [TokenPos] () String
extractConstructorName = token show snd (\t -> case fst t of Constructor str -> Just str; _ -> Nothing)

-- extract the string (variable name) in the variable
extractVariableName :: ParserU String
extractVariableName = token show snd (\t -> case fst t of Var s -> Just s; _ -> Nothing)
--extract the string from the QLitPattern Constructor
extractLitString :: ParserU String
extractLitString = token show snd (\t -> case fst t of StrLit s -> Just s; _ -> Nothing)

extractInteger :: ParserU Integer
extractInteger = token show snd (\t -> case fst t of IntegerLit i -> Just i; _ -> Nothing)

extractInt :: ParserU Int
extractInt = token show snd (\t -> case fst t of IntLit i -> Just i; _ -> Nothing)

-- double
extractFloat :: ParserU Double
extractFloat = token show snd (\t -> case fst t of FloatLit d -> Just d; _ -> Nothing)

extractBool :: ParserU Bool
extractBool = token show snd (\t -> case fst t of BoolLit b -> Just b; _ -> Nothing)

extractTerminal :: ParserU String
extractTerminal = token show snd (\t -> case fst t of TTerminal s -> Just s; _ -> Nothing)



program :: EigenNameEnv -> ParserU Program
program env = isToken Action >> liftM Program (many1 (group env)) >>= \ast -> eof >> return ast <?> "programParser"


group :: EigenNameEnv -> ParserU Group
group env = do
  t@(TypeDecl vt st) <- typeDecl
  rules_ <- many1 (try (rule st env))
  return $ Group t rules_
  <?> "groupParser"

typeDecl :: ParserU TypeDecl
typeDecl = do
  vtype <- extractConstructorName
  isToken Embed
  stype <-extractConstructorName
  return $ TypeDecl (ViewType vtype) (SourceType stype)
  <?> "typeDeclParser"


rule :: SourceType -> EigenNameEnv -> ParserU Rule
rule st env = try (do
  lhs_ <- lhs
  isToken Embed
  rhs_ <- rhs st env
  isToken LineEnd
  return (NormalRule lhs_ rhs_)) <|>
  (do
    AAdaptive adtDecls <- isAdaptive
    isToken LineEnd
    return (UserAdaptiveRule adtDecls))
  <?> "ruleParser, xrule"

lhs = liftM LHS lhsPattern

lhsPattern :: ParserU LHSPattern
lhsPattern =
  try (do -- aspattern
       aswhat <- extractVariableName
       isToken As
       isToken LParen
       pattern <- lhsPattern
       isToken RParen
       return (InParen $ ASPattern aswhat pattern)) <|>
  try (liftM2 NormalP (liftM ViewCon extractConstructorName) (many lhsPattern)) <|> -- normal
  try (liftM ViewVar extractVariableName)      <|> -- just a variable, match anything
  try (liftM LitStrPattern extractLitString)   <|>
  try (liftM LitIntegerPattern extractInteger) <|>
  try (liftM LitIntPattern extractInt)         <|>
  try (liftM LitFloatPattern extractFloat)     <|>
  try (liftM LitBoolPattern extractBool)       <|>
  try (isToken Wildcard >> return WildcardP)   <|>

  (do
    isToken LParen
    innerpatterns <- lhsPattern
    isToken RParen
    return (InParen innerpatterns))
  <?> "lhsPattern"


rhs :: SourceType -> EigenNameEnv -> ParserU RHS
rhs st env = liftM RHS (prodrulePlus st env)

prodrulePlus :: SourceType -> EigenNameEnv -> ParserU ProdrulePlus
prodrulePlus st env = many1 (update env) >>= \eitherupds -> return $ update2ProdrulePlus st env eitherupds

update :: EigenNameEnv -> ParserU (Either Unchanged Update)
update env = try (do
  -- normal update 1
  isToken LParen
  var <- extractVariableName
  isToken Embed
  sub <- extractConstructorName
  --traceM ("it is not too deep!:"  ++ show sub)
  isToken RParen
  -- here the primitive type is changed. eg Int is changed to (Int, String) to contain layout. it is somehow not good...
  return $ Right $ NUpdate var (SourceType (addLayoutFieldIfPrimitive sub))) <|>

  -- terminal
  try (liftM (Left . Terminal) extractTerminal) <|>
  -- deep pattern
  try (update_deepPat env) <|>

  -- normal update 2: the updated part is expanded to a deep pattern
  -- but since you cannot update both the whole deep pattern part and also some of its inner parts
  -- so here we skip the whole deep pattern part and treat it as a normal update.
  try (do
  isToken LParen
  var <- extractVariableName
  isToken Embed
  Right (DUpdate (SourceType con) _) <- update_deepPat env
  isToken RParen
  -- here the primitive type is changed. eg Int is changed to (Int, String) to contain layout. it is somehow not good...
  return $ Right $ NUpdate var (SourceType (addLayoutFieldIfPrimitive con))) <|>

  -- non update
  (extractConstructorName >>= \sourcetype -> return $ (Left . Nonterminal . SourceType) sourcetype)
  <?> "update"

-- deep pattern
update_deepPat :: EigenNameEnv -> ParserU (Either Unchanged Update)
update_deepPat env = do
  isToken LParen
  con <- extractConstructorName
  --traceM ("it is too deep!:"  ++ show con)
  isToken To
  deep <- prodrulePlus (SourceType con) env -- if we go deep, the type of the deep expressions is the name (aka nonterminal) of their parent
  isToken RParen
  return $ Right (DUpdate (SourceType con) deep)
  <?> "error in update_deepPat"


update2ProdrulePlus :: SourceType -> EigenNameEnv -> [Either Unchanged Update] -> ProdrulePlus
update2ProdrulePlus (SourceType st) env eitherupds =
  let pat = getProdrulePat eitherupds
      maybeProdrulename = Map.lookup (pat,st) env
  in  case maybeProdrulename of
        Nothing -> error $ "cannot find pattern in concrete data type (no such production rule):" ++ "(" ++ show pat ++ ", " ++ show st ++ ")"
        Just prodrulename -> ProdrulePlus prodrulename eitherupds

getProdrulePat :: [Either Unchanged Update] -> ProdRuleEigen
getProdrulePat = map getUpdPat
  where getUpdPat :: Either Unchanged Update -> Either String String
        getUpdPat (Left (Nonterminal (SourceType sourcetype))) = Right sourcetype
        getUpdPat (Left (Terminal t)) = Left t
        getUpdPat (Right upd) = case upd of
                                  NUpdate _ (SourceType sourcetype) -> Right sourcetype
                                  DUpdate (SourceType sourcetype) _ -> Right sourcetype



{-
The file provide functions for generating AST of "Actions" part in a BiYacc file.
Like what we do when dealing with the production rules in "Concrete" part, we first generate a temporary AST with holes.
The holes are then filled up with the help of environment.
But this time these two procedures are called mutually recursively.

-}

--------------test functions ---------------


