module GenExec where

import System.Process
import System.Environment
import System.Info

testCases =
  [("expr/expr.txt", "ByExpr")
  ,("tigerUnambiguous/tiger.txt", "ByTigerUnambi")
  ,("exprKleene/kleene.txt", "ByExprKleene")
  ,("exprNonlinear/nonlinear.txt", "ByExprNonlinear")
  ,("exprAdapt/adapt.txt", "ByExprAdapt")
  ,("exprAmbi/exprAmbi.txt", "ByExprAmbi")
  -- ,("tigerUnambiKleene/tigerUnambiKleene.txt", "ByTigerUnambiKleene")
  ]

genExec :: (String,String) -> IO ()
genExec (inFile, outFile) = do
  -- md5_ <- case os of
  --           "darwin" -> readProcess "md5" ["-q", byFile] ""
  --           "linux"  -> readCreateProcess (shell $ "md5sum " ++ byFile ++ " | awk '{print $1}'") ""

  -- let md5 = init md5_   -- The output has an additional newline. Drop it.
  -- putStrLn (show md5)
  readProcess "biyacc" [inFile, outFile] ""
  return ()

genExecs = mapM genExec testCases
