{-# LANGUAGE OverloadedStrings #-}
module BiYacc.Parser.Directives (pDirectives, pHappyConfigs, skipDirectives) where

-- import Prelude hiding (drop, map)
import BiYacc.Language.Def
import BiYacc.Helper.Utils
import BiYacc.Parser.Concrete

import Data.Char (isSpace)
import Data.Map (Map)
import qualified Data.Map as Map
import Text.Parsec
import Text.PrettyPrint as TPP hiding (char)

------------------
-- interpreter the directives for parsing and printing
pDirectives :: Monad m => Pat2NameEnv -> Name2PatEnv -> ParsecT String u m ([Cmd], Map String (Maybe Priority, Maybe Assoc))
pDirectives eenv nenv = do
  posForHappyConf <- getPosition
  byWhiteSpace
  byLexeme (string "#Directives" <?> "expecting keyword #Directives")

  commentSLine <- optionMaybe commLine
  commentSBlock <- optionMaybe commBlock
  let cmdComments = catMaybes [commentSLine,commentSBlock]

  priEnv <- pPriorities eenv
  assocEnv <- pAssocs eenv

  let happyDef = toHappyDef nenv priEnv assocEnv
      exampleDisAmbEnv = toExampleDisAmbEnv priEnv assocEnv

      cmds =  either (error . (++) "error in directives: " . show ) id $
                runParser (pHappyConfigs posForHappyConf) () "" (render happyDef)

  return (cmdComments ++ cmds, exampleDisAmbEnv)


commLine :: Monad m => ParsecT String u m Cmd
commLine = do
  byLexeme (string "LineComment")
  byLexeme (char ':')
  x <- byStrLit <?> "please use double-quotes for single-line comment symbols"
  eatSemi
  return (CmdCommLine x)

commBlock :: Monad m => ParsecT String u m Cmd
commBlock = do
  byLexeme (string "BlockComment")
  byLexeme (char ':')
  startMark <- byStrLit <?> "please use double-quotes multi-line comment symbols"
  endMark   <- byStrLit <?> "please use double-quotes multi-line comment symbols"
  eatSemi
  return (CmdCommBlock startMark endMark)

skipDirectives :: Monad m => ParsecT String u m String
skipDirectives = do
  byWhiteSpace
  byLexeme (string "#Directives" <?> "expecting keyword #Directives")
  directives <- manyTill anyChar (try (string "#Actions"))

  actionSrc    <- getInput
  setInput ("#Actions\n" ++ actionSrc)

  return $ "#Directives\n" ++ directives

-- -- parse the configurations. such as precedences %left, %right...
-- -- and comment declarations: commentLine, commentBlock
pHappyConfigs :: Monad m => SourcePos -> ParsecT String u m [Cmd]
pHappyConfigs srcPos = do
  setPosition srcPos
  cmds <- many ((try leftAssoc <|> try rightAssoc <|> try nonAssoc)
                  >>= \x -> eatSemi >> return x)
  return cmds
leftAssoc :: Monad m => ParsecT String u m Cmd
leftAssoc = byLexeme (do
  byLexeme (string "%left")
  x <- many1 ((terminal >>= return . Left) <|> (nonterminal >>= return .Right))
  return (CmdLeftAssoc x))

rightAssoc :: Monad m => ParsecT String u m Cmd
rightAssoc = byLexeme (do
  byLexeme (string "%right")
  x <- many1 ((terminal >>= return . Left) <|> (nonterminal >>= return . Right))
  return (CmdRightAssoc x))

nonAssoc :: Monad m => ParsecT String u m Cmd
nonAssoc = byLexeme (do
  byLexeme (string "%nonassoc")
  x <- many1 ((terminal >>= return . Left) <|> (nonterminal >>= return . Right))
  return (CmdNonAssoc x))

-- a list of pairs containing production name. the first production has lower priority
pPriorities :: Monad m => Pat2NameEnv -> ParsecT String u m PriEnv
pPriorities eenv = do
  priRelations <- many (pPriority eenv)
  return $ buildPriorityEnv (concat priRelations)


pPriSingleSyntax :: Monad m => Pat2NameEnv -> ParsecT String u m [ProdRuleCons]
pPriSingleSyntax eenv = do
  pName <- nonterminal
  byLexeme (try (string "->"))
  fields <- many1 parseField
  case Map.lookup (map toBiType fields, pName) eenv of
    Nothing -> error $ "\nproduction not defined:\n" ++ pName ++ " -> " ++ show fields
                        -- concatSpace (map ppCTypeField fields)
    Just consName -> return [consName]

  where toBiType :: CTypeField -> CTypeField
        toBiType (CTypeFieldSingle (Right x)) = CTypeFieldSingle . Right . toBiYaccTy $ x
        toBiType (CTypeFieldBundle occ fs) = CTypeFieldBundle occ (map toBiType fs)
        toBiType a = a

pPriBundleSyntax :: Monad m => Pat2NameEnv -> ParsecT String u m [ProdRuleCons]
pPriBundleSyntax eenv = do
  byLexeme (char '{')
  prods <- many1 (do
              pr <- pPriSingleSyntax eenv
              eatSemi
              return pr)
  byLexeme (char '}')
  return (concat prods)

-- for priority: (x,y) means x <= y; if (x,y) and (y,x) and x === y.
pPriority :: Monad m => Pat2NameEnv -> ParsecT String u m [(ProdRuleCons, ProdRuleCons)]
pPriority eenv = do
  prod1s <- pPriSingleSyntax eenv <|> pPriBundleSyntax eenv
  sy <- (byLexeme (string ">>>") >> return "LT") <|> -- preferring means low priority in traditional setting
        (byLexeme (string "<<<") >> return "GT")
  prod2s <- pPriSingleSyntax eenv <|> pPriBundleSyntax eenv
  -- let eqPriProds = [(x, y) | x <- prod1s, y <- prod1s] ++ [(x, y) | x <- prod2s, y <- prod2s]
  let eqPriProds = []

  eatSemi
  return $ case sy of
    "LT" -> eqPriProds ++ [(prod1, prod2) | prod1 <- prod1s, prod2 <- prod2s]
    "GT" -> eqPriProds ++ [(prod2, prod1) | prod1 <- prod1s, prod2 <- prod2s]


buildPriorityEnv :: [(ProdRuleCons, ProdRuleCons)] -> PriEnv
buildPriorityEnv prdPairs =
  Map.unions $ zipWith setPri (sortPOSet . mkTransitive $ prdPairs) [0..]
  where setPri prodCons pri = Map.unions $ map (flip Map.singleton pri) prodCons


minOfPOSet :: Eq a => [(a, a)] -> [a]
minOfPOSet pairs =
  let (potentials, impossibles) = unzip pairs
  in  nub $ [ p | p <- potentials, not (p `elem` impossibles)]

maxOfPOSET :: Eq a => [(a, a)] -> [a]
maxOfPOSET pairs =
  let (impossibles, potentials) = unzip pairs
  in  nub $ [ p | p <- potentials, not (p `elem` impossibles)]

sortPOSet :: Eq a => [(a, a)] -> [[a]]
sortPOSet pairs =
  let maxs = maxOfPOSET pairs
  in  sortPOSet' pairs ++ [maxs]
  where
    sortPOSet' [] = []
    sortPOSet' pairs =
      let mins = minOfPOSet pairs
          newSet = filter (\(a,b) -> not (a `elem` mins)) pairs
      in  mins : sortPOSet' newSet


-- make the priority environment transitive
mkTransitive :: Eq a => [(a, a)] -> [(a, a)]
mkTransitive l = toFixed oneStep l
  where toFixed :: (Eq a) => (a -> a) -> a -> a
        toFixed f s = let s' = f s
                      in  if s' == s then s else toFixed f s'
        oneStep l = nub $ l ++ [(a,c) | (a,b) <- l, (b',c) <- l, b == b' ]


--------------------
pAssocs :: Monad m => Pat2NameEnv -> ParsecT String u m AssocEnv
pAssocs eenv = liftM Map.unions (many (pAssoc eenv))

-- The implementation is just for the moment and very unsafe.
pAssoc :: Monad m => Pat2NameEnv -> ParsecT String u m AssocEnv
pAssoc eenv = do
  lhs <- try saveLHS
  rhs <- saveRHS
  -- eatSemi

  let str = takeWithinParen lhs
  let eigens = either (error . show) id . runParser (many parseField) () "" $ str
  let pName = case Map.lookup eigens (trimPat2NameEnv eenv) of
                Nothing -> error $ "cannot find productions in the environment. is the production unique to its RHS?"
                              ++ "\n RHS: " ++ show eigens
                Just n -> n

  return $ case head lhs of
    '(' -> Map.singleton pName LeftAssoc
    _   -> Map.singleton pName RightAssoc

  where
    saveLHS = do
      c  <- nonSpace
      cs <- manyTill anyChar (try (string "==="))
      byWhiteSpace
      return (c:cs)

    saveRHS = do
      c  <- nonSpace
      cs <- manyTill anyChar (try (string ";")) -- very unsafe
      byWhiteSpace
      return (c:cs)

    trimPat2NameEnv :: Pat2NameEnv -> PartialPat2NameEnv
    trimPat2NameEnv = mapKeys (\k -> fst k) -- very unsafe

    nonSpace :: Monad m => ParsecT String u m Char
    nonSpace = satisfy (not . isSpace)

takeWithinParen :: String -> String
takeWithinParen = takeWhile (/= ')') . drop 1 . dropWhile (/= '(')
----------------

-- generate happy definitions...
toHappyDef :: Name2PatEnv -> PriEnv -> AssocEnv -> Doc
toHappyDef nenv priEnv assocEnv =
  let prodConss = nub $ Map.keys priEnv ++ Map.keys assocEnv
      defPairs = map fff prodConss

  in  foldr pp TPP.empty (sort defPairs)

  where fff prodCons = case (Map.lookup prodCons priEnv, Map.lookup prodCons assocEnv) of
              (Just pri, Just assoc) -> (pri, printAssoc assoc, terminals prodCons)
              (Just pri, Nothing)    -> (pri, "%nonassoc", terminals prodCons)
              (Nothing, Just assoc)  -> (lowest, printAssoc assoc, terminals prodCons)

        pp (pri, assoc, ts) done = text assoc <+> text (concatSpace ts) <+> ";" $+$ done
        lowest = -1

        terminals :: ProdRuleCons -> [String]
        terminals prodCons = (terminalsRec. fst . fromJ "impossible. terminals. 0x0C." . Map.lookup prodCons) nenv

        terminalsRec :: [CTypeField] -> [String]
        terminalsRec (CTypeFieldSingle (Left t)  :xs) = ("'" ++ t ++ "'") : terminalsRec xs
        terminalsRec (CTypeFieldSingle (Right _) :xs) = terminalsRec xs
        terminalsRec (CTypeFieldBundle _ ts :xs) = terminalsRec ts ++ terminalsRec xs
        terminalsRec [] = []

toExampleDisAmbEnv :: PriEnv -> AssocEnv -> Map String (Maybe Priority, Maybe Assoc)
toExampleDisAmbEnv priEnv assocEnv =
  let prodConss = nub $ Map.keys priEnv ++ Map.keys assocEnv
  in  Map.unions $ map f prodConss

  where f prodCons = case (Map.lookup prodCons priEnv, Map.lookup prodCons assocEnv) of
            (Just pri, Just assoc) -> Map.singleton prodCons (Just pri, Just assoc)
            (Just pri, Nothing)    -> Map.singleton prodCons (Just pri, Nothing)
            (Nothing, Just assoc)  -> Map.singleton prodCons (Nothing, Just assoc)


printAssoc LeftAssoc = "%left"
printAssoc RightAssoc = "%right"
printAssoc NonAssoc = "%nonassoc"
