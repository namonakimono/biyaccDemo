{-# Language OverloadedStrings #-}

module BiYacc.Parser.Concrete where

import BiYacc.Language.Def
import BiYacc.Helper.Utils


import Text.Parsec hiding (State, newline)

import Data.Map hiding (foldr, map, drop, filter, (\\))
import qualified Data.Map as Map (lookup, empty)

import Control.Monad.State
import Text.Parsec.Token (identifier)

import Data.Generics hiding (empty)

-- import Text.PrettyPrint hiding (empty, char)
import qualified Text.PrettyPrint as TPP


--will change char literal to string literal
terminal :: Monad m => ParsecT String u m String
terminal = byStrLit <|> byCharLit
  <?> "want a terminal. use quotes for a single character. use doublequotes for a string."

nonterminal :: Monad m => ParsecT String u m String
nonterminal = byLexeme (identifier lexer) <?> "want a nonterminal."


buildTmpCAST :: Monad m => ParsecT String Int m CAST
buildTmpCAST = do
  byWhiteSpace
  byLexeme (string "#Concrete" <?> "expecting keyword #Concrete")
  defs <- many1 datatype
  let (CDataType t _) = head defs
  return $ CAST t defs

datatype :: Monad m => ParsecT String Int m CDataType
datatype = do
  putState 0
  t <- tConstructor
  defs <- datatypeDefs t
  eatSemi
  return $ CDataType t defs

datatypeDefs :: Monad m => String -> ParsecT String Int m [CTypeDef]
datatypeDefs typeName = do
  def1 <- (eatTo >> datatypeDef typeName)
  defn <- many (eatOr >> datatypeDef typeName)
  return (def1:defn)

datatypeDef :: Monad m => String -> ParsecT String Int m CTypeDef
datatypeDef typeName = do
  maybeName <- (modifyState (+1) >> constructorName) <|>
               do {count <- getState; modifyState (+1); return $ Just (typeName ++ show count)}
  ctypefields <- many1 (try zeroOrMore <|> try oneOrMore <|> once)
  brkAttr   <- bracketAttr <|> return Nothing
  -- traceM ("brkAttr: " ++ show brkAttr)
  let n = fromMaybe "" maybeName
  return $ CTypeDef n ctypefields (Annot Nothing Nothing Nothing brkAttr)

parseSingleField :: Monad m => ParsecT String u m ETNT
parseSingleField = (terminal >>= return . Left) <|> (nonterminal >>= return . Right)

constructorName :: Monad m => ParsecT String u m (Maybe String)
constructorName = eatLBrack >> nonterminal >>= \n -> eatRBrack >> return (Just n)
                  <?> "expecting a user-given constructor name"
bracketAttr :: Monad m => ParsecT String u m (Maybe BracketAttr)
bracketAttr = do
  sss <- getInput
  byLexeme (string "{#-")
  byLexeme (string "Bracket")
  byLexeme (string "-#}")
  return $ Just BracketAttr
  <?> "error in parsing disambiguation annotation"

parseField :: Monad m => ParsecT String u m CTypeField
parseField = try zeroOrMore <|> oneOrMore <|> once

once :: Monad m => ParsecT String u m CTypeField
once = parseSingleField >>= return . CTypeFieldSingle

zeroOrMore :: Monad m => ParsecT String u m CTypeField
zeroOrMore = do
  byLexeme (char '{')
  eithers_ <- many1 parseField
  byLexeme (string "}*")
  return $ CTypeFieldBundle ZeroOrMore eithers_

oneOrMore :: Monad m => ParsecT String u m CTypeField
oneOrMore = do
  byLexeme (char '{')
  eithers_ <- many1 parseField
  byLexeme (string "}+")
  return $ CTypeFieldBundle OneOrMore eithers_

------------- parser ends -------


--------------- transform tempCAST to CAST
toCAST :: CAST -> CAST
toCAST tmpcast = addNullConstructor . changeBiYaccTy $ tmpcast

changeBiYaccTy :: CAST -> CAST
changeBiYaccTy = everywhere (mkT changeETNT)
  where changeETNT :: ETNT -> ETNT
        changeETNT = either (Left) (Right . toBiYaccTy)


addNullConstructor :: CAST -> CAST
addNullConstructor = everywhere (mkT addNC)
  where addNC :: CDataType -> CDataType
        addNC (CDataType prefix ctypedefs) =
          CDataType prefix (ctypedefs ++ [CTypeDef (prefix ++ "Null") [] noFilterAnnotation])


-- the input is tempCAST, which does not contain "NullConstructor", "LayoutField"
buildEnv :: CAST -> (Pat2NameEnv, Name2PatEnv, NullEnv, TypeNameEnv, DisAmbEnv)
buildEnv tmpCAST =
  let cast@(CAST topt cdatatypes) = changeBiYaccTy $ tmpCAST
      pat2NameEnv = buildPat2NameEnv cast
      name2PatEnv = buildName2PatEnv cast
      tyNameEnv          = buildTyNameEnv cast
      nullenv            = buildNullEnv tmpCAST
      disAmbEnv          = let  (priEnv, assocEnv, prefEnv, brkMap) = foldr specUnions (Map.empty, Map.empty, Map.empty, Map.empty) $
                                                                             map buildDisAmbEnv cdatatypes
                                brkEnv = if Prelude.null (keys brkMap) then Nothing
                                            else do
                                              let consName = head (keys brkMap)
                                              (tdefs,ty) <- Map.lookup consName name2PatEnv
                                              return (consName, ty, tdefs)
                                -- (brkConsName,brkTypeDefs,brkConsType)
                           in   (priEnv, assocEnv, prefEnv, brkEnv)
  in  (pat2NameEnv, name2PatEnv, nullenv, tyNameEnv, disAmbEnv)


buildName2PatEnv :: CAST -> Name2PatEnv
buildName2PatEnv (CAST _ cdatatypes) = unions $ map go cdatatypes
  where
    go (CDataType ty ctypedefs) = unions (map (go2 ty) ctypedefs)
    go2 ty (CTypeDef key patterns _) = singleton key (patterns,ty)

buildPat2NameEnv :: CAST -> Pat2NameEnv
buildPat2NameEnv (CAST _ cdatatypes) = unions $ map go cdatatypes
  where go (CDataType ty ctypedefs) = unions (map (go2 ty) ctypedefs)
        go2 ty (CTypeDef key patterns _) = (singleton (patterns,ty) key)

buildTyNameEnv :: CAST -> TypeNameEnv
buildTyNameEnv (CAST _ cdatatypes) = unions $ map go cdatatypes
  where
    go (CDataType tyName defs) = builtIn `union` (singleton tyName $ map (\(CTypeDef n _ _) -> n ) defs)
    builtIn = fromList [("String", []), ("BiIdentifyTy", [])
                       , ("BiNumericTy", []), ("BiBoolTy", [])]

-- build the NullEnv. from datatype to its null constructor. eg: Expr ---> ExprNull; Term ----> TermNull
buildNullEnv :: CAST -> NullEnv
buildNullEnv (CAST _ cdatatypes) = unions $ (map addNull cdatatypes)
  where addNull :: CDataType -> NullEnv
        addNull (CDataType prefix ctypedefs) = singleton prefix (prefix ++ "Null")


-- type DisAmbEnv = (PriEnv, AssocEnv, PrefEnv, BracketAttrMap, FollowRestricEnv)
buildDisAmbEnv :: CDataType -> (PriEnv, AssocEnv, PrefEnv, BracketAttrMap)
buildDisAmbEnv (CDataType _ ctypedefs) = foldr specUnions (Map.empty, Map.empty, Map.empty, Map.empty) $ map build2 ctypedefs
  where build2 :: CTypeDef -> (PriEnv, AssocEnv, PrefEnv, BracketAttrMap)
        build2 (CTypeDef conName _ (Annot maybePriority maybeAssoc maybePref maybeBrackAttr)) =
          let a = maybe Map.empty (singleton conName) maybePriority
              b = maybe Map.empty (singleton conName) maybeAssoc
              c = maybe Map.empty (singleton conName) maybePref
              d = maybe Map.empty (singleton conName) maybeBrackAttr
          in  (a, b, c, d)

specUnions :: (PriEnv, AssocEnv, PrefEnv, BracketAttrMap) -> (PriEnv, AssocEnv, PrefEnv, BracketAttrMap)
           -> (PriEnv, AssocEnv, PrefEnv, BracketAttrMap)
specUnions (pri, assoc, pref, brkAttr) (pris, assocs, prefs, brkAttrs) =
  (union pri pris, union assoc assocs, union pref prefs, union brkAttr brkAttrs)

--------------------------------------

-- pNoWs :: Monad m => ParsecT String u m
-- pNoWs = do
--   byLexeme (string "{#")
--   byLexeme (string "NoWs")
--   byLexeme (string "#}")
--   return

----------------

