module BiYacc.Parser.Action where

import Prelude hiding (lookup)
import BiYacc.Language.Def
import BiYacc.Helper.Utils
import BiYacc.Translation.DataQuery

import Data.Generics
import Data.Map hiding (foldr, map, drop, filter, (\\))
import qualified Data.Map as Map

import Text.Parsec

import Text.PrettyPrint as TPP hiding (empty, char)


------- basic (primitive type) parser
-- string literal. will change char literal to string literal
strLit :: Monad m => ParsecT String u m LitPat
strLit = byLexeme $
  (byCharLit >>= \s -> return (LitStrPat s)) <|>
  (byStrLit  >>= \s -> return (LitStrPat s))

numericLit :: Monad m => ParsecT String u m LitPat
numericLit = byLexeme (do
  choice [ try byInteger >>= \i -> return (LitIntegerPat i)
         ,     byFloat   >>= \f -> return (LitDecimalPat f)
         ])

boolLit :: Monad m => ParsecT String u m LitPat
boolLit = byLexeme $
  (string "True"  >> return (LitBoolPat True)) <|>
  (string "False" >> return (LitBoolPat False))

tTerminal :: Monad m => ParsecT String u m String
tTerminal = byCharLit <|> byStrLit
------------

---------------actions parser ----------------
program :: Monad m => SourcePos -> ParsecT String u m Program
program srcPos = do
  setPosition srcPos
  byLexeme (string "#Actions" <?> "expecting keyword \"#Actions\"")
  grps <- many1 group
  eof
  let (Group entranceTydec _) = grps !! 0
  return $ Program entranceTydec grps

group :: Monad m => ParsecT String u m Group
group = do
  t@(TypeDecl _ st) <- typeDecl
  rules_ <- many1 (try (rule st))
  return $ Group t rules_

typeDecl :: Monad m => ParsecT String u m TypeDecl
typeDecl = do
  vt <- viewType <?> "constructor"
  eatEmbed <?> "expecting the \"+>\" symbol"
  st <-tConstructor
  return $ TypeDecl vt (mkSimpleTyRep st)
  <?> "a correct type declaration before actions"


-- parse a single type (type field, type constructor ...)
viewType :: Monad m => ParsecT String u m DataTypeRep
viewType =
  (simpleType <?> "expecting a constructor") <|>
  (maybeType viewType <?> "expecting Maybe type") <|>
  (listType viewType <?> "expecting List type") <|>
  try (tupleType viewType <?> "expecting tuple syntax") <|>
  try (withParen viewType <?> "expecting tuple syntax") <|>
  try (generalType viewType <?> "expecting constructor syntax")

rule :: Monad m => SourceType -> ParsecT String u m Rule
rule st =
  (do
    byLexeme (try (string "Adaptive")) <?> "keyword \"Adaptive\""
    eatColon
    parseAdaptiveP <|> parseAdaptiveG) <|>
  (do
    vside <- pViewSide
    eatEmbed <?> "want a \"+>\" symbol between abstract-side and concrete-side." +^+
                 "It usually happens when abstract-side pattern has a syntactic error."
    sside <- pSrcSide st
    eatLineEnd
    return (NormalRule vside sside))

----adaptive rule------------
parseAdaptiveP :: Monad m => ParsecT String u m Rule
parseAdaptiveP = do
  sp <- try getPattern
  vp <- getPattern
  fn <- getFunction
  eatLineEnd
  return (AdaptRuleP sp vp fn)

parseAdaptiveG :: Monad m => ParsecT String u m Rule
parseAdaptiveG = do
  pred <- getFunction
  fn <- getFunction
  eatLineEnd
  return (AdaptRuleG pred fn)

getPattern :: Monad m => ParsecT String u m String
getPattern = do
  byLexeme (string "[p|")
  p <- manyTill anyChar (try (string "|]") <?> "expecting ending bracket (\"|]\") for a pattern")
  byWhiteSpace
  return p

getFunction :: Monad m => ParsecT String u m String
getFunction = do
  byLexeme (string "[f|")
  f <- manyTill anyChar (try (string "|]") <?> "expecting ending bracket (\"|]\") for a function")
  byWhiteSpace
  return f


-----lhs------view------
pViewSide :: Monad m => ParsecT String u m ViewSide
pViewSide = do
  vPat <- viewPattern
  maybeVConstraints <- try (viewConstraint >>= return . Just) <|> return Nothing
  case maybeVConstraints of
    Just vConstraints -> return $ ViewSide vConstraints vPat
    Nothing -> return $ ViewSide [] vPat

-- overlapped pattern: [var@(...)] and [var]
-- listPat can overlap any other patterns... shall first try it
viewPattern :: Monad m => ParsecT String u m ViewSidePattern
viewPattern = try listPat <|> try primitiveTypes <|> constructorPat <|>
             varOrAsPat <|> try tupleSyntax <|> lhsWithParen <|> wildPat


-- if a pattern is ListCons, its left operant can be any patter EXCLUDING ListCons which is RIGHT associative.
viewPatternWithoutListCons :: Monad m => ParsecT String u m ViewSidePattern
viewPatternWithoutListCons = try listPatWihoutCons <|> try primitiveTypes <|> constructorPat <|>
   varOrAsPat <|> try tupleSyntax <|> lhsWithParen <|> wildPat

varOrAsPat :: Monad m => ParsecT String u m ViewSidePattern
varOrAsPat = do
  v <- tVariable
  c <- try ((eatAs <?> "@ (as-pattern)")>>= return . Just) <|> return Nothing
  case c of -- as-pattern
    Just '@' -> do
      eatLParen
      pattern <- viewPattern
      eatRParen
      -- ad hoc. insert ASPattern into a parentheses to easily distinguish from other patterns
      return (ASPattern v (mkSimpleTyRep "UNDEFINED") pattern)
    -- just a variable, match anything
    Nothing -> return (UpdVar v (mkSimpleTyRep "UNDEFINED"))

-- Constructor var1 (Just var2) ...
constructorPat :: Monad m => ParsecT String u m ViewSidePattern
constructorPat = do
  a <- tConstructor
  args <- many (constructorArgs <?> "want any proper fields of a constructor")
  return (ConsPat a (mkSimpleTyRep "UNDEFINED") args)


wildPat :: Monad m => ParsecT String u m ViewSidePattern
wildPat = eatWildCard >> return WildcardP

lhsWithParen :: Monad m => ParsecT String u m ViewSidePattern
lhsWithParen = do
  eatLParen
  innerpatterns <- viewPattern
  eatRParen
  return innerpatterns


constructorArgs :: Monad m => ParsecT String u m ViewSidePattern
constructorArgs = try listPat <|> try primitiveTypes <|> varOrAsPat <|>
  (tConstructor >>= \con -> return (ConsPat con (mkSimpleTyRep "UNDEFINED") []) <?> "expecting a constructor") <|>
  try tupleSyntax <|> lhsWithParen <|> wildPat
  <?> "error in parsing constructor arguments"

primitiveTypes :: Monad m => ParsecT String u m ViewSidePattern
primitiveTypes = liftM LitPat strLit <|> liftM LitPat numericLit <|> liftM LitPat boolLit

--------
listPat :: Monad m => ParsecT String u m ViewSidePattern
listPat = try singletonOrEmptyList <|> lhsConsList

listPatWihoutCons :: Monad m => ParsecT String u m ViewSidePattern
listPatWihoutCons = try singletonOrEmptyList


singletonOrEmptyList :: Monad m => ParsecT String u m ViewSidePattern
singletonOrEmptyList = do
  eatLBrack
  n <- (try eatRBrack >>= return . Just) <|> return Nothing
  case n of
    Nothing -> do
      inner <- viewPattern
      eatRBrack
      return $ ConsPat "Singleton" (mkSimpleTyRep "UNDEFINED") [inner]
    Just _ -> return (ConsPat "EmptyList" (mkSimpleTyRep "UNDEFINED") [])

lhsConsList :: Monad m => ParsecT String u m ViewSidePattern
lhsConsList = do
  e <- viewPatternWithoutListCons
  eatListCons    -- :
  es <- viewPattern
  return $ ConsPat "ConsList" (mkSimpleTyRep "UNDEFINED") [e, es]


tupleSyntax :: Monad m => ParsecT String u m ViewSidePattern
tupleSyntax = do
  eatLParen
  p1 <- viewPattern
  ps <- many1 (eatComma >> viewPattern)
  eatRParen
  return $ ConsPat "TupleC" (mkSimpleTyRep "UNDEFINED") (p1:ps)
----------------------------------

----------------------------------
-- Mul2 x y a b   |   id x == y, id a == b
--   +> '((' (x +> Expon) '^2' ';'  (y +> Expon) '^2' '))' ;

viewConstraint :: Monad m => ParsecT String u m ViewConstraints
viewConstraint = do
  byLexeme (char '|') <?> "\"| ... \" ( specifying additional view-side constraints."
  fstConstraint <- pureViewConstraint <|> try vVarElimination
  constraints <- many (do
                  byLexeme (char ',')
                  conts <- pureViewConstraint <|> try vVarElimination
                  return conts)
  return (fstConstraint:constraints)



vVarElimination :: Monad m => ParsecT String u m ViewConstraint
vVarElimination = do
  funName <- tVariable
  vvar1   <- tVariable
  byLexeme (string "==")
  vvar2 <- tVariable
  return $ VVarElimination funName vvar1 vvar2

pureViewConstraint :: Monad m => ParsecT String u m ViewConstraint
pureViewConstraint = do
  byLexeme (string "[f|")
  constraint <- manyTill anyChar (try (string "|]") <?> "expecting ending bracket (\"|]\") for a function")
  byWhiteSpace
  return $ PureViewConstraint constraint


------pSrcSide------source---------------------
pSrcSide :: Monad m => SourceType -> ParsecT String u m SrcSide
pSrcSide st = liftM (SrcSide st "EMPTY") (many1 updateUnit)

updateUnit :: Monad m => ParsecT String u m UpdateUnit
updateUnit = updateBundle <|> updateSingle

updateBundle :: Monad m => ParsecT String u m UpdateUnit
updateBundle = try uZeroOrOne <|> try uZeroOrMore <|> uOneOrMore


uZeroOrMore :: Monad m => ParsecT String u m UpdateUnit
uZeroOrMore = do
  byLexeme (char '{')
  us <- many1 updateUnit
  byLexeme (string "}*")
  return $ UpdateUnitBundle ZeroOrMore us

uOneOrMore :: Monad m => ParsecT String u m UpdateUnit
uOneOrMore = do
  byLexeme (char '{')
  us <- many1 updateUnit
  byLexeme (string "}+")
  return $ UpdateUnitBundle OneOrMore us

uZeroOrOne :: Monad m => ParsecT String u m UpdateUnit
uZeroOrOne = do
  byLexeme (char '{')
  us <- many1 updateUnit
  byLexeme (string "}?")
  error "zero-or–one syntax is not supported yet because it seems useless."
  return $ UpdateUnitBundle ZeroOrOne us

updateSingle :: Monad m => ParsecT String u m UpdateUnit
updateSingle = try (do
  -- normal update 1
  eatLParen
  var <- tVariable
  eatEmbed <|> byLexeme (string "~*>")
  sub <- tConstructor
  eatRParen
  -- here the primitive type is changed, to hold the layouts/comments fields
  -- eg. Int is changed to (Int, String) to contain layout. it is somehow not good...
  return . UpdateUnitSingle . Right $ NUpdate var (mkSimpleTyRep sub)) <|>

  -- terminal
  try (liftM (UpdateUnitSingle . Left . Terminal) tTerminal) <|>

  -- deep pattern
  (try (update_deepPat) >>= return . UpdateUnitSingle) <|>

  -- normal update 2: the updated part is expanded to a deep pattern
  -- but since you cannot update both the whole deep pattern part and also some of its inner parts
  -- so here we skip the whole deep pattern part and treat it as a normal update.
  -- THE ABOVE OPERATION IS INCORRECT, SINCE IT LOSES THE PATTERN INFORMATION
  try (do
  eatLParen
  var <- tVariable
  eatEmbed <|> byLexeme (string "~*>")
  Right (DUpdate deep) <- update_deepPat
  eatRParen
  let SrcSide con _ _ = deep
  -- here the primitive type is changed. eg Int is changed to (Int, String) to contain layout. it is somehow not good...
  return . UpdateUnitSingle . Right $ NUpdateWithDeepPat var con deep) <|>

  -- non update
  (liftM (UpdateUnitSingle . Left . Nonterminal . mkSimpleTyRep) tConstructor)

-- deep pattern
update_deepPat :: Monad m => ParsecT String u m (Either Unchanged Update)
update_deepPat = do
  eatLParen
  con <- tConstructor
  let st = mkSimpleTyRep con
  eatTo
  deep <- pSrcSide st -- if we go deep, the type of the deep expressions is the name (aka nonterminal) of their parent
  eatRParen
  return $ Right (DUpdate deep)
  <?> "error in SrcSide, deep pattern. possibly missing ';' in previous right hand side"

-- change Integer, Double to String. change Name to BiYaccNameTy
progToBiYaccType :: Program -> Program
progToBiYaccType prog = everywhere (mkT go) prog
  where
    go :: Either Unchanged Update -> Either Unchanged Update
    go (Left (Nonterminal st)) = Left (Nonterminal (mkSimpleTyRep . toBiYaccTy . typeRep2Str $ st))
    go (Right (NUpdate uv st)) = Right (NUpdate uv (mkSimpleTyRep . toBiYaccTy . typeRep2Str $ st))
    go a = a


---------------------------------------------------
-- Add the production rule name to the SrcSide of an action.
addProdRuleName :: Pat2NameEnv -> Program -> Program
addProdRuleName env prog = everywhere (mkT go) prog
  where
    go :: Rule -> Rule
    go (NormalRule vside (SrcSide st _ units)) = NormalRule vside (add2 st env units)
    go a = a

    add2 :: SourceType -> Pat2NameEnv -> [UpdateUnit] -> SrcSide
    add2 st env units =
      let pat = getProdrulePat units
          maybeProdName = lookup (pat, (typeRep2Str st)) env
      in  case maybeProdName of
            Nothing -> error $ "(impossible) cannot find pattern in concrete data type (no such production rule):\n"
                                ++ "(" ++ ppShow pat ++ ", " ++ ppShow st ++ ")"
            Just prodName -> SrcSide st prodName (map mkDeepPat units)
      where
        mkDeepPat :: UpdateUnit -> UpdateUnit
        mkDeepPat (UpdateUnitSingle u) = UpdateUnitSingle (mkDeepPat2 u)
        mkDeepPat (UpdateUnitBundle occur us) = UpdateUnitBundle occur (map mkDeepPat us)

        mkDeepPat2 :: Either Unchanged Update -> Either Unchanged Update
        mkDeepPat2 (Right (DUpdate (SrcSide ty _ tnts))) = Right (DUpdate (add2 ty env tnts))
        mkDeepPat2 (Right (NUpdateWithDeepPat uv st (SrcSide _ _ tnts))) =
          Right (NUpdateWithDeepPat uv st (add2 st env tnts))
        mkDeepPat2 other                       = other
---------------------------------------------------------------




---------- automatically extract production rules from actions --------
genProdRulesFromActions :: Program -> CAST
genProdRulesFromActions (Program entTy grps) =
  let theMap = unionsWith (++) $ map collectTypeDefs grps
      dataTypes = elems (mapWithKey (\k v -> CDataType (typeRep2Str k) v ) theMap)
  in CAST (mkTopTy entTy) dataTypes

mkTopTy :: TypeDecl -> String
mkTopTy (TypeDecl _ st) = typeRep2Str st

-- collect maps from data types to their definitons
collectTypeDefs :: Group -> Map DataTypeRep [CTypeDef]
collectTypeDefs (Group (TypeDecl vt st) rules) = unionsWith (++) $ map (collectTypeDefs2 st) rules
-- map1 may contain Expr --> [Add .. ..,  ..]
-- map2 may contain Expr --> [Sub]
-- merge the two maps will give Expr --> [Add .. .., Sub .. .., .. ..]


collectTypeDefs2 :: SourceType -> Rule -> Map SourceType [CTypeDef]
collectTypeDefs2 st (NormalRule _ rhs) =
  let (SrcSide _ _ units) = rhs
      map1 = unions $ map handleDeepUpdate units
      map2 = singleton st [(CTypeDef "NONAMEYET" (map toCTypeField units) noFilterAnnotation)]
  in  merge preserveMissing preserveMissing (zipWithMatched (\_ x y -> x ++ y)) map1 map2
collectTypeDefs2 _ _ = Map.empty
-- map1 may contain Expr --> [Add .. ..,  ..] (because deep update strategy may contain new productions)
-- map2 may contain Expr --> [Sub]
-- merge the two maps will give Expr --> [Add .. .., Sub .. .., .. ..]


toCTypeField :: UpdateUnit -> CTypeField
toCTypeField (UpdateUnitSingle (Left (Nonterminal nont)))  = CTypeFieldSingle (Right (typeRep2Str nont))
toCTypeField (UpdateUnitSingle (Left (Terminal terminal))) = CTypeFieldSingle (Left terminal)
toCTypeField (UpdateUnitSingle (Right (NUpdate _ nont)))   = CTypeFieldSingle (Right (typeRep2Str nont))
toCTypeField (UpdateUnitSingle (Right (DUpdate (SrcSide ty _ _))))   = CTypeFieldSingle (Right (typeRep2Str ty))
toCTypeField (UpdateUnitBundle occur units) = CTypeFieldBundle occur (map toCTypeField units)


handleDeepUpdate :: UpdateUnit -> Map SourceType [CTypeDef]
handleDeepUpdate (UpdateUnitSingle (Right (DUpdate rhs@(SrcSide ty _ _)))) =
  -- let SrcSide _ units = rhs
  -- in  collectTypeDefs2 ty (NormalRule undefined (SrcSide rhs))
  collectTypeDefs2 ty (NormalRule undefined rhs)
handleDeepUpdate (UpdateUnitBundle occur units) = unions $ map handleDeepUpdate units
handleDeepUpdate _ = Map.empty

---------------------------------------------------------

{-
The file provide functions for generating AST of "Actions" part in a BiYacc file.
We first generate a temporary AST with holes,
like what we do when dealing with the production rules in "Concrete" part.
The holes are then filled up with the help of environment.
-}
