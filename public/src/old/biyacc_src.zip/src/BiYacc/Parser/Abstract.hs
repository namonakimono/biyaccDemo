{-# LANGUAGE  FlexibleContexts #-}

module BiYacc.Parser.Abstract (pAbstract, buildCon2FieldsEnv) where

import BiYacc.Language.Def
import BiYacc.Helper.Utils
import Text.Parsec.Token (whiteSpace, identifier)

import Text.Parsec
import Data.Map (singleton, unions, Map)
import Control.Monad.State

typeVar :: Monad m => ParsecT String u m String
typeVar = tVariable

-- the next part is "Concrete" syntax
pAbstract :: Monad m => ParsecT String u m ASTDataTypeDecs
pAbstract = byLexeme (do
  byLexeme (string "#Abstract" <?> "need the keyword \"#Abstract\"")
  (decls, j) <- try (manyTill anyChar wConcrete >>= \cs -> return (cs , Just "Concrete")) <|>
                try (manyTill anyChar wDirectives >>= \cs -> return (cs , Just "Directives")) <|>
                try (manyTill anyChar wActions >>= \cs -> return (cs , Just "Actions"))
  inp <- getInput               -- ad hoc part. removed if implemented using template haskell
  case j of
    -- just now we consume an additional "Concrete" string. Set it back.
    Just "Concrete" -> setInput ("#Concrete" ++ inp)
    Just "Directives" -> setInput ("#Directives" ++ inp)
    Just "Actions" -> setInput ("#Actions" ++ inp)
  return $ pAbstract2 decls)

  where wConcrete = try (string "#Concrete" <?> "expecting keyword #Concrete")
        wDirectives = try (string "#Directives" <?> "expecting keyword #Directives")
        wActions = try (string "#Actions" <?> "expecting keyword #Actions")

pAbstract2 :: String -> ASTDataTypeDecs
pAbstract2 decls =
  let typeSynPairs  = map p1 (findTypeSynonyms decls)
      astDataTypeDecs' = p2 (decls ++ " data")
  in  replaceTypeSynonyms typeSynPairs astDataTypeDecs'
  where p1 str = case parse pTypeSyno "abstrac syntax part 1" str of
               Left err -> error $ show err
               Right  a -> a
        p2 str = case parse pDatatypes "abstrac syntax part 2" str of
               Left err -> error $ show err
               Right  a -> a

--   "data X=Y ... data A=B... type Y = Z ... data ... type B = C ..."
-- lines it! ==> [[String]] by lines! something like type Y = Z should appear at the front of a line.
-- filter (\s "type " == take 5 s) can extract the lines starting with "type Y = Z" only
-- then we have the type synonyms. we can use global substitution to replace the type synonyms with the original type...
findTypeSynonyms :: String -> [String]
findTypeSynonyms = map (\s -> s ++ "\0") . filter (\s -> "type " == take 5 s) . lines
-- add a borderline ("\0") for type declaration for simplicity.

--               [(old, new)]         acc
replaceIter :: [(String, String)] -> String -> ASTDataTypeDecs
replaceIter []             acc = read acc
replaceIter ((old,new):xs) acc = replaceIter xs (replace old new acc)

-- very ad-hoc. may cause problems.
replaceTypeSynonyms :: [(String, String)] -> ASTDataTypeDecs -> ASTDataTypeDecs
replaceTypeSynonyms synPairs = replaceIter synPairs . show


----  parse type synonyms definitions,eg: type NewEither a b = Either Int Char
--                              [(old, new)]
pTypeSyno :: Monad m => ParsecT String u m (String, String)
pTypeSyno = do
  byLexeme $ string "type"
  tname <- byLexeme (identifier lexer)
  tVar <- many typeVar
  byLexeme $ char '='
  oldType <- manyTill anyChar (try (string "--") <|> string "\0" )
  return $ if length tVar == 0
             then (tname, oldType)
             else (tname ++ " " ++ (foldr1 (\x xs -> x ++ " " ++ xs) tVar) , oldType)


pDatatypes :: Monad m => ParsecT String u m ASTDataTypeDecs
pDatatypes = many1 $ try pEachDataType

pEachDataType :: Monad m => ParsecT String u m ASTDataTypeDec
pEachDataType = do
  byWhiteSpace
  byLexeme (string "data")
  tyName <- byLexeme (identifier lexer) -- SHOULD SUPPORT PARAMETERISED TYPE IN THE FUTURE
  linedata <- many1 pLines
  ignoreDerivingPart
  return $ ASTDataTypeDec (DataTypeRep tyName []) linedata

pLines :: Monad m => ParsecT String u m ASTDataTypeDef
pLines = do
  byLexeme ((string "=") <|> (string "|"))
  (DataTypeRep con _) <- simpleType
  datatypes <- many singleType
  byWhiteSpace
  return $ ASTDataTypeDef con datatypes

-- parse a single type (type field, type constructor ...)
singleType :: Monad m => ParsecT String u m DataTypeRep
singleType = simpleType <|> try (tupleType singleType) <|> maybeType singleType <|> listType singleType <|>
             eitherType singleType <|> try (withParen singleType) <|> try generalTypeInParen

generalTypeInParen :: Monad m => ParsecT String u m DataTypeRep
generalTypeInParen = byLexeme $ char '(' >> (generalType singleType) >>= \res -> byLexeme $ char ')' >> return res


ignoreDerivingPart :: Monad m => ParsecT String u m ()
ignoreDerivingPart = do
  byWhiteSpace
  string "deriving"
  manyTill anyChar (try (string "data"))
  inp <- getInput
  setInput ("data" ++ inp)


-- build env from constructors to their type fields.    Add ---> ([Arith, Arith], Arith)
buildCon2FieldsEnv :: ASTDataTypeDecs -> Cons2FieldsEnv
buildCon2FieldsEnv datatypes = unions $ map refine1 datatypes
  where
    refine1 :: ASTDataTypeDec -> Cons2FieldsEnv
    refine1 (ASTDataTypeDec ty typedefs) = unions $ map (refine2 ty) typedefs
    refine2 :: DataTypeRep -> ASTDataTypeDef -> Cons2FieldsEnv
    refine2 ty (ASTDataTypeDef cons tyDefs) = singleton cons (tyDefs,ty)


-- replace all occurrence of old with new.
replace :: Eq a => [a] -> [a] -> [a] -> [a]
replace old new l
  = case match l old of
      Just remains -> new ++ replace old new remains
      Nothing      -> case l of
                        []     -> []
                        x : xs -> x : replace old new xs
  where
    match :: Eq a => [a] -> [a] -> Maybe [a]
    match l []                = Just l
    match (x : xs) (y : ys) | x == y = match xs ys
    match _        _                 = Nothing

