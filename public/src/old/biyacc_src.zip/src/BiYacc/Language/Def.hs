{-# Language DeriveDataTypeable #-}

module BiYacc.Language.Def where

import Text.Parsec
import Text.Parsec.Token

import Data.Map as Map
import Data.Generics

import Debug.Trace
import Control.Monad.State (MonadState)

import qualified Text.PrettyPrint as TPP

langDef :: Monad m => GenLanguageDef String u m
langDef = LanguageDef
  {
    commentStart = "{-"
   ,commentEnd = "-}"
   ,commentLine ="--"
   ,nestedComments = True
   ,identStart = upper
   ,identLetter = alphaNum <|> char '_'
   ,opStart = oneOf ":!#$%&*+./<=>?@\\^|-~"
   ,opLetter = oneOf ":!#$%&*+./<=>?@\\^|-~"
   ,reservedNames = ["#Abstract", "#Concrete", "#Directives","#Actions", "data", "Adaptive" ]
   ,reservedOpNames = [""]
   ,caseSensitive = True
  }

lexer :: Monad m => GenTokenParser String u m
lexer = makeTokenParser langDef


-- apply lexeme to a parser to make the parser skip all the following white spaces
byLexeme :: Monad m => ParsecT String u m a -> ParsecT String u m a
byLexeme = lexeme lexer

byWhiteSpace :: Monad m => ParsecT String u m ()
byWhiteSpace = whiteSpace lexer

byStrLit :: Monad m => ParsecT String u m String
byStrLit  = stringLiteral lexer

byCharLit :: Monad m => ParsecT String u m String
byCharLit  = charLiteral lexer >>= \c -> return [c]

byInteger :: Monad m => ParsecT String u m Integer
byInteger = integer lexer

byInt :: Monad m => ParsecT String u m Integer
byInt = integer lexer

byFloat :: Monad m => ParsecT String u m Double
byFloat   = float lexer

lexemeString :: Monad m => String -> ParsecT String u m String
lexemeString = byLexeme . string

---------- data types for abstrac syntax
type ASTDataTypeDecs   = [ASTDataTypeDec]

-- DataType type definitions.  DataType "Arith" [...]
data ASTDataTypeDec    = ASTDataTypeDec  DataTypeRep [ASTDataTypeDef] deriving (Typeable, Data, Show, Eq, Read)

-- TypeDef constructor [types]
data ASTDataTypeDef = ASTDataTypeDef String [DataTypeRep] deriving (Typeable, Data, Show, Eq, Read)

data DataTypeRep = DataTypeRep String [DataTypeRep] deriving (Typeable, Data, Show, Eq, Read, Ord)

--  Add ---> ([Arith, Arith], Arith)
-- constructor ([subsequent fields' types], constructor's type)
type Cons2FieldsEnv = Map String ([DataTypeRep], DataTypeRep)


----------- data types for concrete syntax

-- disambiguation annotations. %left, %right, %nonassoc ...
data Cmd =
    CmdLeftAssoc  [Either String String]
  | CmdRightAssoc [Either String String]
  | CmdNonAssoc   [Either String String]
  | CmdCommLine  String
  | CmdCommBlock String String
  deriving (Typeable, Data, Show, Eq)


-- CAST (top level datatype) [datatypes]
data CAST = CAST String [CDataType] deriving (Typeable, Data, Show, Eq, Ord)

-- CDataType type definitions. CDataType "Expr" [...]
data CDataType = CDataType String [CTypeDef] deriving (Typeable, Data, Show, Eq, Ord)

-- CTypeDef constructor [types]
data CTypeDef = CTypeDef String [CTypeField] FilterAnnotation deriving (Typeable, Data, Show, Eq, Ord)

-- either it is a string terminal or datatypes.
-- Nonterminal is reserved when finishing parsing and used when building the env. It is deleted later.
-- Left: string Terminal. Right: others
type ETNT = Either String String

data CTypeField =
    CTypeFieldSingle ETNT -- the most often case
  | CTypeFieldBundle Occurence [CTypeField] -- e.g.  {"," Expr}
  deriving (Typeable, Data, Show, Eq, Ord)

data Occurence = Once | ZeroOrMore | OneOrMore | ZeroOrOne deriving (Typeable, Data, Show, Eq, Ord)

data FilterAnnotation = Annot (Maybe Priority) (Maybe Assoc) (Maybe Preference) (Maybe BracketAttr)
  deriving (Typeable, Data, Show, Eq, Ord)

noFilterAnnotation :: FilterAnnotation
noFilterAnnotation = Annot Nothing Nothing Nothing Nothing


-- (["Expr", "+", "Term"],"Expr") ---> "A0"
type Pat2NameEnv   = Map ([CTypeField], ProdRuleType) ProdRuleCons

-- ["Expr", "+", "Term"] ---> "A0" ? return the answer for production rules with unique RHS
type PartialPat2NameEnv  = Map [CTypeField] ProdRuleCons

-- "A0"    ---> (["Expr", "+", "Term"],"Expr")
type Name2PatEnv   = Map ProdRuleCons ([CTypeField],ProdRuleType)

-- "Expr"  ---> ["A0","A1","A2"]     (i.e. [Constructor Names])
type TypeNameEnv   = Map ProdRuleType [ProdRuleCons]

-- "Expr"  ---> "ExprNull0"
type NullEnv       = Map ProdRuleType String

-- "Add" ---> ([["Sub","subExpr0","layouts1","subTerm2"],...]
-- we want to keep layouts/comments in when performing adaptation if the source and source' have similar production rules.
-- eg Add Expr Term   is similar to   Sub Expr Term (the type of corresponding sub trees matches)
type SimilarProdruleEnv = Map String [CTypeDef]

type Paths = [ProdRuleCons]

-- preference contains prefer/avoid/reject. the classification is not exactly the same as the ones in ASF + SDF
type DisAmbEnv = (PriEnv, AssocEnv, PrefEnv, BracketAttrEnv)

type ExampleDisAmbEnv = Map String (Maybe Priority, Maybe Assoc) -- for testing

type PathsViaBracket = Map ProdRuleCons Paths

data RawPriority = GreatThan | LessThan | Equal deriving (Typeable, Data, Show, Eq)
type Priority = Int
type PriEnv = Map String Priority -- terminal --> its priority


data Assoc = LeftAssoc | RightAssoc | NonAssoc deriving (Typeable, Data, Show, Eq, Ord)
type AssocEnv = Map String Assoc  -- terminal --> its associativity

data Preference = Prefer | Avoid | Reject deriving (Typeable, Data, Show, Eq, Ord)
type PrefEnv = Map ProdRuleCons Preference

-- in a grammar, only one production rule can be the “bracket attribute”.
data BracketAttr = BracketAttr deriving (Typeable, Data, Show, Eq, Ord)

type BracketAttrMap = Map ProdRuleCons BracketAttr
type BracketAttrEnv = Maybe (ProdRuleCons, ProdRuleType, [CTypeField])

type FollowRestricEnv = Map ProdRuleCons FollowRestrict
data FollowRestrict = UNDEFINED deriving (Typeable, Data, Show, Eq) -- todo : define it later


--------datatype defs for Actions part---------------
-- here the TypeDecl stores the source type and view type to be used for entrance of the program
-- (the types of the first action group)
data Program  = Program TypeDecl [Group]       deriving (Typeable, Data, Show, Eq)
data Group    = Group TypeDecl [Rule]          deriving (Typeable, Data, Show, Eq)
data TypeDecl = TypeDecl ViewType SourceType deriving (Typeable, Data, Show, Eq)

type SourceTypeStr = String
type SourceType    = DataTypeRep
type ViewTypeStr   = String
type VarType       = String
type ViewType      = DataTypeRep
type ViewCon       = String

data Rule =  NormalRule ViewSide SrcSide
  -- the adaptive rule specified by the user with pattern syntax: [p| sp ] [p| vp ] [f| func |]
          |  AdaptRuleP String String String
  -- the adaptive rule specified by the user with a general syntax: [f| lambda-func-predicate :: s->v->Bool |] [f| func |]
          |  AdaptRuleG String String
  deriving (Typeable, Data, Show, Eq)

-- the left hand side of a rule is just represented by a pattern (matching by patterns)
-- ViewSide (type of the pattern) pattern
data ViewSide = ViewSide ViewConstraints ViewSidePattern
  deriving (Typeable, Data, Show, Eq)

data ViewSidePattern
  = ConsPat String DataTypeRep [ViewSidePattern]
    -- constructor pattern: constructor name, type, sub patterns
  | ASPattern String DataTypeRep ViewSidePattern
  -- ASPattern: @. as-what-name; type
  | UpdVar String DataTypeRep  -- variable name; variable type
  | LitPat LitPat    -- literal; type
  | WildcardP
  | DeletedVSP       -- internal usage. the third component of ASPattern can be safely deleted after generating Case-Condition
  deriving (Typeable, Data, Show, Eq)
-- As for NormalP "ConsList" [p,ps], for simplicity, the pattern is limited to
-- Cons [Some (Complex1 pat) (var pat)] (simpleVar) . (the second lhsPattern must be a variable)

data LitPat = LitStrPat String
            | LitIntegerPat Integer
            | LitDecimalPat Double
            | LitBoolPat Bool
  deriving (Typeable, Data, Show, Eq)


-- 1 just for some more constraints other than pattern matching on view.
-- can be any function with arguments producing Boolean results.
-- 2 for view variable elimination. must be of pattern "f var1 == var2"
-- a can be String, Doc, etc...
data ViewConstraint = PureViewConstraint String
                    | VVarElimination String String String -- FunName, VarName, VarName
  deriving (Typeable, Data, Show, Eq)

-- seprerated by comma
type ViewConstraints = [ViewConstraint]

-- the right hand side of a rule is merely a production rule plus some updates somewhere.
data SrcSide = SrcSide SourceType ProdRuleCons [UpdateUnit]
             | DeletedSrc
  deriving (Typeable, Data, Show, Eq)


data UpdateUnit =
    UpdateUnitSingle (Either Unchanged Update) -- the most often case
  | UpdateUnitBundle Occurence [UpdateUnit]    -- e.g.  {"," Expr}
  | UpdateUnitFromBundle UVar SourceType Int SrcSide      -- internal use for the library SYB,
                                               -- bottom-up synthesis of UpdateUnitBundle.
  | Projected
  | ProtectBundle UVar SourceType Occurence [UpdateUnit]
  deriving (Typeable, Data, Show, Eq)

data Unchanged = Nonterminal  SourceType | Terminal String           deriving (Typeable, Data, Show, Eq)
-- "SourceType" is not always a "SourceType". (in Unchanged "SourceType". )

data Update = NUpdate  UVar SourceType
            | DUpdate  SrcSide  -- deep update. deep pattern match
            | NUpdateWithDeepPat UVar SourceType SrcSide
  deriving (Typeable, Data, Show, Eq)

-- type ProdRuleEigen = [Either String String] -- Left: a terminal symbol. Right : datatypes
type ProdRuleEigen = [CTypeField]

type ProdRuleType = String
type ProdRuleCons = String
type UVar         = String

type GenBiGULEnv = (Name2PatEnv, NullEnv, Cons2FieldsEnv
                   , (Map String (Maybe Priority, Maybe Assoc), PathsViaBracket, ProdRuleCons))



-----------------------

type ParsecU = Parsec String ()

eatLParen :: Monad m => ParsecT String u m Char
eatLParen = byLexeme (char '(' )

eatRParen :: Monad m => ParsecT String u m Char
eatRParen = byLexeme (char ')' )

eatLBrack :: Monad m => ParsecT String u m Char
eatLBrack = byLexeme (char '[' )

eatRBrack :: Monad m => ParsecT String u m Char
eatRBrack = byLexeme (char ']' )

eatLBrace :: Monad m => ParsecT String u m Char
eatLBrace = byLexeme (char '{')

eatRBrace :: Monad m => ParsecT String u m Char
eatRBrace = byLexeme (char '}')

eatWildCard :: Monad m => ParsecT String u m Char
eatWildCard = byLexeme (char '_')

eatListCons :: Monad m => ParsecT String u m Char
eatListCons = byLexeme (char ':')

eatEmbed    :: Monad m => ParsecT String u m String
eatEmbed    = byLexeme (string "+>")

eatLineEnd  :: Monad m => ParsecT String u m Char
eatLineEnd  = byLexeme (char ';')

eatAs       :: Monad m => ParsecT String u m Char
eatAs       = byLexeme (char '@')

eatTo :: Monad m => ParsecT String u m String
eatTo = byLexeme (string "->")

eatComma :: Monad m => ParsecT String u m Char
eatComma = byLexeme (char ',')

eatOr :: Monad m => ParsecT String u m Char
eatOr = byLexeme (char '|')

eatSemi :: Monad m => ParsecT String u m Char
eatSemi = eatLineEnd

eatColon :: Monad m => ParsecT String u m Char
eatColon = eatListCons <?> "want a colon (\":\")"



-- variable. starting with lower character
tVariable :: Monad m => ParsecT String u m String
tVariable = byLexeme (do
  fst <- lower
  s   <- many (alphaNum <|> char '_' )
  return $ (fst:s))

-- type constructor. starting with capital character
tConstructor :: Monad m => ParsecT String u m String
tConstructor = byLexeme (identifier lexer)


-- basic combinators for parsing type definitions. a parser for parsing a single type field is parameterised.
-- because, in Abstract part, the AST data type definition. a type with type
-- variables is always in a paren, eg: C (Maybe Int) (Either .. ..) However, in Actions part,
-- the type definition for a group do not need this parenthesis,
-- eg: Maybe TExp +> Exp ( not (Maybe TExp) )
-- we just want to reuse these basic combinators...
tupleType :: Monad m => ParsecT String u m DataTypeRep -> ParsecT String u m DataTypeRep
-- tupleType singleType = try (tuple singleType) <|> triple singleType
tupleType singleType = try (tuple singleType)

generalType :: Monad m => ParsecT String u m DataTypeRep -> ParsecT String u m DataTypeRep
generalType singleType = do
  (DataTypeRep tcon _) <- simpleType
  ts <- many1 singleType
  if length ts == 0
   then error "should not be here. should be handled by other cases"
   else return $ DataTypeRep tcon ts

simpleType :: Monad m => ParsecT String u m DataTypeRep
simpleType = byLexeme (do
  t <- tConstructor
  return $ DataTypeRep t [])

tuple :: Monad m => ParsecT String u m DataTypeRep -> ParsecT String u m DataTypeRep
tuple singleType = do
  eatLParen
  t1 <- singleType
  ts <- many1 (eatComma >> singleType)
  eatRParen
  return $ DataTypeRep "TupleT" (t1:ts)

maybeType :: Monad m => ParsecT String u m DataTypeRep -> ParsecT String u m DataTypeRep
maybeType singleType = do
  byLexeme $ string "Maybe"
  t <- singleType
  return $ DataTypeRep "Maybe" [t]

listType :: Monad m => ParsecT String u m DataTypeRep -> ParsecT String u m DataTypeRep
listType singleType = do
  eatLBrack
  t <- singleType
  eatRBrack
  return $ DataTypeRep "List" [t]

eitherType :: Monad m => ParsecT String u m DataTypeRep -> ParsecT String u m DataTypeRep
eitherType singleType = do
  byLexeme $ string "Either"
  l <- singleType
  r <- singleType
  return $ DataTypeRep "Either" [l,r]

withParen :: Monad m => ParsecT String u m DataTypeRep -> ParsecT String u m DataTypeRep
withParen singleType = do
  eatLParen
  i <- singleType
  eatRParen
  return $ i

