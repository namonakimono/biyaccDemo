{-# Language OverloadedStrings #-}

module BiYacc.Helper.Utils
  ( module BiYacc.Helper.Utils,
    module BiYacc.Language.Def,
    module TPP,

    toLower,
    Map,elems, keys, foldrWithKey,
    filterWithKey, toList, adjust, mergeWithKey, fromList, merge, preserveMissing,
    zipWithMatched, unionsWith, mapWithKey, mapKeys,

    forM_, liftM, liftM2, lift,
    MonadState, State, StateT, get, put, evalState, evalStateT, runState, modify, execState,
    Reader, ReaderT, runReader, ask, asks,

    fromMaybe, catMaybes, rights,
    foldl1, foldl', (\\), intersperse, sort, nub, delete, partition, intersect,

    ppShow, pPrint,
    trace, traceM, traceIO
    ) where

import Prelude hiding (lookup, (<>))
import BiYacc.Language.Def

import Control.Monad -- (forM_, liftM, liftM2)
import Control.Monad.State -- (MonadState, State, StateT, get, put, evalState, modify, execState)
import Control.Monad.Reader -- (Reader, ReaderT, runReader, ask, asks)

import Data.Char (toLower)
import Data.Map as Map (Map, singleton, union, unions, insert, empty, elems, keys, lookup, foldrWithKey,
  filterWithKey, toList, adjust, mergeWithKey, unionsWith, mapWithKey, mapKeys, fromList)
import Data.Map.Merge.Lazy (merge, preserveMissing, zipWithMatched)
import Data.Maybe (fromMaybe, catMaybes)
import Data.List as List (foldl1, (\\), foldl', intersperse, sort, nub, elem, delete, partition, intersect, null)
import Data.Either (rights)
import Text.PrettyPrint as TPP hiding (char)
import Text.Show.Pretty (ppShow, pPrint)

import Debug.Trace

tshow :: Show a => a -> Doc
tshow = text . show

nest2 :: Doc -> Doc
nest2 = nest 2

nest3 = nest 3

nestn6 = nest (-6)

nestn2 = nest (-2)

nestn1 = nest (-1)


wildcardDoc = text "_"

-- put something in  [p|]: [p| ...something... ]
wrapPatQ :: Doc -> Doc
wrapPatQ p = text "[p|" <+> p <+> text "|]"

wrapDecQ :: Doc -> Doc
wrapDecQ d = text "[d|" <+> d <+> text "|]"

wrapExpQ :: Doc -> Doc
wrapExpQ e = text "[|" <+> e <+> text "|]"

vcat2 = vcat3 . punctuate (text "\n")
  where vcat3 [] = TPP.empty
        vcat3 a@(x:xs) = foldr1 ($+$) a

punctuate1 :: Doc -> [Doc] -> [Doc]
punctuate1 d = map (\e -> e <> d)

infixr 5 `newlineSS`
newlineSS :: String -> String -> String
newlineSS s1 s2 = s1 ++ "\n\n" ++ s2

infixr 5 `newlineS`
newlineS :: String -> String -> String
newlineS s1 s2 = s1 ++ "\n" ++ s2

foldr1c :: (a -> b) -> (a -> b -> b) -> [a] -> b
foldr1c c _ [e] = c e
foldr1c c h (e:es) = h e (foldr1c c h es)
foldr1c _ _ [] = error "empty list fed to foldr1c"

foldl1c :: (a -> b) -> (b -> a -> b) -> [a] -> b
foldl1c c _ [e] = c e
foldl1c c h (e:es) = gg h (c e) es
  where gg h c1 [] = c1
        gg h c1 (e:es) = gg h (h c1 e) es
foldl1c _ _ [] = error "empty list fed to foldl1c"

isRight :: Either a b -> Bool
isRight (Left _)  = False
isRight (Right _) = True

typeRep2Str :: DataTypeRep -> String
typeRep2Str t = -- trace (ppShow t) $
  case t of
  DataTypeRep "List" [tts'] -> "[" ++ concatMap typeRep2Str [tts'] ++ "]"
  DataTypeRep "TupleT" tts   -> "(" ++ foldr1 (\t ts -> t ++ ", " ++ ts)
                                             (map typeRep2Str tts) ++ ")"
  DataTypeRep conName []    -> conName
  DataTypeRep conName ts    -> conName ++ " " ++ concatMap typeRep2Str ts

tyAsFunName :: DataTypeRep -> String
tyAsFunName (DataTypeRep "List" [t]) = "List" ++ tyAsFunName t
tyAsFunName (DataTypeRep "TupleT" tts) = "Tuple" ++ foldr1 (++) (map tyAsFunName tts)
tyAsFunName (DataTypeRep n ts) = n ++ foldr (++) "" (map tyAsFunName ts)

-- function name does not support special chars. e.g.: [Arith], so we convert it to ListArith
-- SUPPORT TUPLE LATER.
convertSpecialTy :: DataTypeRep -> String
convertSpecialTy tyRep = let s = typeRep2Str tyRep
  in if head s == '[' && last s == ']'
       then "List" ++ (tail . init $ s)
       else s

tyAsFunType :: DataTypeRep -> String
tyAsFunType = typeRep2Str

-- erase list type if it is the first layer
eraseListTy :: DataTypeRep -> DataTypeRep
eraseListTy (DataTypeRep "List" [t]) = t
eraseListTy t = t

elimListTy :: String -> String
elimListTy s = if head s == '[' && last s == ']'
  then tail . init $ s
  else if take 4 s == "List"
    then drop 4 s
    else s


concatSpace :: [String] -> String
concatSpace [] = []
concatSpace (x:xs) = x ++ " " ++ concatSpace xs

infixr 5 +^+
(+^+) :: String -> String -> String
x +^+ y = x ++ " " ++ y

isPrimitive :: String -> Bool
isPrimitive t = elem t biPrimitive

biPrimitive :: [String]
biPrimitive = ["BiIdentifyTy", "BiStringTy", "BiNumericTy", "BiBoolTy"]

-- change primitive types such as Int, Float to String type to hold precisely all the information
-- the "Name" is pervasive in the libraries of Haskell.
-- so I changed it to another name to avoid confilict...
toBiYaccTy :: String -> String
toBiYaccTy "String"  = "BiStringTy"
toBiYaccTy "Name"    = "BiIdentifyTy"
toBiYaccTy "Numeric" = "BiNumericTy"
toBiYaccTy "Bool"    = "BiBoolTy"
toBiYaccTy a = a


repPrimTy :: String -> String
repPrimTy ("BiStringTy")   = "replaceStrString"
repPrimTy ("BiIdentifyTy") = "replaceStrIdentify"
repPrimTy ("BiNumericTy")  = "replaceStrNumeric"
repPrimTy ("BiBoolTy")     = "replaceStrBool"
repPrimTy st = error $ "source type:" +^+ st +^+ "not implemented"

fst4 (a,_,_,_) = a
snd4 (_,b,_,_) = b
third4 (_,_,c,_) = c
fourth4 (_,_,_,d) = d


trimSpaces :: String -> String
trimSpaces = reverse . dropWhile (flip List.elem ("\t\n\r " :: String)) .
  reverse . dropWhile (flip List.elem ("\t\n\r " :: String))

wrapStrInParen :: String -> String
wrapStrInParen str = "(" ++ str ++ ")"


-- unsafe
fromJ :: String -> Maybe a -> a
fromJ errMsg ma = case ma of
  Nothing -> error errMsg
  Just a  -> a


-- find elements occur more than once in a list.
findDup :: Eq a => [a] -> [a]
findDup xs = nub [x | x <-xs, x `elem` delete x xs]


notNull :: [a] -> Bool
notNull = not . List.null

mkSimpleTyRep :: String -> DataTypeRep
mkSimpleTyRep str = DataTypeRep str []

mkTyRep :: String -> [DataTypeRep] -> DataTypeRep
mkTyRep str fields = DataTypeRep str fields

-- generating text (doc, string ...) for tuple types
genTuple :: (a -> Doc) -> [a] -> Doc
genTuple f [e] = f e
genTuple f (e:es) = parens $ f e <> comma <+> genTuple f es
genTuple _ [] = "()" -- error "error in internal function genTuple. empty list detected."

-- generate right-dense nested 2-tuple
toDenseTupleDoc :: (a -> Doc) -> [a] -> Doc
toDenseTupleDoc f [e] = f e
toDenseTupleDoc f (e:es) = parens $ f e <> comma <+> toDenseTupleDoc f es
toDenseTupleDoc _ [] = "()" -- error "error in internal function genTuple. empty list detected."


-- initial serial number
genSerialTuple :: Int -> (a -> Doc) -> [a] -> Doc
genSerialTuple n f [e] = f e <> text (show n)
genSerialTuple n f (e:es) = parens $ f e <> text (show n) <> comma <+> genSerialTuple (n+1) f es
genSerialTuple n _ [] = error "in internal function genSerialTuple. empty list detected."

