{-# LANGUAGE NoMonomorphismRestriction, FlexibleContexts #-}

module BiYacc.Translation.Check where

import BiYacc.Language.Def
import BiYacc.Helper.Utils
import BiYacc.Translation.DataQuery
import BiYacc.Parser.Concrete
import BiYacc.Translation.BX.GenBasicUpdate

import qualified Data.Map as Map (lookup, elems, keys)
import Data.Maybe (fromJust)
import Control.Monad.Writer
import Control.Monad.Reader
import Data.Generics hiding (empty)

-- the input is tempCAST, which does not contain "NullConstructor", and "LayoutField"
allCheck :: CAST -> Program -> Cons2FieldsEnv -> String
allCheck tmpCAST tmpProgram csEnv =
  let grps = getGroups tmpProgram
      pat2NameEnv = buildPat2NameEnv tmpCAST
      name2PatEnv = buildName2PatEnv tmpCAST
      tyNameEnv = buildTyNameEnv tmpCAST
      (flag1, errLog) = runWriter $ mapM (allCheckG tyNameEnv pat2NameEnv csEnv) grps
      warnLog = maybe "" id (simpleExhaustCheck tmpProgram tyNameEnv name2PatEnv pat2NameEnv)
  in  if and flag1
      then warnLog
      else error $ foldr1c id newlineS errLog


-- check all for a group of actions
allCheckG :: TypeNameEnv -> Pat2NameEnv -> Cons2FieldsEnv ->
  Group -> Writer [String] Bool
allCheckG tenv eenv csEnv (Group ty@(TypeDecl _ st_) rules) = do
  let st = typeRep2Str st_
  flag1 <- case Map.lookup st tenv of
              Nothing -> do tell $ ["the non-terminal" +^+ ppShow st +^+ "in the type declaration of an action group"
                                   +^+ "is not defined in concrete syntax."
                                   +^+ "maybe a wrong type is written?"]
                            return False
              Just _  -> return True
  flag2s <- mapM (allCheckR eenv csEnv ty) rules
  return $ and (flag1:flag2s)

-- check all for a single rule
allCheckR :: Pat2NameEnv -> Cons2FieldsEnv -> TypeDecl ->
  Rule -> Writer [String] Bool
allCheckR p2nEnv csEnv (TypeDecl groupVT groupST) rule@(NormalRule vSide sSide) = do
  let SrcSide  stype consName units = sSide
      ViewSide vConstraints vsp = vSide
      updVarsInS = getVarFromS sSide
      updVarsInV = getVarFromV vSide
      elimVars   = getVVarDep vSide

  flags1 <- mapM (isVarDefined vSide) updVarsInS
  flags2 <- mapM (isVarUsed sSide) (updVarsInV \\ elimVars)
  flag3 <- isProdDefined p2nEnv groupST sSide
  flag4 <- noWildcard vSide
  flag5 <- noVarPatInAsP vSide
  flag6 <- isConsDefined csEnv groupVT vSide
  flag7 <- vVarTyCheck vSide groupVT csEnv
  flag8 <- isNTDefined p2nEnv sSide
  return (and (flags1 ++ flags2 ++ [flag3, flag4, flag5, flag6, flag7, flag8]))
allCheckR _ _ _ _ = return True

-- check if a upd-var in SrcSide is defined in ViewSide
isVarDefined :: ViewSide -> String -> Writer [String] Bool
isVarDefined vside@(ViewSide _ vsp) uv = case findVarType uv vside of
  Nothing -> do tell $ ["cannot find the update variable" +^+ uv
                        +^+ "in the view pattern (ViewSide)" `newlineS`
                        "ViewSide pattern:" +^+ ppShow (vPat2HsCode vsp)]
                return False
  Just _  -> return True

-- check if a variable defined in ViewSide is used in SrcSide
isVarUsed :: SrcSide -> String -> Writer [String] Bool
isVarUsed sSide var = do
  let vars = getVarFromS sSide
  case var `elem` vars of
    False -> do tell $ ["variable" +^+ var +^+ "is not used in source side." `newlineS`
                        "Source side:" +^+ (sSide2ProdStr sSide)]
                return False
    True  -> return True


-- check if a production rule in #Actions part is defined in #Concrete
isProdDefined :: Pat2NameEnv -> SourceType -> SrcSide -> Writer [String] Bool
isProdDefined eenv st_ sSide@(SrcSide _ _ units) = do
  let st = typeRep2Str st_
      prodStr = sSide2ProdStr sSide
  case Map.lookup ((getProdrulePat units),st) eenv of
    Nothing -> do tell ["In #Actions, production rule not found (deep pattern is also checked)" `newlineS` prodStr]
                  return False
    Just _  -> liftM and (mapM chkDeep units) -- go on checking deep pattern
  where
    chkDeep :: UpdateUnit -> Writer [String] Bool
    chkDeep (UpdateUnitSingle u) = chkDeepPat u
    chkDeep (UpdateUnitBundle _ us) = liftM and (mapM chkDeep us)

    chkDeepPat :: Either Unchanged Update -> Writer [String] Bool
    chkDeepPat (Right (DUpdate s@(SrcSide ty _ units))) = isProdDefined eenv ty s
    chkDeepPat (Right (NUpdateWithDeepPat uv ty s)) = isProdDefined eenv ty s
    chkDeepPat _ = return True


-- is view-side valid?  (no wildcard pat.)
noWildcard :: ViewSide -> Writer [String] Bool
noWildcard vSide = do
  let res = everythingBut (++) (mkQ ([],False) wild) vSide
  if null res
    then return True
    else do tell $ ["invalid wildcard (_) pattern found in view side."
                   +^+ render (vSide2HsCode vSide)]
            return False
  where
    wild :: ViewSidePattern -> ([ViewSidePattern],Bool)
    wild (WildcardP)   = ([WildcardP], False)
    wild (ASPattern{}) = ([], True)
    wild _             = ([], False)

-- patterns in AsPattern must not be varaibles
noVarPatInAsP :: ViewSide -> Writer [String] Bool
noVarPatInAsP vSide = do
  let asp  = listify findAsP vSide
      varp = listify findVarP asp
  case null varp of
    True  -> return True
    False -> do tell ["cannot use variable pattern within an as-pattern."
                      +^+ render (vSide2HsCode vSide)]
                return False
  where findAsP :: ViewSidePattern -> Bool
        findAsP (ASPattern{}) = True
        findAsP _ = False
        findVarP :: ViewSidePattern -> Bool
        findVarP (UpdVar{}) = True
        findVarP _ = False

-- is constructors in view-side defined (and with correct arities)
isConsDefined :: Cons2FieldsEnv -> ViewType ->
  ViewSide -> Writer [String] Bool
isConsDefined csEnv groupVTDecl vSide = do
  let csEnv' = extendEnv groupVTDecl csEnv
      consPats = everything (++) (mkQ [] (getConsPat)) vSide
  flags <- mapM (isConsDefined1 csEnv') consPats
  return (and flags)
  where
    getConsPat :: ViewSidePattern -> [ViewSidePattern]
    getConsPat c@(ConsPat {}) = [c]
    getConsPat _ = []

    isConsDefined1 :: Cons2FieldsEnv -> ViewSidePattern -> Writer [String] Bool
    isConsDefined1 env (ConsPat cName ty vsps) = case Map.lookup cName env of
      Nothing -> if isBuildIn cName
          then return True
          else do tell ["In #Actions part, the constructor" +^+ cName +^+ "is not defined."]
                  return False
      Just _  -> return True
    isBuildIn :: String -> Bool
    isBuildIn = flip elem ["TupleC", "ConsList", "Singleton", "EmptyList"
                          , "Just", "Nothing", "Left", "Right"]

-- is a nonterminal defined?
-- after isProdDefined checking, we can make sure that nonterminals used in
-- #Actions are already defined. However, currently BiYacc only supports 4 kinds of
-- primitive types. so we check them.
isNTDefined :: Pat2NameEnv -> SrcSide -> Writer [String] Bool
isNTDefined p2nEnv sSide =
  let definedNTs = nub $ map snd $ Map.keys p2nEnv
      allNTs     = nub $ getNTNames sSide
      suspicious = allNTs \\ (definedNTs ++ prim)
  in  case null suspicious of
        True  -> return True
        False -> do  flags <- mapM errMsg suspicious
                     return False
  where errMsg ty = do
          tell ["unsupported primitive type  " +^+ ty +^+
               "  in concrete syntax (or #Actions part)." `newlineS`
               "Currently only support: Numeric, String, Name."]
          return False
        prim = ["String","Name","Numeric"]



vVarTyCheck :: ViewSide->        -- data to be processed
               ViewType ->       -- the type of the view (type of the group of actions)
               Cons2FieldsEnv -> -- env from constructor to ([subsequent field], type)
               Writer [String] Bool
vVarTyCheck (ViewSide _ vsp) groupVT csEnv =
  let vsp'   = vVarTyCheckB vsp groupVT
      csEnv' = extendEnv groupVT csEnv
      maw    = runWriterT (vVarTyCheck2 vsp' csEnv' Nothing)
  in  writer (runReader maw 0)

vVarTyCheck2 :: ViewSidePattern -> -- data to be processed
                Cons2FieldsEnv ->  -- env from constructor to ([subsequent field], type)
                Maybe String ->    -- constructor of a data type. E.g.: the “Add” in “Add lhs rhs”.
                                   -- to be used for variable pattern.
                                   -- set to Nothing if it is boaderline cases.
                WriterT [String] (Reader Int) Bool
vVarTyCheck2 (ConsPat consName _ vsps) csEnv maybeCon  = do
  oldLoc <- lift ask
  case Map.lookup consName csEnv of
    Just (_, ty)  -> do
      -- when encounter a constructor. Its following field should (re)counter position from 0.
      flags <- mapM (\(p, iLoc) -> local (const iLoc) (go oldLoc p)) (zip vsps [0..])
      return $ and flags
    Nothing -> vVarTyCheckErrMsg oldLoc consName maybeCon csEnv
  where
    go :: Int -> ViewSidePattern -> WriterT [String] (Reader Int) Bool
    go oldLoc p = do
      iLoc <- lift ask
      case Map.lookup consName csEnv of
        Just (tys , _) -> do
          let ty = tys !! iLoc
              csEnv' = extendEnv ty csEnv
          local (const iLoc) (vVarTyCheck2 p csEnv' (Just consName))
        Nothing -> vVarTyCheckErrMsg oldLoc consName maybeCon csEnv


-- variable pattern === wildcard, which does not go wrong (and produce no log)
vVarTyCheck2 pp@(ASPattern name _ vsp) csEnv (Just lastCon) = do
  loc <- lift ask
  let (tys, _) = fromJ "impossible. 0xC12." (Map.lookup lastCon csEnv)
      thisTy = tys !! loc
  -- True && b === b. so just call function on inner part
  vVarTyCheck2 vsp csEnv (Just lastCon)

vVarTyCheck2 (UpdVar var _) csEnv (Just lastCon) = do
  loc <- lift ask
  let (tys , _) = fromJ "impossible. 0xC11." (Map.lookup lastCon csEnv)
      thisTy = tys !! loc
  return True

-- should do more checks
vVarTyCheck2 i _ _ = return True



vVarTyCheckErrMsg :: Int -> String -> Maybe String -> Cons2FieldsEnv ->
  WriterT [String] (Reader Int) Bool
vVarTyCheckErrMsg oldLoc consName maybeCon csEnv = do
  let lastCon = maybe "" id maybeCon
      expectedTy = case Map.lookup lastCon csEnv of
                    Nothing -> mkSimpleTyRep "(sorry, not inferred)"
                    Just (expectedTys, _) -> expectedTys !! oldLoc
  tell ["in the" +^+ count oldLoc +^+ "field of constructor" +^+ lastCon
       ,"type mismatches." +^+ intpC consName +^+
        "but the expected type is" +^+ typeRep2Str expectedTy]
  return False
  where
    -- make some error message for different constructors
    intpC :: String -> String
    intpC "Singleton" = "the syntax represents list type"
    intpC "ConsList"  = "the syntax represents list type"
    intpC "EmptyList" = "the syntax represents list type"
    intpC "TupleC"    = "the syntax represents Tuple type"
    intpC "Just"      = "the syntax represents Maybe type"
    intpC "Nothing"   = "the syntax represents Maybe type"
    intpC "Left"      = "the syntax represents Either type"
    intpC "Right"     = "the syntax represents Either type"
    intpC ty          = "the type is" +^+ ty
    count n | last (show n) == '0' = show (n+1) ++ "st"
    count n | last (show n) == '1' = show (n+1) ++ "nd"
    count n | last (show n) == '2' = show (n+1) ++ "rd"
    count n | True = show (n+1) ++ "th"


-- borderline cases
vVarTyCheckB :: ViewSidePattern -> -- data to be processed
                ViewType ->        -- the type of the view (type of the group of actions)
                ViewSidePattern
vVarTyCheckB (ConsPat "ConsList" _ [v1, v2, vs]) cc@(DataTypeRep "List" [t]) =
  let v1' = vVarTyCheckB v1 t
      v2' = vVarTyCheckB v2 t
      vs' = vVarTyCheckB vs cc
  in  ConsPat "ConsList" cc [v1', v2', vs']

vVarTyCheckB (ConsPat "ConsList" _ [v, vs]) cc@(DataTypeRep "List" [t]) =
  let v' = vVarTyCheckB v t
      vs' = vVarTyCheckB vs cc
  in  ConsPat "ConsList" cc [v', vs']

vVarTyCheckB (ConsPat "Singleton" _ [v]) cc@(DataTypeRep "List" [t]) =
  let v' = vVarTyCheckB v t
  in  ConsPat "Singleton" cc [v']

vVarTyCheckB (ConsPat "TupleC" _ vvs) cc@(DataTypeRep "TupleT" tts) =
  let vvs' = zipWith (\v t -> vVarTyCheckB v t) vvs tts
  in  ConsPat "TupleC" cc vvs'

vVarTyCheckB ((ASPattern uv _ vsp)) vt =
  let vsp' = vVarTyCheckB vsp vt
  in  ASPattern uv vt vsp'

vVarTyCheckB (UpdVar uv' _) vt = UpdVar uv' vt

vVarTyCheckB pat _  = pat

------------------------------------------------------------------------
-- check whether a group of actions use all the production rules.
simpleExhaustCheck :: Program -> TypeNameEnv -> Name2PatEnv -> Pat2NameEnv -> Maybe String
simpleExhaustCheck (Program _ grps) tenv n2pEnv p2nEnv =
  case catMaybes (map (checkGrp tenv n2pEnv p2nEnv) grps) of
    [] -> Nothing
    errMsgs -> Just $ "warning: (however, the program may still be correct)\n" ++
                      foldr1c id newlineS errMsgs

-- Maybe (error message)
checkGrp :: TypeNameEnv -> Name2PatEnv -> Pat2NameEnv -> Group -> Maybe String
checkGrp tenv n2pEnv p2nEnv (Group (TypeDecl vt st_) rules) =
  let st = typeRep2Str st_ in
  let conNames = sort $ fromJust (Map.lookup st tenv)
      namesWrt  = nubSortedList . sort . filter notNull . map (extPrdName st p2nEnv) $ rules
      -- extPrdName adaptation rules return empty strings. filter (not . null) ignore them.
      lack      = map (\e -> "In group: " ++ typeRep2Str vt +^+ "+>" +^+ st ++ "," `newlineS`
                       "production not found: " ++ st +^+ "->" +^+ errMsgRHS e)
                      (conNames \\ namesWrt)
      errMsgRHS name = case Map.lookup name n2pEnv of
                         Nothing -> error "impossible. in errMsgRHS. 0x00."
                         Just a  -> cTypeField2Str . fst $ a
  in  case Prelude.null lack of
        True -> Nothing
        False -> Just $  foldr1c id newlineS lack

nubSortedList :: Eq a => [a] -> [a]
nubSortedList [] = []
nubSortedList [x] = [x]
nubSortedList (x:y:z) = if x == y then nubSortedList (y:z) else x: nubSortedList (y:z)

extPrdName :: SourceTypeStr -> Pat2NameEnv -> Rule -> String
extPrdName st p2nEnv (NormalRule _ (SrcSide _ _ tnts)) =
  fromJust (Map.lookup (getProdrulePat tnts,st) p2nEnv)
extPrdName _ _ (AdaptRuleP{}) = ""
extPrdName _ _ (AdaptRuleG{}) = ""

----------------------------------------------------------------
