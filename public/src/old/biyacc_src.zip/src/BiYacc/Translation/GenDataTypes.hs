{-# LANGUAGE OverloadedStrings #-}
module BiYacc.Translation.GenDataTypes where

import Prelude hiding (lookup, (<>))
import BiYacc.Language.Def
import BiYacc.Helper.Utils
import BiYacc.Translation.BX.GenBrackets


import qualified Data.Map as Map (lookup)
import Data.Maybe (fromJust)
import Data.Generics hiding (empty)
import Text.PrettyPrint as TPP hiding (empty)
import qualified Text.PrettyPrint as TPP


-- generate abstract syntax data types and DeriveBiGulGenerics
prtAbsDTs' :: ASTDataTypeDecs -> String
prtAbsDTs' decls = render (prtAbsDTs decls) `newlineSS` genDrvBiGULGenericAST decls


prtAbsDTs :: ASTDataTypeDecs -> Doc
prtAbsDTs = vcat2 . map prtAbsDT

prtAbsDT :: ASTDataTypeDec -> Doc
prtAbsDT (ASTDataTypeDec ty defs) =
  "data" <+> text (typeRep2Str ty) <+> "=" $+$
  nest2 (foldl1c (\e -> "  " <> prtDef e) (\es e -> es $$ "|" <+> prtDef e) defs) $+$
  nest2 "deriving (Show, Read, Eq)"
  where prtDef :: ASTDataTypeDef -> Doc
        prtDef (ASTDataTypeDef con fields) =
          hsep $ [text con] ++ map (text . wrapParen . typeRep2Str) fields
        -- if there is any space, it means that the type has parameter.
        wrapParen :: String -> String
        wrapParen s@('(':_) = s -- do not add parens for tuple type, no need
        wrapParen s | elem ' ' s = "(" ++ s ++ ")"
        wrapParen s = s


genDrvBiGULGenericAST :: ASTDataTypeDecs -> String
genDrvBiGULGenericAST tydecs =
  foldr newlineS "" $
  map (\(ASTDataTypeDec t _) -> "deriveBiGULGeneric ''" ++ typeRep2Str t) tydecs

----------------------------------------

--- print the AST of #Concrete to Haskell datatypes-------
-- haskell data types do not include disambiguation filters annotation
-- print concrete syntax data types
prtConcDTs :: CAST -> String
prtConcDTs (CAST topt defs) = render $
  foldr ($+$) TPP.empty (punctuate1 "\n" (map prtSrcDatatype defs)) $+$
  text (genDrvBiGULGenericCST (CAST topt defs))

prtSrcDatatype :: CDataType -> Doc
prtSrcDatatype (CDataType dName defs) =
  datadec_head <+> text dName <+> equals $+$
    nest2 (foldl1c (\x -> "  " <> x) (\xs x -> xs $$ ("|" <+> x) ) (map prtSrcTypeDef defs))
    $$ nest2 datadec_drv
  where datadec_head = "data"
        datadec_drv  = "deriving (Show, Read, Eq)"

prtSrcTypeDef :: CTypeDef -> Doc
prtSrcTypeDef (CTypeDef consName typefields _) = hsep (text consName : map f typefields)
  -- represent terminals as strings, with surrounding comments and layouts
  where
    f :: CTypeField -> Doc
    f (CTypeFieldSingle etnt) = g etnt
    f (CTypeFieldBundle ZeroOrMore etnts) = "[" <> genTuple f etnts <> "]"
    f (CTypeFieldBundle OneOrMore  etnts) = "[" <> genTuple f etnts <> "]"

    -- g = either (const (text "String")) (\t -> text $ if isPrimitive t then wrap t else t)
    g = either (const (text "String")) text


genDrvBiGULGenericCST :: CAST -> String
genDrvBiGULGenericCST (CAST _ defs) =
  foldr newlineS "" (map (\(CDataType ty _) -> "deriveBiGULGeneric ''" +^+  ty) defs)
----------------

