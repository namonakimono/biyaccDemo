module BiYacc.Translation.DataQuery where

import BiYacc.Language.Def
import BiYacc.Helper.Utils

import Data.Generics


hasKleeneSyntax :: Data a => a -> Bool
hasKleeneSyntax = not . null . listify p
  where p (UpdateUnitBundle _ _) = True
        p _  = False

-- if view has variable-dependency
hasVVarDep :: ViewSide -> Bool
hasVVarDep (ViewSide vConstraints _ ) =
  let (_, ec) = divideViewConstraints vConstraints
  in  not (null ec)

-- get variables depending on the others
getVVarDep :: ViewSide -> [String]
getVVarDep (ViewSide vConstraints _ ) =
  let (_, ec) = divideViewConstraints vConstraints
      (_,_,eliminated) = unzipVDep ec
  in  eliminated

-- if source side has non-linear variable usage
hasDupVars :: SrcSide -> Bool
hasDupVars = not . null . findDup . getVarFromS

hasVVars :: Data a => a -> Bool
hasVVars = not . null . getVarFromV

-- if source side has update variables
hasSVars :: Data a => a -> Bool
hasSVars = not . null . getVarFromS


-- expand VVarElimination data to tuples (funs, representitive, eliminated)
unzipVDep :: ViewConstraints -> ([String], [String], [String])
unzipVDep (VVarElimination funName v1 v2  :cs) =
  let (funNames, v1s, v2s) = unzipVDep cs
  in  (funName:funNames, v1:v1s, v2:v2s)
unzipVDep [] = ([],[],[])


-- return (PureConstrains, View-dependency-constraints)
divideViewConstraints :: ViewConstraints -> (ViewConstraints, ViewConstraints)
divideViewConstraints (PureViewConstraint c :cs) =
  let (pc, ec) = divideViewConstraints cs
  in  (PureViewConstraint c : pc, ec)
divideViewConstraints (VVarElimination f v1 v2 :cs) =
  let (pc, ec) = divideViewConstraints cs
  in  (pc, VVarElimination f v1 v2 : ec)
divideViewConstraints [] = ([], [])



getGroups :: (Data a) => a -> [Group]
getGroups prog = listify p prog
  where p :: Group -> Bool
        p (Group{}) = True

getProdrulePat :: [UpdateUnit] -> [CTypeField]
getProdrulePat = map getUpdPat1
  where
    getUpdPat1 :: UpdateUnit -> CTypeField
    getUpdPat1 (UpdateUnitSingle u) = CTypeFieldSingle (getUpdPat2 u)
    getUpdPat1 (UpdateUnitBundle occur us) = CTypeFieldBundle occur (map getUpdPat1 us)

    getUpdPat2 :: Either Unchanged Update -> Either String String
    getUpdPat2 (Left (Nonterminal ty)) = Right (typeRep2Str ty)
    getUpdPat2 (Left (Terminal t))    = Left t
    getUpdPat2 (Right (NUpdate _ ty)) = Right (typeRep2Str ty)
    getUpdPat2 (Right (NUpdateWithDeepPat _ ty _)) = Right (typeRep2Str ty)
    getUpdPat2 (Right (DUpdate (SrcSide ty _ _)))  = Right (typeRep2Str ty)

-- collect nonterminals in String representation. cannot use listify.
getNTNames :: Data a => a -> [String]
getNTNames = everything (++) (mkQ [] ntquery)
  where
    ntquery :: Either Unchanged Update -> [String]
    ntquery (Left (Nonterminal st)) = [typeRep2Str st]
    ntquery (Right (NUpdate _ st))  = [typeRep2Str st]
    ntquery (Right (NUpdateWithDeepPat _ st _)) = [typeRep2Str st]
    ntquery _ = []


-- collect view-vars (update vars) in String representation from SrcSide. cannot use listify.
getVarFromS :: Data a => a -> [String]
getVarFromS = everything (++) (mkQ [] vquery)
  where
    vquery :: Either Unchanged Update -> [String]
    vquery (Right (NUpdate var st)) = [var]
    vquery (Right (NUpdateWithDeepPat var _ _)) = [var]
    vquery _ = []


-- collect variables from view-side. cannot use listify.
getVarFromV :: (Data a, Typeable a) => a -> [String]
getVarFromV = everything (++) (mkQ [] collect)
  where collect (UpdVar var _)      = [var]
        collect (ASPattern var _ _) = [var]
        collect _ = []


getVSideLits :: (Data a, Typeable a) => a -> [String]
getVSideLits = everything (++) (mkQ [] extLit)
  where extLit :: ViewSidePattern -> [String]
        extLit (LitPat lit) = [extractLitToString lit]
        extLit _ = []


getSAllParts :: Data a => a -> [UpdateUnit]
getSAllParts = everythingBut (++) (const ([], False) `extQ` go)
  where
    go :: UpdateUnit -> ([UpdateUnit],Bool)
    go s@(UpdateUnitSingle _)   = ([s],False)
    go s@(UpdateUnitBundle _ _) = ([s],True)
    go s@(ProtectBundle{}) = ([s],True)
    go (UpdateUnitFromBundle{}) = error "cannot be UpdateUnitFromBundle. 0xC7."
    -- go s@(Projected) = ([s],False)


-- getSAllParts ::SrcSide -> [UpdateUnit]
-- getSAllParts (SrcSide _ _ us) = concatMap go us
--   where
--     go :: UpdateUnit -> [UpdateUnit]
--     go s@(UpdateUnitSingle _) = [s]
--     go s@(UpdateUnitBundle _ _) = [s]
--     go (UpdateUnitFromBundle{}) = error "cannot be UpdateUnitFromBundle. 0xC7."

getSKleeneStarParts :: Data a => a -> [UpdateUnit]
getSKleeneStarParts = listify isKleeneStarPart

isKleeneStarPart :: UpdateUnit -> Bool
isKleeneStarPart (UpdateUnitBundle{}) = True
isKleeneStarPart (ProtectBundle{}) = True
isKleeneStarPart _ = False


saveDesiredVPat :: [String] -> ViewSidePattern -> [ViewSidePattern]
saveDesiredVPat ns pp@(ASPattern var _ _) | var `elem` ns = [pp]
saveDesiredVPat ns pp@(UpdVar var _)      | var `elem` ns = [pp]
saveDesiredVPat ns pp@(LitPat l)          | extractLitToString l `elem` ns = [pp]
saveDesiredVPat _ _ = []


isDesiredVPat :: [String] -> ViewSidePattern -> Bool
isDesiredVPat names pp@(ASPattern var _ _) = var `elem` names
isDesiredVPat names pp@(UpdVar var _)      = var `elem` names
isDesiredVPat names pp@(LitPat l)          = extractLitToString l `elem` names
isDesiredVPat _ _ = False


extractSSideTy :: SrcSide -> DataTypeRep
extractSSideTy (SrcSide ty _ _) = ty


extractUpdSrcTy :: UpdateUnit -> DataTypeRep
extractUpdSrcTy (UpdateUnitSingle (Left (Nonterminal ty))) = ty
extractUpdSrcTy (UpdateUnitSingle (Left (Terminal _)))    = mkSimpleTyRep "String"
extractUpdSrcTy (UpdateUnitSingle (Right (NUpdate _ ty))) = ty
extractUpdSrcTy (UpdateUnitSingle (Right (NUpdateWithDeepPat _ ty _ ))) = ty
extractUpdSrcTy (UpdateUnitSingle (Right (DUpdate (SrcSide ty _ _)))) = ty
extractUpdSrcTy (UpdateUnitFromBundle _ ty _ _) = ty
extractUpdSrcTy (UpdateUnitBundle _ units) =
  let newSSide@(SrcSide ty _ _) = buildTupleSSide units
  in  ty
  where
    buildTupleSSide :: [UpdateUnit] -> SrcSide
    buildTupleSSide [] = error "empty list. buildTupleSSide. 0xC1."
    buildTupleSSide uus = foldr1c (\u -> SrcSide (extractUpdSrcTy u) "" [u]) twoTuple uus
      where twoTuple x xs =
              let deep = UpdateUnitSingle (Right (DUpdate xs))
                  ty = DataTypeRep "TupleT" [extractUpdSrcTy x, extractSSideTy xs]
              in  SrcSide ty "TupleC" [x, deep]

extractUpdSrcTy (ProtectBundle _ ty _ _) = ty
extractUpdSrcTy a = error $ "extractUpdSrcTy: " ++ ppShow a
  -- error "unsupported data. extractUpdSrcTy. 0xC3"

extractVarTy :: ViewSidePattern -> DataTypeRep
extractVarTy (ASPattern _ ty _) = ty
extractVarTy (UpdVar _ ty)      = ty
extractVarTy (ConsPat "TupleC" ty _) = ty
extractVarTy (ConsPat _ ty _)     = ty -- warning
extractVarTy (LitPat (LitStrPat _))       = mkSimpleTyRep "String"
extractVarTy (LitPat (LitIntegerPat _))   = mkSimpleTyRep "Integer"
extractVarTy (LitPat (LitDecimalPat _)  ) = mkSimpleTyRep "Double"
extractVarTy (LitPat (LitBoolPat _)   )   = mkSimpleTyRep "Bool"
extractVarTy _ = error "cannot extract type. extractVarTy. 0xC2."

extractLitToString :: LitPat -> String
extractLitToString lit = case lit of
  LitStrPat s     -> show s
  LitIntegerPat i -> show i
  LitDecimalPat d   -> show d
  LitBoolPat b    -> show b


----------------------
findVarType :: String -> ViewSide -> Maybe DataTypeRep
findVarType var (ViewSide _ vsp) = findVarType' var vsp
  where
    findVarType' :: String -> ViewSidePattern -> Maybe DataTypeRep
    findVarType' var (ConsPat var' ty subpats) =
      if var == var'
        then Just ty
        else case catMaybes (map (findVarType' var) subpats) of
              [ty] -> Just ty
              _:_  -> error $ "variable " ++ var ++ " occurred more than once in the view pattern"
              []   -> Nothing

    findVarType' var (ASPattern var' ty vsp) =
      if var == var' then Just ty else findVarType' var vsp

    findVarType' var (UpdVar var' ty) = if var /= var' then Nothing else Just ty
    findVarType' _ _ = Nothing
