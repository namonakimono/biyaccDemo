{-# LANGUAGE OverloadedStrings #-}

module BiYacc.Translation.BX.GenCaseCond where

import Prelude hiding (lookup, (<>))
import BiYacc.Language.Def
import BiYacc.Helper.Utils
import BiYacc.Translation.DataQuery
import BiYacc.Translation.BX.GenBasicUpdate

import Control.Monad
import Data.Generics hiding (empty)
import Text.PrettyPrint as TPP hiding (empty)
import qualified Text.PrettyPrint as TPP

{-
The file handles entrance and exit condition parts of a Case sentence.
Case $(normal [|\spat vpat -> entrance predicate |] [|\s -> exit predicate|] ) ...
-}

genCaseCond :: SrcSide -> ViewSide -> (Doc, Doc)
genCaseCond sside vside =
  let (sPat , vPat, vConstraints, exitPat) = genCaseCond1 sside vside
      entCond = "\\" <> sPat <+> vPat <+> "->" <+>
                if TPP.isEmpty vConstraints then "True" else vConstraints
  in  (entCond, exitPat) -- currently no exit predicate (on source). so pat = cond.

-- [|\spat vpat -> predicate (constraint) |] [|\s -> exit predicate|]
genCaseCond1 :: SrcSide -> ViewSide -> (Doc, Doc, Doc, Doc)
genCaseCond1 sside vside =
  (genEntSPat sside, genEntVPat vside, genAdditionalVConstraints vside, genExitSPat sside)


-- generate entrance patterns consisting of only a constructor wild cards, and variables.
-- used for pattern matching on source and decomposing source
genEntSPat :: SrcSide -> Doc
genEntSPat ss@(SrcSide _ prodName maybeUpdates) =
  handleTupleCon prodName (map genEachUnit maybeUpdates)
  -- (text prodName) <+> hsep (map genEachUnit maybeUpdates)
  where
    genEachUnit :: UpdateUnit -> Doc
    genEachUnit (UpdateUnitSingle u) = genSingle u
    genEachUnit (UpdateUnitBundle ZeroOrMore _) = wildcardDoc -- warning. not precise enough
    genEachUnit (UpdateUnitBundle OneOrMore us) =
      parens $ genTuple (const wildcardDoc) us <+> ":" <+> "_"

    -- genTuple foldr1c id (\e es -> e <+> es) (map genEachUnit us)
    -- wildcardDoc -- WARNING. ERROR. better to EXPAND the pattern precisely

    genSingle :: Either Unchanged Update -> Doc
    genSingle (Left _ ) = wildcardDoc
    genSingle (Right (NUpdate{})) = wildcardDoc
    genSingle (Right (NUpdateWithDeepPat _ _ rhs))  = genEntSPat rhs
    genSingle (Right (DUpdate rhs))  = genEntSPat rhs


-- generate entrance patterns consisting of only Constructor, wild cards, and variables.
-- used for pattern matching on view and decomposing view.
genEntVPat = vSide2HsCode

genExitSPat = genEntSPat


genAdditionalVConstraints :: ViewSide -> Doc
genAdditionalVConstraints (ViewSide [] _) = TPP.empty
genAdditionalVConstraints (ViewSide vConstraints _) =
  let inductiveCase = \(VVarElimination f v1 v2) es ->
                        text f <+> text v1 <+> "==" <+> text v2 <> comma <+> es
      baseCase = \(VVarElimination f v1 v2) -> text f <+> text v1 <+> "==" <+> text v2

      (pc, ec) = divideViewConstraints vConstraints
      ecDoc = if null ec
        then TPP.empty
        else "and" <+> brackets (foldr1c baseCase inductiveCase ec)
      pcDoc = if null pc
        then TPP.empty
        else foldr1c (\(PureViewConstraint c) -> text c)
                     (\(PureViewConstraint c) es -> text c <+> "&&" <+> es) pc
  in  case (isEmpty ecDoc, isEmpty pcDoc) of
        (True, True) -> TPP.empty
        (True, _) -> pcDoc
        (_,True) -> ecDoc
        (_,_) -> ecDoc <+> "&&" <+> pcDoc


-- hasAdditionalViewConstraints :: ViewSide -> Bool
-- hasAdditionalViewConstraints (ViewSide (_:_) _ ) = True
-- hasAdditionalViewConstraints (ViewSide [] _ ) = False

