{-# LANGUAGE OverloadedStrings, DeriveDataTypeable, RankNTypes, FlexibleInstances #-}

module BiYacc.Translation.BX.Rearrange where

import Prelude hiding (lookup, (<>))
import BiYacc.Language.Def
import BiYacc.Helper.Utils
import BiYacc.Translation.DataQuery
import BiYacc.Translation.BX.GenCaseCond
import BiYacc.Translation.BX.GenBasicUpdate


import qualified Data.Map as Map
import Data.Generics hiding (empty)

import Text.PrettyPrint as TPP

{-
Arith +> Exprs
ArithList (e:es) ints1 ints2 a x y  | id x = a, id x = y +>
  "hehe"
  (e +> Expr)
  {',' (es ~*> Expr) (ints1 ~*> Dummy) (ints2 ~*> Dummy)}*
  (x +> SDummy) (x +> SDummy);

It contains view-dependency (id x == a, id x == b),
non-linear variable usage (two (x +> SDummy) ),
Kleene* syntax ( {',' (es ~*> Expr) (ints1 ~*> Dummy) (ints2 ~*> Dummy)}* )

We translate it in the following way:
0. do the initial rearrange.

1. solve view-dependency by RearrV

-- solve dependency id x  = a.    source-side remain unchanged
rearrV (\ArithList ees ints1 ints2 a b x y -> ((ees, ints1, ints2, b, x, y), a) ) $
  Dep (\(_,_,_,_,x,y) -> id x) remaining...


-- solve dependency y = id x.     source-side remain unchanged
rearrV (\(ees, ints1, ints2, x, y) -> ((ees, ints1, ints2, x), y) ) $
  Dep (\((_,_,_,_,x,_)) -> id x) remaining...
-- Tuple  ... ---becomes---> Tuple ... rhs does not change

*** the several solve-dependency step can be merged into one to get fast program.


2. solve non-linear use of view variables by RearrV.
source-side need to be updated: (x0 +> SDummy) (x1 +> SDummy)
rearrV (\(ees, ints1, ints2, x) -> (ees, ints1, ints2, x0,x1) )
*** need to make sure x0 and x1 are fresh variables.

3. generate code for Kleene*-Syntax
identify which parts of the view are used for which update bundle.
e.g.: es ints1 and ints2 are used for one update “bundle1” and x (x0 and x1) for others
(if there are any)
ArithList (e:es) ints1 ints2 a x +>
  "hehe"
  (e +> Expr)
  {',' (es ~*> Expr) (ints1 ~*> SDummy) (ints2 ~*> SDummy)}*
  (x +> SDummy) (x +> SDummy);

we need to update both view side and source side (to use lensMap), we use a new constructor
"fromBundle" to distinguish this update from the normal ones. The update will call function
“lensMap” to do alignment. And call function “unzip” to zip several lists in views to match
the list in source: e.g.: change ([Arith],([Int],[Int])) to [(Arith,(Int,Int))]. (length of
the lists are guaranteed to be the same.)

Additionally, generate new Group of rules handling “basic” update used by lensMap:
(Arith, (Int, Int)) +> (String, (Expr, (SDummy, SDummy)))
(arith, (x, y))   +>  (',' (, ((arith +> Expr), ((x +> SDummy), (y +> SDummy)))))

*** bundle containing bundle is not allowed yet both for some practical reason and BX restrictions.
users can introduce another nonterminal for nested bundle syntax.

-}

{-
eval :: Rule -> (String, Rule)
eval aa@(NormalRule vs ss) | var-dependency-in-view vs = do
  (str, rule') <- hDep aa
  return (str, eval rule')

eval aa@(NormalRule vs ss) | var-non-linear-usage-in-source ss = do
  (str, rule') <- hDup aa
  return (str, eval rule')

eval a@(NormalRule vs ss) | bundle-syntax ss = do
-}

-- Variation of "everywhere'" (top-down) with an added stop condition
-- Guarded to let traversal cease if predicate q holds for x
everywhereBut' ::  GenericQ Bool -> GenericT -> GenericT
everywhereBut' q f x
    | q x       = x
    | otherwise = gmapT (everywhereBut' q f) (f x)


-- step0: identifying variables used in RHS and eliminated by view dependency.
-- (literals should NOT be kept. it will cause error in BiGUL. we do not go into detail here)
-- rearrange view to be right-dense 2-tuples of variables identified in step1.
init0RearrV :: Rule -> (Doc, Rule)
init0RearrV r@(NormalRule oldVSide oldSSide) | not (hasVVars oldVSide) = (TPP.empty, r)
init0RearrV (NormalRule oldVSide oldSSide)   | otherwise =
  let -- vars appeared in ViewSide (= used in Source-Side + vars eliminated)
      vSideVars = getVarFromV oldVSide
      preservedVPats = listify (isDesiredVPat vSideVars) oldVSide
      ViewSide vConstraints old_vPat = oldVSide

      -- initial rearrange only convert view-pattern to a (nested) tuple pattern
      newVSide = ViewSide vConstraints (buildTupleVPat preservedVPats)
      newVDoc = vPat2HsCode . buildTupleVPat $ preservedVPats
      oldVDoc = vPat2HsCode old_vPat

      rearrDoc = "\\" <> oldVDoc <+> "->" <+> newVDoc
      rearrDoc2 = "$(rearrV" <+> "[|" <+> rearrDoc <+> "|]" <+> ")" <+> "$"

  in  (rearrDoc2, NormalRule newVSide oldSSide)


-- step1: generate code for view dependency and return modified AST (2-tuples of variables)
vDep :: Rule -> (Doc, Rule)
vDep r@(NormalRule vSide _)   | not (hasVVarDep vSide) = (TPP.empty, r)
vDep (NormalRule vSide sSide) | otherwise =
  let ViewSide vConstraints old_vPat = vSide
      -- (pure constraints, elimination constraints)
      (pc, ec) = divideViewConstraints vConstraints
      -- (functions used to eliminate vars, representitive vars, eliminated vars)
      (elimFuns', repVars', elimVars')  = unzipVDep ec
      elimVarsStr  = elimVars'
      vSideVars = getVarFromV vSide
      rsvdVars  = vSideVars \\ elimVarsStr

  in  if not (chkChainDeps rsvdVars elimVarsStr)
      then error ("view dependency has cycles: " +^+ ppShow (rsvdVars `intersect` elimVarsStr))
      else

  let vLits = getVSideLits vSide
      rsvdVPats  = everything (++) (mkQ [] (saveDesiredVPat (rsvdVars ++ vLits))) vSide
      elimVPats0 = everything (++) (mkQ [] (saveDesiredVPat elimVarsStr)) vSide

      -- need to preserve the order of occurrence of eliminated vars
      elimVPats  = sortByGiven elimVarsStr elimVPats0

      -- make right-dense nested two-tuple
      (newRsvdVPat, newElimVPat)  = (buildTupleVPat rsvdVPats, buildTupleVPat elimVPats)
      rearrNewVPat = buildTupleVPat [newRsvdVPat, newElimVPat]

      -- new AST does not need variables that are eliminated: only reserved ones matter.
      newVConstraints = pc -- pure constraints remains
      newVSide    = ViewSide newVConstraints newRsvdVPat

      (oldVDoc, newVDoc) = (vPat2HsCode old_vPat, vPat2HsCode rearrNewVPat)

      rearrDoc1 = "\\" <> oldVDoc <+> "->" <+> newVDoc
      rearrDoc2 = "$(rearrV" <+> "[|" <+> rearrDoc1 <+> "|]" <+> ")" <+> "$"

      depCodeLHSPat = vPat2HsCode newRsvdVPat
      depCodeRHSPat = toDenseTupleDoc id $ zipWith (<+>) (map text elimFuns') (map text repVars')

      depCode1 = "\\" <> depCodeLHSPat <+> "->" <+> depCodeRHSPat
      depCode2 = "Dep" <+> parens depCode1 <+> "$"

  in  (rearrDoc2 $+$ (nest2 depCode2), NormalRule newVSide sSide)
  where
    sortByGiven :: [String] -> [ViewSidePattern] -> [ViewSidePattern]
    sortByGiven [] _ = []
    sortByGiven _ [] = []
    sortByGiven (x:xs) vps =
      let (a, vps') = partition (\vp -> isDesiredVPat [x] vp) vps
      in  a ++ sortByGiven xs vps'

    chkChainDeps :: [String] -> [String] -> Bool
    chkChainDeps xs ys = case xs `intersect` ys of
      []  -> True
      _:_ -> False


-- step2: generate code for variable duplication and return modified AST (2-tuples of variables)
vDup :: Rule -> (Doc, Rule)
vDup r@(NormalRule _ oldSSide) | not (hasDupVars oldSSide) = (TPP.empty, r)
vDup (NormalRule oldVSide oldSSide) | otherwise =
  let -- variables used more than once in source-side
      vLits = getVSideLits oldVSide
      vSideVars = getVarFromV oldVSide
      dupVars = findDup . getVarFromS $ oldSSide
      sSideVars  = nub . getVarFromS $ oldSSide
  in  if sort vSideVars /= sort sSideVars
      then error "view side vars ≠ source side vars. vDup. 0xD0."
      else

  let ViewSide vConstraints oldVPat = oldVSide

      -- flatten view side pattern to a list and duplicate view vars according to its usage
      preservedVPats    = everything (++) (mkQ [] (saveDesiredVPat (vSideVars ++ vLits))) oldVSide
      preservedVPatDup0 = everything (++) (mkQ [] (mkDup dupVars)) preservedVPats
      preservedVPatDup  = buildTupleVPat preservedVPatDup0 -- re-tuple it

      -- for each dupVar, we need to transform the vPat once to give it a new name
      rearrNewVPat = preservedVPatDup -- in rearrange. variable name must not be serialised
      (oldVDoc,newVDoc) = (vPat2HsCode oldVPat, vPat2HsCode rearrNewVPat)
      rearrDoc1 = "\\" <> oldVDoc <+> "->" <+> newVDoc
      rearrDoc2 = "$(rearrV" <+> "[|" <+> rearrDoc1 <+> "|]" <+> ")" <+> "$"

      newVPat = fst $ foldr serialiseVVar (preservedVPatDup, vSideVars) dupVars
      newVSide = ViewSide vConstraints newVPat
      newSSide = fst $ foldr serialiseSVar (oldSSide, vSideVars) dupVars
      -- now handle source-side similarly---------------

      -- new AST does not need variables that are eliminated. aka: only reserved ones matter.
  in  (rearrDoc2, NormalRule newVSide newSSide)

  where
    mkDup :: [String] -> ViewSidePattern -> [ViewSidePattern]
    mkDup names pp@(ASPattern var _ _) | var `elem` names = [pp,pp]
    mkDup names pp@(UpdVar var _)      | var `elem` names = [pp,pp]
    mkDup _ a = [a]

------------------------------------


-- step3: generate code for Kleene*-Syntax
-- (rearr doc, modified rule, generated basic rules for kleenestar-syntax)
-- literals should have all been dropped by init0RearrV before
sKleeneStar :: Rule -> (Doc, Rule, [Group])
sKleeneStar r@(NormalRule _ oldSSide) | not (hasKleeneSyntax oldSSide) = (TPP.empty, r, [])
sKleeneStar r | otherwise =
  let (initRearrSDoc, NormalRule oldVSide oldSSide) = init0RearrS r
      ViewSide vConstraints oldVPat = oldVSide
      SrcSide  oldSTy oldProdCon _  = oldSSide

      allUpds  = getSAllParts (deTupleSSide oldSSide)
      sKleenes = getSKleeneStarParts oldSSide
      sSingles = allUpds \\ sKleenes

      varGrps = map getVarFromS sKleenes
      varsNotInKleene = getVarFromV oldVSide \\ concat varGrps
      varVPatsNotInKleene = everything (++) (mkQ [] (saveDesiredVPat varsNotInKleene)) oldVPat

  -- 2) group parts of the view for each kleene*,
  -- put other update variables (“single syntax”, literals) not in kleene* to the front
  -- rearrV $( \(Arith e es1 es2 es3) -> (e , ((es1,es2) , (es3)))
      vPatsByVarGrps = map (\vars -> everything (++) (mkQ [] (saveDesiredVPat vars)) oldVPat) varGrps
      vPatTupleByVarGrps = map buildTupleVPat vPatsByVarGrps
      newVPat = buildTupleVPat (varVPatsNotInKleene ++ vPatTupleByVarGrps)

      (oldVDoc,newVDoc) = (vPat2HsCode oldVPat, vPat2HsCode newVPat)
      rearrVDoc1 = "\\" <> oldVDoc <+> "->" <+> newVDoc
      rearrVDoc2 = "$(rearrV" <+> "[|" <+> rearrVDoc1 <+> "|]" <+> ")" <+> "$"

  -- 2') accordingly update SrcSide.
  -- put other updates (“single syntax”, literals) not in kleene* to the front
  -- rearrS $( \(Exprs0 e esints1ints2 ints3 (x, _)) -> (e,((x, _), (esints1ints2, ints3)))

      (oldSDoc,newSDoc) = (sSide2HsCode oldSSide, sSide2HsCode (buildTupleSSide (sSingles ++ sKleenes)))
      rearrSDoc1 = "\\" <> oldSDoc <+> "->" <+> newSDoc
      rearrSDoc2 = "$(rearrS" <+> "[|" <+> rearrSDoc1 <+> "|]" <+> ")" <+> "$"

  -- 3) the update will call minEditDistance
  -- first handle vars in Kleene* parts, do not forget to add vars not in Kleene* parts
      newVPatsForKleene = map (\vpats -> (fuseVars vpats, length vpats)) vPatsByVarGrps
      newVVarsForKleene = map (\vpat -> (getVarName (fst vpat), snd vpat)) newVPatsForKleene
      newKleenes = zipWith updateBundle newVVarsForKleene sKleenes

      newVPatForKleene = buildTupleVPat (varVPatsNotInKleene ++ map fst newVPatsForKleene)

      newSSide = SrcSide oldSTy oldProdCon (sSingles ++ newKleenes)
      newVSide = ViewSide vConstraints newVPatForKleene
      newRule  = NormalRule newVSide newSSide

  -- 4) generate other (basic update) code for the list elements for the first layer (*)
  -- updOnSingleElem12 = ...   updOnSingleElem3  = ...
  -- remember to use **fresh names** for this updOnSingleElemN functions.
      basicRulesForBundles = catMaybes $ zipWith genKleeneBasicRule vPatTupleByVarGrps sKleenes
      basicGrps   = map (\r@(NormalRule vside sside) ->
                            Group (TypeDecl (getVPatTy vside) (getSrcSideTy sside)) [r])
                         basicRulesForBundles

  in  (initRearrSDoc $+$ (nest2 rearrVDoc2 $+$ nest2 rearrSDoc2), newRule, basicGrps)

  where
    -- these function are special (non exhausted pattern matching)
    -- the input data should not be of other form
    getVarName :: ViewSidePattern -> String
    getVarName (UpdVar var _) = var

    getVPatTy :: ViewSide -> DataTypeRep
    getVPatTy (ViewSide _ (ConsPat "TupleC" ty _)) = ty
    getVPatTy (ViewSide _ (UpdVar _ ty)) = ty
    getVPatTy a = error (ppShow a)

    getSrcSideTy :: SrcSide -> DataTypeRep
    getSrcSideTy (SrcSide ty _ _) = ty


--------------------------------
-- we can safely remove constructors (e.g. the "Expr0" in the pattern) and literals (terminals)
-- and then use tuple type instead

-- Expr1 "abc" (x +> Exp) {(z1 +> NT1) (z2 +> NT2) "hehe"}* Exp     generates:
-- \(Expr1 _ x kleene1 _) -> (x, kleene1)
-- in the future, should be \(Expr1 "abc" x kleene1 exp) -> (("abc", exp) , (x, kleene1))
init0RearrS :: Rule -> (Doc, Rule)
init0RearrS (NormalRule oldVSide oldSSide) =
  let vSideVars = getVarFromV oldVSide

      -- the stuff to be projected out are set to Projected
      sSide0 = markPrjNotInKleene . markPrjNoVarKleene $ oldSSide

      -- name for Kleene* must be fresh, initial invalid names are those vSideVars.
      (sSide1, invalid') = renameKleene vSideVars sSide0

      SrcSide _ _ units = sSide1
      newSSide = buildTupleSSide (deletePrj units)

      oldSDoc = genRearrSPat sSide1
      newSDoc = genRearrSPat newSSide

      rearrDoc = "\\" <> oldSDoc <+> "->" <+> newSDoc
      rearrDoc2 = "$(rearrS" <+> "[|" <+> rearrDoc <+> "|]" <+> ")" <+> "$"

  in  -- trace (ppShow sSide1) $
      (rearrDoc2, NormalRule oldVSide newSSide)


-- it is correct (will not touch Kleene) because it is top down.
-- mark parts (not in the Kleene* part) to be projected out in the $(update).
markPrjNotInKleene :: (Data a, Typeable a) => a -> a
markPrjNotInKleene = everywhereBut' (const False `extQ` ceaseKleene) (mkT markT)
  -- const True `extQ` ceaseKleene may cause error ...
  where
    markT :: UpdateUnit -> UpdateUnit
    -- the case covers (Left Terminal) and (Left Nonterminal)
    markT (UpdateUnitSingle (Left _) ) = Projected
    markT a = a

    ceaseKleene :: UpdateUnit -> Bool
    ceaseKleene (UpdateUnitBundle _ us) = True
    ceaseKleene _ = False

-- if a Kleene* does not contain any update variables, it is also need to be projected out.
markPrjNoVarKleene :: (Data a, Typeable a) => a -> a
markPrjNoVarKleene = everywhere (mkT markT)
  where
    markT :: UpdateUnit -> UpdateUnit
    markT b@(UpdateUnitBundle _ us) = if hasSVars b then b else Projected
    markT a = a


deletePrj :: (Data a) => a -> a
deletePrj = everywhere (mkT delT)
  where delT :: [UpdateUnit] -> [UpdateUnit]
        delT = filter (/= Projected)


-- rename Kleene* part to a fresh variable. (used to protect it from RearrS)
renameKleene :: (Data a) => [String] -> a -> (a, [String])
renameKleene invalid old = runState (everywhereM (mkM rename) old) invalid
  where
    rename :: UpdateUnit -> State [String] UpdateUnit
    rename (UpdateUnitBundle occr units) = do
      invalid <- get
      let (invalid', fresh) = mkFresh invalid "by_kleene"
          SrcSide ty _ _ = buildTupleSSide units
      put invalid'
      return $ ProtectBundle fresh ty occr units
    rename a = return a



updateBundle :: (String, Int) -> UpdateUnit -> UpdateUnit
updateBundle (newUV, varNum) (ProtectBundle _ ty occr units) =
  -- typeRep is not useful anymore. we just throw away some information.
  let newSSide@(SrcSide ty1 _ _) = buildTupleSSide units
  in  if ty == ty1
      then UpdateUnitFromBundle (newUV) (mkSimpleTyRep (tyAsFunName ty)) varNum newSSide
      else error "impossible. updateBundle. 0xC10."



-- fuse varaibles used to update one Kleene* part into a "big" one.
fuseVars :: [ViewSidePattern] -> ViewSidePattern
-- fuseVars []  = -- error "empty . hehe"
fuseVars ass = foldr1c eraseVPatListTy fuse ass
  where
    fuse vp1 vp2 =
      let (var1, ty1) = extract vp1
          (var2, ty2) = extract vp2
          (ConsPat "TupleC" ty _) =
            buildTupleVPat [UpdVar var1 (eraseListTy ty1), UpdVar var2 (eraseListTy ty2)]
      in  UpdVar (var1 ++ var2) (mkSimpleTyRep (tyAsFunName ty))
      -- typeRep is not useful anymore. we just throw away some information.

    extract (ASPattern var ty _) = (var, ty)
    extract (UpdVar var ty)      = (var, ty)

    eraseVPatListTy :: ViewSidePattern -> ViewSidePattern
    eraseVPatListTy (ASPattern var ty sub) = ASPattern var (eraseListTy ty) sub
    eraseVPatListTy (UpdVar var ty)        = UpdVar var (eraseListTy ty)



-- for each bundle and its corresponding ViewSidePattern, build a new Normal rule
genKleeneBasicRule :: ViewSidePattern -> UpdateUnit -> Maybe Rule
-- if there is only one unit, then there is no need to produce a new rule calling
-- basic updates. Otherwise it will generate a duplicate BiGUL function.
genKleeneBasicRule vPat (ProtectBundle _ _ _ [onlyOne]) = Nothing

genKleeneBasicRule vPat (ProtectBundle _ _ _ units) =
  let newSSide = buildTupleSSide $ map (everywhere (mkT eraseListTy)) units
      -- we erase List-type, because the basic rule for list-update is not of type
      -- for example, ([Arith],[Int]) +> [(String,(Expr,Dummy))]
      -- but rather (Arith,Int) +> [(String,(Expr, Dummy))]
      newVPat = everywhere (mkT eraseListTy) vPat
  in  Just $ NormalRule (ViewSide noConstraints newVPat) newSSide
  where noConstraints = []



-------------------------------
-- for each duplication, add an additional (unique) number to the name of the var.
-- additional arguments: (updated) invalid names
serialiseVVar :: Data a => String -> (a, [String]) -> (a, [String])
serialiseVVar dupVar (vPat, invalid) =
  runState (everywhereM (mkM (go dupVar)) vPat) invalid
  where
    go :: String -> ViewSidePattern -> State [String] ViewSidePattern
    go dupVar pp@(ASPattern var ty inner) | var == dupVar = do
      invalid <- get
      let (invalid', fresh) = mkFresh invalid dupVar
      put invalid'
      return $ ASPattern fresh ty inner
    go dupVar pp@(UpdVar var ty)   | var == dupVar = do
      invalid <- get
      let (invalid', fresh) = mkFresh invalid dupVar
      put invalid'
      return $ UpdVar fresh ty
    go _ a = return a


-- similar to serialiseVVar
serialiseSVar :: Data a => String -> (a, [String]) -> (a, [String])
serialiseSVar dupVar (sSide,invalid) =
  runState (everywhereM (mkM (go dupVar)) sSide) invalid
  where
    go :: String -> Update -> State [String] Update
    go dupVar (NUpdate uv st)   | dupVar == uv = do
      invalid <- get
      let (invalid', fresh) = mkFresh invalid dupVar
      put invalid'
      return $ NUpdate fresh st
    go dupVar (NUpdateWithDeepPat uv st deep)   | dupVar == uv = do
      invalid <- get
      let (invalid', fresh) = mkFresh invalid dupVar
      put invalid'
      return $ NUpdateWithDeepPat fresh st deep
    go _ a = return a


--  invalid names -> initial name -> (new invalid names, fresh name)
mkFresh :: [String] -> String -> ([String], String)
mkFresh invalid name = mk 0 invalid name
  where mk i invalid name | (name ++ show i) `elem` invalid = mk (i+1) invalid name
        mk i invalid name | otherwise = let n = name ++ show i in (n:invalid, n)

--------------------


-- use tuple to construct a view-side-pattern from a list of view-side-pattern
-- list must be non-empty
buildTupleVPat :: [ViewSidePattern] -> ViewSidePattern
buildTupleVPat [] = error "empty list. buildTupleVPat. 0xC0."
buildTupleVPat ps = foldr1c id twoTuple ps
  where twoTuple x xs =
          let ty = DataTypeRep "TupleT" [extractVarTy x, extractVarTy xs]
          in  ConsPat "TupleC" ty [x, xs]

buildTupleSSide :: [UpdateUnit] -> SrcSide
buildTupleSSide [] = error "empty list. buildTupleSSide. 0xC1."
buildTupleSSide uus = foldr1c (\u -> SrcSide (extractUpdSrcTy u) "" [u]) twoTuple uus
  where twoTuple x xs =
          let deep = UpdateUnitSingle (Right (DUpdate xs))
              ty = DataTypeRep "TupleT" [extractUpdSrcTy x, extractSSideTy xs]
          in  SrcSide ty "TupleC" [x, deep]

deTupleSSide :: SrcSide -> [UpdateUnit]
deTupleSSide (SrcSide ty "TupleC" [x, deep]) =
  let UpdateUnitSingle (Right (DUpdate xs))  = deep
      -- DataTypeRep "TupleT" [tyx, tyxs] = ty
  in  x: deTupleSSide xs
deTupleSSide (SrcSide _ _ units) = units

--------------------
-- generate code series which apply a function f to the i'th element in a tuple
-- e.g. : focuse4_3 f (_,(_,(x,_))) = f x. focuse2_2 f (_,x) = f x
-- however, finally not used ...
genFocuses m =
  foldr (\x xs -> x ++ "\n" ++ xs) "" [genFocuse k l | k <- [1..m] , l <- [1..m], k >= l]

genFocuse m n | m < n  = error "the first argument must not be less than the second"
genFocuse m n | m >= n =
  "focuse" ++ show m ++ "_" ++ show n +^+ "f" +^+ genPat m n +^+ "=" +^+ "f x"
  where
    genPat 0 0 = replicate (m - 1) ')'

    genPat k l | l > 1  = "(_," ++ genPat (k-1) (l-1)
    genPat 1 1 = "x" ++ genPat 0 0
    genPat k 1 | k > 1  = "(x," ++ genPat (k-1) 0

    genPat 1 0 = "_" ++ genPat 0 0
    genPat k 0 = "(_,"  ++ genPat (k-1) 0
----------------




-- resolve constraints later
-- [("y",("f","x")), ("b",("g","a")), ("a",("h","x")), ("c",("hhh","b"))]
-- resolveDep :: [(String, (String,String))] -> [(String, (String,String))]
-- resolveDep deps =
--   let chain = getDeps deps
--   in  case chain of
--     [x] -> let xxx = filter (\dep -> fst x == snd (snd dep)) deps
--            in  map
--     _:_ -> resolveDep ...

-- getChainDeps :: [(String, (String,String))] -> [(String, (String,String))]
-- getChainDeps deps = [dep | dep <- deps, fst dep `elem` map (snd . snd) deps]

