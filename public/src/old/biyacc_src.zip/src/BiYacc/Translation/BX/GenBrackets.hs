{-# LANGUAGE OverloadedStrings #-}

module BiYacc.Translation.BX.GenBrackets where

import BiYacc.Language.Def
import BiYacc.Helper.Utils
import BiYacc.Translation.BX.GenCaseCond
import BiYacc.Translation.BX.GenBasicUpdate
import BiYacc.Translation.BX.Rearrange

import Data.Map (Map, union, unions, singleton)
import qualified Data.Map as Map
import Text.PrettyPrint as TPP hiding (empty)
import qualified Text.PrettyPrint as TPP

addBrkPath :: Doc -> ProdRuleCons -> Reader GenBiGULEnv Doc
addBrkPath dftPatDoc prdName = do
  (_, bracketPaths, brkConsName) <- asks fourth4
  nameEigenEnv <- asks fst4
  case Map.lookup prdName bracketPaths of
    -- no need to generate code for creating parentheses
    Nothing -> return dftPatDoc
    Just brkPaths ->
      let completePath = map text (init brkPaths) ++ [dftPatDoc]
          brkRuleFields = fst (fromJ "impossible . addBrkPath. 0x1F." (Map.lookup brkConsName nameEigenEnv))
          brkDoc = foldr (tuneBrkProd brkConsName brkRuleFields) TPP.empty completePath
          -- the last element of the brkPaths is the constructor (prdName).
          -- we need to replace it with the doc generated for the default pattern
          -- meaning that we first goes to bracket production, then goes back again
          -- to the current production rule to produce what it is supposed to produce.
          cond0 = "if needParen parentDisAmb" <+> parens ("lookupDisAmb parentDisAmb"
                    <+> doubleQuotes (text prdName) <+> "disAmbEnv") <+> "myBranch"
          cond1 = "then" <+> brkDoc
          cond2 = "else" <+> dftPatDoc
      in  return $ cond0 $$ cond1 $$ cond2

    -- for the bracket production. we need to replace
    -- its (only) nonterminal (Right ...) with the already generated doc
    -- and create default layouts (Left ...) .
    -- e.g. :   Factor ->  "(" FExpr ")"   is represented in CST by
    -- (Factor3 String FExpr String). We need to generate :  (Factor3 " " contentWithinParen " ")
  where
    tuneBrkProd :: String -> [CTypeField] -> Doc -> Doc -> Doc
    tuneBrkProd brkConsName brkRuleFields consName xs | render consName == brkConsName =
      parens $ consName <+> hsep (map (ff11 xs) brkRuleFields)
    tuneBrkProd _ _ consName xs = parens (consName <+> xs)

    ff11 :: Doc -> CTypeField -> Doc
    ff11 xs (CTypeFieldSingle field) = either (const (doubleQuotes " ")) (const xs) field
    ff11 xs (CTypeFieldBundle ZeroOrMore fields) = genTuple (ff11 xs) fields




------------ buildEnvironment for adding parentheses
-- e.g.: given "Add _ _", find the route ["ETerm", "TFactor", "FExpr" (Paren), ..., "Add"]
-- then we have the map "Add" ------> ["ETerm", "TFactor", "FExpr", ..., "Add"]

buildBrkPaths :: TypeNameEnv -> Name2PatEnv -> Pat2NameEnv -> BracketAttrEnv -> PathsViaBracket
buildBrkPaths tyNameEnv nameEigenEnv pat2NameEnv brkAttrEnv =
  if  brkAttrEnv == Nothing then Map.empty else
      let Just (brkConsName, brkConsType, _) = brkAttrEnv
          allNonts = keys tyNameEnv
          prePath  = expand $ execState (pathToCertainProd allNonts brkConsName) Map.empty
          consNameHasRoutesToBrkRules = keys prePath
          postPath = pathFromCertainProd brkConsName consNameHasRoutesToBrkRules
          completePath = mergeWithKey (\_ a b -> Just (a ++ tail b)) (const Map.empty) (const Map.empty) prePath postPath
      in  completePath

  where
  addToState :: ProdRuleType -> Paths -> State (Map ProdRuleType Paths) ()
  addToState rTy newRoute = modify (union (singleton rTy newRoute))

  pathToCertainProd :: [ProdRuleType] -> ProdRuleCons -> State (Map ProdRuleType Paths) ()
  pathToCertainProd [] certainProd = return ()
  pathToCertainProd rTys certainProd = do
    -- for each Nonterminal, check if there is a way to the “bracket attribute” production rule.
    routesMap <- get
    let lastState = keys routesMap
    forM_ rTys
      (\srcNont -> do
        let maybeConsForNextRoute = canReachCertainRule srcNont certainProd routesMap
        case maybeConsForNextRoute of
          Nothing -> return ()
          -- if there is, add the route to the state (a Map environment)
          Just consName -> do
            -- two conditions. 1. the nonterminal rTy contains the “bracket attribute” production rule.
            -- 2. the nonterminal rTy need other nonterminals as bridge to the “bracket attribute” production rule.
            -- e.g. fst . fromJust . lookup consName $ nameEigenEnv will produce
            -- for condition 1) [Left "(",Right "Expr",Left ")"]  .    for condition 2) [Right "Factor"]
            -- WARNING. the procedure concatMap extractTypeField is likely to be wrong. But we do not hope to meet the wrong case at run time. fix it later.
            let [nextNont] = rights . concatMap extractTypeField . fst .
                             fromJ "impossible. maybeConsForNextRoute. 0x0E." .
                             Map.lookup consName $ nameEigenEnv
                newRoute = case Map.lookup nextNont $ routesMap of
                    Nothing -> [consName]                           -- condition 1.
                    Just furtherRoutes -> consName : furtherRoutes  -- condition 2.
            addToState srcNont newRoute)

    -- get the current routes, excluding the Nonterminals in the current routes (already
    -- has the way to the “bracket attribute” production rule), enter the next iteration.
    routesMap' <- get
    let newState = keys routesMap'
    if sort lastState == sort newState
      then return ()
      else pathToCertainProd (rTys \\ newState) certainProd

  extractTypeField :: CTypeField -> [ETNT]
  extractTypeField (CTypeFieldSingle etnt) = [etnt]
  extractTypeField (CTypeFieldBundle _ fields) = concatMap extractTypeField fields -- WARNING. error here

  -- two kinds of Nonterminals can reach the “bracket attribute” production rule.
  -- 1. the Nonterminal can produce the “bracket attribute” production rule (inCertainGroup)
  -- 2. the Nonterminal has a production rule which produce only a Nonterminal', and Nonterminal' can
  --    reach the “bracket attribute” production rule using the environment. (oneStepToOtherRoute)
  canReachCertainRule :: ProdRuleType -> ProdRuleCons -> Map ProdRuleType Paths -> Maybe ProdRuleCons
  canReachCertainRule srcNont dstConsName routesMap = case (inCertainGroup srcNont dstConsName) of
    Nothing -> oneStepToOtherRoute srcNont routesMap
    justName -> justName
    where
      inCertainGroup :: ProdRuleType -> ProdRuleCons -> Maybe ProdRuleCons
      inCertainGroup srcNont dstConsName =
        case Map.lookup srcNont tyNameEnv of
          Nothing -> error "impossible. inCertainGroup. 0x01"
          Just conNames ->
            if elem dstConsName conNames
              then Just dstConsName
              else Nothing

      oneStepToOtherRoute :: ProdRuleType -> Map ProdRuleType Paths -> Maybe ProdRuleCons
      oneStepToOtherRoute srcNont routesMap =
        case Map.lookup srcNont tyNameEnv of
          Nothing -> error "impossible. oneStepToOtherRoute. 0x02"
          Just consNames ->
            -- consFieldss e.g.: [[Right "Expr", Left "+", Right "Term"], [...], [Right "Term"]]
            let consFieldss = map (fst . fromJ "impossible. oneStepToOtherRoute. 0x03" . flip Map.lookup nameEigenEnv) consNames
            in  case catMaybes (map selPossibleRoute consFieldss) of
                  nextProdRules@(_:_) ->
                    -- I do not think the grammar of a well-defined programming language can have more than one ways
                    -- reaching the bracket attribute production rule. But if it is, arbitrary choose one.
                    case catMaybes (map forEachElem nextProdRules) of
                      x:_ -> Just x
                      _   -> Nothing
                  _ -> Nothing
        where
          forEachElem :: [ETNT] -> (Maybe ProdRuleCons)
          forEachElem [Right possibleNextNont] =
            case Map.lookup possibleNextNont routesMap of
              Nothing -> Nothing
              Just _  -> Just . fromJ "impossible. forEachElem. 0x04." $ Map.lookup ([CTypeFieldSingle (Right possibleNextNont)], srcNont) pat2NameEnv -- should not fail
          forEachElem _ = Nothing

          selPossibleRoute :: [CTypeField] -> Maybe [ETNT]
          selPossibleRoute cTypeFields =
            if length cTypeFields == 1 && length (rights (catMaybes (map selPossibleRoute1 cTypeFields))) == 1
            then Just (catMaybes (map selPossibleRoute1 cTypeFields))
            else Nothing

          selPossibleRoute1 :: CTypeField -> Maybe ETNT
          selPossibleRoute1 (CTypeFieldSingle etnt) = Just etnt
          selPossibleRoute1 (CTypeFieldBundle _ _) = Nothing

          -- selPossibleRoute :: [ETNT] -> Maybe [ETNT]
          -- selPossibleRoute tnts = if length tnts == 1 && length (rights tnts) == 1 then Just tnts else Nothing

  -- previous it is a map from “a nonterminal” to the “routes to the bracket attribute”
  -- now build a new map expanded from “each production rule of that nonterminal” to the “routes to the bracket attribute”
  expand :: Map ProdRuleType Paths -> PathsViaBracket
  expand = foldrWithKey ff Map.empty
    where
      ff :: ProdRuleType -> Paths -> PathsViaBracket -> PathsViaBracket
      ff rTy rRoutes done =
        case Map.lookup rTy tyNameEnv of
          Nothing -> error "impossible . expand. 0x05."
          Just consNames ->
            union done $ unions $ [singleton consName rRoutes | consName <- consNames]


  -- single source shortest path is almost reasonable fast ...
  pathFromCertainProd :: ProdRuleCons -> Paths -> PathsViaBracket
  pathFromCertainProd certainProd destConss =
    -- trace (show destConss) $
    -- WARNING. possbily the same error as above warning.
    let [nextNont] = rights . concatMap extractTypeField . fst .
                     fromJ "impossible. pathFromCertainProd. 0x06." .
                     Map.lookup certainProd $ nameEigenEnv
        allNonts   = keys tyNameEnv
        results    = catMaybes $ map (forEachElem allNonts) destConss -- results [(destCons, paths), ...]
        envs       = map (\(destCons, paths) -> singleton destCons (certainProd:paths)) results
    in  unions $ envs
    where
      forEachElem :: [ProdRuleType] -> ProdRuleCons -> Maybe (ProdRuleCons, Paths)
      forEachElem allNonts destCons =
        let pathsFromCertainProd = evalState (findPath certainProd destCons allNonts) Map.empty
        in  liftM ((,) destCons) pathsFromCertainProd

  -- the return value “paths” does not include the first path “orgnConsName” itself
  findPath :: ProdRuleCons -> ProdRuleCons -> [ProdRuleType] -> State (PathsViaBracket) (Maybe Paths)
  findPath orgnConsName dstConsName allNonts = do
    previousState <- get
    let pathss = catMaybes $ map (\srcNont -> findPathWithEnv srcNont previousState) allNonts
    -- there are always some nonterminals which can reach dstConsName
    case filter (\(consName, _) -> consName == orgnConsName) pathss of
      -- the last step (base case). There is a direct path from orgnConsName
      (_, paths):_ -> return (Just paths)
      []  -> do mapM_ (addToState) pathss -- need more iterations
                newState <- get
                if previousState == newState
                  then -- trace ("newState: " ++ ppShow newState) $
                       -- from a certain nonterminal, sometimes there is not way to go back to itself (not cyclic).
                       return Nothing
                  else findPath orgnConsName dstConsName allNonts
    where
      addToState :: (ProdRuleCons, Paths) -> State (PathsViaBracket) ()
      addToState (nextConsName, paths) = modify (union (singleton nextConsName paths))

      findPathWithEnv :: ProdRuleType -> PathsViaBracket -> Maybe (ProdRuleCons, Paths)
      findPathWithEnv srcNont currentState =
        -- 1. one step finish.
        let dstNont   = snd . fromJ "impossible. findPathWithEnv. 0x08" $ Map.lookup dstConsName nameEigenEnv
            consNames = -- trace ("\nsrcNont: " ++ srcNont ++ "\n" ++ "dstNont :" ++ dstNont) $
                        fromJ "impossible. findPathWithEnv. 0x09." (Map.lookup srcNont tyNameEnv) -- all constructor names of a nonterminal
            -- all fileds of a consName
            tntss     = -- trace ("\nconsNames :" ++ ppShow consNames) $
                        map (\consName -> (consName, fst . fromJ "impossible. findPathWithEnv. 0x0A" $ Map.lookup consName nameEigenEnv)) consNames
            -- possible conditions： 1) fields has and only has a (Right Nonterminal)
            -- 2) constructor name == originalConstructorName
            possCond1 (condName, xs) = 1 == length xs && 1 == length (rights (concatMap extractTypeField xs))
            possCond2 (condName, xs) = orgnConsName == condName
            adjustedFields = case filter possCond2 tntss of
              -- delete (Left Terminals) fields if the consName is the orgnConsName
              [onlyOne] -> [(fst onlyOne, filter isRight . concatMap extractTypeField . snd $ onlyOne)]
              [] -> map (\e -> (fst e, filter isRight . concatMap extractTypeField $ snd e)) . filter possCond1 $ tntss

        in  case filter ( \(_, [Right nont]) -> nont == dstNont) adjustedFields of
              -- there is only one element in the field and the element is dstNont
              [(nextConsName, _)] -> Just (nextConsName, [dstConsName])

              -- The element is not dstNont. Cannot reach the dstNont directly. Try building the path using previous environment (state)
              [] -> case catMaybes (map searchTheWay adjustedFields) of -- trace ("\npossibletntss: " ++ ppShow adjustedFields) $
                      [] -> Nothing
                      [(nextConsName, paths)] -> Just (nextConsName, paths) -- WARNING: are there more than one ways?
        where
          searchTheWay :: (ProdRuleCons, [ETNT]) -> Maybe (ProdRuleCons, Paths)
          searchTheWay (consName,[Right nont]) = liftM ((,) consName ) (searchWayFromNextNont nont currentState)

          searchWayFromNextNont :: ProdRuleType -> PathsViaBracket -> Maybe Paths
          searchWayFromNextNont nont currentState = -- trace ("Nont: " ++ nont) $
            case Map.lookup nont tyNameEnv of
              Nothing -> error "impossible. searchWayFromNextNont. 0x0B"
              Just consNames ->
                case catMaybes $ map (\consName -> liftM ((,) consName)
                                                   (Map.lookup consName currentState)) consNames of
                  [] -> Nothing
                  [(nextnextConsName, route)] -> Just (nextnextConsName : route) -- remember modify here


