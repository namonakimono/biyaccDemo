{-# LANGUAGE OverloadedStrings #-}

module BiYacc.Translation.ISO.GenPrinter (genPrinter) where

import BiYacc.Language.Def
import BiYacc.Parser.Concrete
import BiYacc.Helper.Utils

import Debug.Trace

-- the printer code for "from CST back to program text"
genPrinter :: CAST -> String
genPrinter (CAST _ dts) = concat (map prtEachPrinter dts)

prtEachPrinter :: CDataType -> String
prtEachPrinter (CDataType dataName defs) =
  let funName = "pp" ++ dataName
  in  foldr (\x xs -> prtPrts funName x ++ xs) "" defs ++ "\n"

prtPrts :: String -> CTypeDef -> String
prtPrts funName (CTypeDef consName fields _) =
  let strs  = evalState (mapM prtPrtRes fields) 0
      strs' = if length strs /= 0
                then foldr1 (\x xs -> x ++ " ++ " ++ xs) strs
                else show consName -- null node
  in  funName ++ " (" ++ consName ++ prtPrtPatt fields ++ ") =" ++ strs' ++ "\n"

prtPrtPatt :: [a] -> String
prtPrtPatt = prtPrtPatt2 0
  where
    prtPrtPatt2 :: Int -> [a] -> String
    prtPrtPatt2 n (x:xs) = " s" ++ show n ++ prtPrtPatt2 (n + 1) xs
    prtPrtPatt2 n [] = ""

-- foldr (\(te0,te1,...) -> te0 ++ te1) ""
-- [(String, [(String, Expr)])]
-- foldr (\(te0, te1) -> te0 ++ foldr (\(te0, te1) xs -> te0 ++ show te1 ++ xs) te1 ) xe
prtPrtRes :: CTypeField -> State Int String
prtPrtRes (CTypeFieldSingle x) = prtPrtRes2 x
prtPrtRes (CTypeFieldBundle ZeroOrMore xs) = do
  n <- get
  strs <- mapM prtPrtRes xs
  let bundleVarsPat = render (genSerialTuple n (const "s") xs)
      vars = "\\" ++ bundleVarsPat ++ " xs"
      opt  = foldr1 (\s ss -> s ++ " ++ " ++ ss) strs
      accPar  = " ++ xs"

  let foldPart = "foldr " ++ wrapStrInParen (vars ++ " -> " ++ opt ++ accPar)

  -- n' <- get
  -- let overCounted = length xs - 1
  -- put (n' - overCounted)
  put (n + 1)

  let str100 = foldPart ++ " \"\" "  ++ ("s" ++ show n)
  return $ str100

prtPrtRes (CTypeFieldBundle OneOrMore xs) = prtPrtRes (CTypeFieldBundle ZeroOrMore xs)

prtPrtRes (CTypeFieldBundle ZeroOrOne xs) = do
  n <- get
  strs <- mapM prtPrtRes xs
  let str100 = "case " ++ ("s" ++ show n) ++ " of " ++
                  "\n  " ++ "Nothing -> " ++ " \"\" " ++
                  "\n  " ++ "Just " ++ render (genSerialTuple n (const "s") xs) +^+ "->" +^+
                                       wrapStrInParen (foldr1 (\s ss -> s ++ " ++ " ++ ss) strs)
  put (n + 1)
  return $ str100


prtPrtRes2 :: ETNT -> State Int String
prtPrtRes2 (Left  x) = do
  n <- get
  modify(+1)
  return $ " " ++ show x ++ " ++ s" ++ show n
prtPrtRes2 (Right x) = do
  n <- get
  modify(+1)
  return $ (judge1 x n) ++ show n

judge1 x n =
  if (x == "BiNumericTy")
    then " fst s" ++ show n ++ " ++ snd s"
    else if (x == "BiIdentifyTy")
      then " fst s" ++ show n ++ " ++ snd s"
      else if (x == "BiStringTy")
        then show "\"" +^+ "++ fst s" ++ show n +^+ "++" +^+ show "\"" +^+ "++ snd s"
        else if (x =="BiBoolStrTy")
          then " fst s" ++ show n ++ " ++ snd s"
          else " " ++ ("pp" ++ x) ++ " s"
