{-# LANGUAGE OverloadedStrings, FlexibleContexts #-}

module BiYacc.Translation.ISO.GenLexer (genLexer) where

import qualified Data.List as List (null, sortBy)
import Data.Char (isAlpha)
-- import Data.Map (Map)
-- import qualified Data.Map as Map
import Prelude hiding (lookup)
import BiYacc.Language.Def
import BiYacc.Parser.Concrete
import BiYacc.Helper.Utils

import qualified Data.Map as Map
import Data.Map hiding (foldl, foldr, map, drop, filter, (\\))
import Data.Generics hiding (GT, LT, EQ)

import Control.Monad.State (MonadState, evalState, get, put)

import Debug.Trace

------------
-- (strFlag, nameFlag, numericFlag)
markPrim :: (Data a) => a -> (Bool, Bool, Bool)
markPrim cAst =
  let res = nub $ everything (++) (mkQ [] go) cAst
  in ("String" `elem` res, "Name" `elem` res, "Numeric" `elem` res)
  where
    go :: ETNT -> [String]
    go (Right "String")  = ["String"]
    go (Right "Name")    = ["Name"]
    go (Right "Numeric") = ["Numeric"]
    go _ = []


mkEscape :: String -> String
mkEscape = foldr (\e es -> f e ++ es) []
  where f '\"' = "\\\""
        f '\\' = "\\\\"
        f c    = [c]

---------------------------

--          terminals env -> [token] -> (lineComm, (blockStartComm, blockEndComm))
prtLexer :: TerminalToTokenIdEnv -> [String] -> (String, (String, String)) -> String
prtLexer (TerminalToTokenIdEnv tokEnv) cs comntSym@(lComm, (bCommS, bCommE)) =
  foldr newlineS ""
  ["isWhiteSpace :: Char -> Bool"
  ,"isWhiteSpace c = elem c \" \\n\\t\\r\\v\""
  ,""
  ,"isValidName :: Char -> Bool"
  ,"isValidName c = isAlphaNum c || c == '_'"
  ,""
  ,"isWildRangeName :: Char -> Bool"
  ,"isWildRangeName c = isAlphaNum c || any ((==) c) \"-_~.:;#&@{}[]()'\""
  ,""
  ,"adhockSeparatable :: Char -> String -> Bool"
  ,"adhockSeparatable c [] = True"
  ,"adhockSeparatable c (sep:_) = isWhiteSpace sep"
  ,"  || (isValidName c && not (isValidName sep))"
  ,"  || (not (isValidName c) && isValidName sep)"
  ,"  || (isSymbol c || isPunctuation c) && (isSymbol sep || isPunctuation sep)"
  ,""
  ,"lexer :: String -> [Token]"
  ,"lexer [] = []"
  ,if List.null lComm
    then ""
    else "lexer (" ++ expand lComm ++ ":cs) = lexerComment1 \"" ++ mkEscape (reverse lComm) ++ "\" cs"
  ,if List.null bCommS
    then ""
    else "lexer (" ++ expand bCommS ++ ":cs) = lexerComment2 \"" ++ mkEscape (reverse bCommS) ++ "\" cs"
  ,concat (map prtLexRule cs)
  ,"lexer (c:cs) | isDigit c ="
  ,"  let (var, rest) = span isDigit (c:cs)"
  ,"  in case rest of"
  ,"        '.':rs -> let (var2, rest2) = span isDigit rs"
  ,"                 in  if not (null var2)"
  ,"                     then TokenNumeric (var ++ \".\" ++ var2, \"\") : lexer rest2"
  ,"                     else TokenNumeric (var, \"\") : lexer rest"
  ,"        _     -> TokenNumeric (var, \"\") : lexer rest"
  ,"  | isWhiteSpace c = let (ws, rest) = span isWhiteSpace (c:cs)"
  ,"      in TokenWS  ws  : lexer rest"
  ,"  | isValidName c = let (var, rest) = span isValidName (c:cs)"
  ,"      in case var of"
  ,"          _ -> TokenName (var, \"\") : lexer rest"
  ,"lexer ('\"':cs) = lexerString \"\" cs"
  ,""
  ,"lexer x = error $ \"Non-exhaustive patterns in function lexer. First unconsumed 100 characters:\\n\" ++ take 100 x"
  ,""
  ,"lexerComment1 :: String -> String -> [Token]"
  ,"lexerComment1 res [] = [TokenWS (reverse res)]"
  ,"lexerComment1 res ('\\n':cs) = TokenWS (reverse ('\\n':res)) : lexer cs"
  ,"lexerComment1 res (c:cs) = lexerComment1 (c:res) cs"
  ,""
  ,"lexerComment2 :: String -> String -> [Token]"
  ,"lexerComment2 res [] = [TokenWS (reverse res)]"
  ,"lexerComment2 res (" ++ expand (bCommE) ++ ":cs) = TokenWS (reverse (" ++
      expand (reverse bCommE) ++ ":res)) : lexer cs"
  ,"lexerComment2 res (c:cs) = lexerComment2 (c:res) cs"
  ,""
  ,"lexerString :: String -> String -> [Token]"
  ,"lexerString res ('\\\\':'\\\\':cs) = lexerString ('\\\\':'\\\\':res) cs"
  ,"lexerString res ('\\\\':'\"':cs) = lexerString ('\"':'\\\\':res) cs"
  ,"lexerString res ('\"':cs) = TokenStr (reverse res, \"\") : lexer cs"
  ,"lexerString res (c:cs) = lexerString (c:res) cs"
  ,"lexerString res [] = [TokenStr (reverse res, \"\")]"
  ,""
  ]
  where
    prtLexRule :: String -> String
    prtLexRule s =
      let Just tok = lookup s tokEnv
      in  "lexer (" ++ expandWithMark s ++ ":cs"  ++ ") | adhockSeparatable c1 cs" +^+ "="
          ++ "\n  " ++ tok +^+ (show "") +^+ ":" +^+ "lexer cs\n"

    -- prtLexCase :: String -> String
    -- prtLexCase s =
    --   let Just tok = lookup s tokEnv
    --   in  "          " ++ show s ++ " -> " ++ tok ++ " \"\" : lexer rest\n"

    expand :: String -> String
    expand []  = show ""
    expand [c] = show c
    expand (c:cs) = '\'':(mkEscape [c]) ++ ('\'':':':(expand cs))

    expandWithMark :: String -> String
    expandWithMark [c] = "c1@" ++ show c
    expandWithMark (c:cs) = '\'':(mkEscape [c]) ++ ('\'':':':(expandWithMark cs))


--------------------
-- TOKEN data type and its show instance
prtData :: (Bool, Bool, Bool) -> TerminalToTokenIdEnv -> [String] -> String
prtData (strFlag, nameFlag, numFlag) (TerminalToTokenIdEnv tokEnv) s =
  foldr newlineS ""
  [ "data Token ="
  , "    TokenWS  String"
  , "  | TokenStr (String, String)"
  , "  | TokenName (String, String)"
  , "  | TokenNumeric (String, String)"
  , prtEachCon s
  , "  deriving (Show, Eq)"]

  where
    prtEachCon :: [String] -> String
    prtEachCon [] = ""
    prtEachCon (c:cs) =
      let Just tok = lookup c tokEnv
      in  "  | " ++ tok ++ " String\n" ++ prtEachCon cs


prtTPrinter :: (Bool, Bool, Bool) -> TerminalToTokenIdEnv -> [String] -> String
prtTPrinter (strFlag, nameFlag, numFlag) (TerminalToTokenIdEnv tokEnv) s =
  prtEachShow s ++
  (if strFlag    then "pToken (TokenStr (s, ws)) = s ++ ws\n" else "") ++
  (if nameFlag   then "pToken (TokenName (s, ws)) = s ++ ws\n" else "") ++
  (if numFlag    then "pToken (TokenNumeric (s, ws)) = s ++ ws\n" else "") ++
  "pToken (TokenWS s) = s\n"
  where
    prtEachShow :: [String] -> String
    prtEachShow [] = ""
    prtEachShow (c:cs) = let Just tok = lookup c tokEnv in
      "pToken (" ++ tok ++ " ws) = " ++ show c ++ " ++ ws" ++ "\n" ++ prtEachShow cs



---------------------
newtype TerminalToTokenIdEnv = TerminalToTokenIdEnv (Map String String) deriving (Show, Eq)
newtype TokenIdToTerminalEnv = TokenIdToTerminalEnv (Map String String) deriving (Show, Eq)

-- generating Map from terminal to its Token
genTerminalMap :: CAST -> State Int (TerminalToTokenIdEnv, TokenIdToTerminalEnv)
genTerminalMap (CAST _ datatypes) = do
  env1 <- liftM unions' $ mapM gen2 datatypes
  let TerminalToTokenIdEnv nakedEnv1 = env1
      env2 = TokenIdToTerminalEnv . fromList . map (\(k,a) -> (a,k)) . toList $ nakedEnv1
  return (env1, env2)
  where
    gen2 :: CDataType -> State Int TerminalToTokenIdEnv
    gen2 (CDataType _ ctypedefs) = liftM unions' $ mapM gen3 ctypedefs

    gen3 :: CTypeDef -> State Int TerminalToTokenIdEnv
    gen3 (CTypeDef _ fields _) = liftM unions' $ mapM gen4 fields

    gen4 :: CTypeField -> State Int TerminalToTokenIdEnv
    gen4 (CTypeFieldSingle (Left terminal)) = do
      i <- get
      modify (+1)
      return $ TerminalToTokenIdEnv $ singleton terminal ("Token" ++ show i)
    gen4 (CTypeFieldBundle _ fields) = liftM unions' $ mapM gen4 fields
    gen4 _ = return (TerminalToTokenIdEnv Map.empty)

    unions' :: [TerminalToTokenIdEnv] -> TerminalToTokenIdEnv
    unions' list =
      let env' = TerminalToTokenIdEnv . unions $ map (\(TerminalToTokenIdEnv env) -> env) list
      in  env'

-- generating Happy program
prtRules :: TerminalToTokenIdEnv -> CAST -> State Int String
prtRules (TerminalToTokenIdEnv tokEnv) (CAST _ cdatatypes) = do
  let (CDataType dataName _) = (cdatatypes !! 0)
  defs <- mapM prtEachRule cdatatypes
  return $ foldr1 (++)
    ["%%\n\n"
    ,"Prog : " ++ dataName ++ " { $1 }\n"
    ,"   | { " ++ dataName ++ "Null }\n\n"
    ,concat defs]
  where
    -- 每行可能都会产生数个newSyntaxProdRule
    prtEachRule :: CDataType -> State Int String
    prtEachRule (CDataType dataName defs) = do
      (eachLineStrs, newSyntaxProdRules) <- liftM unzip (mapM prtDefs2 defs)
      let hehe = foldl1 (\xs x -> xs ++ "\n  | " ++ x) eachLineStrs
          newSyntaxProdRules' = filter (not . List.null) newSyntaxProdRules
      return $ dataName ++ "\n  : " ++ hehe `newlineSS` (foldl newlineSS "" newSyntaxProdRules')

    prtDefs2 :: CTypeDef -> State Int (String, String)
    prtDefs2 (CTypeDef consName fields _) = do
      (symbols, envs) <- liftM unzip (mapM prtEachDef2 fields)
      let env = unions envs
          str1 = foldl1 (\xs x -> xs ++ " " ++ x) symbols
          str2 = str1 ++ " { " ++ consName ++ " " ++ prtEachDef4 fields ++ "}"
          -- genCases = \k v -> k ++ "\n  : " ++ "{- empty -} " ++ "{ [] }" ++ "\n  " ++ v
          -- str3 = foldr newlineSS "" . elems . mapWithKey genCases $ env
          str3 = foldr newlineSS "" . elems $ env
      return $ (str2, str3)


    -- (production rule, new production rule for handling ZeroOrMore/ZeroOrOne occurence syntax)
    prtEachDef2 :: CTypeField -> State Int (String, Map String String)
    prtEachDef2 (CTypeFieldSingle etnt) = return (prtEachDef3 etnt, Map.empty)

    prtEachDef2 (CTypeFieldBundle ZeroOrMore fields) = do
      (symbols, envs) <- liftM unzip (mapM (prtEachDef2) fields)
      i <- get
      let nonTName = "ZeroOrMore" ++ show i
      let newSyntaxProdRule = genZeroOrMoreBaseCase nonTName
                                ++ "\n  " ++ genZeroOrMoreRecCase nonTName symbols
      modify (+1)
      let env' = singleton nonTName newSyntaxProdRule `union` (unions envs)
      return (nonTName, env')

    prtEachDef2 (CTypeFieldBundle OneOrMore fields) = do
      (symbols, envs) <- liftM unzip (mapM (prtEachDef2) fields)
      i <- get
      let nonTName = "OneOrMore" ++ show i
      let newSyntaxProdRule = genOneOrMoreBaseCase nonTName symbols ++ "\n  "
                                ++ genZeroOrMoreRecCase nonTName symbols
      modify (+1)
      let env' = singleton nonTName newSyntaxProdRule `union` (unions envs)
      return (nonTName, env')

    prtEachDef2 (CTypeFieldBundle ZeroOrOne fields) = do
      (symbols, envs) <- liftM unzip (mapM (prtEachDef2) fields)
      i <- get
      let nonTName = "ZeroOrOne" ++ show i
      let newSyntaxProdRule = genZeroOrOne nonTName symbols

      modify (+1)
      let env' = singleton nonTName newSyntaxProdRule `union` (unions envs)
      return (nonTName, env')


    prtEachDef3 :: ETNT -> String
    prtEachDef3 (Left  x) =
      case lookup x tokEnv of
        Nothing  -> error "impossible. prtEachDef3. 0x20."
        Just tok -> lowerTok tok -- ++ " "
    prtEachDef3 (Right "String")  = "str"
    prtEachDef3 (Right "Name")    = "name"
    -- prtEachDef3 (Right "Integer") = "integer"
    -- prtEachDef3 (Right "Int")     = "integer"
    prtEachDef3 (Right "Numeric") = "numeric"
    prtEachDef3 (Right x) = x ++ ""


    genZeroOrMoreBaseCase nonTName = nonTName ++ "\n  : " ++ "{- empty -} " ++ "{ [] }"

    genZeroOrMoreRecCase :: String -> [String] -> String
    genZeroOrMoreRecCase nonTName xss = "| " ++ genZeroOrMoreRecCase' nonTName xss

    genZeroOrMoreRecCase' nonTName xss@(x:xs) =
      foldl1 (\xs x -> xs ++ " " ++ x) xss ++ " " ++ nonTName ++
        " { " ++ prtEachDef4Tuple ZeroOrMore xss ++ " }"

    genOneOrMoreRecCase = genZeroOrMoreRecCase

    genOneOrMoreBaseCase nonTName xss =
      nonTName ++ "\n  : " ++ foldl1 (\xs x -> xs ++ " " ++ x) xss ++
        " { " ++ prtEachDef4Tuple OneOrMore xss ++ " }"

    genZeroOrOne :: String -> [String] -> String
    genZeroOrOne nonTName xss = nonTName ++ "\n  : " ++ "{- empty -} " ++ "{ Nothing }"
      ++ "\n  " ++ "| " ++ foldl1 (\xs x -> xs ++ " " ++ x) xss ++ " "
      ++ " { " ++ prtEachDef4Tuple ZeroOrOne xss ++ " }"


    -- $1 $2 $3 ...
    prtEachDef4 :: [a] -> String
    prtEachDef4 = prtEachDef4' 1

    prtEachDef4' :: Int -> [a] -> String
    prtEachDef4' n (x : xs) = "$" ++ show n ++ " " ++ prtEachDef4' (n + 1) xs
    prtEachDef4' n [] = ""

    -- ($1, $2, $3) ...
    prtEachDef4Tuple :: Occurence -> [a] -> String
    prtEachDef4Tuple ZeroOrMore xs = prtEachDef4Tuple' 1 xs ++ " : " ++ "$" ++ show (length xs + 1) -- the "adding parenthese" looks ugly...
    prtEachDef4Tuple OneOrMore xs  = prtEachDef4Tuple' 1 xs ++ " : " ++ "[]" -- the "adding parenthese" looks ugly...
    prtEachDef4Tuple ZeroOrOne xs  = "Just " ++ prtEachDef4Tuple' 1 xs

    prtEachDef4Tuple' :: Int -> [a] -> String
    prtEachDef4Tuple' n [x] = "(" ++ "$" ++ show n ++ ")"
    prtEachDef4Tuple' n (x: xs) = "(" ++ "$" ++ show n ++ ", " ++ prtEachDef4Tuple' (n + 1) xs ++ ")"
    prtEachDef4Tuple' n [] = "check failed. the argument of function prtEachDef4Tuple should not be an empty list'"

lowerTok :: String -> String
lowerTok (c:cs) = 't' : cs


prtETNT :: ETNT -> String
prtETNT (Left x) = "String " -- terminal
prtETNT (Right "String") = "(String, String) " -- the last "whitespace" is critical
prtETNT (Right "Name") = "(String, String) "
prtETNT (Right "Int") = "(Int, String) "
prtETNT (Right x) = x ++ " "

------------------------

prtCmds :: TerminalToTokenIdEnv -> [Cmd] -> String
prtCmds env@(TerminalToTokenIdEnv tokEnv) [] = []
prtCmds env@(TerminalToTokenIdEnv tokEnv) ((CmdLeftAssoc lst):cs) =
  "%left" ++ prtEachCmd env lst ++ "\n" ++ prtCmds env cs
prtCmds env@(TerminalToTokenIdEnv tokEnv) ((CmdRightAssoc lst):cs) =
  "%right" ++ prtEachCmd env lst ++ "\n" ++ prtCmds env cs
prtCmds env@(TerminalToTokenIdEnv tokEnv) ((CmdNonAssoc lst):cs) =
  "%nonassoc" ++ prtEachCmd env lst ++ "\n" ++ prtCmds env cs


prtEachCmd :: TerminalToTokenIdEnv -> [ETNT] -> String
prtEachCmd (TerminalToTokenIdEnv tokEnv) [] = ""
prtEachCmd (TerminalToTokenIdEnv tokEnv) (Left x : cs) =
  let Just tok = lookup x tokEnv
  in  " " ++ lowerTok tok ++ prtEachCmd (TerminalToTokenIdEnv tokEnv) cs


prtWrap :: (TerminalToTokenIdEnv) -> [String] -> String
prtWrap (TerminalToTokenIdEnv tokEnv) cs =
  (foldr newlineS ""
      ["wrap :: Token -> String -> Token"
      ,"wrap (TokenStr (s, c)) ws = TokenStr (s, c ++ ws)"
      ,"wrap (TokenName (s, c)) ws = TokenName (s, c ++ ws)"
      ,"wrap (TokenNumeric (s, c)) ws = TokenNumeric (s, c ++ ws)"
      ,"wrap (TokenWS c) ws = TokenWS (c ++ ws)"
      ])
  `newlineS` prtWrapEach cs `newlineS`
  (foldr newlineS ""
      ["mergeWS :: [Token] -> [Token]"
      ,"mergeWS [] = []"
      ,"mergeWS (tok : TokenWS ws : toks) = mergeWS (wrap tok ws : toks)"
      ,"mergeWS (tok : toks) = tok : mergeWS toks"
      ,""
      ,"parser2 prog ="
      ,"  let toks = mergeWS (TokenWS \"\" : lexer prog)"
      ,"  in  (pToken (head toks), parser (tail toks))"
      -- ,"-- for smooth lexing, add a whitespace to the beginning of the program and then delete it"
      -- ,"parser2 prog ="
      -- ,"  let prog' = ' ':prog"
      -- ,"      toks = del1Ws . mergeWS $ lexer prog'"
      -- ,"  in  (pToken (head toks), parser (tail toks))"
      -- ,"  where del1Ws (TokenWS w1: other) = TokenWS (tail w1):other"
      ])

  where
    prtWrapEach :: [String] -> String
    prtWrapEach [] = ""
    prtWrapEach (c:cs) = let Just tok = lookup c tokEnv in
      "wrap (" ++ tok ++ " c) ws = " ++ tok ++ " (c ++ ws)\n" ++ prtWrapEach cs


prtParseErr :: String
prtParseErr =
  "parseError :: [Token] -> a" `newlineS`
  "parseError toks = error $ \"Parse error.\" ++"  `newlineS`
  "  \"\\nFirst 20 unconsumed tokens:\\n\" ++" +^+ "ppShow (take 20 toks) ++" `newlineS`
  "  \"\\nConverted to steram:\\n\" ++" +^+ "(concatMap pToken $ take 20 toks)"


----------------
prtHeader :: (Bool, Bool, Bool) -> String
prtHeader (strFlag, nameFlag, numericFlag) =
  foldr newlineS ""
  ["{"
  ,"module Parser where\n"
  ,"import Data.Char"
  ,"import Data.List (any)"
  ,"import YourLangDef"
  ,"import Text.Show.Pretty"
  ,"}"
  ,""
  ,"%name parser"
  ,"%tokentype { Token }"
  ,"%error { parseError }"
  ,""
  ,"%token"
  ,(if strFlag     then   "  str     { TokenStr $$ }\n" else "")
  ,(if nameFlag    then   "  name    { TokenName $$ }\n" else "")
  ,(if numericFlag then   "  numeric     { TokenNumeric $$ }" else "")
  ]

disamb :: [Cmd] -> [Cmd]
disamb [] = []
disamb ((CmdLeftAssoc x):xs) = (CmdLeftAssoc x) : disamb xs
disamb ((CmdRightAssoc x):xs) = (CmdRightAssoc x) : disamb xs
disamb ((CmdNonAssoc x):xs) = (CmdNonAssoc x) : disamb xs
disamb (x:xs) = disamb xs


comment :: [Cmd] -> (String, (String, String))
comment [] = ("//", ("/*", "*/"))
comment ((CmdCommLine s):xs) = (s, snd (comment xs))
comment ((CmdCommBlock sl sr):xs) = (fst (comment xs), (sl, sr))
comment (x:xs) = comment xs


prtToks :: (TokenIdToTerminalEnv) -> String
prtToks (TokenIdToTerminalEnv tokEnv) =
  let tokIds = keys tokEnv
  in  foldr (\tok str -> "  " ++ lowerTok tok ++ "  { " ++ tok ++ " $$ }\n" ++ str) "" tokIds
  where

----------------
genLexer :: ([Cmd], CAST) -> String
genLexer (cmds, cast) =
  let primFlags = markPrim cast

      prog = addTopLevelDataype (addConsName cast)
      (termToTokIdEnv, tokIdToTermEnv) = evalState (genTerminalMap cast) 0
      TerminalToTokenIdEnv nakedtermToTokIdEnv = termToTokIdEnv
      -- sort by longerFirst is important. because the pattern ":=" should come before ":" to avoid the overlap
      tokens = map fst $ List.sortBy longerFirst $ toList nakedtermToTokIdEnv
  in  -- trace (ppShow primFlags) $
  let lists = [prtHeader primFlags
        ,prtToks tokIdToTermEnv
        ,prtCmds termToTokIdEnv (disamb cmds)
        ,evalState (prtRules termToTokIdEnv prog) 0
        ,"{"
        ,prtParseErr
        ,prtData primFlags termToTokIdEnv tokens

        ,str2CST prog

        ,prtTPrinter primFlags termToTokIdEnv tokens
        ,prtLexer termToTokIdEnv tokens (comment cmds)
        ,prtWrap termToTokIdEnv tokens
        ,"}"]
  in  foldr1 newlineS lists


longerFirst :: (String,String) -> (String,String) -> Ordering
longerFirst (a,_) (b,_) =
  if length a == length b
    then EQ
    else if length a > length b
      then LT
      else GT

str2CST :: CAST -> String
str2CST (CAST _ _) = "str2CST s = parser (tail (mergeWS (TokenWS \"\" : lexer s)))\n"


-- add the constructor name to CAST in a state monad. generate a unique constructor name for each CTypeDef
addConsName :: CAST -> CAST
addConsName (CAST topt cdatatypes) = CAST topt (map refine1 cdatatypes)
  where
    refine1 :: CDataType -> CDataType
    refine1 (CDataType prefix ctypedefs) =
      CDataType prefix (evalState (mapM refine2 ctypedefs) (genNameList prefix))
    refine2 :: MonadState [String] m => CTypeDef -> m CTypeDef
    refine2 def@(CTypeDef maybeName tnts annot) = do
      nameList <- get
      put $ tail nameList
      case maybeName of
        "" -> return $ CTypeDef (head nameList) tnts annot -- no given name for the constructor
        _  -> return def

addTopLevelDataype (CAST _ defs) =
  let (CDataType t _) = head defs
  in  CAST t defs

genNameList :: String -> [String]
genNameList name = zipWith (\a b -> a ++ b) (repeat name) (map show [0,1..])
