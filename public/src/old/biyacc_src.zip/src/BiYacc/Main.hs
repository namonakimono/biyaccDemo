{-# Language FlexibleContexts #-}

module BiYacc.Main where

import BiYacc.Language.Def
import BiYacc.Helper.Utils
import BiYacc.Parser.Abstract
import BiYacc.Parser.Concrete
import BiYacc.Parser.Action
import BiYacc.Parser.Directives

import BiYacc.Translation.Check
import BiYacc.Translation.GenDataTypes
import BiYacc.Translation.BX.GenBiGUL
import BiYacc.Translation.BX.AuxFuns
import BiYacc.Translation.BX.GenBrackets

import BiYacc.Translation.ISO.GenLexer
import BiYacc.Translation.ISO.GenPrinter

import Text.Parsec (ParsecT, getInput, setInput, runParser, runParserT, getPosition,
  setPosition, SourcePos, string, lookAhead, try, (<|>), anyChar, ParseError)
import Text.PrettyPrint as TPP

import System.Environment (getArgs)
import System.Process (readProcess, callCommand)
import Control.Monad.Reader (runReader)


-- preprocess a biyacc program. Return the (abstract abstract part, Temp CAST of Concrete part,
-- unconsumed Action part and its position, ALL part)
-- In addition, if the user does not write the "Concrete" sytnax part, we will generate it from "Action" groups.
-- Then re-generate and process a new biyacc file with "Concrete" syntax part.
preProcess :: Monad m => ParsecT String Int m (ASTDataTypeDecs, ([Cmd], CAST), (String, SourcePos), ExampleDisAmbEnv)
preProcess = do
  byWhiteSpace
  absTypeDecls <- pAbstract
  cOrDorA <- try (string "#Concrete") <|> try (string "#Directives") <|> try (string "#Actions")
  case cOrDorA of
    "#Concrete" -> do
      inp <- getInput
      setInput ("#Concrete" `newlineS` inp)

    "#Directives" -> do
      -- srcPos     <- getPosition
      -- concSrc1   <- getInput
      directives <- skipDirectives -- additional rules (eg disambiguation rules) starting with %

      actionSrcPos1 <- getPosition -- for error reporting
      actionSrc1    <- getInput
      let prdRulesStr = genPrinter . genProdRulesFromActions $
                          either (error . show) id (runParser (program actionSrcPos1) () "" actionSrc1)
      setInput ("#Concrete" `newlineS` prdRulesStr `newlineS` directives `newlineSS` "#Actions" `newlineS` actionSrc1)

    "#Actions"  -> do
      srcPos    <- getPosition
      actionSrc <- getInput
      let prdRulesStr = genPrinter . genProdRulesFromActions $
                          either (error . show) id (runParser (program srcPos) () "" actionSrc)
      setInput ("#Concrete" `newlineS` prdRulesStr `newlineSS` actionSrc)

  rem        <- getInput    -- input maybe rearranged by setInput above

  tmpCAST <- buildTmpCAST
  let (pat2NameEnv, nameEigenEnv, _, _, _) = buildEnv tmpCAST

  (cmds, exampleDisAmbEnv) <- pDirectives pat2NameEnv nameEigenEnv

  srcPos     <- getPosition
  actionSrc  <- getInput
  return (absTypeDecls, (cmds,tmpCAST), (actionSrc,srcPos), exampleDisAmbEnv)



main :: IO ()
main  = do
  args <- getArgs
  if length args < 2
    then error "please give input. usage: biyacc biyaccFileName outputExecutableName"
    else do
      putStrLn "compiling process may take to half a minute for a comparative big language."
      let byFileName    = args !! 0
          exeFileName   = args !! 1
          exeFileNameHS =  exeFileName ++ ".hs"
      stream <- readFile byFileName
      let mResult = runParserT preProcess 0 byFileName stream
                    :: MonadState [String] m => m (Either ParseError (ASTDataTypeDecs, ([Cmd], CAST), (String, SourcePos), ExampleDisAmbEnv))
          eParseRes = evalState mResult [""]
          (absDecls, (cmds, tmpCAST), (progStr, srcPos), exampleDisAmbEnv) = either (error . show) id eParseRes
          tmpProgram = either (error . show) id (runParser (program srcPos) () "" progStr)
          csEnv = buildCon2FieldsEnv absDecls
      putStrLn $ allCheck tmpCAST tmpProgram csEnv


      let (srcTypeCAST, srcTypeEnv)    = (toCAST tmpCAST, buildEnv tmpCAST)
          (pat2NameEnv, nameEigenEnv, nullEnv, tyNameEnv, disAmbEnv) = srcTypeEnv
          (priEnv, assocEnv, prefEnv, brkEnv) = disAmbEnv
          bracketPaths = buildBrkPaths tyNameEnv nameEigenEnv pat2NameEnv brkEnv
          Just (brkConsName, brkConsType, _) = brkEnv

          -- ignore it if you do not use disambiguations.
          -- converted from new syntax for disambiguation. errorprone. in testing
          -- exampleDisAmbEnvStr = render $ text "disAmbEnv = " $+$ (nest2 . text . ppShow $ exampleDisAmbEnv)


          progCAST        = addProdRuleName pat2NameEnv . progToBiYaccType $ tmpProgram
          sssprogstring   = runReader (genBiGUL progCAST)
                            (nameEigenEnv,nullEnv,csEnv,
                              (exampleDisAmbEnv,bracketPaths,brkConsName))

          entranceStr     = getEntrance progCAST
          topPPFun        = getTopPPFunction progCAST
          bigulProgramStr = foldr1 newlineSS [importStr, entranceStr, topPPFun, sssprogstring, numTyBiGULDefs
                                             , listFunStr, disStrAll, mainStr]
          srcDeclsStr     = prtConcDTs srcTypeCAST
          absDeclsStr     = prtAbsDTs' absDecls
          cstInstanceShowStr   = genPrinter srcTypeCAST

      -- check whether a group of actions use all the production rules. If Concrete part is not given. results are always true.

      writeFile "YourLangDef.hs" (defFileString absDeclsStr srcDeclsStr cstInstanceShowStr)
      writeFile exeFileNameHS bigulProgramStr

      let lexerStr = genLexer (cmds,tmpCAST)
      writeFile "Parser.y" lexerStr

      readProcess "happy" ["Parser.y"] ""
      readProcess "ghc" ["Parser.hs"] ""
      readProcess "ghc" ["YourLangDef.hs"] ""
      readProcess "ghc" [exeFileNameHS, "-o", exeFileName] ""

      -- some cleaning work
      let removeStr = ["rm"
                      ,"YourLangDef.dyn_o","YourLangDef.dyn_hi","YourLangDef.o","YourLangDef.hi","YourLangDef.hs"
                      ,"Parser.dyn_o","Parser.dyn_hi","Parser.o","Parser.hi","Parser.y", "Parser.hs"
                      ,exeFileName++".dyn_o",exeFileName++".dyn_hi",exeFileName++".o",exeFileName++".hi",exeFileNameHS]
      putStrLn "nothing serious if the callCommand fails... it just make some cleaning work"
      callCommand $ foldl1 (\xs x -> xs ++ " " ++ x) removeStr
      putStrLn $ "successfully generated " ++ exeFileName
      return ()


-- put abstract datatypes, concrete datatypes into a separate file.
defFileString :: String -> String -> String -> String
defFileString absDef concDef cstInstanceShowStr =
  (foldr (\x xs -> x ++ "\n" ++ xs )
        ""
        ["{-# Language TemplateHaskell, TypeFamilies #-}"
        ,"module YourLangDef where"
        ,"import GHC.Generics"
        ,"import Generics.BiGUL.TH"
        ,"import Data.Natural"
        ,""
        ,"type BiNumericTy  = (String, String)"
        ,"type BiIdentifyTy = (String, String)"
        ,"type BiStringTy   = (String, String)"
        ,"type BiBoolTy     = (String, String)"
        ])
  `newlineSS` absDef `newlineSS` concDef `newlineSS` cstInstanceShowStr


