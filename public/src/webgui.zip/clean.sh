./stop
sudo npm uninstall jade
sudo npm uninstall ejs
sudo npm uninstall express
sudo npm uninstall html
sudo npm uninstall forever
rm ./exe/*
