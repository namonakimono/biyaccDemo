#!/bin/bash
cp ./config_ubuntu ../config.js
sudo npm install
sudo npm install forever

