#!/bin/bash
cp ./config_mac ../config.js
sudo npm install
sudo npm install forever -g

