// for mac os
module.exports = {
    biyacc : '/Users/zhuzirun/Library/Haskell/bin/biyacc',
    BiFluX : '/Users/zhuzirun/Library/Haskell/bin/BiFluX',
    ghc : '/usr/bin/ghc',
}

