// for ubuntu
// module.exports = {
//     biyacc : '/home/ubuntu/.cabal/bin/biyacc',
//     BiFluX : '/home/ubuntu/.cabal/bin/BiFluX',
//     ghc : '/usr/bin/ghc',
// }

// for mac os
module.exports = {
    biyacc : '/Users/zhuzirun/Library/Haskell/bin/biyacc',
    BiFluX : '/Users/zhuzirun/Library/Haskell/bin/BiFluX',
    ghc : '/usr/bin/ghc',
}
