{-# LANGUAGE DeriveGeneric #-}
module Concrete where

import Data.Map (Map(..))
import qualified Data.Map as Map
import Text.XML.HaXml.XmlContent hiding (List1)
import Text.XML.HaXml.Types
import Text.XML.BiFluX.DTD.HaXml.TypeDef
import Text.XML.BiFluX.DTD.Type
import Text.XML.HaXml.DtdToHaskell.TypeDef (Name(..))
import Control.Monad
import GHC.Generics as Generics

type EMPTY = ()


data Expr = ExprA0 Concrete.A0
          | ExprA1 Concrete.A1
          | ExprNull Concrete.Null
          deriving (Eq,Show,Generic)
data A0 = A0 		deriving (Eq,Show,Generic)
data A1 = A1 Concrete.Lvalue Concrete.Expr
        deriving (Eq,Show,Generic)
data Binaryop = BinaryopA2 Concrete.A2
              | BinaryopA3 Concrete.A3
              | BinaryopNull Concrete.Null
              deriving (Eq,Show,Generic)
data A2 = A2 Concrete.Binaryop Concrete.Binaryop1
        deriving (Eq,Show,Generic)
newtype A3 = A3 Concrete.Binaryop1 		deriving (Eq,Show,Generic)
data Binaryop1 = Binaryop1A4 Concrete.A4
               | Binaryop1A5 Concrete.A5
               | Binaryop1Null Concrete.Null
               deriving (Eq,Show,Generic)
data A4 = A4 Concrete.Binaryop1 Concrete.Binaryop2
        deriving (Eq,Show,Generic)
newtype A5 = A5 Concrete.Binaryop2 		deriving (Eq,Show,Generic)
data Binaryop2 = Binaryop2A6 Concrete.A6
               | Binaryop2A7 Concrete.A7
               | Binaryop2Null Concrete.Null
               deriving (Eq,Show,Generic)
data A6 = A6 Concrete.Binaryop2 Concrete.Binaryop3
        deriving (Eq,Show,Generic)
newtype A7 = A7 Concrete.Binaryop3 		deriving (Eq,Show,Generic)
data Binaryop3 = Binaryop3A8 Concrete.A8
               | Binaryop3A9 Concrete.A9
               | Binaryop3A10 Concrete.A10
               | Binaryop3Null Concrete.Null
               deriving (Eq,Show,Generic)
data A8 = A8 Concrete.Binaryop3 Concrete.Binaryop4
        deriving (Eq,Show,Generic)
data A9 = A9 Concrete.Binaryop3 Concrete.Binaryop4
        deriving (Eq,Show,Generic)
newtype A10 = A10 Concrete.Binaryop4 		deriving (Eq,Show,Generic)
data Binaryop4 = Binaryop4A11 Concrete.A11
               | Binaryop4A12 Concrete.A12
               | Binaryop4A13 Concrete.A13
               | Binaryop4Null Concrete.Null
               deriving (Eq,Show,Generic)
data A11 = A11 Concrete.Binaryop4 Concrete.Binaryop5
         deriving (Eq,Show,Generic)
data A12 = A12 Concrete.Binaryop4 Concrete.Binaryop5
         deriving (Eq,Show,Generic)
newtype A13 = A13 Concrete.Binaryop5 		deriving (Eq,Show,Generic)
data Binaryop5 = Binaryop5A14 Concrete.A14
               | Binaryop5A15 Concrete.A15
               | Binaryop5A16 Concrete.A16
               | Binaryop5A17 Concrete.A17
               | Binaryop5Null Concrete.Null
               deriving (Eq,Show,Generic)
newtype A14 = A14 Concrete.Biyaccpcdata 		deriving (Eq,Show,Generic)
newtype A15 = A15 Concrete.Lvalue 		deriving (Eq,Show,Generic)
newtype A16 = A16 Concrete.Binaryop5 		deriving (Eq,Show,Generic)
newtype A17 = A17 Concrete.Binaryop 		deriving (Eq,Show,Generic)
data Lvalue = LvalueA18 Concrete.A18
            | LvalueA19 Concrete.A19
            | LvalueA20 Concrete.A20
            | LvalueNull Concrete.Null
            deriving (Eq,Show,Generic)
newtype A18 = A18 Concrete.Biyaccpcdata 		deriving (Eq,Show,Generic)
data A19 = A19 Concrete.Lvalue Concrete.Biyaccpcdata
         deriving (Eq,Show,Generic)
data A20 = A20 Concrete.Lvalue Concrete.Expr
         deriving (Eq,Show,Generic)
newtype Biyaccpcdata = Biyaccpcdata Str 		deriving (Eq,Show,Generic)
data Null = Null 		deriving (Eq,Show,Generic)
instance HTypeable Concrete.Expr where
    toHType x = Defined "expr" [] []
instance XmlContent Concrete.Expr where
    toContents (Concrete.ExprA0 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (Concrete.ExprA1 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (Concrete.ExprNull a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    parseContents = do 
        { e@(Elem _ [] _) <- element ["expr"]
        ; interior e $ oneOf
            [ return (Concrete.ExprA0) `apply` parseContents
            , return (Concrete.ExprA1) `apply` parseContents
            , return (Concrete.ExprNull) `apply` parseContents
            ] `adjustErr` ("in <expr>, "++)
        }
instance HTypeable Concrete.A0 where
    toHType x = Defined "a0" [] []
instance XmlContent Concrete.A0 where
    toContents Concrete.A0 =
        [CElem (Elem (N "a0") [] []) ()]
    parseContents = do
        { (Elem _ as []) <- element ["a0"]
        ; return Concrete.A0
        } `adjustErr` ("in <a0>, "++)
instance HTypeable Concrete.A1 where
    toHType x = Defined "a1" [] []
instance XmlContent Concrete.A1 where
    toContents (Concrete.A1 a b) =
        [CElem (Elem (N "a1") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a1"]
        ; interior e $ return (Concrete.A1) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a1>, "++)
instance HTypeable Concrete.Binaryop where
    toHType x = Defined "binaryop" [] []
instance XmlContent Concrete.Binaryop where
    toContents (Concrete.BinaryopA2 a) =
        [CElem (Elem (N "binaryop") [] (toContents a) ) ()]
    toContents (Concrete.BinaryopA3 a) =
        [CElem (Elem (N "binaryop") [] (toContents a) ) ()]
    toContents (Concrete.BinaryopNull a) =
        [CElem (Elem (N "binaryop") [] (toContents a) ) ()]
    parseContents = do 
        { e@(Elem _ [] _) <- element ["binaryop"]
        ; interior e $ oneOf
            [ return (Concrete.BinaryopA2) `apply` parseContents
            , return (Concrete.BinaryopA3) `apply` parseContents
            , return (Concrete.BinaryopNull) `apply` parseContents
            ] `adjustErr` ("in <binaryop>, "++)
        }
instance HTypeable Concrete.A2 where
    toHType x = Defined "a2" [] []
instance XmlContent Concrete.A2 where
    toContents (Concrete.A2 a b) =
        [CElem (Elem (N "a2") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a2"]
        ; interior e $ return (Concrete.A2) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a2>, "++)
instance HTypeable Concrete.A3 where
    toHType x = Defined "a3" [] []
instance XmlContent Concrete.A3 where
    toContents (Concrete.A3 a) =
        [CElem (Elem (N "a3") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a3"]
        ; interior e $ return (Concrete.A3) `apply` parseContents
        } `adjustErr` ("in <a3>, "++)
instance HTypeable Concrete.Binaryop1 where
    toHType x = Defined "binaryop1" [] []
instance XmlContent Concrete.Binaryop1 where
    toContents (Concrete.Binaryop1A4 a) =
        [CElem (Elem (N "binaryop1") [] (toContents a) ) ()]
    toContents (Concrete.Binaryop1A5 a) =
        [CElem (Elem (N "binaryop1") [] (toContents a) ) ()]
    toContents (Concrete.Binaryop1Null a) =
        [CElem (Elem (N "binaryop1") [] (toContents a) ) ()]
    parseContents = do 
        { e@(Elem _ [] _) <- element ["binaryop1"]
        ; interior e $ oneOf
            [ return (Concrete.Binaryop1A4) `apply` parseContents
            , return (Concrete.Binaryop1A5) `apply` parseContents
            , return (Concrete.Binaryop1Null) `apply` parseContents
            ] `adjustErr` ("in <binaryop1>, "++)
        }
instance HTypeable Concrete.A4 where
    toHType x = Defined "a4" [] []
instance XmlContent Concrete.A4 where
    toContents (Concrete.A4 a b) =
        [CElem (Elem (N "a4") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a4"]
        ; interior e $ return (Concrete.A4) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a4>, "++)
instance HTypeable Concrete.A5 where
    toHType x = Defined "a5" [] []
instance XmlContent Concrete.A5 where
    toContents (Concrete.A5 a) =
        [CElem (Elem (N "a5") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a5"]
        ; interior e $ return (Concrete.A5) `apply` parseContents
        } `adjustErr` ("in <a5>, "++)
instance HTypeable Concrete.Binaryop2 where
    toHType x = Defined "binaryop2" [] []
instance XmlContent Concrete.Binaryop2 where
    toContents (Concrete.Binaryop2A6 a) =
        [CElem (Elem (N "binaryop2") [] (toContents a) ) ()]
    toContents (Concrete.Binaryop2A7 a) =
        [CElem (Elem (N "binaryop2") [] (toContents a) ) ()]
    toContents (Concrete.Binaryop2Null a) =
        [CElem (Elem (N "binaryop2") [] (toContents a) ) ()]
    parseContents = do 
        { e@(Elem _ [] _) <- element ["binaryop2"]
        ; interior e $ oneOf
            [ return (Concrete.Binaryop2A6) `apply` parseContents
            , return (Concrete.Binaryop2A7) `apply` parseContents
            , return (Concrete.Binaryop2Null) `apply` parseContents
            ] `adjustErr` ("in <binaryop2>, "++)
        }
instance HTypeable Concrete.A6 where
    toHType x = Defined "a6" [] []
instance XmlContent Concrete.A6 where
    toContents (Concrete.A6 a b) =
        [CElem (Elem (N "a6") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a6"]
        ; interior e $ return (Concrete.A6) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a6>, "++)
instance HTypeable Concrete.A7 where
    toHType x = Defined "a7" [] []
instance XmlContent Concrete.A7 where
    toContents (Concrete.A7 a) =
        [CElem (Elem (N "a7") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a7"]
        ; interior e $ return (Concrete.A7) `apply` parseContents
        } `adjustErr` ("in <a7>, "++)
instance HTypeable Concrete.Binaryop3 where
    toHType x = Defined "binaryop3" [] []
instance XmlContent Concrete.Binaryop3 where
    toContents (Concrete.Binaryop3A8 a) =
        [CElem (Elem (N "binaryop3") [] (toContents a) ) ()]
    toContents (Concrete.Binaryop3A9 a) =
        [CElem (Elem (N "binaryop3") [] (toContents a) ) ()]
    toContents (Concrete.Binaryop3A10 a) =
        [CElem (Elem (N "binaryop3") [] (toContents a) ) ()]
    toContents (Concrete.Binaryop3Null a) =
        [CElem (Elem (N "binaryop3") [] (toContents a) ) ()]
    parseContents = do 
        { e@(Elem _ [] _) <- element ["binaryop3"]
        ; interior e $ oneOf
            [ return (Concrete.Binaryop3A8) `apply` parseContents
            , return (Concrete.Binaryop3A9) `apply` parseContents
            , return (Concrete.Binaryop3A10) `apply` parseContents
            , return (Concrete.Binaryop3Null) `apply` parseContents
            ] `adjustErr` ("in <binaryop3>, "++)
        }
instance HTypeable Concrete.A8 where
    toHType x = Defined "a8" [] []
instance XmlContent Concrete.A8 where
    toContents (Concrete.A8 a b) =
        [CElem (Elem (N "a8") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a8"]
        ; interior e $ return (Concrete.A8) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a8>, "++)
instance HTypeable Concrete.A9 where
    toHType x = Defined "a9" [] []
instance XmlContent Concrete.A9 where
    toContents (Concrete.A9 a b) =
        [CElem (Elem (N "a9") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a9"]
        ; interior e $ return (Concrete.A9) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a9>, "++)
instance HTypeable Concrete.A10 where
    toHType x = Defined "a10" [] []
instance XmlContent Concrete.A10 where
    toContents (Concrete.A10 a) =
        [CElem (Elem (N "a10") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a10"]
        ; interior e $ return (Concrete.A10) `apply` parseContents
        } `adjustErr` ("in <a10>, "++)
instance HTypeable Concrete.Binaryop4 where
    toHType x = Defined "binaryop4" [] []
instance XmlContent Concrete.Binaryop4 where
    toContents (Concrete.Binaryop4A11 a) =
        [CElem (Elem (N "binaryop4") [] (toContents a) ) ()]
    toContents (Concrete.Binaryop4A12 a) =
        [CElem (Elem (N "binaryop4") [] (toContents a) ) ()]
    toContents (Concrete.Binaryop4A13 a) =
        [CElem (Elem (N "binaryop4") [] (toContents a) ) ()]
    toContents (Concrete.Binaryop4Null a) =
        [CElem (Elem (N "binaryop4") [] (toContents a) ) ()]
    parseContents = do 
        { e@(Elem _ [] _) <- element ["binaryop4"]
        ; interior e $ oneOf
            [ return (Concrete.Binaryop4A11) `apply` parseContents
            , return (Concrete.Binaryop4A12) `apply` parseContents
            , return (Concrete.Binaryop4A13) `apply` parseContents
            , return (Concrete.Binaryop4Null) `apply` parseContents
            ] `adjustErr` ("in <binaryop4>, "++)
        }
instance HTypeable Concrete.A11 where
    toHType x = Defined "a11" [] []
instance XmlContent Concrete.A11 where
    toContents (Concrete.A11 a b) =
        [CElem (Elem (N "a11") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a11"]
        ; interior e $ return (Concrete.A11) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a11>, "++)
instance HTypeable Concrete.A12 where
    toHType x = Defined "a12" [] []
instance XmlContent Concrete.A12 where
    toContents (Concrete.A12 a b) =
        [CElem (Elem (N "a12") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a12"]
        ; interior e $ return (Concrete.A12) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a12>, "++)
instance HTypeable Concrete.A13 where
    toHType x = Defined "a13" [] []
instance XmlContent Concrete.A13 where
    toContents (Concrete.A13 a) =
        [CElem (Elem (N "a13") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a13"]
        ; interior e $ return (Concrete.A13) `apply` parseContents
        } `adjustErr` ("in <a13>, "++)
instance HTypeable Concrete.Binaryop5 where
    toHType x = Defined "binaryop5" [] []
instance XmlContent Concrete.Binaryop5 where
    toContents (Concrete.Binaryop5A14 a) =
        [CElem (Elem (N "binaryop5") [] (toContents a) ) ()]
    toContents (Concrete.Binaryop5A15 a) =
        [CElem (Elem (N "binaryop5") [] (toContents a) ) ()]
    toContents (Concrete.Binaryop5A16 a) =
        [CElem (Elem (N "binaryop5") [] (toContents a) ) ()]
    toContents (Concrete.Binaryop5A17 a) =
        [CElem (Elem (N "binaryop5") [] (toContents a) ) ()]
    toContents (Concrete.Binaryop5Null a) =
        [CElem (Elem (N "binaryop5") [] (toContents a) ) ()]
    parseContents = do 
        { e@(Elem _ [] _) <- element ["binaryop5"]
        ; interior e $ oneOf
            [ return (Concrete.Binaryop5A14) `apply` parseContents
            , return (Concrete.Binaryop5A15) `apply` parseContents
            , return (Concrete.Binaryop5A16) `apply` parseContents
            , return (Concrete.Binaryop5A17) `apply` parseContents
            , return (Concrete.Binaryop5Null) `apply` parseContents
            ] `adjustErr` ("in <binaryop5>, "++)
        }
instance HTypeable Concrete.A14 where
    toHType x = Defined "a14" [] []
instance XmlContent Concrete.A14 where
    toContents (Concrete.A14 a) =
        [CElem (Elem (N "a14") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a14"]
        ; interior e $ return (Concrete.A14) `apply` parseContents
        } `adjustErr` ("in <a14>, "++)
instance HTypeable Concrete.A15 where
    toHType x = Defined "a15" [] []
instance XmlContent Concrete.A15 where
    toContents (Concrete.A15 a) =
        [CElem (Elem (N "a15") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a15"]
        ; interior e $ return (Concrete.A15) `apply` parseContents
        } `adjustErr` ("in <a15>, "++)
instance HTypeable Concrete.A16 where
    toHType x = Defined "a16" [] []
instance XmlContent Concrete.A16 where
    toContents (Concrete.A16 a) =
        [CElem (Elem (N "a16") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a16"]
        ; interior e $ return (Concrete.A16) `apply` parseContents
        } `adjustErr` ("in <a16>, "++)
instance HTypeable Concrete.A17 where
    toHType x = Defined "a17" [] []
instance XmlContent Concrete.A17 where
    toContents (Concrete.A17 a) =
        [CElem (Elem (N "a17") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a17"]
        ; interior e $ return (Concrete.A17) `apply` parseContents
        } `adjustErr` ("in <a17>, "++)
instance HTypeable Concrete.Lvalue where
    toHType x = Defined "lvalue" [] []
instance XmlContent Concrete.Lvalue where
    toContents (Concrete.LvalueA18 a) =
        [CElem (Elem (N "lvalue") [] (toContents a) ) ()]
    toContents (Concrete.LvalueA19 a) =
        [CElem (Elem (N "lvalue") [] (toContents a) ) ()]
    toContents (Concrete.LvalueA20 a) =
        [CElem (Elem (N "lvalue") [] (toContents a) ) ()]
    toContents (Concrete.LvalueNull a) =
        [CElem (Elem (N "lvalue") [] (toContents a) ) ()]
    parseContents = do 
        { e@(Elem _ [] _) <- element ["lvalue"]
        ; interior e $ oneOf
            [ return (Concrete.LvalueA18) `apply` parseContents
            , return (Concrete.LvalueA19) `apply` parseContents
            , return (Concrete.LvalueA20) `apply` parseContents
            , return (Concrete.LvalueNull) `apply` parseContents
            ] `adjustErr` ("in <lvalue>, "++)
        }
instance HTypeable Concrete.A18 where
    toHType x = Defined "a18" [] []
instance XmlContent Concrete.A18 where
    toContents (Concrete.A18 a) =
        [CElem (Elem (N "a18") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a18"]
        ; interior e $ return (Concrete.A18) `apply` parseContents
        } `adjustErr` ("in <a18>, "++)
instance HTypeable Concrete.A19 where
    toHType x = Defined "a19" [] []
instance XmlContent Concrete.A19 where
    toContents (Concrete.A19 a b) =
        [CElem (Elem (N "a19") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a19"]
        ; interior e $ return (Concrete.A19) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a19>, "++)
instance HTypeable Concrete.A20 where
    toHType x = Defined "a20" [] []
instance XmlContent Concrete.A20 where
    toContents (Concrete.A20 a b) =
        [CElem (Elem (N "a20") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a20"]
        ; interior e $ return (Concrete.A20) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a20>, "++)
instance HTypeable Concrete.Biyaccpcdata where
    toHType x = Defined "biyaccpcdata" [] []
instance XmlContent Concrete.Biyaccpcdata where
    toContents (Concrete.Biyaccpcdata a) =
        [CElem (Elem (N "biyaccpcdata") [] ((toText . unStr) a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["biyaccpcdata"]
        ; interior e $ return (Concrete.Biyaccpcdata)
                       `apply` (liftM Str text `onFail` return (Str ""))
        } `adjustErr` ("in <biyaccpcdata>, "++)
instance HTypeable Concrete.Null where
    toHType x = Defined "null" [] []
instance XmlContent Concrete.Null where
    toContents Concrete.Null =
        [CElem (Elem (N "null") [] []) ()]
    parseContents = do
        { (Elem _ as []) <- element ["null"]
        ; return Concrete.Null
        } `adjustErr` ("in <null>, "++)
instance Typeable Concrete.Expr where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "expr" "Expr") typeof
instance Typeable Concrete.A0 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a0" "A0") One
instance Typeable Concrete.A1 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a1" "A1") typeof
instance Typeable Concrete.Binaryop where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "binaryop" "Binaryop") typeof
instance Typeable Concrete.A2 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a2" "A2") typeof
instance Typeable Concrete.A3 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a3" "A3") typeof
instance Typeable Concrete.Binaryop1 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "binaryop1" "Binaryop1") typeof
instance Typeable Concrete.A4 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a4" "A4") typeof
instance Typeable Concrete.A5 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a5" "A5") typeof
instance Typeable Concrete.Binaryop2 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "binaryop2" "Binaryop2") typeof
instance Typeable Concrete.A6 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a6" "A6") typeof
instance Typeable Concrete.A7 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a7" "A7") typeof
instance Typeable Concrete.Binaryop3 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "binaryop3" "Binaryop3") typeof
instance Typeable Concrete.A8 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a8" "A8") typeof
instance Typeable Concrete.A9 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a9" "A9") typeof
instance Typeable Concrete.A10 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a10" "A10") typeof
instance Typeable Concrete.Binaryop4 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "binaryop4" "Binaryop4") typeof
instance Typeable Concrete.A11 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a11" "A11") typeof
instance Typeable Concrete.A12 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a12" "A12") typeof
instance Typeable Concrete.A13 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a13" "A13") typeof
instance Typeable Concrete.Binaryop5 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "binaryop5" "Binaryop5") typeof
instance Typeable Concrete.A14 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a14" "A14") typeof
instance Typeable Concrete.A15 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a15" "A15") typeof
instance Typeable Concrete.A16 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a16" "A16") typeof
instance Typeable Concrete.A17 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a17" "A17") typeof
instance Typeable Concrete.Lvalue where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "lvalue" "Lvalue") typeof
instance Typeable Concrete.A18 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a18" "A18") typeof
instance Typeable Concrete.A19 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a19" "A19") typeof
instance Typeable Concrete.A20 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a20" "A20") typeof
instance Typeable Concrete.Biyaccpcdata where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "biyaccpcdata" "Biyaccpcdata") typeof
instance Typeable Concrete.Null where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "null" "Null") One

typeEnv = Map.insert "expr" (DynT (typeof :: Type (Concrete.Expr))) (Map.insert "a0" (DynT (typeof :: Type (Concrete.A0))) (Map.insert "a1" (DynT (typeof :: Type (Concrete.A1))) (Map.insert "binaryop" (DynT (typeof :: Type (Concrete.Binaryop))) (Map.insert "a2" (DynT (typeof :: Type (Concrete.A2))) (Map.insert "a3" (DynT (typeof :: Type (Concrete.A3))) (Map.insert "binaryop1" (DynT (typeof :: Type (Concrete.Binaryop1))) (Map.insert "a4" (DynT (typeof :: Type (Concrete.A4))) (Map.insert "a5" (DynT (typeof :: Type (Concrete.A5))) (Map.insert "binaryop2" (DynT (typeof :: Type (Concrete.Binaryop2))) (Map.insert "a6" (DynT (typeof :: Type (Concrete.A6))) (Map.insert "a7" (DynT (typeof :: Type (Concrete.A7))) (Map.insert "binaryop3" (DynT (typeof :: Type (Concrete.Binaryop3))) (Map.insert "a8" (DynT (typeof :: Type (Concrete.A8))) (Map.insert "a9" (DynT (typeof :: Type (Concrete.A9))) (Map.insert "a10" (DynT (typeof :: Type (Concrete.A10))) (Map.insert "binaryop4" (DynT (typeof :: Type (Concrete.Binaryop4))) (Map.insert "a11" (DynT (typeof :: Type (Concrete.A11))) (Map.insert "a12" (DynT (typeof :: Type (Concrete.A12))) (Map.insert "a13" (DynT (typeof :: Type (Concrete.A13))) (Map.insert "binaryop5" (DynT (typeof :: Type (Concrete.Binaryop5))) (Map.insert "a14" (DynT (typeof :: Type (Concrete.A14))) (Map.insert "a15" (DynT (typeof :: Type (Concrete.A15))) (Map.insert "a16" (DynT (typeof :: Type (Concrete.A16))) (Map.insert "a17" (DynT (typeof :: Type (Concrete.A17))) (Map.insert "lvalue" (DynT (typeof :: Type (Concrete.Lvalue))) (Map.insert "a18" (DynT (typeof :: Type (Concrete.A18))) (Map.insert "a19" (DynT (typeof :: Type (Concrete.A19))) (Map.insert "a20" (DynT (typeof :: Type (Concrete.A20))) (Map.insert "biyaccpcdata" (DynT (typeof :: Type (Concrete.Biyaccpcdata))) (Map.insert "null" (DynT (typeof :: Type (Concrete.Null))) (Map.empty)))))))))))))))))))))))))))))))

xmlTypeEnv = Map.insert "expr" (XmlT (typeof :: Type (Concrete.Expr))) (Map.insert "a0" (XmlT (typeof :: Type (Concrete.A0))) (Map.insert "a1" (XmlT (typeof :: Type (Concrete.A1))) (Map.insert "binaryop" (XmlT (typeof :: Type (Concrete.Binaryop))) (Map.insert "a2" (XmlT (typeof :: Type (Concrete.A2))) (Map.insert "a3" (XmlT (typeof :: Type (Concrete.A3))) (Map.insert "binaryop1" (XmlT (typeof :: Type (Concrete.Binaryop1))) (Map.insert "a4" (XmlT (typeof :: Type (Concrete.A4))) (Map.insert "a5" (XmlT (typeof :: Type (Concrete.A5))) (Map.insert "binaryop2" (XmlT (typeof :: Type (Concrete.Binaryop2))) (Map.insert "a6" (XmlT (typeof :: Type (Concrete.A6))) (Map.insert "a7" (XmlT (typeof :: Type (Concrete.A7))) (Map.insert "binaryop3" (XmlT (typeof :: Type (Concrete.Binaryop3))) (Map.insert "a8" (XmlT (typeof :: Type (Concrete.A8))) (Map.insert "a9" (XmlT (typeof :: Type (Concrete.A9))) (Map.insert "a10" (XmlT (typeof :: Type (Concrete.A10))) (Map.insert "binaryop4" (XmlT (typeof :: Type (Concrete.Binaryop4))) (Map.insert "a11" (XmlT (typeof :: Type (Concrete.A11))) (Map.insert "a12" (XmlT (typeof :: Type (Concrete.A12))) (Map.insert "a13" (XmlT (typeof :: Type (Concrete.A13))) (Map.insert "binaryop5" (XmlT (typeof :: Type (Concrete.Binaryop5))) (Map.insert "a14" (XmlT (typeof :: Type (Concrete.A14))) (Map.insert "a15" (XmlT (typeof :: Type (Concrete.A15))) (Map.insert "a16" (XmlT (typeof :: Type (Concrete.A16))) (Map.insert "a17" (XmlT (typeof :: Type (Concrete.A17))) (Map.insert "lvalue" (XmlT (typeof :: Type (Concrete.Lvalue))) (Map.insert "a18" (XmlT (typeof :: Type (Concrete.A18))) (Map.insert "a19" (XmlT (typeof :: Type (Concrete.A19))) (Map.insert "a20" (XmlT (typeof :: Type (Concrete.A20))) (Map.insert "biyaccpcdata" (XmlT (typeof :: Type (Concrete.Biyaccpcdata))) (Map.insert "null" (XmlT (typeof :: Type (Concrete.Null))) (Map.empty)))))))))))))))))))))))))))))))
