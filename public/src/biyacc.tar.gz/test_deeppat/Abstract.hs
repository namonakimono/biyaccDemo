{-# LANGUAGE DeriveGeneric #-}
module Abstract where

import Data.Map (Map(..))
import qualified Data.Map as Map
import Text.XML.HaXml.XmlContent hiding (List1)
import Text.XML.HaXml.Types
import Text.XML.BiFluX.DTD.HaXml.TypeDef
import Text.XML.BiFluX.DTD.Type
import Text.XML.HaXml.DtdToHaskell.TypeDef (Name(..))
import Control.Monad
import GHC.Generics as Generics

type EMPTY = ()


data Arith = ArithPlus Abstract.Plus
           | ArithMinus Abstract.Minus
           | ArithTimes Abstract.Times
           | ArithDiv Abstract.Div
           | ArithVar Abstract.Var
           | ArithEqual Abstract.Equal
           | ArithOr Abstract.Or
           | ArithAnd Abstract.And
           | ArithANum Abstract.ANum
           deriving (Eq,Show,Generic)
data Plus = Plus Abstract.Arith Abstract.Arith
          deriving (Eq,Show,Generic)
data Minus = Minus Abstract.Arith Abstract.Arith
           deriving (Eq,Show,Generic)
data Times = Times Abstract.Arith Abstract.Arith
           deriving (Eq,Show,Generic)
data Div = Div Abstract.Arith Abstract.Arith
         deriving (Eq,Show,Generic)
newtype Var = Var Abstract.Biyaccpcdata 		deriving (Eq,Show,Generic)
data Equal = Equal Abstract.Arith Abstract.Arith
           deriving (Eq,Show,Generic)
data Or = Or Abstract.Arith Abstract.Arith
        deriving (Eq,Show,Generic)
data And = And Abstract.Arith Abstract.Arith
         deriving (Eq,Show,Generic)
newtype ANum = ANum Abstract.Biyaccpcdata 		deriving (Eq,Show,Generic)
newtype Biyaccpcdata = Biyaccpcdata Str 		deriving (Eq,Show,Generic)
instance HTypeable Abstract.Arith where
    toHType x = Defined "arith" [] []
instance XmlContent Abstract.Arith where
    toContents (Abstract.ArithPlus a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (Abstract.ArithMinus a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (Abstract.ArithTimes a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (Abstract.ArithDiv a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (Abstract.ArithVar a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (Abstract.ArithEqual a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (Abstract.ArithOr a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (Abstract.ArithAnd a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (Abstract.ArithANum a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    parseContents = do 
        { e@(Elem _ [] _) <- element ["arith"]
        ; interior e $ oneOf
            [ return (Abstract.ArithPlus) `apply` parseContents
            , return (Abstract.ArithMinus) `apply` parseContents
            , return (Abstract.ArithTimes) `apply` parseContents
            , return (Abstract.ArithDiv) `apply` parseContents
            , return (Abstract.ArithVar) `apply` parseContents
            , return (Abstract.ArithEqual) `apply` parseContents
            , return (Abstract.ArithOr) `apply` parseContents
            , return (Abstract.ArithAnd) `apply` parseContents
            , return (Abstract.ArithANum) `apply` parseContents
            ] `adjustErr` ("in <arith>, "++)
        }
instance HTypeable Abstract.Plus where
    toHType x = Defined "plus" [] []
instance XmlContent Abstract.Plus where
    toContents (Abstract.Plus a b) =
        [CElem (Elem (N "plus") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["plus"]
        ; interior e $ return (Abstract.Plus) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <plus>, "++)
instance HTypeable Abstract.Minus where
    toHType x = Defined "minus" [] []
instance XmlContent Abstract.Minus where
    toContents (Abstract.Minus a b) =
        [CElem (Elem (N "minus") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["minus"]
        ; interior e $ return (Abstract.Minus) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <minus>, "++)
instance HTypeable Abstract.Times where
    toHType x = Defined "times" [] []
instance XmlContent Abstract.Times where
    toContents (Abstract.Times a b) =
        [CElem (Elem (N "times") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["times"]
        ; interior e $ return (Abstract.Times) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <times>, "++)
instance HTypeable Abstract.Div where
    toHType x = Defined "div" [] []
instance XmlContent Abstract.Div where
    toContents (Abstract.Div a b) =
        [CElem (Elem (N "div") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["div"]
        ; interior e $ return (Abstract.Div) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <div>, "++)
instance HTypeable Abstract.Var where
    toHType x = Defined "var" [] []
instance XmlContent Abstract.Var where
    toContents (Abstract.Var a) =
        [CElem (Elem (N "var") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["var"]
        ; interior e $ return (Abstract.Var) `apply` parseContents
        } `adjustErr` ("in <var>, "++)
instance HTypeable Abstract.Equal where
    toHType x = Defined "equal" [] []
instance XmlContent Abstract.Equal where
    toContents (Abstract.Equal a b) =
        [CElem (Elem (N "equal") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["equal"]
        ; interior e $ return (Abstract.Equal) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <equal>, "++)
instance HTypeable Abstract.Or where
    toHType x = Defined "or" [] []
instance XmlContent Abstract.Or where
    toContents (Abstract.Or a b) =
        [CElem (Elem (N "or") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["or"]
        ; interior e $ return (Abstract.Or) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <or>, "++)
instance HTypeable Abstract.And where
    toHType x = Defined "and" [] []
instance XmlContent Abstract.And where
    toContents (Abstract.And a b) =
        [CElem (Elem (N "and") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["and"]
        ; interior e $ return (Abstract.And) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <and>, "++)
instance HTypeable Abstract.ANum where
    toHType x = Defined "num" [] []
instance XmlContent Abstract.ANum where
    toContents (Abstract.ANum a) =
        [CElem (Elem (N "num") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["num"]
        ; interior e $ return (Abstract.ANum) `apply` parseContents
        } `adjustErr` ("in <num>, "++)
instance HTypeable Abstract.Biyaccpcdata where
    toHType x = Defined "biyaccpcdata" [] []
instance XmlContent Abstract.Biyaccpcdata where
    toContents (Abstract.Biyaccpcdata a) =
        [CElem (Elem (N "biyaccpcdata") [] ((toText . unStr) a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["biyaccpcdata"]
        ; interior e $ return (Abstract.Biyaccpcdata)
                       `apply` (liftM Str text `onFail` return (Str ""))
        } `adjustErr` ("in <biyaccpcdata>, "++)
instance Typeable Abstract.Arith where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "arith" "Arith") typeof
instance Typeable Abstract.Plus where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "plus" "Plus") typeof
instance Typeable Abstract.Minus where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "minus" "Minus") typeof
instance Typeable Abstract.Times where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "times" "Times") typeof
instance Typeable Abstract.Div where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "div" "Div") typeof
instance Typeable Abstract.Var where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "var" "Var") typeof
instance Typeable Abstract.Equal where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "equal" "Equal") typeof
instance Typeable Abstract.Or where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "or" "Or") typeof
instance Typeable Abstract.And where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "and" "And") typeof
instance Typeable Abstract.ANum where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "num" "ANum") typeof
instance Typeable Abstract.Biyaccpcdata where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "biyaccpcdata" "Biyaccpcdata") typeof

typeEnv = Map.insert "arith" (DynT (typeof :: Type (Abstract.Arith))) (Map.insert "plus" (DynT (typeof :: Type (Abstract.Plus))) (Map.insert "minus" (DynT (typeof :: Type (Abstract.Minus))) (Map.insert "times" (DynT (typeof :: Type (Abstract.Times))) (Map.insert "div" (DynT (typeof :: Type (Abstract.Div))) (Map.insert "var" (DynT (typeof :: Type (Abstract.Var))) (Map.insert "equal" (DynT (typeof :: Type (Abstract.Equal))) (Map.insert "or" (DynT (typeof :: Type (Abstract.Or))) (Map.insert "and" (DynT (typeof :: Type (Abstract.And))) (Map.insert "num" (DynT (typeof :: Type (Abstract.ANum))) (Map.insert "biyaccpcdata" (DynT (typeof :: Type (Abstract.Biyaccpcdata))) (Map.empty)))))))))))

xmlTypeEnv = Map.insert "arith" (XmlT (typeof :: Type (Abstract.Arith))) (Map.insert "plus" (XmlT (typeof :: Type (Abstract.Plus))) (Map.insert "minus" (XmlT (typeof :: Type (Abstract.Minus))) (Map.insert "times" (XmlT (typeof :: Type (Abstract.Times))) (Map.insert "div" (XmlT (typeof :: Type (Abstract.Div))) (Map.insert "var" (XmlT (typeof :: Type (Abstract.Var))) (Map.insert "equal" (XmlT (typeof :: Type (Abstract.Equal))) (Map.insert "or" (XmlT (typeof :: Type (Abstract.Or))) (Map.insert "and" (XmlT (typeof :: Type (Abstract.And))) (Map.insert "num" (XmlT (typeof :: Type (Abstract.ANum))) (Map.insert "biyaccpcdata" (XmlT (typeof :: Type (Abstract.Biyaccpcdata))) (Map.empty)))))))))))
