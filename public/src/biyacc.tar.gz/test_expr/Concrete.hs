{-# LANGUAGE DeriveGeneric #-}
module Concrete where

import Data.Map (Map(..))
import qualified Data.Map as Map
import Text.XML.HaXml.XmlContent hiding (List1)
import Text.XML.HaXml.Types
import Text.XML.BiFluX.DTD.HaXml.TypeDef
import Text.XML.BiFluX.DTD.Type
import Text.XML.HaXml.DtdToHaskell.TypeDef (Name(..))
import Control.Monad
import GHC.Generics as Generics

type EMPTY = ()


data Expr = ExprA0 Concrete.A0
          | ExprA1 Concrete.A1
          | ExprA2 Concrete.A2
          | ExprNull Concrete.Null
          deriving (Eq,Show,Generic)
data A0 = A0 Concrete.Expr Concrete.Term
        deriving (Eq,Show,Generic)
data A1 = A1 Concrete.Expr Concrete.Term
        deriving (Eq,Show,Generic)
newtype A2 = A2 Concrete.Term 		deriving (Eq,Show,Generic)
data Term = TermA3 Concrete.A3
          | TermA4 Concrete.A4
          | TermA5 Concrete.A5
          | TermNull Concrete.Null
          deriving (Eq,Show,Generic)
data A3 = A3 Concrete.Term Concrete.Factor
        deriving (Eq,Show,Generic)
data A4 = A4 Concrete.Term Concrete.Factor
        deriving (Eq,Show,Generic)
newtype A5 = A5 Concrete.Factor 		deriving (Eq,Show,Generic)
data Factor = FactorA6 Concrete.A6
            | FactorA7 Concrete.A7
            | FactorA8 Concrete.A8
            | FactorNull Concrete.Null
            deriving (Eq,Show,Generic)
newtype A6 = A6 Concrete.Factor 		deriving (Eq,Show,Generic)
newtype A7 = A7 Concrete.Biyaccpcdata 		deriving (Eq,Show,Generic)
newtype A8 = A8 Concrete.Expr 		deriving (Eq,Show,Generic)
newtype Biyaccpcdata = Biyaccpcdata Str 		deriving (Eq,Show,Generic)
data Null = Null 		deriving (Eq,Show,Generic)
instance HTypeable Concrete.Expr where
    toHType x = Defined "expr" [] []
instance XmlContent Concrete.Expr where
    toContents (Concrete.ExprA0 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (Concrete.ExprA1 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (Concrete.ExprA2 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (Concrete.ExprNull a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    parseContents = do 
        { e@(Elem _ [] _) <- element ["expr"]
        ; interior e $ oneOf
            [ return (Concrete.ExprA0) `apply` parseContents
            , return (Concrete.ExprA1) `apply` parseContents
            , return (Concrete.ExprA2) `apply` parseContents
            , return (Concrete.ExprNull) `apply` parseContents
            ] `adjustErr` ("in <expr>, "++)
        }
instance HTypeable Concrete.A0 where
    toHType x = Defined "a0" [] []
instance XmlContent Concrete.A0 where
    toContents (Concrete.A0 a b) =
        [CElem (Elem (N "a0") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a0"]
        ; interior e $ return (Concrete.A0) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a0>, "++)
instance HTypeable Concrete.A1 where
    toHType x = Defined "a1" [] []
instance XmlContent Concrete.A1 where
    toContents (Concrete.A1 a b) =
        [CElem (Elem (N "a1") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a1"]
        ; interior e $ return (Concrete.A1) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a1>, "++)
instance HTypeable Concrete.A2 where
    toHType x = Defined "a2" [] []
instance XmlContent Concrete.A2 where
    toContents (Concrete.A2 a) =
        [CElem (Elem (N "a2") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a2"]
        ; interior e $ return (Concrete.A2) `apply` parseContents
        } `adjustErr` ("in <a2>, "++)
instance HTypeable Concrete.Term where
    toHType x = Defined "term" [] []
instance XmlContent Concrete.Term where
    toContents (Concrete.TermA3 a) =
        [CElem (Elem (N "term") [] (toContents a) ) ()]
    toContents (Concrete.TermA4 a) =
        [CElem (Elem (N "term") [] (toContents a) ) ()]
    toContents (Concrete.TermA5 a) =
        [CElem (Elem (N "term") [] (toContents a) ) ()]
    toContents (Concrete.TermNull a) =
        [CElem (Elem (N "term") [] (toContents a) ) ()]
    parseContents = do 
        { e@(Elem _ [] _) <- element ["term"]
        ; interior e $ oneOf
            [ return (Concrete.TermA3) `apply` parseContents
            , return (Concrete.TermA4) `apply` parseContents
            , return (Concrete.TermA5) `apply` parseContents
            , return (Concrete.TermNull) `apply` parseContents
            ] `adjustErr` ("in <term>, "++)
        }
instance HTypeable Concrete.A3 where
    toHType x = Defined "a3" [] []
instance XmlContent Concrete.A3 where
    toContents (Concrete.A3 a b) =
        [CElem (Elem (N "a3") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a3"]
        ; interior e $ return (Concrete.A3) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a3>, "++)
instance HTypeable Concrete.A4 where
    toHType x = Defined "a4" [] []
instance XmlContent Concrete.A4 where
    toContents (Concrete.A4 a b) =
        [CElem (Elem (N "a4") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a4"]
        ; interior e $ return (Concrete.A4) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a4>, "++)
instance HTypeable Concrete.A5 where
    toHType x = Defined "a5" [] []
instance XmlContent Concrete.A5 where
    toContents (Concrete.A5 a) =
        [CElem (Elem (N "a5") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a5"]
        ; interior e $ return (Concrete.A5) `apply` parseContents
        } `adjustErr` ("in <a5>, "++)
instance HTypeable Concrete.Factor where
    toHType x = Defined "factor" [] []
instance XmlContent Concrete.Factor where
    toContents (Concrete.FactorA6 a) =
        [CElem (Elem (N "factor") [] (toContents a) ) ()]
    toContents (Concrete.FactorA7 a) =
        [CElem (Elem (N "factor") [] (toContents a) ) ()]
    toContents (Concrete.FactorA8 a) =
        [CElem (Elem (N "factor") [] (toContents a) ) ()]
    toContents (Concrete.FactorNull a) =
        [CElem (Elem (N "factor") [] (toContents a) ) ()]
    parseContents = do 
        { e@(Elem _ [] _) <- element ["factor"]
        ; interior e $ oneOf
            [ return (Concrete.FactorA6) `apply` parseContents
            , return (Concrete.FactorA7) `apply` parseContents
            , return (Concrete.FactorA8) `apply` parseContents
            , return (Concrete.FactorNull) `apply` parseContents
            ] `adjustErr` ("in <factor>, "++)
        }
instance HTypeable Concrete.A6 where
    toHType x = Defined "a6" [] []
instance XmlContent Concrete.A6 where
    toContents (Concrete.A6 a) =
        [CElem (Elem (N "a6") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a6"]
        ; interior e $ return (Concrete.A6) `apply` parseContents
        } `adjustErr` ("in <a6>, "++)
instance HTypeable Concrete.A7 where
    toHType x = Defined "a7" [] []
instance XmlContent Concrete.A7 where
    toContents (Concrete.A7 a) =
        [CElem (Elem (N "a7") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a7"]
        ; interior e $ return (Concrete.A7) `apply` parseContents
        } `adjustErr` ("in <a7>, "++)
instance HTypeable Concrete.A8 where
    toHType x = Defined "a8" [] []
instance XmlContent Concrete.A8 where
    toContents (Concrete.A8 a) =
        [CElem (Elem (N "a8") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a8"]
        ; interior e $ return (Concrete.A8) `apply` parseContents
        } `adjustErr` ("in <a8>, "++)
instance HTypeable Concrete.Biyaccpcdata where
    toHType x = Defined "biyaccpcdata" [] []
instance XmlContent Concrete.Biyaccpcdata where
    toContents (Concrete.Biyaccpcdata a) =
        [CElem (Elem (N "biyaccpcdata") [] ((toText . unStr) a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["biyaccpcdata"]
        ; interior e $ return (Concrete.Biyaccpcdata)
                       `apply` (liftM Str text `onFail` return (Str ""))
        } `adjustErr` ("in <biyaccpcdata>, "++)
instance HTypeable Concrete.Null where
    toHType x = Defined "null" [] []
instance XmlContent Concrete.Null where
    toContents Concrete.Null =
        [CElem (Elem (N "null") [] []) ()]
    parseContents = do
        { (Elem _ as []) <- element ["null"]
        ; return Concrete.Null
        } `adjustErr` ("in <null>, "++)
instance Typeable Concrete.Expr where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "expr" "Expr") typeof
instance Typeable Concrete.A0 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a0" "A0") typeof
instance Typeable Concrete.A1 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a1" "A1") typeof
instance Typeable Concrete.A2 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a2" "A2") typeof
instance Typeable Concrete.Term where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "term" "Term") typeof
instance Typeable Concrete.A3 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a3" "A3") typeof
instance Typeable Concrete.A4 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a4" "A4") typeof
instance Typeable Concrete.A5 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a5" "A5") typeof
instance Typeable Concrete.Factor where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "factor" "Factor") typeof
instance Typeable Concrete.A6 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a6" "A6") typeof
instance Typeable Concrete.A7 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a7" "A7") typeof
instance Typeable Concrete.A8 where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "a8" "A8") typeof
instance Typeable Concrete.Biyaccpcdata where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "biyaccpcdata" "Biyaccpcdata") typeof
instance Typeable Concrete.Null where
    typeof = Data (Text.XML.HaXml.DtdToHaskell.TypeDef.Name "null" "Null") One

typeEnv = Map.insert "expr" (DynT (typeof :: Type (Concrete.Expr))) (Map.insert "a0" (DynT (typeof :: Type (Concrete.A0))) (Map.insert "a1" (DynT (typeof :: Type (Concrete.A1))) (Map.insert "a2" (DynT (typeof :: Type (Concrete.A2))) (Map.insert "term" (DynT (typeof :: Type (Concrete.Term))) (Map.insert "a3" (DynT (typeof :: Type (Concrete.A3))) (Map.insert "a4" (DynT (typeof :: Type (Concrete.A4))) (Map.insert "a5" (DynT (typeof :: Type (Concrete.A5))) (Map.insert "factor" (DynT (typeof :: Type (Concrete.Factor))) (Map.insert "a6" (DynT (typeof :: Type (Concrete.A6))) (Map.insert "a7" (DynT (typeof :: Type (Concrete.A7))) (Map.insert "a8" (DynT (typeof :: Type (Concrete.A8))) (Map.insert "biyaccpcdata" (DynT (typeof :: Type (Concrete.Biyaccpcdata))) (Map.insert "null" (DynT (typeof :: Type (Concrete.Null))) (Map.empty))))))))))))))

xmlTypeEnv = Map.insert "expr" (XmlT (typeof :: Type (Concrete.Expr))) (Map.insert "a0" (XmlT (typeof :: Type (Concrete.A0))) (Map.insert "a1" (XmlT (typeof :: Type (Concrete.A1))) (Map.insert "a2" (XmlT (typeof :: Type (Concrete.A2))) (Map.insert "term" (XmlT (typeof :: Type (Concrete.Term))) (Map.insert "a3" (XmlT (typeof :: Type (Concrete.A3))) (Map.insert "a4" (XmlT (typeof :: Type (Concrete.A4))) (Map.insert "a5" (XmlT (typeof :: Type (Concrete.A5))) (Map.insert "factor" (XmlT (typeof :: Type (Concrete.Factor))) (Map.insert "a6" (XmlT (typeof :: Type (Concrete.A6))) (Map.insert "a7" (XmlT (typeof :: Type (Concrete.A7))) (Map.insert "a8" (XmlT (typeof :: Type (Concrete.A8))) (Map.insert "biyaccpcdata" (XmlT (typeof :: Type (Concrete.Biyaccpcdata))) (Map.insert "null" (XmlT (typeof :: Type (Concrete.Null))) (Map.empty))))))))))))))
