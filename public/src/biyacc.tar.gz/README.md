# What is this repository for? #

* BiYacc - a tool for generating pretty-printer and parser in a single programme.

----

#Installation#
1. Install GHC(Glasgow Haskell Compiler) or Haskell Platform.
2. Install BiFluX. (Refer to its README file)
3. Change your directory to the root of biyacc. Then run `cabal configure`.
4. run `cabal install`. Cabal will automatically generate you the executable file somewhere in your computer.
In mac, the location usually is: `/Users/zhuzirun/Library/Haskell/bin/biyacc`
In ubuntu, the location usually is: `/home/ubuntu/.cabal/bin/biyacc`
It depends on the system as well as the *version of your cabal*

----

#Usage#
Now we have not implemented the tool for automatically generating parser/pretty-printer pairs for **string <-> source XML** and **AST <-> view XML** according to the *concrete syntax* and *abstract syntax*. So all you can do is to do transformation between the *two XML files* rather than the *string* and the *AST*

## Try it on the website ##
Go to http://52.68.36.96, or
http://biyacc.yozora.moe
Try the *arithmetic expression* example online.

We write the pairs of parser/pretty-printers by hand, so you *cannot* change the concrete and abstract syntax.
But you can write your own interesting updating strategies(actions).
E.g. add `arith             -> '-' (Factor -> '-' (arith => Factor))`
to the first of the last group of the actions.
This will make "--x" become "x".

***Also, you can install this website on your own computer. Follow the instructions on the website.***

## On your own machine ##
1. Run `biyacc inputFile outputFile`. The default name for *outputFile* is *u.upd*. It will generate you the *concrete.dtd*, *abstract.dtd*, and *u.upd*, which is necessary for *BiFluX* to do the transformation.
2. Refer to BiFluX's documents to see how to do the transformation.
[An old tutorial](http://www.prg.nii.ac.jp/projects/BiFluX/papers/tutorial.pdf)
[The git repository](https://bitbucket.org/prl_tokyo/biflux.git). Once you cloned it, you will find there is a new unfinished tutorial in the root folder of the project.
