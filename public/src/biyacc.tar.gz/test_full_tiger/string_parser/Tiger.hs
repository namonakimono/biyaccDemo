{-# OPTIONS_GHC -w #-}
module Tiger where
import Data.Char
import Concrete
import Control.Applicative(Applicative(..))

-- parser produced by Happy Version 1.19.4

data HappyAbsSyn t5 t6 t7 t8 t9 t10 t11 t12 t13 t14 t15 t16 t17 t18 t19 t20 t21 t22
	= HappyTerminal (Token)
	| HappyErrorToken Int
	| HappyAbsSyn4 (Expr)
	| HappyAbsSyn5 t5
	| HappyAbsSyn6 t6
	| HappyAbsSyn7 t7
	| HappyAbsSyn8 t8
	| HappyAbsSyn9 t9
	| HappyAbsSyn10 t10
	| HappyAbsSyn11 t11
	| HappyAbsSyn12 t12
	| HappyAbsSyn13 t13
	| HappyAbsSyn14 t14
	| HappyAbsSyn15 t15
	| HappyAbsSyn16 t16
	| HappyAbsSyn17 t17
	| HappyAbsSyn18 t18
	| HappyAbsSyn19 t19
	| HappyAbsSyn20 t20
	| HappyAbsSyn21 t21
	| HappyAbsSyn22 t22

action_0 (23) = happyShift action_11
action_0 (24) = happyShift action_12
action_0 (26) = happyShift action_13
action_0 (30) = happyShift action_14
action_0 (32) = happyShift action_15
action_0 (34) = happyShift action_16
action_0 (35) = happyShift action_2
action_0 (41) = happyShift action_17
action_0 (45) = happyShift action_18
action_0 (53) = happyShift action_19
action_0 (4) = happyGoto action_3
action_0 (16) = happyGoto action_4
action_0 (17) = happyGoto action_5
action_0 (18) = happyGoto action_6
action_0 (19) = happyGoto action_7
action_0 (20) = happyGoto action_8
action_0 (21) = happyGoto action_9
action_0 (22) = happyGoto action_10
action_0 _ = happyFail

action_1 (35) = happyShift action_2
action_1 _ = happyFail

action_2 _ = happyReduce_1

action_3 (65) = happyAccept
action_3 _ = happyFail

action_4 (63) = happyShift action_54
action_4 _ = happyReduce_3

action_5 (62) = happyShift action_53
action_5 _ = happyReduce_36

action_6 (56) = happyShift action_47
action_6 (57) = happyShift action_48
action_6 (58) = happyShift action_49
action_6 (59) = happyShift action_50
action_6 (60) = happyShift action_51
action_6 (61) = happyShift action_52
action_6 _ = happyReduce_38

action_7 (52) = happyShift action_45
action_7 (53) = happyShift action_46
action_7 _ = happyReduce_45

action_8 (54) = happyShift action_43
action_8 (55) = happyShift action_44
action_8 _ = happyReduce_48

action_9 _ = happyReduce_51

action_10 (47) = happyShift action_40
action_10 (51) = happyShift action_41
action_10 (64) = happyShift action_42
action_10 _ = happyReduce_53

action_11 _ = happyReduce_52

action_12 (45) = happyShift action_38
action_12 (49) = happyShift action_39
action_12 _ = happyReduce_56

action_13 _ = happyReduce_2

action_14 (24) = happyShift action_37
action_14 _ = happyFail

action_15 (23) = happyShift action_11
action_15 (24) = happyShift action_12
action_15 (26) = happyShift action_13
action_15 (30) = happyShift action_14
action_15 (32) = happyShift action_15
action_15 (34) = happyShift action_16
action_15 (35) = happyShift action_2
action_15 (41) = happyShift action_17
action_15 (45) = happyShift action_18
action_15 (53) = happyShift action_19
action_15 (4) = happyGoto action_36
action_15 (16) = happyGoto action_4
action_15 (17) = happyGoto action_5
action_15 (18) = happyGoto action_6
action_15 (19) = happyGoto action_7
action_15 (20) = happyGoto action_8
action_15 (21) = happyGoto action_9
action_15 (22) = happyGoto action_10
action_15 _ = happyFail

action_16 (31) = happyShift action_33
action_16 (39) = happyShift action_34
action_16 (40) = happyShift action_35
action_16 (7) = happyGoto action_28
action_16 (8) = happyGoto action_29
action_16 (10) = happyGoto action_30
action_16 (11) = happyGoto action_31
action_16 (12) = happyGoto action_32
action_16 _ = happyFail

action_17 (23) = happyShift action_11
action_17 (24) = happyShift action_12
action_17 (26) = happyShift action_13
action_17 (30) = happyShift action_14
action_17 (32) = happyShift action_15
action_17 (34) = happyShift action_16
action_17 (35) = happyShift action_2
action_17 (41) = happyShift action_17
action_17 (45) = happyShift action_18
action_17 (53) = happyShift action_19
action_17 (4) = happyGoto action_27
action_17 (16) = happyGoto action_4
action_17 (17) = happyGoto action_5
action_17 (18) = happyGoto action_6
action_17 (19) = happyGoto action_7
action_17 (20) = happyGoto action_8
action_17 (21) = happyGoto action_9
action_17 (22) = happyGoto action_10
action_17 _ = happyFail

action_18 (23) = happyShift action_11
action_18 (24) = happyShift action_12
action_18 (26) = happyShift action_13
action_18 (30) = happyShift action_14
action_18 (32) = happyShift action_15
action_18 (34) = happyShift action_16
action_18 (35) = happyShift action_2
action_18 (41) = happyShift action_17
action_18 (45) = happyShift action_18
action_18 (53) = happyShift action_19
action_18 (4) = happyGoto action_24
action_18 (9) = happyGoto action_25
action_18 (16) = happyGoto action_26
action_18 (17) = happyGoto action_5
action_18 (18) = happyGoto action_6
action_18 (19) = happyGoto action_7
action_18 (20) = happyGoto action_8
action_18 (21) = happyGoto action_9
action_18 (22) = happyGoto action_10
action_18 _ = happyFail

action_19 (23) = happyShift action_11
action_19 (24) = happyShift action_22
action_19 (45) = happyShift action_23
action_19 (53) = happyShift action_19
action_19 (21) = happyGoto action_20
action_19 (22) = happyGoto action_21
action_19 _ = happyFail

action_20 _ = happyReduce_54

action_21 (47) = happyShift action_40
action_21 (51) = happyShift action_41
action_21 _ = happyReduce_53

action_22 _ = happyReduce_56

action_23 (23) = happyShift action_11
action_23 (24) = happyShift action_22
action_23 (45) = happyShift action_23
action_23 (53) = happyShift action_19
action_23 (16) = happyGoto action_85
action_23 (17) = happyGoto action_5
action_23 (18) = happyGoto action_6
action_23 (19) = happyGoto action_7
action_23 (20) = happyGoto action_8
action_23 (21) = happyGoto action_9
action_23 (22) = happyGoto action_21
action_23 _ = happyFail

action_24 _ = happyReduce_22

action_25 (44) = happyShift action_83
action_25 (46) = happyShift action_84
action_25 _ = happyFail

action_26 (46) = happyShift action_82
action_26 (63) = happyShift action_54
action_26 _ = happyReduce_3

action_27 (27) = happyShift action_81
action_27 _ = happyFail

action_28 (33) = happyShift action_80
action_28 _ = happyFail

action_29 (31) = happyShift action_33
action_29 (39) = happyShift action_34
action_29 (40) = happyShift action_35
action_29 (7) = happyGoto action_79
action_29 (8) = happyGoto action_29
action_29 (10) = happyGoto action_30
action_29 (11) = happyGoto action_31
action_29 (12) = happyGoto action_32
action_29 _ = happyReduce_17

action_30 _ = happyReduce_20

action_31 _ = happyReduce_21

action_32 _ = happyReduce_19

action_33 (24) = happyShift action_78
action_33 _ = happyFail

action_34 (24) = happyShift action_77
action_34 _ = happyFail

action_35 (24) = happyShift action_76
action_35 _ = happyFail

action_36 (37) = happyShift action_75
action_36 _ = happyFail

action_37 (64) = happyShift action_74
action_37 _ = happyFail

action_38 (23) = happyShift action_11
action_38 (24) = happyShift action_12
action_38 (26) = happyShift action_13
action_38 (30) = happyShift action_14
action_38 (32) = happyShift action_15
action_38 (34) = happyShift action_16
action_38 (35) = happyShift action_2
action_38 (41) = happyShift action_17
action_38 (45) = happyShift action_18
action_38 (53) = happyShift action_19
action_38 (4) = happyGoto action_72
action_38 (5) = happyGoto action_73
action_38 (16) = happyGoto action_4
action_38 (17) = happyGoto action_5
action_38 (18) = happyGoto action_6
action_38 (19) = happyGoto action_7
action_38 (20) = happyGoto action_8
action_38 (21) = happyGoto action_9
action_38 (22) = happyGoto action_10
action_38 _ = happyFail

action_39 (24) = happyShift action_71
action_39 (6) = happyGoto action_70
action_39 _ = happyFail

action_40 (23) = happyShift action_11
action_40 (24) = happyShift action_12
action_40 (26) = happyShift action_13
action_40 (30) = happyShift action_14
action_40 (32) = happyShift action_15
action_40 (34) = happyShift action_16
action_40 (35) = happyShift action_2
action_40 (41) = happyShift action_17
action_40 (45) = happyShift action_18
action_40 (53) = happyShift action_19
action_40 (4) = happyGoto action_69
action_40 (16) = happyGoto action_4
action_40 (17) = happyGoto action_5
action_40 (18) = happyGoto action_6
action_40 (19) = happyGoto action_7
action_40 (20) = happyGoto action_8
action_40 (21) = happyGoto action_9
action_40 (22) = happyGoto action_10
action_40 _ = happyFail

action_41 (24) = happyShift action_68
action_41 _ = happyFail

action_42 (23) = happyShift action_11
action_42 (24) = happyShift action_12
action_42 (26) = happyShift action_13
action_42 (30) = happyShift action_14
action_42 (32) = happyShift action_15
action_42 (34) = happyShift action_16
action_42 (35) = happyShift action_2
action_42 (41) = happyShift action_17
action_42 (45) = happyShift action_18
action_42 (53) = happyShift action_19
action_42 (4) = happyGoto action_67
action_42 (16) = happyGoto action_4
action_42 (17) = happyGoto action_5
action_42 (18) = happyGoto action_6
action_42 (19) = happyGoto action_7
action_42 (20) = happyGoto action_8
action_42 (21) = happyGoto action_9
action_42 (22) = happyGoto action_10
action_42 _ = happyFail

action_43 (23) = happyShift action_11
action_43 (24) = happyShift action_22
action_43 (45) = happyShift action_23
action_43 (53) = happyShift action_19
action_43 (21) = happyGoto action_66
action_43 (22) = happyGoto action_21
action_43 _ = happyFail

action_44 (23) = happyShift action_11
action_44 (24) = happyShift action_22
action_44 (45) = happyShift action_23
action_44 (53) = happyShift action_19
action_44 (21) = happyGoto action_65
action_44 (22) = happyGoto action_21
action_44 _ = happyFail

action_45 (23) = happyShift action_11
action_45 (24) = happyShift action_22
action_45 (45) = happyShift action_23
action_45 (53) = happyShift action_19
action_45 (20) = happyGoto action_64
action_45 (21) = happyGoto action_9
action_45 (22) = happyGoto action_21
action_45 _ = happyFail

action_46 (23) = happyShift action_11
action_46 (24) = happyShift action_22
action_46 (45) = happyShift action_23
action_46 (53) = happyShift action_19
action_46 (20) = happyGoto action_63
action_46 (21) = happyGoto action_9
action_46 (22) = happyGoto action_21
action_46 _ = happyFail

action_47 (23) = happyShift action_11
action_47 (24) = happyShift action_22
action_47 (45) = happyShift action_23
action_47 (53) = happyShift action_19
action_47 (19) = happyGoto action_62
action_47 (20) = happyGoto action_8
action_47 (21) = happyGoto action_9
action_47 (22) = happyGoto action_21
action_47 _ = happyFail

action_48 (23) = happyShift action_11
action_48 (24) = happyShift action_22
action_48 (45) = happyShift action_23
action_48 (53) = happyShift action_19
action_48 (19) = happyGoto action_61
action_48 (20) = happyGoto action_8
action_48 (21) = happyGoto action_9
action_48 (22) = happyGoto action_21
action_48 _ = happyFail

action_49 (23) = happyShift action_11
action_49 (24) = happyShift action_22
action_49 (45) = happyShift action_23
action_49 (53) = happyShift action_19
action_49 (19) = happyGoto action_60
action_49 (20) = happyGoto action_8
action_49 (21) = happyGoto action_9
action_49 (22) = happyGoto action_21
action_49 _ = happyFail

action_50 (23) = happyShift action_11
action_50 (24) = happyShift action_22
action_50 (45) = happyShift action_23
action_50 (53) = happyShift action_19
action_50 (19) = happyGoto action_59
action_50 (20) = happyGoto action_8
action_50 (21) = happyGoto action_9
action_50 (22) = happyGoto action_21
action_50 _ = happyFail

action_51 (23) = happyShift action_11
action_51 (24) = happyShift action_22
action_51 (45) = happyShift action_23
action_51 (53) = happyShift action_19
action_51 (19) = happyGoto action_58
action_51 (20) = happyGoto action_8
action_51 (21) = happyGoto action_9
action_51 (22) = happyGoto action_21
action_51 _ = happyFail

action_52 (23) = happyShift action_11
action_52 (24) = happyShift action_22
action_52 (45) = happyShift action_23
action_52 (53) = happyShift action_19
action_52 (19) = happyGoto action_57
action_52 (20) = happyGoto action_8
action_52 (21) = happyGoto action_9
action_52 (22) = happyGoto action_21
action_52 _ = happyFail

action_53 (23) = happyShift action_11
action_53 (24) = happyShift action_22
action_53 (45) = happyShift action_23
action_53 (53) = happyShift action_19
action_53 (18) = happyGoto action_56
action_53 (19) = happyGoto action_7
action_53 (20) = happyGoto action_8
action_53 (21) = happyGoto action_9
action_53 (22) = happyGoto action_21
action_53 _ = happyFail

action_54 (23) = happyShift action_11
action_54 (24) = happyShift action_22
action_54 (45) = happyShift action_23
action_54 (53) = happyShift action_19
action_54 (17) = happyGoto action_55
action_54 (18) = happyGoto action_6
action_54 (19) = happyGoto action_7
action_54 (20) = happyGoto action_8
action_54 (21) = happyGoto action_9
action_54 (22) = happyGoto action_21
action_54 _ = happyFail

action_55 (62) = happyShift action_53
action_55 _ = happyReduce_35

action_56 (56) = happyShift action_47
action_56 (57) = happyShift action_48
action_56 (58) = happyShift action_49
action_56 (59) = happyShift action_50
action_56 (60) = happyShift action_51
action_56 (61) = happyShift action_52
action_56 _ = happyReduce_37

action_57 (52) = happyShift action_45
action_57 (53) = happyShift action_46
action_57 _ = happyReduce_43

action_58 (52) = happyShift action_45
action_58 (53) = happyShift action_46
action_58 _ = happyReduce_40

action_59 (52) = happyShift action_45
action_59 (53) = happyShift action_46
action_59 _ = happyReduce_44

action_60 (52) = happyShift action_45
action_60 (53) = happyShift action_46
action_60 _ = happyReduce_41

action_61 (52) = happyShift action_45
action_61 (53) = happyShift action_46
action_61 _ = happyReduce_42

action_62 (52) = happyShift action_45
action_62 (53) = happyShift action_46
action_62 _ = happyReduce_39

action_63 (54) = happyShift action_43
action_63 (55) = happyShift action_44
action_63 _ = happyReduce_47

action_64 (54) = happyShift action_43
action_64 (55) = happyShift action_44
action_64 _ = happyReduce_46

action_65 _ = happyReduce_50

action_66 _ = happyReduce_49

action_67 _ = happyReduce_4

action_68 _ = happyReduce_57

action_69 (48) = happyShift action_100
action_69 _ = happyFail

action_70 (42) = happyShift action_98
action_70 (50) = happyShift action_99
action_70 _ = happyFail

action_71 (56) = happyShift action_97
action_71 _ = happyFail

action_72 _ = happyReduce_13

action_73 (42) = happyShift action_95
action_73 (46) = happyShift action_96
action_73 _ = happyFail

action_74 (23) = happyShift action_11
action_74 (24) = happyShift action_12
action_74 (26) = happyShift action_13
action_74 (30) = happyShift action_14
action_74 (32) = happyShift action_15
action_74 (34) = happyShift action_16
action_74 (35) = happyShift action_2
action_74 (41) = happyShift action_17
action_74 (45) = happyShift action_18
action_74 (53) = happyShift action_19
action_74 (4) = happyGoto action_94
action_74 (16) = happyGoto action_4
action_74 (17) = happyGoto action_5
action_74 (18) = happyGoto action_6
action_74 (19) = happyGoto action_7
action_74 (20) = happyGoto action_8
action_74 (21) = happyGoto action_9
action_74 (22) = happyGoto action_10
action_74 _ = happyFail

action_75 (23) = happyShift action_11
action_75 (24) = happyShift action_12
action_75 (26) = happyShift action_13
action_75 (30) = happyShift action_14
action_75 (32) = happyShift action_15
action_75 (34) = happyShift action_16
action_75 (35) = happyShift action_2
action_75 (41) = happyShift action_17
action_75 (45) = happyShift action_18
action_75 (53) = happyShift action_19
action_75 (4) = happyGoto action_93
action_75 (16) = happyGoto action_4
action_75 (17) = happyGoto action_5
action_75 (18) = happyGoto action_6
action_75 (19) = happyGoto action_7
action_75 (20) = happyGoto action_8
action_75 (21) = happyGoto action_9
action_75 (22) = happyGoto action_10
action_75 _ = happyFail

action_76 (43) = happyShift action_91
action_76 (64) = happyShift action_92
action_76 _ = happyFail

action_77 (56) = happyShift action_90
action_77 _ = happyFail

action_78 (45) = happyShift action_89
action_78 _ = happyFail

action_79 _ = happyReduce_18

action_80 (23) = happyShift action_11
action_80 (24) = happyShift action_12
action_80 (26) = happyShift action_13
action_80 (30) = happyShift action_14
action_80 (32) = happyShift action_15
action_80 (34) = happyShift action_16
action_80 (35) = happyShift action_2
action_80 (41) = happyShift action_17
action_80 (45) = happyShift action_18
action_80 (53) = happyShift action_19
action_80 (4) = happyGoto action_24
action_80 (9) = happyGoto action_88
action_80 (16) = happyGoto action_4
action_80 (17) = happyGoto action_5
action_80 (18) = happyGoto action_6
action_80 (19) = happyGoto action_7
action_80 (20) = happyGoto action_8
action_80 (21) = happyGoto action_9
action_80 (22) = happyGoto action_10
action_80 _ = happyFail

action_81 (23) = happyShift action_11
action_81 (24) = happyShift action_12
action_81 (26) = happyShift action_13
action_81 (30) = happyShift action_14
action_81 (32) = happyShift action_15
action_81 (34) = happyShift action_16
action_81 (35) = happyShift action_2
action_81 (41) = happyShift action_17
action_81 (45) = happyShift action_18
action_81 (53) = happyShift action_19
action_81 (4) = happyGoto action_87
action_81 (16) = happyGoto action_4
action_81 (17) = happyGoto action_5
action_81 (18) = happyGoto action_6
action_81 (19) = happyGoto action_7
action_81 (20) = happyGoto action_8
action_81 (21) = happyGoto action_9
action_81 (22) = happyGoto action_10
action_81 _ = happyFail

action_82 _ = happyReduce_55

action_83 (23) = happyShift action_11
action_83 (24) = happyShift action_12
action_83 (26) = happyShift action_13
action_83 (30) = happyShift action_14
action_83 (32) = happyShift action_15
action_83 (34) = happyShift action_16
action_83 (35) = happyShift action_2
action_83 (41) = happyShift action_17
action_83 (45) = happyShift action_18
action_83 (53) = happyShift action_19
action_83 (4) = happyGoto action_86
action_83 (16) = happyGoto action_4
action_83 (17) = happyGoto action_5
action_83 (18) = happyGoto action_6
action_83 (19) = happyGoto action_7
action_83 (20) = happyGoto action_8
action_83 (21) = happyGoto action_9
action_83 (22) = happyGoto action_10
action_83 _ = happyFail

action_84 _ = happyReduce_8

action_85 (46) = happyShift action_82
action_85 (63) = happyShift action_54
action_85 _ = happyFail

action_86 _ = happyReduce_23

action_87 _ = happyReduce_6

action_88 (29) = happyShift action_115
action_88 (44) = happyShift action_83
action_88 _ = happyFail

action_89 (24) = happyShift action_114
action_89 (14) = happyGoto action_112
action_89 (15) = happyGoto action_113
action_89 _ = happyFail

action_90 (24) = happyShift action_109
action_90 (25) = happyShift action_110
action_90 (49) = happyShift action_111
action_90 (13) = happyGoto action_108
action_90 _ = happyFail

action_91 (24) = happyShift action_107
action_91 _ = happyFail

action_92 (23) = happyShift action_11
action_92 (24) = happyShift action_12
action_92 (26) = happyShift action_13
action_92 (30) = happyShift action_14
action_92 (32) = happyShift action_15
action_92 (34) = happyShift action_16
action_92 (35) = happyShift action_2
action_92 (41) = happyShift action_17
action_92 (45) = happyShift action_18
action_92 (53) = happyShift action_19
action_92 (4) = happyGoto action_106
action_92 (16) = happyGoto action_4
action_92 (17) = happyGoto action_5
action_92 (18) = happyGoto action_6
action_92 (19) = happyGoto action_7
action_92 (20) = happyGoto action_8
action_92 (21) = happyGoto action_9
action_92 (22) = happyGoto action_10
action_92 _ = happyFail

action_93 (28) = happyShift action_105
action_93 _ = happyReduce_12

action_94 (38) = happyShift action_104
action_94 _ = happyFail

action_95 (23) = happyShift action_11
action_95 (24) = happyShift action_12
action_95 (26) = happyShift action_13
action_95 (30) = happyShift action_14
action_95 (32) = happyShift action_15
action_95 (34) = happyShift action_16
action_95 (35) = happyShift action_2
action_95 (41) = happyShift action_17
action_95 (45) = happyShift action_18
action_95 (53) = happyShift action_19
action_95 (4) = happyGoto action_103
action_95 (16) = happyGoto action_4
action_95 (17) = happyGoto action_5
action_95 (18) = happyGoto action_6
action_95 (19) = happyGoto action_7
action_95 (20) = happyGoto action_8
action_95 (21) = happyGoto action_9
action_95 (22) = happyGoto action_10
action_95 _ = happyFail

action_96 _ = happyReduce_9

action_97 (23) = happyShift action_11
action_97 (24) = happyShift action_12
action_97 (26) = happyShift action_13
action_97 (30) = happyShift action_14
action_97 (32) = happyShift action_15
action_97 (34) = happyShift action_16
action_97 (35) = happyShift action_2
action_97 (41) = happyShift action_17
action_97 (45) = happyShift action_18
action_97 (53) = happyShift action_19
action_97 (4) = happyGoto action_102
action_97 (16) = happyGoto action_4
action_97 (17) = happyGoto action_5
action_97 (18) = happyGoto action_6
action_97 (19) = happyGoto action_7
action_97 (20) = happyGoto action_8
action_97 (21) = happyGoto action_9
action_97 (22) = happyGoto action_10
action_97 _ = happyFail

action_98 (24) = happyShift action_101
action_98 _ = happyFail

action_99 _ = happyReduce_10

action_100 _ = happyReduce_58

action_101 (56) = happyShift action_124
action_101 _ = happyFail

action_102 _ = happyReduce_15

action_103 _ = happyReduce_14

action_104 (23) = happyShift action_11
action_104 (24) = happyShift action_12
action_104 (26) = happyShift action_13
action_104 (30) = happyShift action_14
action_104 (32) = happyShift action_15
action_104 (34) = happyShift action_16
action_104 (35) = happyShift action_2
action_104 (41) = happyShift action_17
action_104 (45) = happyShift action_18
action_104 (53) = happyShift action_19
action_104 (4) = happyGoto action_123
action_104 (16) = happyGoto action_4
action_104 (17) = happyGoto action_5
action_104 (18) = happyGoto action_6
action_104 (19) = happyGoto action_7
action_104 (20) = happyGoto action_8
action_104 (21) = happyGoto action_9
action_104 (22) = happyGoto action_10
action_104 _ = happyFail

action_105 (23) = happyShift action_11
action_105 (24) = happyShift action_12
action_105 (26) = happyShift action_13
action_105 (30) = happyShift action_14
action_105 (32) = happyShift action_15
action_105 (34) = happyShift action_16
action_105 (35) = happyShift action_2
action_105 (41) = happyShift action_17
action_105 (45) = happyShift action_18
action_105 (53) = happyShift action_19
action_105 (4) = happyGoto action_122
action_105 (16) = happyGoto action_4
action_105 (17) = happyGoto action_5
action_105 (18) = happyGoto action_6
action_105 (19) = happyGoto action_7
action_105 (20) = happyGoto action_8
action_105 (21) = happyGoto action_9
action_105 (22) = happyGoto action_10
action_105 _ = happyFail

action_106 _ = happyReduce_24

action_107 (64) = happyShift action_121
action_107 _ = happyFail

action_108 _ = happyReduce_28

action_109 _ = happyReduce_29

action_110 (36) = happyShift action_120
action_110 _ = happyFail

action_111 (24) = happyShift action_114
action_111 (14) = happyGoto action_119
action_111 (15) = happyGoto action_113
action_111 _ = happyFail

action_112 (46) = happyShift action_118
action_112 _ = happyFail

action_113 (42) = happyShift action_117
action_113 _ = happyReduce_32

action_114 (43) = happyShift action_116
action_114 _ = happyFail

action_115 _ = happyReduce_7

action_116 (24) = happyShift action_133
action_116 _ = happyFail

action_117 (24) = happyShift action_114
action_117 (14) = happyGoto action_132
action_117 (15) = happyGoto action_113
action_117 _ = happyFail

action_118 (43) = happyShift action_130
action_118 (56) = happyShift action_131
action_118 _ = happyFail

action_119 (50) = happyShift action_129
action_119 _ = happyFail

action_120 (24) = happyShift action_128
action_120 _ = happyFail

action_121 (23) = happyShift action_11
action_121 (24) = happyShift action_12
action_121 (26) = happyShift action_13
action_121 (30) = happyShift action_14
action_121 (32) = happyShift action_15
action_121 (34) = happyShift action_16
action_121 (35) = happyShift action_2
action_121 (41) = happyShift action_17
action_121 (45) = happyShift action_18
action_121 (53) = happyShift action_19
action_121 (4) = happyGoto action_127
action_121 (16) = happyGoto action_4
action_121 (17) = happyGoto action_5
action_121 (18) = happyGoto action_6
action_121 (19) = happyGoto action_7
action_121 (20) = happyGoto action_8
action_121 (21) = happyGoto action_9
action_121 (22) = happyGoto action_10
action_121 _ = happyFail

action_122 _ = happyReduce_11

action_123 (27) = happyShift action_126
action_123 _ = happyFail

action_124 (23) = happyShift action_11
action_124 (24) = happyShift action_12
action_124 (26) = happyShift action_13
action_124 (30) = happyShift action_14
action_124 (32) = happyShift action_15
action_124 (34) = happyShift action_16
action_124 (35) = happyShift action_2
action_124 (41) = happyShift action_17
action_124 (45) = happyShift action_18
action_124 (53) = happyShift action_19
action_124 (4) = happyGoto action_125
action_124 (16) = happyGoto action_4
action_124 (17) = happyGoto action_5
action_124 (18) = happyGoto action_6
action_124 (19) = happyGoto action_7
action_124 (20) = happyGoto action_8
action_124 (21) = happyGoto action_9
action_124 (22) = happyGoto action_10
action_124 _ = happyFail

action_125 _ = happyReduce_16

action_126 (23) = happyShift action_11
action_126 (24) = happyShift action_12
action_126 (26) = happyShift action_13
action_126 (30) = happyShift action_14
action_126 (32) = happyShift action_15
action_126 (34) = happyShift action_16
action_126 (35) = happyShift action_2
action_126 (41) = happyShift action_17
action_126 (45) = happyShift action_18
action_126 (53) = happyShift action_19
action_126 (4) = happyGoto action_136
action_126 (16) = happyGoto action_4
action_126 (17) = happyGoto action_5
action_126 (18) = happyGoto action_6
action_126 (19) = happyGoto action_7
action_126 (20) = happyGoto action_8
action_126 (21) = happyGoto action_9
action_126 (22) = happyGoto action_10
action_126 _ = happyFail

action_127 _ = happyReduce_25

action_128 _ = happyReduce_31

action_129 _ = happyReduce_30

action_130 (24) = happyShift action_135
action_130 _ = happyFail

action_131 (23) = happyShift action_11
action_131 (24) = happyShift action_12
action_131 (26) = happyShift action_13
action_131 (30) = happyShift action_14
action_131 (32) = happyShift action_15
action_131 (34) = happyShift action_16
action_131 (35) = happyShift action_2
action_131 (41) = happyShift action_17
action_131 (45) = happyShift action_18
action_131 (53) = happyShift action_19
action_131 (4) = happyGoto action_134
action_131 (16) = happyGoto action_4
action_131 (17) = happyGoto action_5
action_131 (18) = happyGoto action_6
action_131 (19) = happyGoto action_7
action_131 (20) = happyGoto action_8
action_131 (21) = happyGoto action_9
action_131 (22) = happyGoto action_10
action_131 _ = happyFail

action_132 _ = happyReduce_33

action_133 _ = happyReduce_34

action_134 _ = happyReduce_26

action_135 (56) = happyShift action_137
action_135 _ = happyFail

action_136 _ = happyReduce_5

action_137 (23) = happyShift action_11
action_137 (24) = happyShift action_12
action_137 (26) = happyShift action_13
action_137 (30) = happyShift action_14
action_137 (32) = happyShift action_15
action_137 (34) = happyShift action_16
action_137 (35) = happyShift action_2
action_137 (41) = happyShift action_17
action_137 (45) = happyShift action_18
action_137 (53) = happyShift action_19
action_137 (4) = happyGoto action_138
action_137 (16) = happyGoto action_4
action_137 (17) = happyGoto action_5
action_137 (18) = happyGoto action_6
action_137 (19) = happyGoto action_7
action_137 (20) = happyGoto action_8
action_137 (21) = happyGoto action_9
action_137 (22) = happyGoto action_10
action_137 _ = happyFail

action_138 _ = happyReduce_27

happyReduce_1 = happySpecReduce_1  4 happyReduction_1
happyReduction_1 _
	 =  HappyAbsSyn4
		 (ExprA0 A0
	)

happyReduce_2 = happySpecReduce_1  4 happyReduction_2
happyReduction_2 _
	 =  HappyAbsSyn4
		 (ExprA1 A1
	)

happyReduce_3 = happySpecReduce_1  4 happyReduction_3
happyReduction_3 (HappyAbsSyn16  happy_var_1)
	 =  HappyAbsSyn4
		 (ExprA2 (A2 happy_var_1)
	)
happyReduction_3 _  = notHappyAtAll 

happyReduce_4 = happySpecReduce_3  4 happyReduction_4
happyReduction_4 (HappyAbsSyn4  happy_var_3)
	_
	(HappyAbsSyn22  happy_var_1)
	 =  HappyAbsSyn4
		 (ExprA3 (A3 happy_var_1 happy_var_3)
	)
happyReduction_4 _ _ _  = notHappyAtAll 

happyReduce_5 = happyReduce 8 4 happyReduction_5
happyReduction_5 ((HappyAbsSyn4  happy_var_8) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn4  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn4  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (TokenString happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn4
		 (ExprA4 (A4 (Biyaccpcdata happy_var_2) happy_var_4 happy_var_6 happy_var_8)
	) `HappyStk` happyRest

happyReduce_6 = happyReduce 4 4 happyReduction_6
happyReduction_6 ((HappyAbsSyn4  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn4  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn4
		 (ExprA5 (A5 happy_var_2 happy_var_4)
	) `HappyStk` happyRest

happyReduce_7 = happyReduce 5 4 happyReduction_7
happyReduction_7 (_ `HappyStk`
	(HappyAbsSyn9  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn7  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn4
		 (ExprA6 (A6 happy_var_2 happy_var_4)
	) `HappyStk` happyRest

happyReduce_8 = happySpecReduce_3  4 happyReduction_8
happyReduction_8 _
	(HappyAbsSyn9  happy_var_2)
	_
	 =  HappyAbsSyn4
		 (ExprA7 (A7 happy_var_2)
	)
happyReduction_8 _ _ _  = notHappyAtAll 

happyReduce_9 = happyReduce 4 4 happyReduction_9
happyReduction_9 (_ `HappyStk`
	(HappyAbsSyn5  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (TokenString happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn4
		 (ExprA8 (A8 (Biyaccpcdata happy_var_1) happy_var_3)
	) `HappyStk` happyRest

happyReduce_10 = happyReduce 4 4 happyReduction_10
happyReduction_10 (_ `HappyStk`
	(HappyAbsSyn6  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (TokenString happy_var_1)) `HappyStk`
	happyRest)
	 = HappyAbsSyn4
		 (ExprA9 (A9 (Biyaccpcdata happy_var_1) happy_var_3)
	) `HappyStk` happyRest

happyReduce_11 = happyReduce 6 4 happyReduction_11
happyReduction_11 ((HappyAbsSyn4  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn4  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn4  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn4
		 (ExprA10 (A10 happy_var_2 happy_var_4 happy_var_6)
	) `HappyStk` happyRest

happyReduce_12 = happyReduce 4 4 happyReduction_12
happyReduction_12 ((HappyAbsSyn4  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn4  happy_var_2) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn4
		 (ExprA11 (A11 happy_var_2 happy_var_4)
	) `HappyStk` happyRest

happyReduce_13 = happySpecReduce_1  5 happyReduction_13
happyReduction_13 (HappyAbsSyn4  happy_var_1)
	 =  HappyAbsSyn5
		 (ExprlistA12 (A12 happy_var_1)
	)
happyReduction_13 _  = notHappyAtAll 

happyReduce_14 = happySpecReduce_3  5 happyReduction_14
happyReduction_14 (HappyAbsSyn4  happy_var_3)
	_
	(HappyAbsSyn5  happy_var_1)
	 =  HappyAbsSyn5
		 (ExprlistA13 (A13 happy_var_1 happy_var_3)
	)
happyReduction_14 _ _ _  = notHappyAtAll 

happyReduce_15 = happySpecReduce_3  6 happyReduction_15
happyReduction_15 (HappyAbsSyn4  happy_var_3)
	_
	(HappyTerminal (TokenString happy_var_1))
	 =  HappyAbsSyn6
		 (FieldlistA14 (A14 (Biyaccpcdata happy_var_1) happy_var_3)
	)
happyReduction_15 _ _ _  = notHappyAtAll 

happyReduce_16 = happyReduce 5 6 happyReduction_16
happyReduction_16 ((HappyAbsSyn4  happy_var_5) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (TokenString happy_var_3)) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn6  happy_var_1) `HappyStk`
	happyRest)
	 = HappyAbsSyn6
		 (FieldlistA15 (A15 happy_var_1 (Biyaccpcdata happy_var_3) happy_var_5)
	) `HappyStk` happyRest

happyReduce_17 = happySpecReduce_1  7 happyReduction_17
happyReduction_17 (HappyAbsSyn8  happy_var_1)
	 =  HappyAbsSyn7
		 (DeclarationlistA16 (A16 happy_var_1)
	)
happyReduction_17 _  = notHappyAtAll 

happyReduce_18 = happySpecReduce_2  7 happyReduction_18
happyReduction_18 (HappyAbsSyn7  happy_var_2)
	(HappyAbsSyn8  happy_var_1)
	 =  HappyAbsSyn7
		 (DeclarationlistA17 (A17 happy_var_1 happy_var_2)
	)
happyReduction_18 _ _  = notHappyAtAll 

happyReduce_19 = happySpecReduce_1  8 happyReduction_19
happyReduction_19 (HappyAbsSyn12  happy_var_1)
	 =  HappyAbsSyn8
		 (DeclarationA18 (A18 happy_var_1)
	)
happyReduction_19 _  = notHappyAtAll 

happyReduce_20 = happySpecReduce_1  8 happyReduction_20
happyReduction_20 (HappyAbsSyn10  happy_var_1)
	 =  HappyAbsSyn8
		 (DeclarationA19 (A19 happy_var_1)
	)
happyReduction_20 _  = notHappyAtAll 

happyReduce_21 = happySpecReduce_1  8 happyReduction_21
happyReduction_21 (HappyAbsSyn11  happy_var_1)
	 =  HappyAbsSyn8
		 (DeclarationA20 (A20 happy_var_1)
	)
happyReduction_21 _  = notHappyAtAll 

happyReduce_22 = happySpecReduce_1  9 happyReduction_22
happyReduction_22 (HappyAbsSyn4  happy_var_1)
	 =  HappyAbsSyn9
		 (ExprseqA21 (A21 happy_var_1)
	)
happyReduction_22 _  = notHappyAtAll 

happyReduce_23 = happySpecReduce_3  9 happyReduction_23
happyReduction_23 (HappyAbsSyn4  happy_var_3)
	_
	(HappyAbsSyn9  happy_var_1)
	 =  HappyAbsSyn9
		 (ExprseqA22 (A22 happy_var_1 happy_var_3)
	)
happyReduction_23 _ _ _  = notHappyAtAll 

happyReduce_24 = happyReduce 4 10 happyReduction_24
happyReduction_24 ((HappyAbsSyn4  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (TokenString happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn10
		 (VariabledeclarationA23 (A23 (Biyaccpcdata happy_var_2) happy_var_4)
	) `HappyStk` happyRest

happyReduce_25 = happyReduce 6 10 happyReduction_25
happyReduction_25 ((HappyAbsSyn4  happy_var_6) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (TokenString happy_var_4)) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (TokenString happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn10
		 (VariabledeclarationA24 (A24 (Biyaccpcdata happy_var_2) (Biyaccpcdata happy_var_4) happy_var_6)
	) `HappyStk` happyRest

happyReduce_26 = happyReduce 7 11 happyReduction_26
happyReduction_26 ((HappyAbsSyn4  happy_var_7) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn14  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (TokenString happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn11
		 (FunctiondeclarationA25 (A25 (Biyaccpcdata happy_var_2) happy_var_4 happy_var_7)
	) `HappyStk` happyRest

happyReduce_27 = happyReduce 9 11 happyReduction_27
happyReduction_27 ((HappyAbsSyn4  happy_var_9) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (TokenString happy_var_7)) `HappyStk`
	_ `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn14  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (TokenString happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn11
		 (FunctiondeclarationA26 (A26 (Biyaccpcdata happy_var_2) happy_var_4 (Biyaccpcdata happy_var_7) happy_var_9)
	) `HappyStk` happyRest

happyReduce_28 = happyReduce 4 12 happyReduction_28
happyReduction_28 ((HappyAbsSyn13  happy_var_4) `HappyStk`
	_ `HappyStk`
	(HappyTerminal (TokenString happy_var_2)) `HappyStk`
	_ `HappyStk`
	happyRest)
	 = HappyAbsSyn12
		 (TypedeclarationA27 (A27 (Biyaccpcdata happy_var_2) happy_var_4)
	) `HappyStk` happyRest

happyReduce_29 = happySpecReduce_1  13 happyReduction_29
happyReduction_29 (HappyTerminal (TokenString happy_var_1))
	 =  HappyAbsSyn13
		 (PtypeA28 (A28 (Biyaccpcdata happy_var_1))
	)
happyReduction_29 _  = notHappyAtAll 

happyReduce_30 = happySpecReduce_3  13 happyReduction_30
happyReduction_30 _
	(HappyAbsSyn14  happy_var_2)
	_
	 =  HappyAbsSyn13
		 (PtypeA29 (A29 happy_var_2)
	)
happyReduction_30 _ _ _  = notHappyAtAll 

happyReduce_31 = happySpecReduce_3  13 happyReduction_31
happyReduction_31 (HappyTerminal (TokenString happy_var_3))
	_
	_
	 =  HappyAbsSyn13
		 (PtypeA30 (A30 (Biyaccpcdata happy_var_3))
	)
happyReduction_31 _ _ _  = notHappyAtAll 

happyReduce_32 = happySpecReduce_1  14 happyReduction_32
happyReduction_32 (HappyAbsSyn15  happy_var_1)
	 =  HappyAbsSyn14
		 (TypefieldsA31 (A31 happy_var_1)
	)
happyReduction_32 _  = notHappyAtAll 

happyReduce_33 = happySpecReduce_3  14 happyReduction_33
happyReduction_33 (HappyAbsSyn14  happy_var_3)
	_
	(HappyAbsSyn15  happy_var_1)
	 =  HappyAbsSyn14
		 (TypefieldsA32 (A32 happy_var_1 happy_var_3)
	)
happyReduction_33 _ _ _  = notHappyAtAll 

happyReduce_34 = happySpecReduce_3  15 happyReduction_34
happyReduction_34 (HappyTerminal (TokenString happy_var_3))
	_
	(HappyTerminal (TokenString happy_var_1))
	 =  HappyAbsSyn15
		 (TypefieldA33 (A33 (Biyaccpcdata happy_var_1) (Biyaccpcdata happy_var_3))
	)
happyReduction_34 _ _ _  = notHappyAtAll 

happyReduce_35 = happySpecReduce_3  16 happyReduction_35
happyReduction_35 (HappyAbsSyn17  happy_var_3)
	_
	(HappyAbsSyn16  happy_var_1)
	 =  HappyAbsSyn16
		 (BinaryopA34 (A34 happy_var_1 happy_var_3)
	)
happyReduction_35 _ _ _  = notHappyAtAll 

happyReduce_36 = happySpecReduce_1  16 happyReduction_36
happyReduction_36 (HappyAbsSyn17  happy_var_1)
	 =  HappyAbsSyn16
		 (BinaryopA35 (A35 happy_var_1)
	)
happyReduction_36 _  = notHappyAtAll 

happyReduce_37 = happySpecReduce_3  17 happyReduction_37
happyReduction_37 (HappyAbsSyn18  happy_var_3)
	_
	(HappyAbsSyn17  happy_var_1)
	 =  HappyAbsSyn17
		 (Binaryop1A36 (A36 happy_var_1 happy_var_3)
	)
happyReduction_37 _ _ _  = notHappyAtAll 

happyReduce_38 = happySpecReduce_1  17 happyReduction_38
happyReduction_38 (HappyAbsSyn18  happy_var_1)
	 =  HappyAbsSyn17
		 (Binaryop1A37 (A37 happy_var_1)
	)
happyReduction_38 _  = notHappyAtAll 

happyReduce_39 = happySpecReduce_3  18 happyReduction_39
happyReduction_39 (HappyAbsSyn19  happy_var_3)
	_
	(HappyAbsSyn18  happy_var_1)
	 =  HappyAbsSyn18
		 (Binaryop2A38 (A38 happy_var_1 happy_var_3)
	)
happyReduction_39 _ _ _  = notHappyAtAll 

happyReduce_40 = happySpecReduce_3  18 happyReduction_40
happyReduction_40 (HappyAbsSyn19  happy_var_3)
	_
	(HappyAbsSyn18  happy_var_1)
	 =  HappyAbsSyn18
		 (Binaryop2A39 (A39 happy_var_1 happy_var_3)
	)
happyReduction_40 _ _ _  = notHappyAtAll 

happyReduce_41 = happySpecReduce_3  18 happyReduction_41
happyReduction_41 (HappyAbsSyn19  happy_var_3)
	_
	(HappyAbsSyn18  happy_var_1)
	 =  HappyAbsSyn18
		 (Binaryop2A40 (A40 happy_var_1 happy_var_3)
	)
happyReduction_41 _ _ _  = notHappyAtAll 

happyReduce_42 = happySpecReduce_3  18 happyReduction_42
happyReduction_42 (HappyAbsSyn19  happy_var_3)
	_
	(HappyAbsSyn18  happy_var_1)
	 =  HappyAbsSyn18
		 (Binaryop2A41 (A41 happy_var_1 happy_var_3)
	)
happyReduction_42 _ _ _  = notHappyAtAll 

happyReduce_43 = happySpecReduce_3  18 happyReduction_43
happyReduction_43 (HappyAbsSyn19  happy_var_3)
	_
	(HappyAbsSyn18  happy_var_1)
	 =  HappyAbsSyn18
		 (Binaryop2A42 (A42 happy_var_1 happy_var_3)
	)
happyReduction_43 _ _ _  = notHappyAtAll 

happyReduce_44 = happySpecReduce_3  18 happyReduction_44
happyReduction_44 (HappyAbsSyn19  happy_var_3)
	_
	(HappyAbsSyn18  happy_var_1)
	 =  HappyAbsSyn18
		 (Binaryop2A43 (A43 happy_var_1 happy_var_3)
	)
happyReduction_44 _ _ _  = notHappyAtAll 

happyReduce_45 = happySpecReduce_1  18 happyReduction_45
happyReduction_45 (HappyAbsSyn19  happy_var_1)
	 =  HappyAbsSyn18
		 (Binaryop2A44 (A44 happy_var_1)
	)
happyReduction_45 _  = notHappyAtAll 

happyReduce_46 = happySpecReduce_3  19 happyReduction_46
happyReduction_46 (HappyAbsSyn20  happy_var_3)
	_
	(HappyAbsSyn19  happy_var_1)
	 =  HappyAbsSyn19
		 (Binaryop3A45 (A45 happy_var_1 happy_var_3)
	)
happyReduction_46 _ _ _  = notHappyAtAll 

happyReduce_47 = happySpecReduce_3  19 happyReduction_47
happyReduction_47 (HappyAbsSyn20  happy_var_3)
	_
	(HappyAbsSyn19  happy_var_1)
	 =  HappyAbsSyn19
		 (Binaryop3A46 (A46 happy_var_1 happy_var_3)
	)
happyReduction_47 _ _ _  = notHappyAtAll 

happyReduce_48 = happySpecReduce_1  19 happyReduction_48
happyReduction_48 (HappyAbsSyn20  happy_var_1)
	 =  HappyAbsSyn19
		 (Binaryop3A47 (A47 happy_var_1)
	)
happyReduction_48 _  = notHappyAtAll 

happyReduce_49 = happySpecReduce_3  20 happyReduction_49
happyReduction_49 (HappyAbsSyn21  happy_var_3)
	_
	(HappyAbsSyn20  happy_var_1)
	 =  HappyAbsSyn20
		 (Binaryop4A48 (A48 happy_var_1 happy_var_3)
	)
happyReduction_49 _ _ _  = notHappyAtAll 

happyReduce_50 = happySpecReduce_3  20 happyReduction_50
happyReduction_50 (HappyAbsSyn21  happy_var_3)
	_
	(HappyAbsSyn20  happy_var_1)
	 =  HappyAbsSyn20
		 (Binaryop4A49 (A49 happy_var_1 happy_var_3)
	)
happyReduction_50 _ _ _  = notHappyAtAll 

happyReduce_51 = happySpecReduce_1  20 happyReduction_51
happyReduction_51 (HappyAbsSyn21  happy_var_1)
	 =  HappyAbsSyn20
		 (Binaryop4A50 (A50 happy_var_1)
	)
happyReduction_51 _  = notHappyAtAll 

happyReduce_52 = happySpecReduce_1  21 happyReduction_52
happyReduction_52 (HappyTerminal (TokenNumber happy_var_1))
	 =  HappyAbsSyn21
		 (Binaryop5A51 (A51 (Biyaccpcdata (show happy_var_1)))
	)
happyReduction_52 _  = notHappyAtAll 

happyReduce_53 = happySpecReduce_1  21 happyReduction_53
happyReduction_53 (HappyAbsSyn22  happy_var_1)
	 =  HappyAbsSyn21
		 (Binaryop5A52 (A52 happy_var_1)
	)
happyReduction_53 _  = notHappyAtAll 

happyReduce_54 = happySpecReduce_2  21 happyReduction_54
happyReduction_54 (HappyAbsSyn21  happy_var_2)
	_
	 =  HappyAbsSyn21
		 (Binaryop5A53 (A53 happy_var_2)
	)
happyReduction_54 _ _  = notHappyAtAll 

happyReduce_55 = happySpecReduce_3  21 happyReduction_55
happyReduction_55 _
	(HappyAbsSyn16  happy_var_2)
	_
	 =  HappyAbsSyn21
		 (Binaryop5A54 (A54 happy_var_2)
	)
happyReduction_55 _ _ _  = notHappyAtAll 

happyReduce_56 = happySpecReduce_1  22 happyReduction_56
happyReduction_56 (HappyTerminal (TokenString happy_var_1))
	 =  HappyAbsSyn22
		 (LvalueA55 (A55 (Biyaccpcdata happy_var_1))
	)
happyReduction_56 _  = notHappyAtAll 

happyReduce_57 = happySpecReduce_3  22 happyReduction_57
happyReduction_57 (HappyTerminal (TokenString happy_var_3))
	_
	(HappyAbsSyn22  happy_var_1)
	 =  HappyAbsSyn22
		 (LvalueA56 (A56 happy_var_1 (Biyaccpcdata happy_var_3))
	)
happyReduction_57 _ _ _  = notHappyAtAll 

happyReduce_58 = happyReduce 4 22 happyReduction_58
happyReduction_58 (_ `HappyStk`
	(HappyAbsSyn4  happy_var_3) `HappyStk`
	_ `HappyStk`
	(HappyAbsSyn22  happy_var_1) `HappyStk`
	happyRest)
	 = HappyAbsSyn22
		 (LvalueA57 (A57 happy_var_1 happy_var_3)
	) `HappyStk` happyRest

happyNewToken action sts stk [] =
	action 65 65 notHappyAtAll (HappyState action) sts stk []

happyNewToken action sts stk (tk:tks) =
	let cont i = action i i tk (HappyState action) sts stk tks in
	case tk of {
	TokenNumber happy_dollar_dollar -> cont 23;
	TokenString happy_dollar_dollar -> cont 24;
	TokenArray -> cont 25;
	TokenBreak -> cont 26;
	TokenDo -> cont 27;
	TokenElse -> cont 28;
	TokenEnd -> cont 29;
	TokenFor -> cont 30;
	TokenFunction -> cont 31;
	TokenIf -> cont 32;
	TokenIn -> cont 33;
	TokenLet -> cont 34;
	TokenNil -> cont 35;
	TokenOf -> cont 36;
	TokenThen -> cont 37;
	TokenTo -> cont 38;
	TokenType -> cont 39;
	TokenVar -> cont 40;
	TokenWhile -> cont 41;
	TokenComma -> cont 42;
	TokenColon -> cont 43;
	TokenSemicolon -> cont 44;
	TokenLeftParentheses -> cont 45;
	TokenRightParentheses -> cont 46;
	TokenLeftBracket -> cont 47;
	TokenRightBracket -> cont 48;
	TokenLeftBrace -> cont 49;
	TokenRightBrace -> cont 50;
	TokenPeriod -> cont 51;
	TokenPlus -> cont 52;
	TokenMinus -> cont 53;
	TokenMult -> cont 54;
	TokenDivision -> cont 55;
	TokenEqual -> cont 56;
	TokenDiff -> cont 57;
	TokenLT -> cont 58;
	TokenLET -> cont 59;
	TokenGT -> cont 60;
	TokenGET -> cont 61;
	TokenAnd -> cont 62;
	TokenOr -> cont 63;
	TokenAssign -> cont 64;
	_ -> happyError' (tk:tks)
	}

happyError_ 65 tk tks = happyError' tks
happyError_ _ tk tks = happyError' (tk:tks)

newtype HappyIdentity a = HappyIdentity a
happyIdentity = HappyIdentity
happyRunIdentity (HappyIdentity a) = a

instance Functor HappyIdentity where
    fmap f (HappyIdentity a) = HappyIdentity (f a)

instance Applicative HappyIdentity where
    pure    = return
    a <*> b = (fmap id a) <*> b
instance Monad HappyIdentity where
    return = HappyIdentity
    (HappyIdentity p) >>= q = q p

happyThen :: () => HappyIdentity a -> (a -> HappyIdentity b) -> HappyIdentity b
happyThen = (>>=)
happyReturn :: () => a -> HappyIdentity a
happyReturn = (return)
happyThen1 m k tks = (>>=) m (\a -> k a tks)
happyReturn1 :: () => a -> b -> HappyIdentity a
happyReturn1 = \a tks -> (return) a
happyError' :: () => [(Token)] -> HappyIdentity a
happyError' = HappyIdentity . happyError

tiger tks = happyRunIdentity happySomeParser where
  happySomeParser = happyThen (happyParse action_0 tks) (\x -> case x of {HappyAbsSyn4 z -> happyReturn z; _other -> notHappyAtAll })

happySeq = happyDontSeq


happyError :: [Token] -> a
happyError a = error ("Parse error -> " ++ show a ++ "\n")








data Token = TokenArray
           | TokenNumber Int
           | TokenString String
           | TokenBreak    
           | TokenDo 
           | TokenElse   
           | TokenEnd  
           | TokenFor  
           | TokenFunction      
           | TokenIf       
           | TokenIn       
           | TokenLet       
           | TokenNil       
           | TokenOf       
           | TokenThen       
           | TokenTo       
           | TokenType       
           | TokenVar       
           | TokenWhile       
           | TokenComma 
           | TokenColon 
           | TokenSemicolon 
           | TokenLeftParentheses 
           | TokenRightParentheses
           | TokenLeftBracket 
           | TokenRightBracket 
           | TokenLeftBrace 
           | TokenRightBrace 
           | TokenPeriod 
           | TokenPlus 
           | TokenMinus 
           | TokenMult
           | TokenDivision 
           | TokenEqual 
           | TokenDiff  
           | TokenLT 
           | TokenLET  
           | TokenGT 
           | TokenGET  
           | TokenAnd 
           | TokenOr 
           | TokenAssign
           deriving (Show)


lexer :: String -> [Token]
lexer [] = []
lexer ('"':cs)                             = let (a,b) = scanString cs
                                             in  TokenString a : lexer b
lexer ('<':'>':cs)                         = TokenDiff             : lexer cs   
lexer ('<':'=':cs)                         = TokenLET              : lexer cs  
lexer ('>':'=':cs)                         = TokenGET              : lexer cs  
lexer (':':'=':cs)                         = TokenAssign           : lexer cs
lexer (',':cs)                             = TokenComma            : lexer cs 
lexer (':':cs)                             = TokenColon            : lexer cs 
lexer (';':cs)                             = TokenSemicolon        : lexer cs   
lexer ('(':cs)                             = TokenLeftParentheses  : lexer cs     
lexer (')':cs)                             = TokenRightParentheses : lexer cs 
lexer ('[':cs)                             = TokenLeftBracket      : lexer cs 
lexer (']':cs)                             = TokenRightBracket     : lexer cs  
lexer ('{':cs)                             = TokenLeftBrace        : lexer cs   
lexer ('}':cs)                             = TokenRightBrace       : lexer cs    
lexer ('.':cs)                             = TokenPeriod           : lexer cs
lexer ('+':cs)                             = TokenPlus             : lexer cs
lexer ('-':cs)                             = TokenMinus            : lexer cs   
lexer ('*':cs)                             = TokenMult             : lexer cs  
lexer ('/':cs)                             = TokenDivision         : lexer cs  
lexer ('=':cs)                             = TokenEqual            : lexer cs   
lexer ('<':cs)                             = TokenLT               : lexer cs
lexer ('>':cs)                             = TokenGT               : lexer cs
lexer ('&':cs)                             = TokenAnd              : lexer cs 
lexer ('|':cs)                             = TokenOr               : lexer cs
lexer (c:cs) 
	| isSpace c = lexer cs
	| isAlpha c = lexString (c:cs)
	| isDigit c = lexNum (c:cs)
lexer cs = error . show $ cs  

scanString :: String -> (String, String)
scanString ('"':cs) = ([] , cs)
scanString ('\\':'"':cs) = let (x, xs) = scanString cs
                           in  (['\\','"'] ++ x , xs)
scanString (c:cs)   = let (x,xs) = scanString cs
                      in (c:x,xs)
scanString [] = error "Unterminated String"

lexNum cs = TokenNumber (read num) : lexer rest
	where (num,rest) = span isDigit cs
lexString cs = case span (\x -> isAlpha x || isDigit x) cs of
             (string,rest) -> case string of
                                  ("array")      -> TokenArray            : lexer rest 
                                  ("break")      -> TokenBreak            : lexer rest 
                                  ("do")         -> TokenDo               : lexer rest 
                                  ("else")       -> TokenElse             : lexer rest 
                                  ("end")        -> TokenEnd              : lexer rest 
                                  ("for")        -> TokenFor              : lexer rest 
                                  ("function")   -> TokenFunction         : lexer rest 
                                  ("if")         -> TokenIf               : lexer rest 
                                  ("in")         -> TokenIn               : lexer rest 
                                  ("let")        -> TokenLet              : lexer rest 
                                  ("nil")        -> TokenNil              : lexer rest 
                                  ("of")         -> TokenOf               : lexer rest 
                                  ("then")       -> TokenThen             : lexer rest 
                                  ("to")         -> TokenTo               : lexer rest
                                  ("type")       -> TokenType             : lexer rest 
                                  ("var")        -> TokenVar              : lexer rest 
                                  ("while")      -> TokenWhile            : lexer rest                          
                                  _              -> (TokenString string)  : lexer rest
{-# LINE 1 "templates/GenericTemplate.hs" #-}
-- Id: GenericTemplate.hs,v 1.26 2005/01/14 14:47:22 simonmar Exp 

























infixr 9 `HappyStk`
data HappyStk a = HappyStk a (HappyStk a)

-----------------------------------------------------------------------------
-- starting the parse

happyParse start_state = happyNewToken start_state notHappyAtAll notHappyAtAll

-----------------------------------------------------------------------------
-- Accepting the parse

-- If the current token is (1), it means we've just accepted a partial
-- parse (a %partial parser).  We must ignore the saved token on the top of
-- the stack in this case.
happyAccept (1) tk st sts (_ `HappyStk` ans `HappyStk` _) =
        happyReturn1 ans
happyAccept j tk st sts (HappyStk ans _) = 
         (happyReturn1 ans)

-----------------------------------------------------------------------------
-- Arrays only: do the next action



-----------------------------------------------------------------------------
-- HappyState data type (not arrays)



newtype HappyState b c = HappyState
        (Int ->                    -- token number
         Int ->                    -- token number (yes, again)
         b ->                           -- token semantic value
         HappyState b c ->              -- current state
         [HappyState b c] ->            -- state stack
         c)



-----------------------------------------------------------------------------
-- Shifting a token

happyShift new_state (1) tk st sts stk@(x `HappyStk` _) =
     let i = (case x of { HappyErrorToken (i) -> i }) in
--     trace "shifting the error token" $
     new_state i i tk (HappyState (new_state)) ((st):(sts)) (stk)

happyShift new_state i tk st sts stk =
     happyNewToken new_state ((st):(sts)) ((HappyTerminal (tk))`HappyStk`stk)

-- happyReduce is specialised for the common cases.

happySpecReduce_0 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_0 nt fn j tk st@((HappyState (action))) sts stk
     = action nt j tk st ((st):(sts)) (fn `HappyStk` stk)

happySpecReduce_1 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_1 nt fn j tk _ sts@(((st@(HappyState (action))):(_))) (v1`HappyStk`stk')
     = let r = fn v1 in
       happySeq r (action nt j tk st sts (r `HappyStk` stk'))

happySpecReduce_2 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_2 nt fn j tk _ ((_):(sts@(((st@(HappyState (action))):(_))))) (v1`HappyStk`v2`HappyStk`stk')
     = let r = fn v1 v2 in
       happySeq r (action nt j tk st sts (r `HappyStk` stk'))

happySpecReduce_3 i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happySpecReduce_3 nt fn j tk _ ((_):(((_):(sts@(((st@(HappyState (action))):(_))))))) (v1`HappyStk`v2`HappyStk`v3`HappyStk`stk')
     = let r = fn v1 v2 v3 in
       happySeq r (action nt j tk st sts (r `HappyStk` stk'))

happyReduce k i fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happyReduce k nt fn j tk st sts stk
     = case happyDrop (k - ((1) :: Int)) sts of
         sts1@(((st1@(HappyState (action))):(_))) ->
                let r = fn stk in  -- it doesn't hurt to always seq here...
                happyDoSeq r (action nt j tk st1 sts1 r)

happyMonadReduce k nt fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happyMonadReduce k nt fn j tk st sts stk =
      case happyDrop k ((st):(sts)) of
        sts1@(((st1@(HappyState (action))):(_))) ->
          let drop_stk = happyDropStk k stk in
          happyThen1 (fn stk tk) (\r -> action nt j tk st1 sts1 (r `HappyStk` drop_stk))

happyMonad2Reduce k nt fn (1) tk st sts stk
     = happyFail (1) tk st sts stk
happyMonad2Reduce k nt fn j tk st sts stk =
      case happyDrop k ((st):(sts)) of
        sts1@(((st1@(HappyState (action))):(_))) ->
         let drop_stk = happyDropStk k stk





             new_state = action

          in
          happyThen1 (fn stk tk) (\r -> happyNewToken new_state sts1 (r `HappyStk` drop_stk))

happyDrop (0) l = l
happyDrop n ((_):(t)) = happyDrop (n - ((1) :: Int)) t

happyDropStk (0) l = l
happyDropStk n (x `HappyStk` xs) = happyDropStk (n - ((1)::Int)) xs

-----------------------------------------------------------------------------
-- Moving to a new state after a reduction









happyGoto action j tk st = action j j tk (HappyState action)


-----------------------------------------------------------------------------
-- Error recovery ((1) is the error token)

-- parse error if we are in recovery and we fail again
happyFail (1) tk old_st _ stk@(x `HappyStk` _) =
     let i = (case x of { HappyErrorToken (i) -> i }) in
--      trace "failing" $ 
        happyError_ i tk

{-  We don't need state discarding for our restricted implementation of
    "error".  In fact, it can cause some bogus parses, so I've disabled it
    for now --SDM

-- discard a state
happyFail  (1) tk old_st (((HappyState (action))):(sts)) 
                                                (saved_tok `HappyStk` _ `HappyStk` stk) =
--      trace ("discarding state, depth " ++ show (length stk))  $
        action (1) (1) tk (HappyState (action)) sts ((saved_tok`HappyStk`stk))
-}

-- Enter error recovery: generate an error token,
--                       save the old token and carry on.
happyFail  i tk (HappyState (action)) sts stk =
--      trace "entering error recovery" $
        action (1) (1) tk (HappyState (action)) sts ( (HappyErrorToken (i)) `HappyStk` stk)

-- Internal happy errors:

notHappyAtAll :: a
notHappyAtAll = error "Internal Happy error\n"

-----------------------------------------------------------------------------
-- Hack to get the typechecker to accept our action functions







-----------------------------------------------------------------------------
-- Seq-ing.  If the --strict flag is given, then Happy emits 
--      happySeq = happyDoSeq
-- otherwise it emits
--      happySeq = happyDontSeq

happyDoSeq, happyDontSeq :: a -> b -> b
happyDoSeq   a b = a `seq` b
happyDontSeq a b = b

-----------------------------------------------------------------------------
-- Don't inline any functions from the template.  GHC has a nasty habit
-- of deciding to inline happyGoto everywhere, which increases the size of
-- the generated parser quite a bit.









{-# NOINLINE happyShift #-}
{-# NOINLINE happySpecReduce_0 #-}
{-# NOINLINE happySpecReduce_1 #-}
{-# NOINLINE happySpecReduce_2 #-}
{-# NOINLINE happySpecReduce_3 #-}
{-# NOINLINE happyReduce #-}
{-# NOINLINE happyMonadReduce #-}
{-# NOINLINE happyGoto #-}
{-# NOINLINE happyFail #-}

-- end of Happy Template.

