module Concrete where

import Text.XML.HaXml.XmlContent
import Text.XML.HaXml.Types
import Text.XML.HaXml.OneOfN


{-Type decls-}

data Expr = ExprA0 A0
          | ExprA1 A1
          | ExprA2 A2
          | ExprA3 A3
          | ExprA4 A4
          | ExprA5 A5
          | ExprA6 A6
          | ExprA7 A7
          | ExprA8 A8
          | ExprA9 A9
          | ExprA10 A10
          | ExprA11 A11
          | ExprNull Null
          deriving (Eq,Show)
data A0 = A0 		deriving (Eq,Show)
data A1 = A1 		deriving (Eq,Show)
newtype A2 = A2 Binaryop 		deriving (Eq,Show)
data A3 = A3 Lvalue Expr
        deriving (Eq,Show)
data A4 = A4 Biyaccpcdata Expr Expr Expr
        deriving (Eq,Show)
data A5 = A5 Expr Expr
        deriving (Eq,Show)
data A6 = A6 Declarationlist Exprseq
        deriving (Eq,Show)
newtype A7 = A7 Exprseq 		deriving (Eq,Show)
data A8 = A8 Biyaccpcdata Exprlist
        deriving (Eq,Show)
data A9 = A9 Biyaccpcdata Fieldlist
        deriving (Eq,Show)
data A10 = A10 Expr Expr Expr
         deriving (Eq,Show)
data A11 = A11 Expr Expr
         deriving (Eq,Show)
data Exprlist = ExprlistA12 A12
              | ExprlistA13 A13
              | ExprlistNull Null
              deriving (Eq,Show)
newtype A12 = A12 Expr 		deriving (Eq,Show)
data A13 = A13 Exprlist Expr
         deriving (Eq,Show)
data Fieldlist = FieldlistA14 A14
               | FieldlistA15 A15
               | FieldlistNull Null
               deriving (Eq,Show)
data A14 = A14 Biyaccpcdata Expr
         deriving (Eq,Show)
data A15 = A15 Fieldlist Biyaccpcdata Expr
         deriving (Eq,Show)
data Declarationlist = DeclarationlistA16 A16
                     | DeclarationlistA17 A17
                     | DeclarationlistNull Null
                     deriving (Eq,Show)
newtype A16 = A16 Declaration 		deriving (Eq,Show)
data A17 = A17 Declaration Declarationlist
         deriving (Eq,Show)
data Declaration = DeclarationA18 A18
                 | DeclarationA19 A19
                 | DeclarationA20 A20
                 | DeclarationNull Null
                 deriving (Eq,Show)
newtype A18 = A18 Typedeclaration 		deriving (Eq,Show)
newtype A19 = A19 Variabledeclaration 		deriving (Eq,Show)
newtype A20 = A20 Functiondeclaration 		deriving (Eq,Show)
data Exprseq = ExprseqA21 A21
             | ExprseqA22 A22
             | ExprseqNull Null
             deriving (Eq,Show)
newtype A21 = A21 Expr 		deriving (Eq,Show)
data A22 = A22 Exprseq Expr
         deriving (Eq,Show)
data Variabledeclaration = VariabledeclarationA23 A23
                         | VariabledeclarationA24 A24
                         | VariabledeclarationNull Null
                         deriving (Eq,Show)
data A23 = A23 Biyaccpcdata Expr
         deriving (Eq,Show)
data A24 = A24 Biyaccpcdata Biyaccpcdata Expr
         deriving (Eq,Show)
data Functiondeclaration = FunctiondeclarationA25 A25
                         | FunctiondeclarationA26 A26
                         | FunctiondeclarationNull Null
                         deriving (Eq,Show)
data A25 = A25 Biyaccpcdata Typefields Expr
         deriving (Eq,Show)
data A26 = A26 Biyaccpcdata Typefields Biyaccpcdata Expr
         deriving (Eq,Show)
data Typedeclaration = TypedeclarationA27 A27
                     | TypedeclarationNull Null
                     deriving (Eq,Show)
data A27 = A27 Biyaccpcdata Ptype
         deriving (Eq,Show)
data Ptype = PtypeA28 A28
           | PtypeA29 A29
           | PtypeA30 A30
           | PtypeNull Null
           deriving (Eq,Show)
newtype A28 = A28 Biyaccpcdata 		deriving (Eq,Show)
newtype A29 = A29 Typefields 		deriving (Eq,Show)
newtype A30 = A30 Biyaccpcdata 		deriving (Eq,Show)
data Typefields = TypefieldsA31 A31
                | TypefieldsA32 A32
                | TypefieldsNull Null
                deriving (Eq,Show)
newtype A31 = A31 Typefield 		deriving (Eq,Show)
data A32 = A32 Typefield Typefields
         deriving (Eq,Show)
data Typefield = TypefieldA33 A33
               | TypefieldNull Null
               deriving (Eq,Show)
data A33 = A33 Biyaccpcdata Biyaccpcdata
         deriving (Eq,Show)
data Binaryop = BinaryopA34 A34
              | BinaryopA35 A35
              | BinaryopNull Null
              deriving (Eq,Show)
data A34 = A34 Binaryop Binaryop1
         deriving (Eq,Show)
newtype A35 = A35 Binaryop1 		deriving (Eq,Show)
data Binaryop1 = Binaryop1A36 A36
               | Binaryop1A37 A37
               | Binaryop1Null Null
               deriving (Eq,Show)
data A36 = A36 Binaryop1 Binaryop2
         deriving (Eq,Show)
newtype A37 = A37 Binaryop2 		deriving (Eq,Show)
data Binaryop2 = Binaryop2A38 A38
               | Binaryop2A39 A39
               | Binaryop2A40 A40
               | Binaryop2A41 A41
               | Binaryop2A42 A42
               | Binaryop2A43 A43
               | Binaryop2A44 A44
               | Binaryop2Null Null
               deriving (Eq,Show)
data A38 = A38 Binaryop2 Binaryop3
         deriving (Eq,Show)
data A39 = A39 Binaryop2 Binaryop3
         deriving (Eq,Show)
data A40 = A40 Binaryop2 Binaryop3
         deriving (Eq,Show)
data A41 = A41 Binaryop2 Binaryop3
         deriving (Eq,Show)
data A42 = A42 Binaryop2 Binaryop3
         deriving (Eq,Show)
data A43 = A43 Binaryop2 Binaryop3
         deriving (Eq,Show)
newtype A44 = A44 Binaryop3 		deriving (Eq,Show)
data Binaryop3 = Binaryop3A45 A45
               | Binaryop3A46 A46
               | Binaryop3A47 A47
               | Binaryop3Null Null
               deriving (Eq,Show)
data A45 = A45 Binaryop3 Binaryop4
         deriving (Eq,Show)
data A46 = A46 Binaryop3 Binaryop4
         deriving (Eq,Show)
newtype A47 = A47 Binaryop4 		deriving (Eq,Show)
data Binaryop4 = Binaryop4A48 A48
               | Binaryop4A49 A49
               | Binaryop4A50 A50
               | Binaryop4Null Null
               deriving (Eq,Show)
data A48 = A48 Binaryop4 Binaryop5
         deriving (Eq,Show)
data A49 = A49 Binaryop4 Binaryop5
         deriving (Eq,Show)
newtype A50 = A50 Binaryop5 		deriving (Eq,Show)
data Binaryop5 = Binaryop5A51 A51
               | Binaryop5A52 A52
               | Binaryop5A53 A53
               | Binaryop5A54 A54
               | Binaryop5Null Null
               deriving (Eq,Show)
newtype A51 = A51 Biyaccpcdata 		deriving (Eq,Show)
newtype A52 = A52 Lvalue 		deriving (Eq,Show)
newtype A53 = A53 Binaryop5 		deriving (Eq,Show)
newtype A54 = A54 Binaryop 		deriving (Eq,Show)
data Lvalue = LvalueA55 A55
            | LvalueA56 A56
            | LvalueA57 A57
            | LvalueNull Null
            deriving (Eq,Show)
newtype A55 = A55 Biyaccpcdata 		deriving (Eq,Show)
data A56 = A56 Lvalue Biyaccpcdata
         deriving (Eq,Show)
data A57 = A57 Lvalue Expr
         deriving (Eq,Show)
newtype Biyaccpcdata = Biyaccpcdata String 		deriving (Eq,Show)
data Null = Null 		deriving (Eq,Show)


{-Instance decls-}

instance HTypeable Expr where
    toHType x = Defined "expr" [] []
instance XmlContent Expr where
    toContents (ExprA0 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (ExprA1 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (ExprA2 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (ExprA3 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (ExprA4 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (ExprA5 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (ExprA6 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (ExprA7 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (ExprA8 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (ExprA9 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (ExprA10 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (ExprA11 a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    toContents (ExprNull a) =
        [CElem (Elem (N "expr") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["expr"]
        ; interior e $ oneOf
            [ return (ExprA0) `apply` parseContents
            , return (ExprA1) `apply` parseContents
            , return (ExprA2) `apply` parseContents
            , return (ExprA3) `apply` parseContents
            , return (ExprA4) `apply` parseContents
            , return (ExprA5) `apply` parseContents
            , return (ExprA6) `apply` parseContents
            , return (ExprA7) `apply` parseContents
            , return (ExprA8) `apply` parseContents
            , return (ExprA9) `apply` parseContents
            , return (ExprA10) `apply` parseContents
            , return (ExprA11) `apply` parseContents
            , return (ExprNull) `apply` parseContents
            ] `adjustErr` ("in <expr>, "++)
        }

instance HTypeable A0 where
    toHType x = Defined "a0" [] []
instance XmlContent A0 where
    toContents A0 =
        [CElem (Elem (N "a0") [] []) ()]
    parseContents = do
        { (Elem _ as []) <- element ["a0"]
        ; return A0
        } `adjustErr` ("in <a0>, "++)

instance HTypeable A1 where
    toHType x = Defined "a1" [] []
instance XmlContent A1 where
    toContents A1 =
        [CElem (Elem (N "a1") [] []) ()]
    parseContents = do
        { (Elem _ as []) <- element ["a1"]
        ; return A1
        } `adjustErr` ("in <a1>, "++)

instance HTypeable A2 where
    toHType x = Defined "a2" [] []
instance XmlContent A2 where
    toContents (A2 a) =
        [CElem (Elem (N "a2") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a2"]
        ; interior e $ return (A2) `apply` parseContents
        } `adjustErr` ("in <a2>, "++)

instance HTypeable A3 where
    toHType x = Defined "a3" [] []
instance XmlContent A3 where
    toContents (A3 a b) =
        [CElem (Elem (N "a3") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a3"]
        ; interior e $ return (A3) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a3>, "++)

instance HTypeable A4 where
    toHType x = Defined "a4" [] []
instance XmlContent A4 where
    toContents (A4 a b c d) =
        [CElem (Elem (N "a4") [] (toContents a ++ toContents b ++
                                  toContents c ++ toContents d)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a4"]
        ; interior e $ return (A4) `apply` parseContents
                       `apply` parseContents `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <a4>, "++)

instance HTypeable A5 where
    toHType x = Defined "a5" [] []
instance XmlContent A5 where
    toContents (A5 a b) =
        [CElem (Elem (N "a5") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a5"]
        ; interior e $ return (A5) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a5>, "++)

instance HTypeable A6 where
    toHType x = Defined "a6" [] []
instance XmlContent A6 where
    toContents (A6 a b) =
        [CElem (Elem (N "a6") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a6"]
        ; interior e $ return (A6) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a6>, "++)

instance HTypeable A7 where
    toHType x = Defined "a7" [] []
instance XmlContent A7 where
    toContents (A7 a) =
        [CElem (Elem (N "a7") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a7"]
        ; interior e $ return (A7) `apply` parseContents
        } `adjustErr` ("in <a7>, "++)

instance HTypeable A8 where
    toHType x = Defined "a8" [] []
instance XmlContent A8 where
    toContents (A8 a b) =
        [CElem (Elem (N "a8") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a8"]
        ; interior e $ return (A8) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a8>, "++)

instance HTypeable A9 where
    toHType x = Defined "a9" [] []
instance XmlContent A9 where
    toContents (A9 a b) =
        [CElem (Elem (N "a9") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a9"]
        ; interior e $ return (A9) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a9>, "++)

instance HTypeable A10 where
    toHType x = Defined "a10" [] []
instance XmlContent A10 where
    toContents (A10 a b c) =
        [CElem (Elem (N "a10") [] (toContents a ++ toContents b ++
                                   toContents c)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a10"]
        ; interior e $ return (A10) `apply` parseContents
                       `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <a10>, "++)

instance HTypeable A11 where
    toHType x = Defined "a11" [] []
instance XmlContent A11 where
    toContents (A11 a b) =
        [CElem (Elem (N "a11") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a11"]
        ; interior e $ return (A11) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a11>, "++)

instance HTypeable Exprlist where
    toHType x = Defined "exprlist" [] []
instance XmlContent Exprlist where
    toContents (ExprlistA12 a) =
        [CElem (Elem (N "exprlist") [] (toContents a) ) ()]
    toContents (ExprlistA13 a) =
        [CElem (Elem (N "exprlist") [] (toContents a) ) ()]
    toContents (ExprlistNull a) =
        [CElem (Elem (N "exprlist") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["exprlist"]
        ; interior e $ oneOf
            [ return (ExprlistA12) `apply` parseContents
            , return (ExprlistA13) `apply` parseContents
            , return (ExprlistNull) `apply` parseContents
            ] `adjustErr` ("in <exprlist>, "++)
        }

instance HTypeable A12 where
    toHType x = Defined "a12" [] []
instance XmlContent A12 where
    toContents (A12 a) =
        [CElem (Elem (N "a12") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a12"]
        ; interior e $ return (A12) `apply` parseContents
        } `adjustErr` ("in <a12>, "++)

instance HTypeable A13 where
    toHType x = Defined "a13" [] []
instance XmlContent A13 where
    toContents (A13 a b) =
        [CElem (Elem (N "a13") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a13"]
        ; interior e $ return (A13) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a13>, "++)

instance HTypeable Fieldlist where
    toHType x = Defined "fieldlist" [] []
instance XmlContent Fieldlist where
    toContents (FieldlistA14 a) =
        [CElem (Elem (N "fieldlist") [] (toContents a) ) ()]
    toContents (FieldlistA15 a) =
        [CElem (Elem (N "fieldlist") [] (toContents a) ) ()]
    toContents (FieldlistNull a) =
        [CElem (Elem (N "fieldlist") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["fieldlist"]
        ; interior e $ oneOf
            [ return (FieldlistA14) `apply` parseContents
            , return (FieldlistA15) `apply` parseContents
            , return (FieldlistNull) `apply` parseContents
            ] `adjustErr` ("in <fieldlist>, "++)
        }

instance HTypeable A14 where
    toHType x = Defined "a14" [] []
instance XmlContent A14 where
    toContents (A14 a b) =
        [CElem (Elem (N "a14") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a14"]
        ; interior e $ return (A14) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a14>, "++)

instance HTypeable A15 where
    toHType x = Defined "a15" [] []
instance XmlContent A15 where
    toContents (A15 a b c) =
        [CElem (Elem (N "a15") [] (toContents a ++ toContents b ++
                                   toContents c)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a15"]
        ; interior e $ return (A15) `apply` parseContents
                       `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <a15>, "++)

instance HTypeable Declarationlist where
    toHType x = Defined "declarationlist" [] []
instance XmlContent Declarationlist where
    toContents (DeclarationlistA16 a) =
        [CElem (Elem (N "declarationlist") [] (toContents a) ) ()]
    toContents (DeclarationlistA17 a) =
        [CElem (Elem (N "declarationlist") [] (toContents a) ) ()]
    toContents (DeclarationlistNull a) =
        [CElem (Elem (N "declarationlist") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["declarationlist"]
        ; interior e $ oneOf
            [ return (DeclarationlistA16) `apply` parseContents
            , return (DeclarationlistA17) `apply` parseContents
            , return (DeclarationlistNull) `apply` parseContents
            ] `adjustErr` ("in <declarationlist>, "++)
        }

instance HTypeable A16 where
    toHType x = Defined "a16" [] []
instance XmlContent A16 where
    toContents (A16 a) =
        [CElem (Elem (N "a16") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a16"]
        ; interior e $ return (A16) `apply` parseContents
        } `adjustErr` ("in <a16>, "++)

instance HTypeable A17 where
    toHType x = Defined "a17" [] []
instance XmlContent A17 where
    toContents (A17 a b) =
        [CElem (Elem (N "a17") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a17"]
        ; interior e $ return (A17) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a17>, "++)

instance HTypeable Declaration where
    toHType x = Defined "declaration" [] []
instance XmlContent Declaration where
    toContents (DeclarationA18 a) =
        [CElem (Elem (N "declaration") [] (toContents a) ) ()]
    toContents (DeclarationA19 a) =
        [CElem (Elem (N "declaration") [] (toContents a) ) ()]
    toContents (DeclarationA20 a) =
        [CElem (Elem (N "declaration") [] (toContents a) ) ()]
    toContents (DeclarationNull a) =
        [CElem (Elem (N "declaration") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["declaration"]
        ; interior e $ oneOf
            [ return (DeclarationA18) `apply` parseContents
            , return (DeclarationA19) `apply` parseContents
            , return (DeclarationA20) `apply` parseContents
            , return (DeclarationNull) `apply` parseContents
            ] `adjustErr` ("in <declaration>, "++)
        }

instance HTypeable A18 where
    toHType x = Defined "a18" [] []
instance XmlContent A18 where
    toContents (A18 a) =
        [CElem (Elem (N "a18") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a18"]
        ; interior e $ return (A18) `apply` parseContents
        } `adjustErr` ("in <a18>, "++)

instance HTypeable A19 where
    toHType x = Defined "a19" [] []
instance XmlContent A19 where
    toContents (A19 a) =
        [CElem (Elem (N "a19") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a19"]
        ; interior e $ return (A19) `apply` parseContents
        } `adjustErr` ("in <a19>, "++)

instance HTypeable A20 where
    toHType x = Defined "a20" [] []
instance XmlContent A20 where
    toContents (A20 a) =
        [CElem (Elem (N "a20") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a20"]
        ; interior e $ return (A20) `apply` parseContents
        } `adjustErr` ("in <a20>, "++)

instance HTypeable Exprseq where
    toHType x = Defined "exprseq" [] []
instance XmlContent Exprseq where
    toContents (ExprseqA21 a) =
        [CElem (Elem (N "exprseq") [] (toContents a) ) ()]
    toContents (ExprseqA22 a) =
        [CElem (Elem (N "exprseq") [] (toContents a) ) ()]
    toContents (ExprseqNull a) =
        [CElem (Elem (N "exprseq") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["exprseq"]
        ; interior e $ oneOf
            [ return (ExprseqA21) `apply` parseContents
            , return (ExprseqA22) `apply` parseContents
            , return (ExprseqNull) `apply` parseContents
            ] `adjustErr` ("in <exprseq>, "++)
        }

instance HTypeable A21 where
    toHType x = Defined "a21" [] []
instance XmlContent A21 where
    toContents (A21 a) =
        [CElem (Elem (N "a21") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a21"]
        ; interior e $ return (A21) `apply` parseContents
        } `adjustErr` ("in <a21>, "++)

instance HTypeable A22 where
    toHType x = Defined "a22" [] []
instance XmlContent A22 where
    toContents (A22 a b) =
        [CElem (Elem (N "a22") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a22"]
        ; interior e $ return (A22) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a22>, "++)

instance HTypeable Variabledeclaration where
    toHType x = Defined "variabledeclaration" [] []
instance XmlContent Variabledeclaration where
    toContents (VariabledeclarationA23 a) =
        [CElem (Elem (N "variabledeclaration") [] (toContents a) ) ()]
    toContents (VariabledeclarationA24 a) =
        [CElem (Elem (N "variabledeclaration") [] (toContents a) ) ()]
    toContents (VariabledeclarationNull a) =
        [CElem (Elem (N "variabledeclaration") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["variabledeclaration"]
        ; interior e $ oneOf
            [ return (VariabledeclarationA23) `apply` parseContents
            , return (VariabledeclarationA24) `apply` parseContents
            , return (VariabledeclarationNull) `apply` parseContents
            ] `adjustErr` ("in <variabledeclaration>, "++)
        }

instance HTypeable A23 where
    toHType x = Defined "a23" [] []
instance XmlContent A23 where
    toContents (A23 a b) =
        [CElem (Elem (N "a23") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a23"]
        ; interior e $ return (A23) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a23>, "++)

instance HTypeable A24 where
    toHType x = Defined "a24" [] []
instance XmlContent A24 where
    toContents (A24 a b c) =
        [CElem (Elem (N "a24") [] (toContents a ++ toContents b ++
                                   toContents c)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a24"]
        ; interior e $ return (A24) `apply` parseContents
                       `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <a24>, "++)

instance HTypeable Functiondeclaration where
    toHType x = Defined "functiondeclaration" [] []
instance XmlContent Functiondeclaration where
    toContents (FunctiondeclarationA25 a) =
        [CElem (Elem (N "functiondeclaration") [] (toContents a) ) ()]
    toContents (FunctiondeclarationA26 a) =
        [CElem (Elem (N "functiondeclaration") [] (toContents a) ) ()]
    toContents (FunctiondeclarationNull a) =
        [CElem (Elem (N "functiondeclaration") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["functiondeclaration"]
        ; interior e $ oneOf
            [ return (FunctiondeclarationA25) `apply` parseContents
            , return (FunctiondeclarationA26) `apply` parseContents
            , return (FunctiondeclarationNull) `apply` parseContents
            ] `adjustErr` ("in <functiondeclaration>, "++)
        }

instance HTypeable A25 where
    toHType x = Defined "a25" [] []
instance XmlContent A25 where
    toContents (A25 a b c) =
        [CElem (Elem (N "a25") [] (toContents a ++ toContents b ++
                                   toContents c)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a25"]
        ; interior e $ return (A25) `apply` parseContents
                       `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <a25>, "++)

instance HTypeable A26 where
    toHType x = Defined "a26" [] []
instance XmlContent A26 where
    toContents (A26 a b c d) =
        [CElem (Elem (N "a26") [] (toContents a ++ toContents b ++
                                   toContents c ++ toContents d)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a26"]
        ; interior e $ return (A26) `apply` parseContents
                       `apply` parseContents `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <a26>, "++)

instance HTypeable Typedeclaration where
    toHType x = Defined "typedeclaration" [] []
instance XmlContent Typedeclaration where
    toContents (TypedeclarationA27 a) =
        [CElem (Elem (N "typedeclaration") [] (toContents a) ) ()]
    toContents (TypedeclarationNull a) =
        [CElem (Elem (N "typedeclaration") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["typedeclaration"]
        ; interior e $ oneOf
            [ return (TypedeclarationA27) `apply` parseContents
            , return (TypedeclarationNull) `apply` parseContents
            ] `adjustErr` ("in <typedeclaration>, "++)
        }

instance HTypeable A27 where
    toHType x = Defined "a27" [] []
instance XmlContent A27 where
    toContents (A27 a b) =
        [CElem (Elem (N "a27") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a27"]
        ; interior e $ return (A27) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a27>, "++)

instance HTypeable Ptype where
    toHType x = Defined "ptype" [] []
instance XmlContent Ptype where
    toContents (PtypeA28 a) =
        [CElem (Elem (N "ptype") [] (toContents a) ) ()]
    toContents (PtypeA29 a) =
        [CElem (Elem (N "ptype") [] (toContents a) ) ()]
    toContents (PtypeA30 a) =
        [CElem (Elem (N "ptype") [] (toContents a) ) ()]
    toContents (PtypeNull a) =
        [CElem (Elem (N "ptype") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["ptype"]
        ; interior e $ oneOf
            [ return (PtypeA28) `apply` parseContents
            , return (PtypeA29) `apply` parseContents
            , return (PtypeA30) `apply` parseContents
            , return (PtypeNull) `apply` parseContents
            ] `adjustErr` ("in <ptype>, "++)
        }

instance HTypeable A28 where
    toHType x = Defined "a28" [] []
instance XmlContent A28 where
    toContents (A28 a) =
        [CElem (Elem (N "a28") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a28"]
        ; interior e $ return (A28) `apply` parseContents
        } `adjustErr` ("in <a28>, "++)

instance HTypeable A29 where
    toHType x = Defined "a29" [] []
instance XmlContent A29 where
    toContents (A29 a) =
        [CElem (Elem (N "a29") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a29"]
        ; interior e $ return (A29) `apply` parseContents
        } `adjustErr` ("in <a29>, "++)

instance HTypeable A30 where
    toHType x = Defined "a30" [] []
instance XmlContent A30 where
    toContents (A30 a) =
        [CElem (Elem (N "a30") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a30"]
        ; interior e $ return (A30) `apply` parseContents
        } `adjustErr` ("in <a30>, "++)

instance HTypeable Typefields where
    toHType x = Defined "typefields" [] []
instance XmlContent Typefields where
    toContents (TypefieldsA31 a) =
        [CElem (Elem (N "typefields") [] (toContents a) ) ()]
    toContents (TypefieldsA32 a) =
        [CElem (Elem (N "typefields") [] (toContents a) ) ()]
    toContents (TypefieldsNull a) =
        [CElem (Elem (N "typefields") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["typefields"]
        ; interior e $ oneOf
            [ return (TypefieldsA31) `apply` parseContents
            , return (TypefieldsA32) `apply` parseContents
            , return (TypefieldsNull) `apply` parseContents
            ] `adjustErr` ("in <typefields>, "++)
        }

instance HTypeable A31 where
    toHType x = Defined "a31" [] []
instance XmlContent A31 where
    toContents (A31 a) =
        [CElem (Elem (N "a31") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a31"]
        ; interior e $ return (A31) `apply` parseContents
        } `adjustErr` ("in <a31>, "++)

instance HTypeable A32 where
    toHType x = Defined "a32" [] []
instance XmlContent A32 where
    toContents (A32 a b) =
        [CElem (Elem (N "a32") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a32"]
        ; interior e $ return (A32) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a32>, "++)

instance HTypeable Typefield where
    toHType x = Defined "typefield" [] []
instance XmlContent Typefield where
    toContents (TypefieldA33 a) =
        [CElem (Elem (N "typefield") [] (toContents a) ) ()]
    toContents (TypefieldNull a) =
        [CElem (Elem (N "typefield") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["typefield"]
        ; interior e $ oneOf
            [ return (TypefieldA33) `apply` parseContents
            , return (TypefieldNull) `apply` parseContents
            ] `adjustErr` ("in <typefield>, "++)
        }

instance HTypeable A33 where
    toHType x = Defined "a33" [] []
instance XmlContent A33 where
    toContents (A33 a b) =
        [CElem (Elem (N "a33") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a33"]
        ; interior e $ return (A33) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a33>, "++)

instance HTypeable Binaryop where
    toHType x = Defined "binaryop" [] []
instance XmlContent Binaryop where
    toContents (BinaryopA34 a) =
        [CElem (Elem (N "binaryop") [] (toContents a) ) ()]
    toContents (BinaryopA35 a) =
        [CElem (Elem (N "binaryop") [] (toContents a) ) ()]
    toContents (BinaryopNull a) =
        [CElem (Elem (N "binaryop") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["binaryop"]
        ; interior e $ oneOf
            [ return (BinaryopA34) `apply` parseContents
            , return (BinaryopA35) `apply` parseContents
            , return (BinaryopNull) `apply` parseContents
            ] `adjustErr` ("in <binaryop>, "++)
        }

instance HTypeable A34 where
    toHType x = Defined "a34" [] []
instance XmlContent A34 where
    toContents (A34 a b) =
        [CElem (Elem (N "a34") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a34"]
        ; interior e $ return (A34) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a34>, "++)

instance HTypeable A35 where
    toHType x = Defined "a35" [] []
instance XmlContent A35 where
    toContents (A35 a) =
        [CElem (Elem (N "a35") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a35"]
        ; interior e $ return (A35) `apply` parseContents
        } `adjustErr` ("in <a35>, "++)

instance HTypeable Binaryop1 where
    toHType x = Defined "binaryop1" [] []
instance XmlContent Binaryop1 where
    toContents (Binaryop1A36 a) =
        [CElem (Elem (N "binaryop1") [] (toContents a) ) ()]
    toContents (Binaryop1A37 a) =
        [CElem (Elem (N "binaryop1") [] (toContents a) ) ()]
    toContents (Binaryop1Null a) =
        [CElem (Elem (N "binaryop1") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["binaryop1"]
        ; interior e $ oneOf
            [ return (Binaryop1A36) `apply` parseContents
            , return (Binaryop1A37) `apply` parseContents
            , return (Binaryop1Null) `apply` parseContents
            ] `adjustErr` ("in <binaryop1>, "++)
        }

instance HTypeable A36 where
    toHType x = Defined "a36" [] []
instance XmlContent A36 where
    toContents (A36 a b) =
        [CElem (Elem (N "a36") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a36"]
        ; interior e $ return (A36) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a36>, "++)

instance HTypeable A37 where
    toHType x = Defined "a37" [] []
instance XmlContent A37 where
    toContents (A37 a) =
        [CElem (Elem (N "a37") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a37"]
        ; interior e $ return (A37) `apply` parseContents
        } `adjustErr` ("in <a37>, "++)

instance HTypeable Binaryop2 where
    toHType x = Defined "binaryop2" [] []
instance XmlContent Binaryop2 where
    toContents (Binaryop2A38 a) =
        [CElem (Elem (N "binaryop2") [] (toContents a) ) ()]
    toContents (Binaryop2A39 a) =
        [CElem (Elem (N "binaryop2") [] (toContents a) ) ()]
    toContents (Binaryop2A40 a) =
        [CElem (Elem (N "binaryop2") [] (toContents a) ) ()]
    toContents (Binaryop2A41 a) =
        [CElem (Elem (N "binaryop2") [] (toContents a) ) ()]
    toContents (Binaryop2A42 a) =
        [CElem (Elem (N "binaryop2") [] (toContents a) ) ()]
    toContents (Binaryop2A43 a) =
        [CElem (Elem (N "binaryop2") [] (toContents a) ) ()]
    toContents (Binaryop2A44 a) =
        [CElem (Elem (N "binaryop2") [] (toContents a) ) ()]
    toContents (Binaryop2Null a) =
        [CElem (Elem (N "binaryop2") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["binaryop2"]
        ; interior e $ oneOf
            [ return (Binaryop2A38) `apply` parseContents
            , return (Binaryop2A39) `apply` parseContents
            , return (Binaryop2A40) `apply` parseContents
            , return (Binaryop2A41) `apply` parseContents
            , return (Binaryop2A42) `apply` parseContents
            , return (Binaryop2A43) `apply` parseContents
            , return (Binaryop2A44) `apply` parseContents
            , return (Binaryop2Null) `apply` parseContents
            ] `adjustErr` ("in <binaryop2>, "++)
        }

instance HTypeable A38 where
    toHType x = Defined "a38" [] []
instance XmlContent A38 where
    toContents (A38 a b) =
        [CElem (Elem (N "a38") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a38"]
        ; interior e $ return (A38) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a38>, "++)

instance HTypeable A39 where
    toHType x = Defined "a39" [] []
instance XmlContent A39 where
    toContents (A39 a b) =
        [CElem (Elem (N "a39") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a39"]
        ; interior e $ return (A39) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a39>, "++)

instance HTypeable A40 where
    toHType x = Defined "a40" [] []
instance XmlContent A40 where
    toContents (A40 a b) =
        [CElem (Elem (N "a40") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a40"]
        ; interior e $ return (A40) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a40>, "++)

instance HTypeable A41 where
    toHType x = Defined "a41" [] []
instance XmlContent A41 where
    toContents (A41 a b) =
        [CElem (Elem (N "a41") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a41"]
        ; interior e $ return (A41) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a41>, "++)

instance HTypeable A42 where
    toHType x = Defined "a42" [] []
instance XmlContent A42 where
    toContents (A42 a b) =
        [CElem (Elem (N "a42") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a42"]
        ; interior e $ return (A42) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a42>, "++)

instance HTypeable A43 where
    toHType x = Defined "a43" [] []
instance XmlContent A43 where
    toContents (A43 a b) =
        [CElem (Elem (N "a43") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a43"]
        ; interior e $ return (A43) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a43>, "++)

instance HTypeable A44 where
    toHType x = Defined "a44" [] []
instance XmlContent A44 where
    toContents (A44 a) =
        [CElem (Elem (N "a44") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a44"]
        ; interior e $ return (A44) `apply` parseContents
        } `adjustErr` ("in <a44>, "++)

instance HTypeable Binaryop3 where
    toHType x = Defined "binaryop3" [] []
instance XmlContent Binaryop3 where
    toContents (Binaryop3A45 a) =
        [CElem (Elem (N "binaryop3") [] (toContents a) ) ()]
    toContents (Binaryop3A46 a) =
        [CElem (Elem (N "binaryop3") [] (toContents a) ) ()]
    toContents (Binaryop3A47 a) =
        [CElem (Elem (N "binaryop3") [] (toContents a) ) ()]
    toContents (Binaryop3Null a) =
        [CElem (Elem (N "binaryop3") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["binaryop3"]
        ; interior e $ oneOf
            [ return (Binaryop3A45) `apply` parseContents
            , return (Binaryop3A46) `apply` parseContents
            , return (Binaryop3A47) `apply` parseContents
            , return (Binaryop3Null) `apply` parseContents
            ] `adjustErr` ("in <binaryop3>, "++)
        }

instance HTypeable A45 where
    toHType x = Defined "a45" [] []
instance XmlContent A45 where
    toContents (A45 a b) =
        [CElem (Elem (N "a45") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a45"]
        ; interior e $ return (A45) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a45>, "++)

instance HTypeable A46 where
    toHType x = Defined "a46" [] []
instance XmlContent A46 where
    toContents (A46 a b) =
        [CElem (Elem (N "a46") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a46"]
        ; interior e $ return (A46) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a46>, "++)

instance HTypeable A47 where
    toHType x = Defined "a47" [] []
instance XmlContent A47 where
    toContents (A47 a) =
        [CElem (Elem (N "a47") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a47"]
        ; interior e $ return (A47) `apply` parseContents
        } `adjustErr` ("in <a47>, "++)

instance HTypeable Binaryop4 where
    toHType x = Defined "binaryop4" [] []
instance XmlContent Binaryop4 where
    toContents (Binaryop4A48 a) =
        [CElem (Elem (N "binaryop4") [] (toContents a) ) ()]
    toContents (Binaryop4A49 a) =
        [CElem (Elem (N "binaryop4") [] (toContents a) ) ()]
    toContents (Binaryop4A50 a) =
        [CElem (Elem (N "binaryop4") [] (toContents a) ) ()]
    toContents (Binaryop4Null a) =
        [CElem (Elem (N "binaryop4") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["binaryop4"]
        ; interior e $ oneOf
            [ return (Binaryop4A48) `apply` parseContents
            , return (Binaryop4A49) `apply` parseContents
            , return (Binaryop4A50) `apply` parseContents
            , return (Binaryop4Null) `apply` parseContents
            ] `adjustErr` ("in <binaryop4>, "++)
        }

instance HTypeable A48 where
    toHType x = Defined "a48" [] []
instance XmlContent A48 where
    toContents (A48 a b) =
        [CElem (Elem (N "a48") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a48"]
        ; interior e $ return (A48) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a48>, "++)

instance HTypeable A49 where
    toHType x = Defined "a49" [] []
instance XmlContent A49 where
    toContents (A49 a b) =
        [CElem (Elem (N "a49") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a49"]
        ; interior e $ return (A49) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a49>, "++)

instance HTypeable A50 where
    toHType x = Defined "a50" [] []
instance XmlContent A50 where
    toContents (A50 a) =
        [CElem (Elem (N "a50") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a50"]
        ; interior e $ return (A50) `apply` parseContents
        } `adjustErr` ("in <a50>, "++)

instance HTypeable Binaryop5 where
    toHType x = Defined "binaryop5" [] []
instance XmlContent Binaryop5 where
    toContents (Binaryop5A51 a) =
        [CElem (Elem (N "binaryop5") [] (toContents a) ) ()]
    toContents (Binaryop5A52 a) =
        [CElem (Elem (N "binaryop5") [] (toContents a) ) ()]
    toContents (Binaryop5A53 a) =
        [CElem (Elem (N "binaryop5") [] (toContents a) ) ()]
    toContents (Binaryop5A54 a) =
        [CElem (Elem (N "binaryop5") [] (toContents a) ) ()]
    toContents (Binaryop5Null a) =
        [CElem (Elem (N "binaryop5") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["binaryop5"]
        ; interior e $ oneOf
            [ return (Binaryop5A51) `apply` parseContents
            , return (Binaryop5A52) `apply` parseContents
            , return (Binaryop5A53) `apply` parseContents
            , return (Binaryop5A54) `apply` parseContents
            , return (Binaryop5Null) `apply` parseContents
            ] `adjustErr` ("in <binaryop5>, "++)
        }

instance HTypeable A51 where
    toHType x = Defined "a51" [] []
instance XmlContent A51 where
    toContents (A51 a) =
        [CElem (Elem (N "a51") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a51"]
        ; interior e $ return (A51) `apply` parseContents
        } `adjustErr` ("in <a51>, "++)

instance HTypeable A52 where
    toHType x = Defined "a52" [] []
instance XmlContent A52 where
    toContents (A52 a) =
        [CElem (Elem (N "a52") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a52"]
        ; interior e $ return (A52) `apply` parseContents
        } `adjustErr` ("in <a52>, "++)

instance HTypeable A53 where
    toHType x = Defined "a53" [] []
instance XmlContent A53 where
    toContents (A53 a) =
        [CElem (Elem (N "a53") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a53"]
        ; interior e $ return (A53) `apply` parseContents
        } `adjustErr` ("in <a53>, "++)

instance HTypeable A54 where
    toHType x = Defined "a54" [] []
instance XmlContent A54 where
    toContents (A54 a) =
        [CElem (Elem (N "a54") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a54"]
        ; interior e $ return (A54) `apply` parseContents
        } `adjustErr` ("in <a54>, "++)

instance HTypeable Lvalue where
    toHType x = Defined "lvalue" [] []
instance XmlContent Lvalue where
    toContents (LvalueA55 a) =
        [CElem (Elem (N "lvalue") [] (toContents a) ) ()]
    toContents (LvalueA56 a) =
        [CElem (Elem (N "lvalue") [] (toContents a) ) ()]
    toContents (LvalueA57 a) =
        [CElem (Elem (N "lvalue") [] (toContents a) ) ()]
    toContents (LvalueNull a) =
        [CElem (Elem (N "lvalue") [] (toContents a) ) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["lvalue"]
        ; interior e $ oneOf
            [ return (LvalueA55) `apply` parseContents
            , return (LvalueA56) `apply` parseContents
            , return (LvalueA57) `apply` parseContents
            , return (LvalueNull) `apply` parseContents
            ] `adjustErr` ("in <lvalue>, "++)
        }

instance HTypeable A55 where
    toHType x = Defined "a55" [] []
instance XmlContent A55 where
    toContents (A55 a) =
        [CElem (Elem (N "a55") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a55"]
        ; interior e $ return (A55) `apply` parseContents
        } `adjustErr` ("in <a55>, "++)

instance HTypeable A56 where
    toHType x = Defined "a56" [] []
instance XmlContent A56 where
    toContents (A56 a b) =
        [CElem (Elem (N "a56") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a56"]
        ; interior e $ return (A56) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a56>, "++)

instance HTypeable A57 where
    toHType x = Defined "a57" [] []
instance XmlContent A57 where
    toContents (A57 a b) =
        [CElem (Elem (N "a57") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["a57"]
        ; interior e $ return (A57) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <a57>, "++)

instance HTypeable Biyaccpcdata where
    toHType x = Defined "biyaccpcdata" [] []
instance XmlContent Biyaccpcdata where
    toContents (Biyaccpcdata a) =
        [CElem (Elem (N "biyaccpcdata") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["biyaccpcdata"]
        ; interior e $ return (Biyaccpcdata)
                       `apply` (text `onFail` return "")
        } `adjustErr` ("in <biyaccpcdata>, "++)

instance HTypeable Null where
    toHType x = Defined "null" [] []
instance XmlContent Null where
    toContents Null =
        [CElem (Elem (N "null") [] []) ()]
    parseContents = do
        { (Elem _ as []) <- element ["null"]
        ; return Null
        } `adjustErr` ("in <null>, "++)



{-Done-}
