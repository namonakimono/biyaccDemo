module RunParser where

import Text.XML.HaXml.XmlContent
import Text.XML.HaXml.Types
import Text.XML.HaXml.OneOfN
import Text.XML.HaXml.Verbatim
import Text.XML.HaXml.Parse

import Tiger
import Concrete

main :: IO()
main = do --file    <- getLine
          -- program <- readFile "program.tiger"--file
          program <- readFile "if.tiger"--file
          let sout = (verbatim . toContents . tiger . lexer $ program)
          putStrLn sout
          writeFile "s.xml" sout

ppXML :: IO()
ppXML = do xml <- readFile "s.xml"
           let doc = xmlParse "parsing_errors.log"  xml
           putStrLn . ppDocument $ doc

ppDocument (Document _ _ element _) = ppElement element

ppElement (Elem qname list_attribute content) = case qname of
   (N "a0"  ) -> "nil" {- 'nil' -}
   (N "a1"  ) -> "break" {- 'break' -}
   (N "a2"  ) -> (ppContent (e1 content)) {- BINARYOP -}
   (N "a3"  ) -> (ppContent (e1 content))++" := "++(ppContent (e2 content))++"\n" {- LVALUE ':=' EXPR -}
   (N "a4"  ) -> "\nfor "++(ppContent (e1 content))++" := "++(ppContent (e2 content))++"\nto "++(ppContent (e3 content))++"\ndo "++(ppContent (e4 content)) {- 'for' 'string' ':=' EXPR 'to' EXPR 'do' EXPR -}
   (N "a5"  ) -> "\nwhile "++(ppContent (e1 content))++"\ndo "++(ppContent (e2 content)) {- 'while' EXPR 'do' EXPR -}
   (N "a6"  ) -> "\nlet "++(ppContent (e1 content))++"\nin "++(ppContent (e2 content))++"\nend" {- 'let' DECLARATIONLIST 'in' EXPRSEQ 'end' -}
   (N "a7"  ) -> "( "++(ppContent (e1 content))++" )" {- '(' EXPRSEQ ')' -}
   (N "a8"  ) -> (ppContent (e1 content))++"( "++(ppContent (e2 content))++" )" {- 'string' '(' EXPRLIST ')' -}
   (N "a9"  ) -> (ppContent (e1 content))++"{ "++(ppContent (e2 content))++" }" {- 'string' '{' FIELDLIST '}' -}
   (N "a10" ) -> "\nif "++(ppContent (e1 content))++"\nthen "++(ppContent (e2 content))++"\nelse "++(ppContent (e3 content)) {- 'if' EXPR 'then' EXPR 'else' EXPR -}
   (N "a11" ) -> "\nif "++(ppContent (e1 content))++"\nthen "++(ppContent (e2 content)) {- 'if' EXPR 'then' EXPR -}
   (N "a12" ) -> (ppContent (e1 content)) {- EXPR -}
   (N "a13" ) -> (ppContent (e1 content))++" , "++(ppContent (e2 content)) {- EXPRLIST ',' EXPR -}
   (N "a14" ) -> (ppContent (e1 content))++" = "++(ppContent (e2 content)) {- 'string' '=' EXPR -}
   (N "a15" ) -> (ppContent (e1 content))++" , "++(ppContent (e2 content))++" = "++(ppContent (e3 content)) {- FIELDLIST ',' 'string' '=' EXPR -}
   (N "a16" ) -> (ppContent (e1 content)) {- DECLARATION -}
   (N "a17" ) -> (ppContent (e1 content))++" "++(ppContent (e2 content)) {- DECLARATION DECLARATIONLIST -}
   (N "a18" ) -> (ppContent (e1 content)) {- TYPEDECLARATION -}
   (N "a19" ) -> (ppContent (e1 content)) {- VARIABLEDECLARATION -}
   (N "a20" ) -> (ppContent (e1 content)) {- FUNCTIONDECLARATION -}
   (N "a21" ) -> (ppContent (e1 content)) {- EXPR -}
   (N "a22" ) -> (ppContent (e1 content))++" ; " ++(ppContent (e2 content)) {- EXPRSEQ ';' EXPR -}
   (N "a23" ) -> "\nvar "++(ppContent (e1 content))++" := "++(ppContent (e2 content)) {- 'var' 'string' ':=' EXPR -}
   (N "a24" ) -> "\nvar "++(ppContent (e1 content))++" : "++(ppContent (e2 content))++" := "++(ppContent (e3 content)) {- 'var' 'string' ':' 'string' ':=' EXPR -}
   (N "a25" ) -> "\nfunction "++(ppContent (e1 content))++" ( "++(ppContent (e2 content))++" ) = "++(ppContent (e3 content)) {- 'function' 'string' '(' TYPEFIELDS ')' '=' EXPR -}
   (N "a26" ) -> "\nfunction "++(ppContent (e1 content))++" ( "++(ppContent (e2 content))++" ) : "++(ppContent (e3 content))++" = "++(ppContent (e4 content)) {- 'function' 'string' '(' TYPEFIELDS ')' ':' 'string' '=' EXPR -}
   (N "a27" ) -> "\ntype "++(ppContent (e1 content))++" = "++(ppContent (e2 content)) {- 'type' 'string' '=' TYPE -}
   (N "a28" ) -> (ppContent (e1 content)) {- 'string' -}
   (N "a29" ) -> "{ "++(ppContent (e1 content))++" }" {- '{' TYPEFIELDS '}' -}
   (N "a30" ) -> "array of "++(ppContent (e1 content)) {- 'array' 'of' 'string' -}
   (N "a31" ) -> (ppContent (e1 content)) {-T YPEFIELD -}
   (N "a32" ) -> (ppContent (e1 content))++" , " ++(ppContent (e2 content)) {- TYPEFIELD ',' TYPEFIELDS -}
   (N "a33" ) -> (ppContent (e1 content))++" : " ++(ppContent (e2 content)) {- 'string' ':' 'string' -}
   (N "a34" ) -> (ppContent (e1 content))++" | " ++(ppContent (e2 content)) {- BINARYOP '|' BINARYOP1 -}
   (N "a35" ) -> (ppContent (e1 content)) {- BINARYOP1 -}
   (N "a36" ) -> (ppContent (e1 content))++" & " ++(ppContent (e2 content)) {- BINARYOP1 '&' BINARYOP2 -}
   (N "a37" ) -> (ppContent (e1 content)) {- BINARYOP2 -}
   (N "a38" ) -> (ppContent (e1 content))++" = " ++(ppContent (e2 content)) {- BINARYOP2 '='  BINARYOP3 -}
   (N "a39" ) -> (ppContent (e1 content))++" > " ++(ppContent (e2 content)) {- BINARYOP2 '>'  BINARYOP3 -}
   (N "a40" ) -> (ppContent (e1 content))++" < " ++(ppContent (e2 content)) {- BINARYOP2 '<'  BINARYOP3 -}
   (N "a41" ) -> (ppContent (e1 content))++" <> "++(ppContent (e2 content)) {- BINARYOP2 '<>' BINARYOP3 -}
   (N "a42" ) -> (ppContent (e1 content))++" >= "++(ppContent (e2 content)) {- BINARYOP2 '>=' BINARYOP3 -}
   (N "a43" ) -> (ppContent (e1 content))++" <= "++(ppContent (e2 content)) {- BINARYOP2 '<=' BINARYOP3 -}
   (N "a44" ) -> (ppContent (e1 content)) {- BINARYOP3 -}
   (N "a45" ) -> (ppContent (e1 content))++" + "++(ppContent (e2 content)) {- BINARYOP3 '+' BINARYOP4 -}
   (N "a46" ) -> (ppContent (e1 content))++" - "++(ppContent (e2 content)) {- BINARYOP3 '-' BINARYOP4 -}
   (N "a47" ) -> (ppContent (e1 content)) {- BINARYOP4 -}
   (N "a48" ) -> (ppContent (e1 content))++" * "++(ppContent (e2 content)) {- BINARYOP4 '*' BINARYOP5 -}
   (N "a49" ) -> (ppContent (e1 content))++" / "++(ppContent (e2 content)) {- BINARYOP4 '/' BINARYOP5 -}
   (N "a50" ) -> (ppContent (e1 content)) {- BINARYOP5 -}
   (N "a51" ) -> (ppContent (e1 content)) {- 'number' -}
   (N "a52" ) -> (ppContent (e1 content)) {- LVALUE -}
   (N "a53" ) -> "- "++(ppContent (e1 content)) {- '-' BINARYOP5 -}
   (N "a54" ) -> "( "++(ppContent (e1 content))++" )" {- '(' BINARYOP ')' -}
   (N "a55" ) -> (ppContent (e1 content)) {- 'string' -}
   (N "a56" ) -> (ppContent (e1 content))++" . "++(ppContent (e2 content)) {- LVALUE '.' 'string' -}
   (N "a57" ) -> (ppContent (e1 content))++" [ "++(ppContent (e2 content))++" ] " {- LVALUE '[' EXPR ']' -}
   (N "biyaccpcdata") -> (ppContent (e1 content))
   (N a)      -> (concat . map ppContent $ content)
   (QN a _)   -> "QN " ++ show a ++ (concat . map ppContent $ content)

ppContent (CElem     e _) = ppElement e
ppContent (CString _ chardata _) = chardata
ppContent (CRef      _ _) = "CRef\n"
ppContent (CMisc     _ _) = "CMisc\n"

e1 (x:xs) = x
e2 (_:x:xs) = x
e3 (_:_:x:xs) = x
e4 (_:_:_:x:xs) = x


{-
PLEASE DO NOT DELETE THIS
Sometimes this is very useful for debugging, or if we have to adapt the PP to a new grammar/dtd

ppElement (Elem qname list_attribute content) = case qname of --"QName -> "++show qname++" Attribute -> "++show list_attribute++"\n"++(concat . map ppContent $ content)
   (N "a0"  ) -> "nil\n"   ++ (concat . map ppContent $ content) {-'nil'-}
   (N "a1"  ) -> "break\n" ++ (concat . map ppContent $ content) {-'break'-}
   (N "a2"  ) -> (concat . map ppContent $ content) {-BINARYOP-}
   (N "a3"  ) -> "a3\n"  ++ (concat . map ppContent $ content) {-LVALUE ':=' EXPR-}
   (N "a4"  ) -> "a4\n"  ++ (concat . map ppContent $ content) {-'for' 'string' ':=' EXPR 'to' EXPR 'do' EXPR-}
   (N "a5"  ) -> "a5\n"  ++ (concat . map ppContent $ content) {-'while' EXPR 'do' EXPR                      -}
   (N "a6"  ) -> "a6\n"  ++ (concat . map ppContent $ content) {-'let' DECLARATIONLIST 'in' EXPRSEQ 'end'    -}
   (N "a7"  ) -> "a7\n"  ++ (concat . map ppContent $ content) {-'(' EXPRSEQ ')'                             -}
   (N "a8"  ) -> "a8\n"  ++ (concat . map ppContent $ content) {-'string' '(' EXPRLIST ')'                   -}
   (N "a9"  ) -> "a9\n"  ++ (concat . map ppContent $ content) {-'string' '{' FIELDLIST '}'                  -}
   (N "a10" ) -> "a10\n" ++ (concat . map ppContent $ content) {-'if' EXPR 'then' EXPR 'else' EXPR           -}
   (N "a11" ) -> "a11\n" ++ (concat . map ppContent $ content) {-'if' EXPR 'then' EXPR                       -}
   (N "a12" ) -> "a12\n" ++ (concat . map ppContent $ content) {-EXPR                            -}
   (N "a13" ) -> "a13\n" ++ (concat . map ppContent $ content) {-EXPRLIST ',' EXPR               -}
   (N "a14" ) -> "a14\n" ++ (concat . map ppContent $ content) {-'string' '=' EXPR               -}
   (N "a15" ) -> "a15\n" ++ (concat . map ppContent $ content) {-FIELDLIST ',' 'string' '=' EXPR -}
   (N "a16" ) -> "a16\n" ++ (concat . map ppContent $ content) {-DECLARATION                     -}
   (N "a17" ) -> "a17\n" ++ (concat . map ppContent $ content) {-DECLARATION DECLARATIONLIST     -}
   (N "a18" ) -> "a18\n" ++ (concat . map ppContent $ content) {-TYPEDECLARATION                 -}
   (N "a19" ) -> "a19\n" ++ (concat . map ppContent $ content) {-VARIABLEDECLARATION             -}
   (N "a20" ) -> "a20\n" ++ (concat . map ppContent $ content) {-FUNCTIONDECLARATION             -}
   (N "a21" ) -> "a21\n" ++ (concat . map ppContent $ content) {- EXPR             -}
   (N "a22" ) -> "a22\n" ++ (concat . map ppContent $ content) {- EXPRSEQ ';' EXPR -}
   (N "a23" ) -> "a23\n" ++ (concat . map ppContent $ content) {- 'var' 'string' ':=' EXPR              -}
   (N "a24" ) -> "a24\n" ++ (concat . map ppContent $ content) {- 'var' 'string' ':' 'string' ':=' EXPR -}
   (N "a25" ) -> "a25\n" ++ (concat . map ppContent $ content) {- 'function' 'string' '(' TYPEFIELDS ')' '=' EXPR              -}
   (N "a26" ) -> "a26\n" ++ (concat . map ppContent $ content) {- 'function' 'string' '(' TYPEFIELDS ')' ':' 'string' '=' EXPR -}
   (N "a27" ) -> "a27\n" ++ (concat . map ppContent $ content) {- 'type' 'string' '=' TYPE -}
   (N "a28" ) -> "a28\n" ++ (concat . map ppContent $ content) {- 'string'              -}
   (N "a29" ) -> "a29\n" ++ (concat . map ppContent $ content) {- '{' TYPEFIELDS '}'    -}
   (N "a30" ) -> "a30\n" ++ (concat . map ppContent $ content) {- 'array' 'of' 'string' -}
   (N "a31" ) -> "a31\n" ++ (concat . map ppContent $ content) {- TYPEFIELD                -}
   (N "a32" ) -> "a32\n" ++ (concat . map ppContent $ content) {- TYPEFIELD ',' TYPEFIELDS -}
   (N "a33" ) -> "a33\n" ++ (concat . map ppContent $ content) {- 'string' ':' 'string' -}
   (N "a34" ) -> "a34\n" ++ (concat . map ppContent $ content) {- BINARYOP '|' BINARYOP1 -}
   (N "a35" ) -> "a35\n" ++ (concat . map ppContent $ content) {- BINARYOP1              -}
   (N "a36" ) -> "a36\n" ++ (concat . map ppContent $ content) {- BINARYOP1 '&' BINARYOP2 -}
   (N "a37" ) -> "a37\n" ++ (concat . map ppContent $ content) {- BINARYOP2               -}
   (N "a38" ) -> "a38\n" ++ (concat . map ppContent $ content) {- BINARYOP2 '='  BINARYOP3 -}
   (N "a39" ) -> "a39\n" ++ (concat . map ppContent $ content) {- BINARYOP2 '>'  BINARYOP3 -}
   (N "a40" ) -> "a40\n" ++ (concat . map ppContent $ content) {- BINARYOP2 '<'  BINARYOP3 -}
   (N "a41" ) -> "a41\n" ++ (concat . map ppContent $ content) {- BINARYOP2 '<>' BINARYOP3 -}
   (N "a42" ) -> "a42\n" ++ (concat . map ppContent $ content) {- BINARYOP2 '>=' BINARYOP3 -}
   (N "a43" ) -> "a43\n" ++ (concat . map ppContent $ content) {- BINARYOP2 '<=' BINARYOP3 -}
   (N "a44" ) -> "a44\n" ++ (concat . map ppContent $ content) {- BINARYOP3                -}
   (N "a45" ) -> "a45\n" ++ (concat . map ppContent $ content) {- BINARYOP3 '+' BINARYOP4 -}
   (N "a46" ) -> "a46\n" ++ (concat . map ppContent $ content) {- BINARYOP3 '-' BINARYOP4 -}
   (N "a47" ) -> "a47\n" ++ (concat . map ppContent $ content) {- BINARYOP4               -}
   (N "a48" ) -> "a48\n" ++ (concat . map ppContent $ content) {- BINARYOP4 '*' BINARYOP5 -}
   (N "a49" ) -> "a49\n" ++ (concat . map ppContent $ content) {- BINARYOP4 '/' BINARYOP5 -}
   (N "a50" ) -> "a50\n" ++ (concat . map ppContent $ content) {- BINARYOP5               -}
   (N "a51" ) -> "a51\n" ++ (concat . map ppContent $ content) {- 'number'         -}
   (N "a52" ) -> "a52\n" ++ (concat . map ppContent $ content) {- LVALUE           -}
   (N "a53" ) -> "a53\n" ++ (concat . map ppContent $ content) {- '-' BINARYOP5    -}
   (N "a54" ) -> "a54\n" ++ (concat . map ppContent $ content) {- '(' BINARYOP ')' -}
   (N "a55" ) -> "a55\n" ++ (concat . map ppContent $ content) {- 'string'            -}
   (N "a56" ) -> "a56\n" ++ (concat . map ppContent $ content) {- LVALUE '.' 'string' -}
   (N "a57" ) -> "a57\n" ++ (concat . map ppContent $ content) {- LVALUE '[' EXPR ']' -}
   (N "biyaccpcdata") -> "biyaccpcdata\n" ++ (concat . map ppContent $ content)
   (N a)      -> (concat . map ppContent $ content)
   (QN a _)   -> "QN " ++ show a ++ (concat . map ppContent $ content)
-}


