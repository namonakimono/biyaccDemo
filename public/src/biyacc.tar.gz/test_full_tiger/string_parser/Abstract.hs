module Arith where

import Text.XML.HaXml.XmlContent
import Text.XML.HaXml.Types
import Text.XML.HaXml.OneOfN


{-Type decls-}

data Arith = ArithArithstring Arithstring
           | ArithArithnumber Arithnumber
           | ArithArithnil Arithnil
           | ArithArithfunctionapplication Arithfunctionapplication
           | ArithArithcreaterecordinstance Arithcreaterecordinstance
           | ArithArithcreatearray Arithcreatearray
           | ArithArithifthenelse Arithifthenelse
           | ArithArithwhile Arithwhile
           | ArithArithfor Arithfor
           | ArithArithbreak Arithbreak
           | ArithArithletin Arithletin
           | ArithArithrecordfield Arithrecordfield
           | ArithAritharrayfield Aritharrayfield
           | ArithArithtypedeclaration Arithtypedeclaration
           | ArithArithnewarray Arithnewarray
           | ArithArithtypefield Arithtypefield
           | ArithArithvardeclwithtype Arithvardeclwithtype
           | ArithArithfunctiondeclaration Arithfunctiondeclaration
           | ArithArithfunctiondeclarationwithtype Arithfunctiondeclarationwithtype
           | ArithArithor Arithor
           | ArithArithand Arithand
           | ArithArithequal Arithequal
           | ArithArithgt Arithgt
           | ArithArithlt Arithlt
           | ArithArithdiff Arithdiff
           | ArithArithget Arithget
           | ArithArithlet Arithlet
           | ArithArithplus Arithplus
           | ArithArithminus Arithminus
           | ArithArithmult Arithmult
           | ArithArithdiv Arithdiv
           | ArithArithexprlist Arithexprlist
           | ArithArithseq Arithseq
           | ArithArithparentheses Arithparentheses
           | ArithArithassignment Arithassignment
           | ArithArithassignmentlist Arithassignmentlist
           | ArithArithstruct Arithstruct
           deriving (Eq,Show)
newtype Arithstring = Arithstring Biyaccpcdata 		deriving (Eq,Show)
newtype Arithnumber = Arithnumber Biyaccpcdata 		deriving (Eq,Show)
data Arithnil = Arithnil 		deriving (Eq,Show)
data Arithfunctionapplication = Arithfunctionapplication Biyaccpcdata
                                                         Arith
                              deriving (Eq,Show)
data Arithcreaterecordinstance = Arithcreaterecordinstance Biyaccpcdata
                                                           Arith
                               deriving (Eq,Show)
data Arithcreatearray = Arithcreatearray Biyaccpcdata Arith Arith
                      deriving (Eq,Show)
data Arithifthenelse = Arithifthenelse Arith Arith Arith
                     deriving (Eq,Show)
data Arithwhile = Arithwhile Arith Arith
                deriving (Eq,Show)
data Arithfor = Arithfor Biyaccpcdata Arith Arith Arith
              deriving (Eq,Show)
data Arithbreak = Arithbreak 		deriving (Eq,Show)
data Arithletin = Arithletin Arith Arith
                deriving (Eq,Show)
data Arithrecordfield = Arithrecordfield Arith Biyaccpcdata
                      deriving (Eq,Show)
data Aritharrayfield = Aritharrayfield Arith Arith
                     deriving (Eq,Show)
data Arithtypedeclaration = Arithtypedeclaration Biyaccpcdata Arith
                          deriving (Eq,Show)
newtype Arithnewarray = Arithnewarray Biyaccpcdata 		deriving (Eq,Show)
data Arithtypefield = Arithtypefield Biyaccpcdata Arith
                    deriving (Eq,Show)
data Arithvardeclwithtype = Arithvardeclwithtype Biyaccpcdata
                                                 Biyaccpcdata Arith
                          deriving (Eq,Show)
data Arithfunctiondeclaration = Arithfunctiondeclaration Biyaccpcdata
                                                         Arith Arith
                              deriving (Eq,Show)
data Arithfunctiondeclarationwithtype = Arithfunctiondeclarationwithtype Biyaccpcdata
                                                                         Arith Biyaccpcdata Arith
                                      deriving (Eq,Show)
data Arithor = Arithor Arith Arith
             deriving (Eq,Show)
data Arithand = Arithand Arith Arith
              deriving (Eq,Show)
data Arithequal = Arithequal Arith Arith
                deriving (Eq,Show)
data Arithgt = Arithgt Arith Arith
             deriving (Eq,Show)
data Arithlt = Arithlt Arith Arith
             deriving (Eq,Show)
data Arithdiff = Arithdiff Arith Arith
               deriving (Eq,Show)
data Arithget = Arithget Arith Arith
              deriving (Eq,Show)
data Arithlet = Arithlet Arith Arith
              deriving (Eq,Show)
data Arithplus = Arithplus Arith Arith
               deriving (Eq,Show)
data Arithminus = Arithminus Arith Arith
                deriving (Eq,Show)
data Arithmult = Arithmult Arith Arith
               deriving (Eq,Show)
data Arithdiv = Arithdiv Arith Arith
              deriving (Eq,Show)
data Arithexprlist = Arithexprlist Arith Arith
                   deriving (Eq,Show)
data Arithseq = Arithseq Arith Arith
              deriving (Eq,Show)
newtype Arithparentheses = Arithparentheses Arith 		deriving (Eq,Show)
data Arithassignment = Arithassignment Biyaccpcdata Arith
                     deriving (Eq,Show)
data Arithassignmentlist = Arithassignmentlist Arith Arith
                         deriving (Eq,Show)
newtype Arithstruct = Arithstruct Arith 		deriving (Eq,Show)
newtype Biyaccpcdata = Biyaccpcdata String 		deriving (Eq,Show)


{-Instance decls-}

instance HTypeable Arith where
    toHType x = Defined "arith" [] []
instance XmlContent Arith where
    toContents (ArithArithstring a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithnumber a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithnil a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithfunctionapplication a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithcreaterecordinstance a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithcreatearray a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithifthenelse a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithwhile a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithfor a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithbreak a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithletin a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithrecordfield a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithAritharrayfield a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithtypedeclaration a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithnewarray a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithtypefield a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithvardeclwithtype a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithfunctiondeclaration a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithfunctiondeclarationwithtype a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithor a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithand a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithequal a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithgt a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithlt a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithdiff a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithget a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithlet a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithplus a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithminus a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithmult a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithdiv a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithexprlist a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithseq a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithparentheses a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithassignment a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithassignmentlist a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    toContents (ArithArithstruct a) =
        [CElem (Elem (N "arith") [] (toContents a) ) ()]
    parseContents = do 
        { e@(Elem _ [] _) <- element ["arith"]
        ; interior e $ oneOf
            [ return (ArithArithstring) `apply` parseContents
            , return (ArithArithnumber) `apply` parseContents
            , return (ArithArithnil) `apply` parseContents
            , return (ArithArithfunctionapplication) `apply` parseContents
            , return (ArithArithcreaterecordinstance) `apply` parseContents
            , return (ArithArithcreatearray) `apply` parseContents
            , return (ArithArithifthenelse) `apply` parseContents
            , return (ArithArithwhile) `apply` parseContents
            , return (ArithArithfor) `apply` parseContents
            , return (ArithArithbreak) `apply` parseContents
            , return (ArithArithletin) `apply` parseContents
            , return (ArithArithrecordfield) `apply` parseContents
            , return (ArithAritharrayfield) `apply` parseContents
            , return (ArithArithtypedeclaration) `apply` parseContents
            , return (ArithArithnewarray) `apply` parseContents
            , return (ArithArithtypefield) `apply` parseContents
            , return (ArithArithvardeclwithtype) `apply` parseContents
            , return (ArithArithfunctiondeclaration) `apply` parseContents
            , return (ArithArithfunctiondeclarationwithtype)
              `apply` parseContents
            , return (ArithArithor) `apply` parseContents
            , return (ArithArithand) `apply` parseContents
            , return (ArithArithequal) `apply` parseContents
            , return (ArithArithgt) `apply` parseContents
            , return (ArithArithlt) `apply` parseContents
            , return (ArithArithdiff) `apply` parseContents
            , return (ArithArithget) `apply` parseContents
            , return (ArithArithlet) `apply` parseContents
            , return (ArithArithplus) `apply` parseContents
            , return (ArithArithminus) `apply` parseContents
            , return (ArithArithmult) `apply` parseContents
            , return (ArithArithdiv) `apply` parseContents
            , return (ArithArithexprlist) `apply` parseContents
            , return (ArithArithseq) `apply` parseContents
            , return (ArithArithparentheses) `apply` parseContents
            , return (ArithArithassignment) `apply` parseContents
            , return (ArithArithassignmentlist) `apply` parseContents
            , return (ArithArithstruct) `apply` parseContents
            ] `adjustErr` ("in <arith>, "++)
        }

instance HTypeable Arithstring where
    toHType x = Defined "arithstring" [] []
instance XmlContent Arithstring where
    toContents (Arithstring a) =
        [CElem (Elem (N "arithstring") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithstring"]
        ; interior e $ return (Arithstring) `apply` parseContents
        } `adjustErr` ("in <arithstring>, "++)

instance HTypeable Arithnumber where
    toHType x = Defined "arithnumber" [] []
instance XmlContent Arithnumber where
    toContents (Arithnumber a) =
        [CElem (Elem (N "arithnumber") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithnumber"]
        ; interior e $ return (Arithnumber) `apply` parseContents
        } `adjustErr` ("in <arithnumber>, "++)

instance HTypeable Arithnil where
    toHType x = Defined "arithnil" [] []
instance XmlContent Arithnil where
    toContents Arithnil =
        [CElem (Elem (N "arithnil") [] []) ()]
    parseContents = do
        { (Elem _ as []) <- element ["arithnil"]
        ; return Arithnil
        } `adjustErr` ("in <arithnil>, "++)

instance HTypeable Arithfunctionapplication where
    toHType x = Defined "arithfunctionapplication" [] []
instance XmlContent Arithfunctionapplication where
    toContents (Arithfunctionapplication a b) =
        [CElem (Elem (N "arithfunctionapplication") [] (toContents a ++
                                                        toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithfunctionapplication"]
        ; interior e $ return (Arithfunctionapplication)
                       `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <arithfunctionapplication>, "++)

instance HTypeable Arithcreaterecordinstance where
    toHType x = Defined "arithcreaterecordinstance" [] []
instance XmlContent Arithcreaterecordinstance where
    toContents (Arithcreaterecordinstance a b) =
        [CElem (Elem (N "arithcreaterecordinstance") [] (toContents a ++
                                                         toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithcreaterecordinstance"]
        ; interior e $ return (Arithcreaterecordinstance)
                       `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <arithcreaterecordinstance>, "++)

instance HTypeable Arithcreatearray where
    toHType x = Defined "arithcreatearray" [] []
instance XmlContent Arithcreatearray where
    toContents (Arithcreatearray a b c) =
        [CElem (Elem (N "arithcreatearray") [] (toContents a ++
                                                toContents b ++ toContents c)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithcreatearray"]
        ; interior e $ return (Arithcreatearray) `apply` parseContents
                       `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <arithcreatearray>, "++)

instance HTypeable Arithifthenelse where
    toHType x = Defined "arithifthenelse" [] []
instance XmlContent Arithifthenelse where
    toContents (Arithifthenelse a b c) =
        [CElem (Elem (N "arithifthenelse") [] (toContents a ++ toContents b
                                               ++ toContents c)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithifthenelse"]
        ; interior e $ return (Arithifthenelse) `apply` parseContents
                       `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <arithifthenelse>, "++)

instance HTypeable Arithwhile where
    toHType x = Defined "arithwhile" [] []
instance XmlContent Arithwhile where
    toContents (Arithwhile a b) =
        [CElem (Elem (N "arithwhile") [] (toContents a ++
                                          toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithwhile"]
        ; interior e $ return (Arithwhile) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithwhile>, "++)

instance HTypeable Arithfor where
    toHType x = Defined "arithfor" [] []
instance XmlContent Arithfor where
    toContents (Arithfor a b c d) =
        [CElem (Elem (N "arithfor") [] (toContents a ++ toContents b ++
                                        toContents c ++ toContents d)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithfor"]
        ; interior e $ return (Arithfor) `apply` parseContents
                       `apply` parseContents `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <arithfor>, "++)

instance HTypeable Arithbreak where
    toHType x = Defined "arithbreak" [] []
instance XmlContent Arithbreak where
    toContents Arithbreak =
        [CElem (Elem (N "arithbreak") [] []) ()]
    parseContents = do
        { (Elem _ as []) <- element ["arithbreak"]
        ; return Arithbreak
        } `adjustErr` ("in <arithbreak>, "++)

instance HTypeable Arithletin where
    toHType x = Defined "arithletin" [] []
instance XmlContent Arithletin where
    toContents (Arithletin a b) =
        [CElem (Elem (N "arithletin") [] (toContents a ++
                                          toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithletin"]
        ; interior e $ return (Arithletin) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithletin>, "++)

instance HTypeable Arithrecordfield where
    toHType x = Defined "arithrecordfield" [] []
instance XmlContent Arithrecordfield where
    toContents (Arithrecordfield a b) =
        [CElem (Elem (N "arithrecordfield") [] (toContents a ++
                                                toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithrecordfield"]
        ; interior e $ return (Arithrecordfield) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithrecordfield>, "++)

instance HTypeable Aritharrayfield where
    toHType x = Defined "aritharrayfield" [] []
instance XmlContent Aritharrayfield where
    toContents (Aritharrayfield a b) =
        [CElem (Elem (N "aritharrayfield") [] (toContents a ++
                                               toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["aritharrayfield"]
        ; interior e $ return (Aritharrayfield) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <aritharrayfield>, "++)

instance HTypeable Arithtypedeclaration where
    toHType x = Defined "arithtypedeclaration" [] []
instance XmlContent Arithtypedeclaration where
    toContents (Arithtypedeclaration a b) =
        [CElem (Elem (N "arithtypedeclaration") [] (toContents a ++
                                                    toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithtypedeclaration"]
        ; interior e $ return (Arithtypedeclaration) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithtypedeclaration>, "++)

instance HTypeable Arithnewarray where
    toHType x = Defined "arithnewarray" [] []
instance XmlContent Arithnewarray where
    toContents (Arithnewarray a) =
        [CElem (Elem (N "arithnewarray") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithnewarray"]
        ; interior e $ return (Arithnewarray) `apply` parseContents
        } `adjustErr` ("in <arithnewarray>, "++)

instance HTypeable Arithtypefield where
    toHType x = Defined "arithtypefield" [] []
instance XmlContent Arithtypefield where
    toContents (Arithtypefield a b) =
        [CElem (Elem (N "arithtypefield") [] (toContents a ++
                                              toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithtypefield"]
        ; interior e $ return (Arithtypefield) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithtypefield>, "++)

instance HTypeable Arithvardeclwithtype where
    toHType x = Defined "arithvardeclwithtype" [] []
instance XmlContent Arithvardeclwithtype where
    toContents (Arithvardeclwithtype a b c) =
        [CElem (Elem (N "arithvardeclwithtype") [] (toContents a ++
                                                    toContents b ++ toContents c)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithvardeclwithtype"]
        ; interior e $ return (Arithvardeclwithtype) `apply` parseContents
                       `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <arithvardeclwithtype>, "++)

instance HTypeable Arithfunctiondeclaration where
    toHType x = Defined "arithfunctiondeclaration" [] []
instance XmlContent Arithfunctiondeclaration where
    toContents (Arithfunctiondeclaration a b c) =
        [CElem (Elem (N "arithfunctiondeclaration") [] (toContents a ++
                                                        toContents b ++ toContents c)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithfunctiondeclaration"]
        ; interior e $ return (Arithfunctiondeclaration)
                       `apply` parseContents `apply` parseContents `apply` parseContents
        } `adjustErr` ("in <arithfunctiondeclaration>, "++)

instance HTypeable Arithfunctiondeclarationwithtype where
    toHType x = Defined "arithfunctiondeclarationwithtype" [] []
instance XmlContent Arithfunctiondeclarationwithtype where
    toContents (Arithfunctiondeclarationwithtype a b c d) =
        [CElem (Elem (N "arithfunctiondeclarationwithtype") [] (toContents a
                                                                ++ toContents b ++ toContents c ++
                                                                toContents d)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithfunctiondeclarationwithtype"]
        ; interior e $ return (Arithfunctiondeclarationwithtype)
                       `apply` parseContents `apply` parseContents `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithfunctiondeclarationwithtype>, "++)

instance HTypeable Arithor where
    toHType x = Defined "arithor" [] []
instance XmlContent Arithor where
    toContents (Arithor a b) =
        [CElem (Elem (N "arithor") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithor"]
        ; interior e $ return (Arithor) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithor>, "++)

instance HTypeable Arithand where
    toHType x = Defined "arithand" [] []
instance XmlContent Arithand where
    toContents (Arithand a b) =
        [CElem (Elem (N "arithand") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithand"]
        ; interior e $ return (Arithand) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithand>, "++)

instance HTypeable Arithequal where
    toHType x = Defined "arithequal" [] []
instance XmlContent Arithequal where
    toContents (Arithequal a b) =
        [CElem (Elem (N "arithequal") [] (toContents a ++
                                          toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithequal"]
        ; interior e $ return (Arithequal) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithequal>, "++)

instance HTypeable Arithgt where
    toHType x = Defined "arithgt" [] []
instance XmlContent Arithgt where
    toContents (Arithgt a b) =
        [CElem (Elem (N "arithgt") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithgt"]
        ; interior e $ return (Arithgt) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithgt>, "++)

instance HTypeable Arithlt where
    toHType x = Defined "arithlt" [] []
instance XmlContent Arithlt where
    toContents (Arithlt a b) =
        [CElem (Elem (N "arithlt") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithlt"]
        ; interior e $ return (Arithlt) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithlt>, "++)

instance HTypeable Arithdiff where
    toHType x = Defined "arithdiff" [] []
instance XmlContent Arithdiff where
    toContents (Arithdiff a b) =
        [CElem (Elem (N "arithdiff") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithdiff"]
        ; interior e $ return (Arithdiff) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithdiff>, "++)

instance HTypeable Arithget where
    toHType x = Defined "arithget" [] []
instance XmlContent Arithget where
    toContents (Arithget a b) =
        [CElem (Elem (N "arithget") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithget"]
        ; interior e $ return (Arithget) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithget>, "++)

instance HTypeable Arithlet where
    toHType x = Defined "arithlet" [] []
instance XmlContent Arithlet where
    toContents (Arithlet a b) =
        [CElem (Elem (N "arithlet") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithlet"]
        ; interior e $ return (Arithlet) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithlet>, "++)

instance HTypeable Arithplus where
    toHType x = Defined "arithplus" [] []
instance XmlContent Arithplus where
    toContents (Arithplus a b) =
        [CElem (Elem (N "arithplus") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithplus"]
        ; interior e $ return (Arithplus) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithplus>, "++)

instance HTypeable Arithminus where
    toHType x = Defined "arithminus" [] []
instance XmlContent Arithminus where
    toContents (Arithminus a b) =
        [CElem (Elem (N "arithminus") [] (toContents a ++
                                          toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithminus"]
        ; interior e $ return (Arithminus) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithminus>, "++)

instance HTypeable Arithmult where
    toHType x = Defined "arithmult" [] []
instance XmlContent Arithmult where
    toContents (Arithmult a b) =
        [CElem (Elem (N "arithmult") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithmult"]
        ; interior e $ return (Arithmult) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithmult>, "++)

instance HTypeable Arithdiv where
    toHType x = Defined "arithdiv" [] []
instance XmlContent Arithdiv where
    toContents (Arithdiv a b) =
        [CElem (Elem (N "arithdiv") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithdiv"]
        ; interior e $ return (Arithdiv) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithdiv>, "++)

instance HTypeable Arithexprlist where
    toHType x = Defined "arithexprlist" [] []
instance XmlContent Arithexprlist where
    toContents (Arithexprlist a b) =
        [CElem (Elem (N "arithexprlist") [] (toContents a ++
                                             toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithexprlist"]
        ; interior e $ return (Arithexprlist) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithexprlist>, "++)

instance HTypeable Arithseq where
    toHType x = Defined "arithseq" [] []
instance XmlContent Arithseq where
    toContents (Arithseq a b) =
        [CElem (Elem (N "arithseq") [] (toContents a ++ toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithseq"]
        ; interior e $ return (Arithseq) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithseq>, "++)

instance HTypeable Arithparentheses where
    toHType x = Defined "arithparentheses" [] []
instance XmlContent Arithparentheses where
    toContents (Arithparentheses a) =
        [CElem (Elem (N "arithparentheses") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithparentheses"]
        ; interior e $ return (Arithparentheses) `apply` parseContents
        } `adjustErr` ("in <arithparentheses>, "++)

instance HTypeable Arithassignment where
    toHType x = Defined "arithassignment" [] []
instance XmlContent Arithassignment where
    toContents (Arithassignment a b) =
        [CElem (Elem (N "arithassignment") [] (toContents a ++
                                               toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithassignment"]
        ; interior e $ return (Arithassignment) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithassignment>, "++)

instance HTypeable Arithassignmentlist where
    toHType x = Defined "arithassignmentlist" [] []
instance XmlContent Arithassignmentlist where
    toContents (Arithassignmentlist a b) =
        [CElem (Elem (N "arithassignmentlist") [] (toContents a ++
                                                   toContents b)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithassignmentlist"]
        ; interior e $ return (Arithassignmentlist) `apply` parseContents
                       `apply` parseContents
        } `adjustErr` ("in <arithassignmentlist>, "++)

instance HTypeable Arithstruct where
    toHType x = Defined "arithstruct" [] []
instance XmlContent Arithstruct where
    toContents (Arithstruct a) =
        [CElem (Elem (N "arithstruct") [] (toContents a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["arithstruct"]
        ; interior e $ return (Arithstruct) `apply` parseContents
        } `adjustErr` ("in <arithstruct>, "++)

instance HTypeable Biyaccpcdata where
    toHType x = Defined "biyaccpcdata" [] []
instance XmlContent Biyaccpcdata where
    toContents (Biyaccpcdata a) =
        [CElem (Elem (N "biyaccpcdata") [] (toText a)) ()]
    parseContents = do
        { e@(Elem _ [] _) <- element ["biyaccpcdata"]
        ; interior e $ return (Biyaccpcdata)
                       `apply` (text `onFail` return "")
        } `adjustErr` ("in <biyaccpcdata>, "++)



{-Done-}
