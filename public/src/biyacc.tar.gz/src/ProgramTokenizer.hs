module ProgramTokenizer where

import qualified Text.Parsec.Token as PT
import Text.Parsec as P
import qualified Text.Parsec.Char as PC
import Text.Parsec.Pos
import Text.Parsec.Language
import Text.Parsec.Char
import Text.Parsec.Combinator

import System.IO
import System.Environment
import Text.Parsec.Perm
import Text.Parsec.Prim

import Debug.Trace

data Arith = ADD Arith Arith
           | SUB Arith Arith
           | MUL Arith Arith
           | DIV Arith Arith
           | NUM Int

data Token = LParen | RParen
            | HasType      -- +>
            | QAction      -- keyword Program
            | QNL           -- new line
            | QRArrow       -- ->
            | QUpdateArr   -- =>
            | QCreateArr    -- ~>
            -- | QRepStar      -- * --replace. not repeat
            | QASPattern       -- @ represent the whole expression.
            | QScope        -- _ match any cases, ignore the value
            -- | QAdd | QSub | QMul | QDiv | QNeg
            | QCon String  -- Abstract type, must be upper case letters: ADD, SUB
            | QVar String   -- must be lower case letters: lhs, rhs
            | QStrLtr String      -- literal string. "abc". autumatically change 'a' to "a"
  deriving (Show, Eq)

type TokenPos = (Token, SourcePos)


dslDef = PT.LanguageDef
  {
    PT.commentStart = "{-"
   ,PT.commentEnd = "-}"
   ,PT.commentLine ="--"
   ,PT.nestedComments = False
   ,PT.identStart = PC.lower
   ,PT.identLetter = PC.lower <|> PC.digit
   ,PT.opStart = PC.oneOf ":!#$%&*+./<=>?@\\^|-~"
   ,PT.opLetter = PC.oneOf ":!#$%&*+./<=>?@\\^|-~"
   ,PT.reservedNames = ["String", "Abstract", "Concrete", "Actions"]
   ,PT.reservedOpNames = [""]
   ,PT.caseSensitive = True
  }

tokenParser = PT.makeTokenParser dslDef
-- apply lexeme to a parser to make the parser skip all the following white spaces

comment :: Parsec String () ()
comment = (try oneLineComment <|> multiLineComment) >> simpleSpace <?> "comment"

oneLineComment :: Parsec String () ()
oneLineComment = (do
  string "--"
  skipMany (satisfy (\x -> x /= '\n' && x /= '\r'))
  simpleSpace
  return () )
  <?> "oneLineComment"

multiLineComment :: Parsec String () ()
multiLineComment = (do
  string "{-"
  manyTill anyChar (try (string "-}"))
  simpleSpace
  return ())
  <?> "multiLineComment"

whiteSpace :: Parsec String () ()
whiteSpace = comment <|> simpleSpace <?> "whiteSpace"

simpleSpace :: Parsec String () ()
simpleSpace = (skipMany (satisfy isSpace')) <?> "simpleSpace"


isSpace' :: Char -> Bool
isSpace' c =
  c == ' '     ||
  c == '\t'    ||
  c == '\r'    ||
  c == '\f'    ||
  c == '\v'    ||
  c == '\xa0'
   -- iswspace (fromIntegral (ord c)) /= 0


newLine :: Parsec String () TokenPos
newLine = lexeme (do
  pos <- getPosition
  skipMany1 endOfLine
  return (QNL, pos))
  <?> "newLine"

-- isNewLine :: Char -> Bool
-- isNewLine c = c == '\n'




stringLiteral :: Parsec String () String
stringLiteral = PT.stringLiteral tokenParser


-- myCharLiteral :: TokenPos
charLiteral = lexeme (do
   try(char '\'')
   str <- manyTill (noneOf "\'") (string "\'")
   return str)
   <?> "myCharLiteral"

lexeme :: Parsec String () a -> Parsec String () a
lexeme p = do{ x <- p; whiteSpace; return x }





-- try the following tokenizers!
tryTable = [newLine,tokenKeyword, tokenIdentifier, tokenQCon, tokenBuiltInOpt,
           tokenStrLtr, tokenSymbol]

-- program tokenizer.
tokenizer :: Parsec String () [TokenPos]
tokenizer = whiteSpace >> (many $ foldr1 ((<|>) . try) tryTable)


--string literal
--will change char literal to string literal
tokenStrLtr :: Parsec String () TokenPos
tokenStrLtr = lexeme (do
  pos <- getPosition
  choice [stringLiteral >>= \str -> return (QStrLtr str, pos)
         ,charLiteral >>= \str -> return (QStrLtr str, pos)])
  <?> "tokenStrLtr"

-- identifier
tokenIdentifier :: Parsec String () TokenPos
tokenIdentifier = lexeme (do
  pos <- getPosition
  identifier <- PT.identifier tokenParser
  return (QVar identifier, pos))
  <?> "tokenIdentifier"

-- built in operator
tokenBuiltInOpt :: Parsec String () TokenPos
tokenBuiltInOpt = lexeme (do
  pos <- getPosition
  choice [string "->" >> return (QRArrow, pos)
         ,string "=>" >> return (QUpdateArr, pos)
         ,string "~>" >> return (QCreateArr, pos)
         -- ,string "*"  >> return (QRepStar, pos)
         ,string "@"  >> return (QASPattern, pos)
         ,string "_"  >> return (QScope, pos)
         ,string "+>" >> return (HasType, pos)])
  <?> "tokenBuiltInOpt"

tokenKeyword = lexeme (do
  pos <- getPosition
  string "Actions" >> return (QAction, pos))
  <?> "tokenKeyword"

-- operation for this problem. hard coding
-- tokenOpt :: Parsec String () TokenPos
-- tokenOpt = lexeme (do
--   pos <- getPosition
--   choice [char '+' >> return (QAdd, pos)
--          ,char '-' >> return (QSub, pos)
--          ,char '*' >> return (QMul, pos)
--          ,char '/' >> return (QDiv, pos)])
--   <?> "tokenOpt"

-- type constructor
tokenQCon :: Parsec String () TokenPos
tokenQCon = lexeme (do
  pos <- getPosition
  f <- PC.upper
  t <- many1 (PC.alphaNum <|> PC.char '_')
  return (QCon (f:t), pos))
  <?> "tokenQCon"

-- symbols, '(', ')', etc.
tokenSymbol :: Parsec String () TokenPos
tokenSymbol = lexeme (do
  pos <- getPosition
  choice [char '(' >> return (LParen, pos)
         ,char ')' >> return (RParen, pos)])
  <?> "tokenSymbol"


-- for test use
t1 = do
  stream <- readFile "dsl.dsl"
  case (runParser tokenizer () "dsl.dsl" stream) of
    Left err -> print err
    Right tokens -> print $ foldr ((:) . fst) [] tokens

t2 = do
  stream <- readFile "dsl.dsl"
  case (runParser tokenizer () "dsl.dsl" stream) of
    Left err -> print err
    Right tokens -> print tokens
