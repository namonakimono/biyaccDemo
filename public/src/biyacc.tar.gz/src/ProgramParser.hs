module ProgramParser where

import ProgramTokenizer

import Text.Parsec.Prim
import Text.Parsec.Combinator
import Control.Monad
-- import Debug.Trace
import Text.PrettyPrint as PPrint
import Data.List (intersperse, map)
import Data.Char (toLower)

-- data type for parser to return to build the AST.
newtype SourceCon = SourceCon String deriving (Show, Eq)
newtype ViewCon   = ViewCon String deriving (Show, Eq)

newtype Program  = Program [Piece] deriving (Show, Eq)
data Piece    = Piece TypeDecl [Rule] deriving (Show, Eq)
data TypeDecl = TypeDecl ViewCon SourceCon deriving (Show, Eq)

data Rule = NormalRule LHSPattern [RHSUpdate]
          | AdaptRule
  deriving (Show, Eq)

data LHSPattern = NormalP ViewCon [LHSPattern]   -- NormalP: normal pattern(I just do not know how to call it)
                | ASPattern String LHSPattern         -- ASPattern: @
                | ViewVar String
                | AStrLtr String
                | Scope                          -- Scope: _
  deriving (Show, Eq)

data RHSUpdate = Update String SourceCon    -- (lhs => Expr).  Update viewvar source constructor
                | NonUpdate SourceCon        -- a single constructor
                | RHSLiteral String           -- "-", '+', etc.
                | DeepPat String [RHSUpdate] -- (Factor -> (lhs => Factor) '^2'); DeepPat (SourceCon name) [rhspats]
  deriving (Show, Eq)

isToken :: Token -> Parsec [TokenPos] () Token
isToken tok = token show snd (\t -> if fst t == tok then Just (fst t) else Nothing)

-- extract the string in the QCon Constructor
qCon :: Parsec [TokenPos] () String
qCon = token show snd
         (\t -> case fst t of
           QCon str -> Just str
           _ -> Nothing)

-- extract the string in the QVar Constructor
qVar :: Parsec [TokenPos] () String
qVar = token show snd
         (\t -> case fst t of
           QVar str -> Just str
           _ -> Nothing)
--extract the string from the QStrLtr Constructor
qStrLtr :: Parsec [TokenPos] () String
qStrLtr = token show snd
            (\t -> case fst t of
             QStrLtr str -> Just str
             _ -> Nothing)



programParser :: Parsec [TokenPos] () Program
programParser = isToken QAction >> isToken QNL >> liftM Program (many pieceParser)
            >>= \josh -> eof >> return josh <?> "programParser"


-- add a new line token at the end of the file.
-- consider it a trick for the parser.
addNewLine :: [TokenPos] -> [TokenPos]
addNewLine t = t ++ [(QNL, snd . last $ t)]


throwMulNewLine :: [TokenPos] -> [TokenPos]
throwMulNewLine [] = []
throwMulNewLine ((QNL,_):(QNL,pos):xs) = throwMulNewLine ((QNL,pos):xs)
throwMulNewLine (x:xs) = x : throwMulNewLine xs


pieceParser :: Parsec [TokenPos] () Piece
pieceParser = do
  typedecl <- typeDeclParser
  rules <- many1 (try ruleParser)
  return (Piece typedecl rules)
  <?> "pieceParser"

typeDeclParser :: Parsec [TokenPos] () TypeDecl
typeDeclParser = do
  vcon <- qCon
  isToken HasType
  scon <-qCon
  isToken QNL
  return $ TypeDecl (ViewCon vcon) (SourceCon scon)
  <?> "typeDeclParser"


-- data Rule = NormalRule LHSPattern [RHSUpdate]
ruleParser :: Parsec [TokenPos] () Rule
ruleParser =
  -- (try (isToken QRepStar >> isToken QCreateArr >> isToken QRepStar >>
  --       isToken QNL >> return AdaptRule) <?> "ruleParser, replace rule") <|>
  (try (do
        rulelhs <- ruleLHSPatternParser
        isToken QRArrow
        rulerhs <- manyTill rhsUpdateParser (isToken QNL)
        return (NormalRule rulelhs rulerhs)) <?> "ruleParser, normal rule") <|>
  ((do
    isToken LParen
    inner <- ruleParser
    isToken RParen
    try (isToken QNL)
    return inner) <?> "ruleParser, parenthesis rule")


ruleLHSPatternParser :: Parsec [TokenPos] () LHSPattern
ruleLHSPatternParser =
  try (do
       vvar <- qVar
       isToken QASPattern
       isToken LParen
       pattern <- ruleLHSPatternParser
       isToken RParen
       return (ASPattern vvar pattern)) <|>
  try (do
        vcon <- qCon
        elemsOf <- many (try ruleLHSPatternParser)
        return (NormalP (ViewCon vcon) elemsOf)) <|>
  try (liftM ViewVar qVar) <|>
  try (isToken QScope >> return Scope) <|>
  try (liftM AStrLtr qStrLtr) <|>
  (do
    isToken LParen
    innerpatterns <- ruleLHSPatternParser
    isToken RParen
    return innerpatterns)
  <?> "ruleLHSPatternParser"


rhsUpdateParser :: Parsec [TokenPos] () RHSUpdate
rhsUpdateParser =
  (try (do
    isToken LParen
    scon <- qCon
    isToken QRArrow
    following <- many1 rhsUpdateParser
    isToken RParen
    return $ DeepPat scon following
  ) <?> "DeepPat" ) <|>
  try (do
        vvar <- try qVar <|> qStrLtr
        isToken QUpdateArr
        scon <- qCon
        return $ Update vvar (SourceCon scon)) <|>
  -- problematic, from the view of Tokens, this pattern is the same as part of the LHS side: (SourceCon String)
  try (do
        scon <- qCon
        return $ NonUpdate (SourceCon scon)) <|>
  try (liftM RHSLiteral qStrLtr) <|>
  (do
    isToken LParen
    inner <- rhsUpdateParser
    isToken RParen
    return inner)
  <?> "rhsUpdateParser"


genProgramAST fname = do
  stream <- readFile fname
  case runParser tokenizer () fname stream of
    Left err -> print err
    Right tokens ->
      case runParser programParser () fname tokens of
        Left err -> print err
        Right ast -> do
          putStrLn "compiler has not been implemented. see ast below"
          print ast

-- used by the main module. some redundant work...
tokenToAst :: [TokenPos] -> FilePath -> Program
tokenToAst tokens fname =
  case runParser programParser () fname (throwMulNewLine . addNewLine $ tokens) of
    Left err -> error $ show err
    Right ast -> ast

-------------------end program parser ------------------


-------------------ast pretty printer ----------------------
pprogram :: Program -> Doc
pprogram (Program pieces) = text "Actions" $+$ ppieces pieces

ppieces =  foldr (($+$) . ppiece) PPrint.empty

ppiece (Piece typedecl rules) = ptypedecl typedecl $+$ prules rules $+$ text "\n"

-- print type declaration
ptypedecl (TypeDecl viewcon sourcecon) = text "Type Declaration" <+> pviewcon viewcon <+> text "->" <+> psourcecon sourcecon
pviewcon (ViewCon str) = text str
psourcecon (SourceCon str) = text str

prules :: [Rule] -> Doc
prules = foldr (($+$) . prule) PPrint.empty

prule :: Rule -> Doc
prule (NormalRule lhs rhs) = text "\nGeneral update rule" $+$ nest 2 ( (plhs lhs <+> text "->") $+$ prhs rhs)
-- prule (AdaptRule) = text "Adaptation rule: * ~> *"

plhs :: LHSPattern -> Doc
plhs lhspat = text "Left sides:" <+> nest 2 (pLhsPattern lhspat)

pLhsPattern :: LHSPattern -> Doc
pLhsPattern (NormalP viewcon pats) = pviewcon viewcon <+> pLhsPatterns pats
pLhsPattern (ASPattern varname lhspat)  = text "@" <> text varname <+> pLhsPattern lhspat
pLhsPattern Scope                  = text "_"
pLhsPattern (AStrLtr str)          = text str
pLhsPattern (ViewVar varname)      = text varname

pLhsPatterns :: [LHSPattern] -> Doc
pLhsPatterns =  foldr ((<+>) . pLhsPattern) PPrint.empty

prhs :: [RHSUpdate] -> Doc
prhs replaces = text "Right sides:" <+> nest 2 (pUpdates replaces)

pUpdates :: [RHSUpdate] -> Doc
pUpdates = foldr ((<+>) . pUpdate) PPrint.empty

pUpdate :: RHSUpdate -> Doc
pUpdate (Update varname sourcecon) = text varname <+> text "=>" <+> psourcecon sourcecon
pUpdate (NonUpdate sourcecon) = text "No replace:" <+> psourcecon sourcecon
pUpdate (RHSLiteral str) = text str

printAST fname = do
  stream <- readFile fname
  case runParser tokenizer () fname stream of
    Left err -> print err
    Right tokens ->
      case runParser programParser () fname tokens of
        Left err -> print err
        Right ast -> do
          putStrLn "compiler has not been implemented. see ast below"
          putStrLn . render . pprogram $ ast

-----------------end ast pretty printer ---------------------

--------------test functions ---------------


