module ViewTypeToDtd where

-- tokenizer and parser for translating the Abstract datatype to corresponding dtd file.
import Text.Parsec.Token as PT
import Text.Parsec.Char as PC
import Text.Parsec.Prim
import Text.Parsec.Combinator
import Text.Parsec.Pos

import Data.List as List (intersperse)
import Data.Char (toLower, toUpper)
import Data.Map (Map)
import qualified Data.Map as Map (unions, singleton, map)

astTypeDef = PT.LanguageDef
  {
    commentStart = "{-"
   ,commentEnd = "-}"
   ,commentLine ="--"
   ,nestedComments = False
   ,identStart = upper
   ,identLetter = alphaNum <|> char '_'
   ,opStart = PC.oneOf ":!#$%&*+./<=>?@\\^|-~"
   ,opLetter = PC.oneOf ":!#$%&*+./<=>?@\\^|-~"
   ,reservedNames = ["String", "Abstract", "Concrete", "Actions"]
   ,reservedOpNames = [""]
   ,caseSensitive = True
  }

--------------tokenizer    start--------------

tokenParser = makeTokenParser astTypeDef
-- apply lexeme to a parser to make the parser skip all the following white spaces
myLexeme = lexeme tokenParser
myWhiteSpace = whiteSpace tokenParser

-- the constructor of the token may be used in other packages,
-- so I add a prefix character 'K' which means keyword
data Token = KEQ | KOR      -- =, |
           | KTypeCon String -- type constructor, but I regard it as identifier  in order to use the default identifier function for convenience.
           | KViewType      -- keyword, ViewType
  deriving (Eq, Show)

type TokenPos = (Token, SourcePos)

symbolTokenizer :: Parsec String () TokenPos
symbolTokenizer = myLexeme (do
  pos <- getPosition
  choice [string "=" >> return (KEQ, pos)
         ,string "|" >> return (KOR, pos)]
  <?> "symbolTokenizer")

identifierTokenizer :: Parsec String () TokenPos
identifierTokenizer = myLexeme (do
  pos <- getPosition
  id <- identifier tokenParser
  return (KTypeCon id, pos)
  <?> "identifierTokenizer")

keywordTokenizer :: Parsec String () TokenPos
keywordTokenizer = myLexeme (do
  pos <- getPosition
  choice [-- string "data" >> return (KData, pos)
         string "Abstract" >> return (KViewType, pos)
         ,string "String" >> return (KTypeCon "String", pos)]
  <?> "keywordTokenizer")

tokenizer :: Parsec String () [TokenPos]
tokenizer = myWhiteSpace >> many (foldr1 ((<|>) . try) [keywordTokenizer,identifierTokenizer,symbolTokenizer])


--------------tokenizer    end--------------

--------------parser      start-------------
type DP = Parsec [TokenPos] ()

isToken :: Token -> DP Token
isToken tok = token show snd (\t -> if fst t == tok then Just tok else Nothing)


-- extract the string in the constructor
getTypeCon :: DP String
getTypeCon = token show snd
  (\t -> case fst t of
          KTypeCon str -> Just str
          _            -> Nothing)

data Dtd = Dtd Doctype [Block] deriving (Eq, Show) -- no attribute, no fun.
data Doctype = Doctype String deriving (Eq, Show)
data Block = Block Leading [Element] deriving (Eq, Show)    -- see below
data Element = Element TagName [SubTag] deriving (Eq, Show) -- tagName with a list of children names
type TagName = String
type SubTag  = String
type Leading = String


buildAST :: DP Dtd
buildAST = do
  doctype <- parseDoctype
  blocks <- many parseBlock
  return $ Dtd doctype blocks
  <?> "buildAST"

parseDoctype :: DP Doctype
parseDoctype = do
  -- the document type is the same as the type of the root element.
  -- use lookAhead to prevent consume it. leave it consumed by other parsers
  isToken KViewType
  doctype <-  lookAhead getTypeCon
  return $ Doctype doctype
  <?> "parseDoctype"

parseBlock :: DP Block
parseBlock = do
  -- isToken KData
  leading <- parseLeading
  elements <- many parseElement
  return $ Block leading elements
  <?> "parseBlock"

parseLeading :: DP Leading
parseLeading = do
  leading <- getTypeCon
  lookAhead (isToken KEQ)    -- just a check, make sure this is a leading element
  return $ leading
  <?> "parseLeading"

parseElement :: DP Element
parseElement = do
  -- the first type constructor will be the tag name.
  -- following type constructor will be the child nodes of this node
  (try $ isToken KOR) <|> isToken KEQ
  tagName <- getTypeCon
  subtags <- many parseSubtag
  return $ Element tagName subtags
  <?> "parseElement"

parseSubtag :: DP SubTag
parseSubtag = try( do
  subtag <- getTypeCon
  notFollowedBy (isToken KEQ)
  return subtag
  <?> "parseSubtag")

-------------- parser       end  --------------




--------------Translator   start --------------

toDtdString :: Dtd -> String
toDtdString (Dtd (Doctype doctype) blocks) = wrapDoc (map toLower doctype) (wrapBrackets . docAddPCDATA . concat . (map genBlock) $ blocks)

genBlock :: Block -> String
genBlock block@(Block leading elements)= genLeading block ++ (concat (map genElement elements)) ++ "\n"

genElement :: Element -> String
genElement (Element ename subtags) =
  "<!ELEMENT " ++ (map toLower ename) ++ genSubTags subtags ++ ">\n"

genLeading :: Block -> String
genLeading (Block leading elements) =
  let tagName = map toLower leading
      subtags = map (\tag -> case tag of Element tname _ -> (map toLower tname)) elements
  in  "<!ELEMENT " ++ tagName ++ (collectSubTags subtags) ++ ">\n"

-- convert ["ABC","DEF",...] to ["ABC|DEF| ..."]
collectSubTags :: [SubTag] -> String
collectSubTags = wrapParen . concat . intersperse "|"

-- convert ["ABC","DEF",...] to ["ABC, DEF, ..."]
genSubTags :: [SubTag] -> String
genSubTags tag
  | null tag  = " EMPTY"
  | otherwise = wrapParen . concat . intersperse ", " . map (\x -> if map toUpper x == "STRING" then "biyaccpcdata" else map toLower x) $ tag

docAddPCDATA :: String -> String
docAddPCDATA = (++ "<!ELEMENT biyaccpcdata (#PCDATA)>\n")

-- wrap elements in "(...)"
wrapParen :: String -> String
wrapParen str = " (" ++ str ++ ")"

-- wrap element in <!DOCTYPE ... >
wrapDoc :: String -> String -> String
wrapDoc doc body = "<!DOCTYPE " ++ doc ++ body ++ ">"

-- wrap element in [], just for the "<!DOCTYPE xxx [!ELEMENT... ]>
-- newline is used to make it look nice.
wrapBrackets :: String -> String
wrapBrackets str = "[\n\n" ++ str ++ "\n]"

-------------end     translator-------------

-------------generate type environment------------------

type AbsEnv = Map String (String, [String])
-- map ("ADD"("Arith", ["Arith","Arith"]))
genViewTypeEnv :: Dtd -> AbsEnv
genViewTypeEnv (Dtd (Doctype _) blocks) = Map.unions (map auxBlock blocks)
  where
    auxBlock :: Block -> Map String (String, [String])
    auxBlock (Block blocktype elements) = Map.unions (map (auxElement blocktype) elements)
      where
        auxElement :: String -> Element -> Map String (String, [String])
        auxElement blocktype (Element name subtypes) = Map.singleton name (blocktype,subtypes)

genViewPats :: Map String (String, [String]) -> Map String [String]
genViewPats = Map.map (\(t,pat) -> pat)


getDocType :: Dtd -> String
getDocType (Dtd (Doctype doctype) _) = doctype

------------end generate type environment----------------







-- main program. invoke tokenizer, parser, and compiler to translate view data types in dsl to a dtd file
writeDtd :: FilePath -> IO ()
writeDtd fname = do
  stream  <- readFile fname
  case runParser tokenizer () fname stream of
    Left err     -> error $ show err
    Right tokens ->
      case runParser buildAST () fname tokens of
        Left errr -> error $ show errr
        Right ast -> do
          writeFile fname (toDtdString ast)
          putStrLn "abstract dtd has been written to \"abstract.dtd\""

writeDtdFile :: String -> FilePath -> IO ()
writeDtdFile dtd fname = do
  writeFile fname dtd
  putStrLn "abstract dtd has been written to \"abstract.dtd\""

--
-- used by the main module. some redundant work...
tokenToDtd tokens fname =
  case runParser buildAST () fname tokens of
    Left errr -> error $ show errr
    Right ast -> ast


----------test functions
testTokenizer fname = do
  stream <- readFile fname
  case runParser tokenizer () fname stream of
    Left err -> print err
    Right token -> print token

testTokenizer1 fname = do
  stream <- readFile fname
  case runParser tokenizer () fname stream of
    Left err -> print err
    -- Right token -> print $ foldr ((:) . fst) [] token
    Right token -> print $ (map fst) token

testParser fname = do
  stream <- readFile fname
  case runParser tokenizer () fname stream of
    Left err     -> error $ show err
    Right tokens -> print (runParser buildAST () fname tokens)

testCompiler fname = do
  stream <- readFile fname
  case runParser tokenizer () fname stream of
    Left err     -> error $ show err
    Right tokens -> print (fmap toDtdString $ runParser buildAST () fname tokens)


testViewTypeEnv fname = do
  stream <- readFile fname
  case (runParser tokenizer () fname stream) of
    Left err -> print err
    Right tokens -> do
      -- print (tokens)
      -- print (map fst tokens)
      case runParser buildAST () fname tokens of
        Left err -> print err
        Right ast -> do
          print (genViewTypeEnv ast)
          print (genViewPats (genViewTypeEnv ast))
