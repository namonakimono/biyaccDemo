module Main where

import ProgramParser      as PParser
import ProgramTokenizer   as PTknz
import ViewTypeToDtd      as VT2Dtd
import SourceTypeToDtd    as ST2Dtd
import ProgramTrans       as PTrans
import Text.Parsec
import Control.Monad
import Text.PrettyPrint   as PPrint

import Control.Monad.State as State

import System.IO
import System.Environment
---------------translate view type to dtd file-----------------------

genViewDtd = VT2Dtd.writeDtd

---------------end translate view type to dtd file-------------------

---------------translate source type to dtd file---------------------

genSourceDtd = ST2Dtd.writeDtd

---------------end translate source type to dtd file-----------------

---------------translate byacc program to BiFlux program-------------

genProgramAst = PParser.genProgramAST

---------------end translate byacc program to BiFlux program---------

-- glue the three tokenizers together into one. then feed the parsers with the correspinding tokens, respectively.
-- then do feed them into the compiler to generate dtds and biflux programs (not implementd yet)
main = do
  args <- getArgs
  -- arg!!0 = input biyacc file, arg!!1 = output biflux upd file.
  let inFile =
        case length args of
          2 -> args !! 0
          1 -> args !! 0
          -- 0 -> "./test_expr/expr.by"
          _ -> error $ "incorrect parameters.\n" ++
                        "usage: biyacc input [output].\n" ++ "default output is \"u.upd\""
  let outFile =
        case length args of
          2 -> args !! 1
          _ -> "u.upd"
  let path  = getPath outFile
  stream <- readFile inFile
  let tokenizer = liftM3 (,,) VT2Dtd.tokenizer ST2Dtd.tokenizer PTknz.tokenizer
  case runParser tokenizer () inFile stream of
    Left err -> print err
    Right tokens ->
      case tokens of
        (vdtokens, sdtokens, prgtokens) -> do
          -- sdtdPats contains terminating symbols: Expr '+' Term
          -- sdtd does not contain terminationg symbols: Expr Term
          let vdtd = VT2Dtd.tokenToDtd vdtokens inFile
              sdtd = ST2Dtd.tokenToDtd sdtokens inFile
              sdtdPats = ST2Dtd.tokenToDtdPats sdtokens inFile
              vdoctype = VT2Dtd.getDocType vdtd
              sdoctype = ST2Dtd.getDocType sdtd
          ST2Dtd.writeDtdFile (ST2Dtd.toDtdString sdtd) (path ++ "concrete.dtd")
          -- VT2Dtd.writeDtdFile (VT2Dtd.toDtdString vdtd) (path++"abstract.dtd")
          VT2Dtd.writeDtdFile (VT2Dtd.toDtdString vdtd) (path ++ "abstract.dtd")
          let ast = PParser.tokenToAst prgtokens inFile
          let absEnv = VT2Dtd.genViewTypeEnv vdtd
          let conEnv = ST2Dtd.genSourceTypeEnv sdtdPats
          -- print $ map fst (throwMulNewLine prgtokens)

          let upd = PTrans.biFluX2Doc ast absEnv conEnv (vdoctype, sdoctype)
          writeFile outFile (render upd)
          putStrLn ("generated biflux upd file is: " ++ outFile)


-- get path, split at "/" (slash)
getPath :: String -> String
getPath s' =
  let s = reverse s'
  in  getpath' s s
  where
    getpath' :: String -> String -> String
    -- the first pattern means there is no path, only file name.
    getpath' [] whole = []
    getpath' s@(x:xs) whole =
      case x of
        '/' -> reverse s
        _   -> getpath' xs whole

