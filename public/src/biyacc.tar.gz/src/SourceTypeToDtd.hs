module SourceTypeToDtd where

-- tokenizer and parser for translating the Concrete datatype to corresponding dtd file.
import Text.Parsec.Token as PT
import Text.Parsec.Char as PC
import Text.Parsec.Prim
import Text.Parsec.Combinator
import Text.Parsec.Pos

import Data.List (intersperse, null)
import Data.Char (toLower, toUpper)
import Data.Map (Map)

import Control.Monad (liftM)
import qualified Data.Map as Map (singleton, unions, map)
import qualified Control.Monad.State as State -- (State, state, put, get)

astTypeDef = PT.LanguageDef
  {
    commentStart = "{-"
   ,commentEnd = "-}"
   ,commentLine ="--"
   ,nestedComments = False
   ,identStart = upper
   ,identLetter = alphaNum <|> char '_'
   ,opStart = PC.oneOf ":!#$%&*+./<=>?@\\^|-~"
   ,opLetter = PC.oneOf ":!#$%&*+./<=>?@\\^|-~"
   ,reservedNames = ["String", "Abstract", "Concrete", "Actions"]
   ,reservedOpNames = [""]
   ,caseSensitive = True
  }

----------------------start        tokenizer ----------------------
tokenParser = makeTokenParser astTypeDef
-- apply lexeme to a parser to make the parser skip all the following white spaces
myLexeme        = lexeme tokenParser
myWhiteSpace    = whiteSpace tokenParser
myStringLiteral = stringLiteral tokenParser
-- myCharLiteral   = charLiteral tokenParser

-- myCharLiteral :: TokenPos
myCharLiteral = myLexeme (do
           try(char '\'')
           str <- (manyTill (noneOf "\'") (string "\'"))
           return str
           <?> "myCharLiteral"
          )


-- the constructor of the token may be used in other packages,
-- so I add a prefix character 'C' which means keyword
data Token = CEQ | COR      -- =, |
           | CTypeCon String -- type constructor, but I regard it as "identifier", in order to use the default "identifier tokenizer" function for convinience.
           | CRArrow           --  "->"
           | CSourceType       -- keyword, SourceType
           | CData             -- keyword, "data"
           | CStrLtr String    -- string.
  deriving (Eq, Show)

type TokenPos = (Token, SourcePos)
type TokenType = Parsec String () TokenPos

--string literal
--will change char literal to string literal
strLtrTokenizer :: TokenType
strLtrTokenizer = myLexeme (do
  pos <- getPosition
  choice [myStringLiteral >>= \str -> return (CStrLtr str, pos)
         ,myCharLiteral >>= \chr   -> return (CStrLtr chr, pos)]
  <?> "strLtrTokenizer")

symbolTokenizer :: TokenType
symbolTokenizer = myLexeme (do
  pos <- getPosition
  choice [string "->" >> return (CRArrow, pos)
         ,string "|"  >> return (COR, pos)]
  <?> "symbolTokenizer")

identifierTokenizer :: TokenType
identifierTokenizer = myLexeme (do
  pos <- getPosition
  id <- identifier tokenParser
  return (CTypeCon id, pos)
  <?> "identifierTokenizer")

keywordTokenizer :: TokenType
keywordTokenizer = myLexeme (do
  pos <- getPosition
  choice $ map try
    [string "data"       >> return (CData, pos)
    ,string "Concrete" >> return (CSourceType, pos)
    ,string "String"     >> return (CTypeCon "String", pos)] -- represent dtd "#PCDATA"
  <?> "keywordTokenizer")

tokenizer :: Parsec String () [TokenPos]
tokenizer = myWhiteSpace >> many (foldr1 ((<|>) . try) [keywordTokenizer,identifierTokenizer,symbolTokenizer,strLtrTokenizer])


--------------tokenizer     end---------------

--------------Parser      Start---------------

type DP = Parsec [TokenPos] ()
-- type DP = Parsec [TokenPosrmCStrLtr] State.State

data Dtd = Dtd Doctype [Block] deriving (Eq, Show) -- no attribute, no fun.
data Doctype = Doctype String deriving (Eq, Show)
data Block = Block Leading [Element] deriving (Eq, Show)    -- see below
data Element = Element TagName [SubTag] deriving (Eq, Show) -- tagName with a list of children names
type TagName = String
type SubTag  = String
type Leading = String


isToken :: Token -> DP Token
isToken tok = token show snd (\t -> if fst t == tok then Just tok else Nothing)

-- extract the string in the constructor
getTypeCon :: DP String
getTypeCon = token show snd
  (\t -> case fst t of
          CTypeCon str -> Just str
          _            -> Nothing)

-- remove CStrLtr (which will not be used in the concrete dtd) from the [TokenPos]
rmCStrLtr:: [TokenPos] -> [TokenPos]
rmCStrLtr = filter (\e -> case fst e of
                          CStrLtr _ -> False
                          _         -> True)

buildAST :: DP Dtd
buildAST = do
  doctype <- parseDoctype
  blocks <- many parseBlock
  return $ Dtd doctype blocks

parseDoctype :: DP Doctype
parseDoctype = do
  -- the document type is the same as the type of the root element.
  -- use lookAhead to prevent consume it. leave it consumed by other parsers
  isToken CSourceType
  doctype <- lookAhead getTypeCon
  return $ Doctype (map toLower doctype)
  <?> "parseDoctype"

parseBlock :: DP Block
parseBlock = do
  leading <- parseLeading
  elements <- many parseElement
  return $ Block leading elements
  <?> "parseBlock"

parseLeading :: DP Leading
parseLeading = do
  leading <- getTypeCon
  lookAhead (isToken CRArrow)    -- just a check, make sure this is a leading element
  return $ map toLower leading
  <?> "parseLeading"

parseElement :: DP Element
parseElement = do
  (isToken CRArrow) <|> (isToken COR)
  let tagName = "create it later"
  subtags <- many parseSubtag
  return $ Element (map toLower tagName) (map (map toLower) subtags)
  <?> "parseElement"

parseSubtag :: DP SubTag
parseSubtag = try( do
  subtag <- getTypeCon
  notFollowedBy (isToken CRArrow)
  return subtag
  <?> "parseSubtag")

--------------end      Parser---------------


--------------translator      start-------------
type GenName a = State.State [String] a

-- genarate name for the constructors in the Dtd.
-- each element is in the form (Element "create it later" ["expr","term"])
-- here, change the name "create it later" to the "a1","a2",... in order
genName :: Dtd -> State.State [String] Dtd
genName (Dtd doctype blocks) =
  let newBlocks = mapM filter2 blocks
  in  (liftM (Dtd doctype) newBlocks)
  where
    filter2 :: Block -> State.State [String] Block
    filter2 (Block leading elements) =
      liftM (Block leading)
      (mapM (\(Element name subtags) -> liftM (flip Element subtags) getFreshName) elements)

-- extract a fresh name from the sequence genSerial
getFreshName :: State.State [String] String
getFreshName = pop
  where pop :: State.State [String] String
        pop =  State.state $ \(x:xs) -> (x,xs)

lookFreshName :: State.State [String] String
lookFreshName = State.state $ \(x:xs) -> (x, x:xs)

genSerial :: String -> [String]
genSerial str = zipWith (\x y -> x ++ y) (repeat str) ( map show [0,1..] )

-- write dtd file to disk
writeDtd fname = do
  stream <- readFile fname
  case (runParser tokenizer () fname stream) of
    Left err -> print err
    Right tokens -> do
      case runParser buildAST () fname (rmCStrLtr tokens) of
        Left err -> print err
        Right ast -> do
          -- putStrLn "concrete type tokens"
          -- print (map fst tokens)
          let dtd = toDtdString ast
          writeFile "concrete.dtd" dtd
          putStrLn "concrete dtd has been written to concrete.dtd"

-- used by the main module. some redundant work...
tokenToDtdPats tokens fname =
  case runParser buildAST' () fname tokens of
    Left err -> error $ show err
    Right ast -> ast

tokenToDtd tokens fname =
  case runParser buildAST () fname (rmCStrLtr tokens) of
    Left err -> error $ show err
    Right ast -> ast


writeDtdFile :: String -> FilePath -> IO ()
writeDtdFile dtd fname = do
  writeFile fname dtd
  putStrLn "concrete dtd has been written to concrete.dtd"

toDtdString :: Dtd -> String
toDtdString olddtd =
  let dtd = State.evalState (genName olddtd) (genSerial "a")
      (Dtd (Doctype doctype) blocks) = dtd
  in  wrapDoc doctype (wrapBrackets . docAddNull . docAddPCDATA. concat . (map genBlock) $ blocks)

genBlock :: Block -> String
genBlock block@(Block leading elements)= genLeading block ++ (concat (map genElement elements)) ++ "\n"

genElement :: Element -> String
genElement (Element ename subtags) =
  "<!ELEMENT " ++ ename ++ genSubTags subtags ++ ">\n"

--add null to the leading element
leadingAddNull :: [SubTag] -> [String]
leadingAddNull = (++ ["null"])

-- add null to the whole document
docAddNull :: String -> String
docAddNull = (++ "<!ELEMENT null EMPTY>\n")

docAddPCDATA :: String -> String
docAddPCDATA = (++ "<!ELEMENT biyaccpcdata (#PCDATA)>\n")

-- Element "create it later"["expr","term"]
-- subtags ["create it later", "create it later", ...]
genLeading :: Block -> String
genLeading (Block leading elements) =
  let tagName = leading
      subtags = map (\tag -> case tag of Element tname _ -> tname) elements
  in  "<!ELEMENT " ++ tagName ++ (collectSubTags . leadingAddNull $ subtags) ++ ">\n"

-- convert ["ABC","DEF",...] to ["ABC|DEF| ..."]
collectSubTags :: [SubTag] -> String
collectSubTags = wrapParen . concat . intersperse "|"

-- convert ["ABC","DEF",...] to ["ABC, DEF, ..."]
genSubTags :: [SubTag] -> String
genSubTags tag
  | null tag  = " EMPTY"
  | otherwise = wrapParen . concat . intersperse ", " . map (\x -> if map toUpper x == "STRING" then "biyaccpcdata" else map toLower x) $ tag

-- wrap elements in "(...)"
wrapParen :: String -> String
wrapParen str = " (" ++ str ++ ")"

-- wrap element in <!DOCTYPE ... >
wrapDoc :: String -> String -> String
wrapDoc doc body = "<!DOCTYPE " ++ doc ++ body ++ ">"

-- wrap element in [], just for the "<!DOCTYPE xxx [!ELEMENT... ]>
-- newline is used to make it look nice.
wrapBrackets :: String -> String
wrapBrackets str = "[\n\n" ++ str ++ "\n]"
-------------translator      end----------------

-------------generate source patterns-----------
--source patterns are stuff such as: Expr '+' Term
--to be compared with(pattern match) "(lhs => Expr) '+' (rhs => Term)"

-- remove CStrLtr (which will not be used in the concrete dtd) from the [TokenPos]
getCStrLtr:: DP String
getCStrLtr = token show snd
  (\t -> case fst t of
          CStrLtr str -> Just str
          _            -> Nothing)

buildAST' :: DP Dtd
buildAST' = do
  doctype <- parseDoctype'
  blocks <- many parseBlock'
  return $ Dtd doctype blocks

parseDoctype' :: DP Doctype
parseDoctype' = do
  -- the document type is the same as the type of the root element.
  -- use lookAhead to prevent consume it. leave it consumed by other parsers
  isToken CSourceType
  doctype <- lookAhead getTypeCon
  return $ Doctype doctype
  <?> "parseDoctype'"

parseBlock' :: DP Block
parseBlock' = do
  leading <- parseLeading'
  elements <- many parseElement'
  return $ Block leading elements
  <?> "parseBlock"

parseLeading' :: DP Leading
parseLeading' = do
  leading <- getTypeCon
  lookAhead (isToken CRArrow)    -- just a check, make sure this is a leading element
  return $ leading
  <?> "parseLeading"

parseElement' :: DP Element
parseElement' = do
  (isToken CRArrow) <|> (isToken COR)
  let tagName = "create it later"
  subtags <- many parseSubtag'
  return $ Element tagName subtags
  <?> "parseElement"

parseSubtag' :: DP SubTag
parseSubtag' =
  try (do
        subtag <- getTypeCon
        notFollowedBy (isToken CRArrow)
        return subtag) <|>
  try (do
        subtag <- getCStrLtr
        notFollowedBy (isToken CRArrow)
        return subtag)
  <?> "parseSubtag"

-- map ("a1"("Expr, ["Expr", "+", "Term"]))
-- type ConEnv = Map String (String, [String])
-- map Pattern (constructor, type) . e.g. Map ["Expr", "+", "Term"] ("a0","Expr")
type ConEnv = Map [String] String
type ConPats = Map String [String]

genSourceTypeEnv :: Dtd -> ConEnv
genSourceTypeEnv olddtd =
  let Dtd (Doctype _) blocks = State.evalState (genName olddtd) (genSerial "a")
  in  Map.unions (map auxBlock blocks)
  where
    auxBlock :: Block -> ConEnv
    auxBlock (Block blocktype elements) = Map.unions (map (auxElement blocktype) elements)
      where
        auxElement :: String -> Element -> ConEnv
        auxElement blocktype (Element name subtypes) = Map.singleton (blocktype:subtypes) (name)

-- genSourcePats :: Map String (String, [String]) -> Map String [String]
-- genSourcePats = Map.map (\(t,pat) -> pat)

getDocType :: Dtd -> String
getDocType (Dtd (Doctype doctype) _) = doctype

-------------end generate source patterns-------




--------------test         functions---------
t1 fname = do
  stream <- readFile fname
  case (runParser tokenizer () fname stream) of
    Left err -> print err
    Right tokens -> print $ foldr ((:) . fst) [] tokens

t2 fname = do
  stream <- readFile fname
  case (runParser tokenizer () fname stream) of
    Left err -> print err
    Right tokens -> print tokens

t3 fname = do
  stream <- readFile fname
  case (runParser tokenizer () fname stream) of
    Left err -> print err
    Right tokens -> do
      let ttokens = rmCStrLtr tokens
      print (ttokens)
      print (map fst ttokens)
      case runParser buildAST () fname ttokens of
        Left err -> print err
        Right ast -> print ast

t3' fname = do
  stream <- readFile fname
  case (runParser tokenizer () fname stream) of
    Left err -> print err
    Right tokens -> do
      -- print (tokens)
      -- print (map fst tokens)
      case runParser buildAST' () fname tokens of
        Left err -> print err
        Right ast -> do
          print (genSourceTypeEnv ast)
          -- print (genSourcePats (genSourceTypeEnv ast))


