{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE FlexibleInstances #-}

module ProgramTrans where

import ProgramParser
import SourceTypeToDtd
import ViewTypeToDtd

import Data.List (dropWhile, filter, length)
import Data.Char (toLower)
import qualified Data.Map as Map
import Data.Map (Map, fromList)

import Control.Monad
import Control.Monad.State (State)
import qualified Control.Monad.State as State

import Text.PrettyPrint as PP
import Debug.Trace


type TypedViewEnv = Map String TypedViewPattern
type VSDocTypes = (String, String)
type NameSerial = String
type SourceType = String
type ViewType = String


type FunNameEnv = Map String String
type VSTypeEnv = Map String (String, String) -- view source type env.

data TypedViewPattern = TVVar String String  -- name, type
                      | TVCon String [TypedViewPattern] String -- name, sub-patterns, type
                      | TVLit String
                      deriving (Show,Eq)


data TypedSourcePattern = TSVar (Maybe TypedViewPattern) String String
                            -- optional view pattern for updating, name, and type
                        | TSCon String String [TypedSourcePattern] -- TSCon type constructor(name) subpatterns
                        | TSLit (Maybe TypedViewPattern) String String
                        deriving (Show,Eq)

disjointKeys :: Ord k => Map k a -> Map k b -> Bool
disjointKeys m0 m1 = Map.null (Map.intersection m0 m1)

viewPatternType :: TypedViewPattern -> String
viewPatternType (TVVar _ t  ) = t
viewPatternType (TVCon _ _ t) = t
viewPatternType (TVLit _    ) = "String"


toTypedSourcePatterns :: [RHSUpdate] -> String -> AbsEnv -> ConEnv -> TypedViewEnv -> TypedSourcePattern
toTypedSourcePatterns rhss scon absEnv conEnv typedVEnv =
  let rhspat = getEigen rhss scon
      rhsCnstrct = getRhsCnstrct rhspat conEnv
      typedSubPats = map (toTypedSourcePattern absEnv conEnv typedVEnv) (delRHSLit rhss)
  in TSCon scon rhsCnstrct typedSubPats

toTypedSourcePattern :: AbsEnv -> ConEnv -> TypedViewEnv -> RHSUpdate -> TypedSourcePattern
toTypedSourcePattern absEnv conEnv typedVEnv (RHSLiteral str) =
  error "RHSLiteral should have be eliminated in the prefixify procedure"
toTypedSourcePattern absEnv conEnv typedVEnv (Update vvar (SourceCon scon)) =
  case Map.lookup vvar typedVEnv of
    -- nothing does not mean error. maybe vvar is a const string literal which appeared just in the RHS.
    -- and we want to use this string literal to update source
    -- problematic. of course.
    Nothing -> TSLit (Just (TVLit vvar)) scon scon
    Just (TVVar vvarname vvartype) -> TSVar (Just (TVVar vvar vvartype)) scon scon
    Just (TVCon _ _ vcontype) -> TSVar (Just (TVVar vvar vcontype)) scon scon
toTypedSourcePattern absEnv conEnv typedVEnv (NonUpdate (SourceCon scon)) =
  TSVar Nothing scon scon
toTypedSourcePattern absEnv conEnv typedVEnv (DeepPat name subpats) =
  toTypedSourcePatterns subpats name absEnv conEnv typedVEnv



-- e.g. getRhsCons "Expr -> Expr '+' Term" returns "a0", which is a constructor for " Expr '+' Term"
-- in the dtd and haskell datetype
getRhsCnstrct :: [String] -> ConEnv -> String
getRhsCnstrct rhsEigen conEnv =
  case Map.lookup rhsEigen conEnv of
    Nothing -> error $ "\nproduction rule not found: " ++ show rhsEigen
    Just rhsCnstrct -> rhsCnstrct
      -- rhsCnstrct = Map.foldrWithKey (\k x ks -> if k == rhsEigen then k:ks else ks) [] conEnv
      -- rhsType    = Map.foldrWithKey (\k x ks -> if k == rhsEigen then

getEigen :: [RHSUpdate] -> String -> [String]
getEigen rhss scon = scon : map getEigen' rhss
  where
    getEigen' :: RHSUpdate -> String
    getEigen' (Update vvar (SourceCon scon)) = scon
    getEigen' (NonUpdate (SourceCon scon)) = scon
    getEigen' (RHSLiteral str) = str
    getEigen' (DeepPat name _ ) = name

-- generate typed view pattern and typed view environment for the selected rules
toTypedViewPattern :: LHSPattern -> String -> AbsEnv -> GenName (TypedViewPattern, Map String TypedViewPattern)
toTypedViewPattern (NormalP (ViewCon name) pats) expectedType absEnv =
  case Map.lookup name absEnv of
    Nothing -> error $ "unknown constructor " ++ name
    Just (resType, argTypes) ->
      if resType /= expectedType
      then error $ "constructor " ++ name ++ " does not construct a value of type " ++ expectedType
      else if length argTypes /= length pats
           then error $ "incorrect number of arguments for constructor " ++ name
           else do
             tms <- zipWithM (\pat argType -> toTypedViewPattern pat argType absEnv) pats argTypes
             let pat = TVCon name (map fst tms) resType
             let env = foldr (\m m' -> if disjointKeys m m'
                                       then m `Map.union` m'
                                       else error $ "repeated variables in " ++ show m ++ " and " ++ show m')
                             Map.empty
                             (map snd tms)
             return (pat, env)
toTypedViewPattern (ASPattern name pat) expectedType absEnv =
  liftM (\(pat', env) -> if name `Map.notMember` env
                            then (pat', Map.insert name pat' env)
                            else error $ "repeated variables " ++ name ++ " and " ++ show env)
        (toTypedViewPattern pat expectedType absEnv)
toTypedViewPattern (ViewVar name) expectedType absEnv =
  let pat = TVVar name expectedType in return (pat, Map.singleton name pat)
toTypedViewPattern (AStrLtr str) expectedType absEnv = return (TVLit str, Map.empty)
-- assign a fresh name to scope
toTypedViewPattern Scope expectedType absEnv = liftM (\name -> let pat = TVVar name expectedType
                                                               in  (pat, Map.singleton name pat))
                                                     getFreshName


-- generate typedViewEnv for the matched rules
toTypedViewEnv' :: TypedViewPattern -> TypedViewPattern -> TypedViewEnv
toTypedViewEnv' uniquePat coveredPat =
  case uniquePat of
    uniTVCon@(TVCon uniTVConName uniSubpats uniTVConType) ->
      case coveredPat of
        TVCon covTVConName covSubpats covTVConType ->
          if uniTVConName == covTVConName && uniTVConType == covTVConType
             && length uniSubpats == length covSubpats
             then Map.unions $ zipWith (\unisub covsub -> toTypedViewEnv' unisub covsub) uniSubpats covSubpats
             else error $ "types or names or length of subpattrens mismatch between unique pattern and covered pattern"
        TVVar covTVVarName covTVVarType -> Map.singleton covTVVarName uniTVCon
        TVLit covstr -> error $ "TVLit " ++ covstr ++ "cannot cover unique pattern:" ++ show uniquePat
    TVVar uniTVVarName uniTVVarType ->
      case coveredPat of
        covTVVar@(TVVar covTVVarName covTVVarType) ->
          -- in fact. nothing to do XD
          if uniTVVarType == covTVVarType
             then Map.singleton covTVVarName covTVVar
             else error $ "unique TVVarType and covered TVVarType mismatch"
        TVCon covTVConName covSubpats covTVConType ->
          error $ "TVCon: " ++ covTVConName ++ " does not cover TVVar: " ++ uniTVVarName
        TVLit covstr -> error $ "TVLit: " ++ covstr ++ " does not cover TVVar: " ++ uniTVVarName
    TVLit unistr ->
      -- equal or error XD
      case coveredPat of
        covTVVar@(TVVar covTVVarName covTVVarType) ->
          error $ "TVVar: " ++ covTVVarName ++ " does not cover TVLit: " ++ unistr
        TVCon covTVConName covSubpats covTVConType ->
          error $ "TVCon: " ++ covTVConName ++ " does not cover TVLit: " ++ unistr
        TVLit covstr ->
          if unistr == covstr
            then Map.empty
            else error $ "TVLit: " ++ covstr ++ " does not cover TVLit: " ++ unistr

-- generate


-- generate function name. Arith +> Expr will generate name syncExprArith with key "Expr"
genFunNameEnv :: Program -> Map String String
genFunNameEnv (Program pieces) = Map.unions (map genFunNameEnv' pieces)
  where genFunNameEnv' :: Piece -> Map String String
        genFunNameEnv' (Piece (TypeDecl (ViewCon vcon) (SourceCon scon)) _ ) =
          Map.singleton scon $ "sync" ++ scon ++ vcon

-- Arith +> Expr will generate Expr |--> (Expr,Arith)
genVSTypeEnv :: Program -> Map String (String, String)
genVSTypeEnv (Program pieces) = Map.unions (map genVSTypeEnv' pieces)
  where genVSTypeEnv' :: Piece -> Map String (String, String)
        genVSTypeEnv' (Piece (TypeDecl (ViewCon vcon) (SourceCon scon)) _ ) =
          Map.singleton scon $ (vcon, scon)



biFluX2Doc :: Program -> AbsEnv -> ConEnv -> VSDocTypes -> Doc
biFluX2Doc program absEnv conEnv (vdoctype, sdoctype) =
  let funNameEnv = genFunNameEnv program
      vsTypeEnv = genVSTypeEnv program
      (Program pieces) = program
      headDoc = mkHeads (vdoctype, sdoctype)
      startDoc = mkStart program funNameEnv
      temp = map ((flip State.evalState (genSerial "")) . piece2Doc absEnv conEnv funNameEnv vsTypeEnv) pieces --[Doc]
      pieceDocs = vsep . punctuate "\n" $ temp
  in  (headDoc $+$ "\n" <> startDoc <> "\n" $+$ pieceDocs)

mkHeads :: VSDocTypes -> Doc
mkHeads (vdoctype, sdoctype) =
  let impts = "IMPORT" <+> doubleQuotes "concrete.dtd" <+> "AS" <+> "s"
      imptv = "IMPORT" <+> doubleQuotes "abstract.dtd" <+> "AS" <+> "v"
      sv = "$source" <+> "=" <+> "doc" <> parens (doubleQuotes "concrete.xml") <+> "AS" <+> "s:" <> toLower' sdoctype
      vv = "$view"   <+> "=" <+> "doc" <> parens (doubleQuotes "abstract.xml") <+> "AS" <+> "v:" <> toLower' vdoctype
  in impts $+$ imptv $+$ sv $+$ vv

mkStart :: Program -> FunNameEnv -> Doc
mkStart (Program pieces) funNameEnv =
  let (Piece (TypeDecl (ViewCon vcon) (SourceCon scon)) _ ) = head pieces in
  case Map.lookup scon funNameEnv of
    Just funName ->
      "START" <+> equals <+> text (funName ++ "0") <>
      parens ("$source/" <> toLower' scon <> comma <+> "$view/" <> toLower' vcon)


piece2Doc :: AbsEnv -> ConEnv -> FunNameEnv -> VSTypeEnv -> Piece -> GenName Doc
piece2Doc absEnv conEnv funNameEnv vsTypeEnv piece =
  liftM2 ($+$) (piece2DocNDoc absEnv conEnv funNameEnv vsTypeEnv piece)
      (piece2DocCDoc absEnv conEnv funNameEnv vsTypeEnv piece)

piece2DocNDoc :: AbsEnv -> ConEnv -> FunNameEnv -> VSTypeEnv -> Piece -> GenName Doc
piece2DocNDoc absEnv conEnv funNameEnv vsTypeEnv piece = do
  let (Piece typedecl old_rules) = piece
      rules = old_rules ++ [AdaptRule]
  liftM (foldr1 (\x y -> (x <> "\n" $+$ y)) ) (mkNRule absEnv conEnv funNameEnv vsTypeEnv typedecl rules)


piece2DocCDoc :: AbsEnv -> ConEnv -> FunNameEnv -> VSTypeEnv -> Piece -> GenName Doc
piece2DocCDoc absEnv conEnv funNameEnv vsTypeEnv piece = do
  freshSerial <- getFreshName
  let (Piece typedecl old_rules) = piece
      rules =  old_rules ++ [AdaptRule]
  procOutlineDoc <- mkProcOutline typedecl funNameEnv freshSerial
  let cRuleDoc = map (mkCRule absEnv conEnv funNameEnv vsTypeEnv typedecl rules) $ rules
      formatedRulesDoc = case length cRuleDoc of
                          0 -> error "error in piece2DocCDoc, the rules you write is empty"
                          1 -> head cRuleDoc
                          _ -> head cRuleDoc $+$ nestn2 (foldr1 (($+$) . (<+>) "|" ) (tail cRuleDoc))
  -- traceM $! ("\nprocOutlineDoc:\n" ++ show procOutlineDoc)
  return (procOutlineDoc $+$ nest2 (lbrace <+> formatedRulesDoc <+> rbrace) $+$ "\n" )

mkProcOutline :: TypeDecl -> FunNameEnv -> String -> GenName Doc
mkProcOutline (TypeDecl (ViewCon vcon) (SourceCon scon)) funNameEnv freshserial_ =
  case Map.lookup scon funNameEnv of
    Nothing -> error "mkProcOutline"
    Just funName -> do
      let sExprPart = "SOURCE" <+> "$" <> toLower' scon <+> "AS" <+> "s:" <> toLower' scon
          vExprPart = "VIEW" <+> "$" <> toLower' vcon <+> "AS" <+> "v:" <> toLower' vcon
          casePart = "CASE" <+> "$" <> toLower' vcon <+> "OF"
      return ("PROCEDURE" <+> text (funName ++ freshserial_) <>
            parens(sExprPart <> comma <+> vExprPart) <+> "=" $+$ nest 2 casePart)


mkNRule :: AbsEnv -> ConEnv -> FunNameEnv -> VSTypeEnv -> TypeDecl -> [Rule] -> GenName [Doc]
mkNRule absEnv conEnv funNameEnv vsTypeEnv typedecl [] = return []
mkNRule absEnv conEnv funNameEnv vsTypeEnv tdecl@(TypeDecl (ViewCon vcon) (SourceCon scon)) (r:rs) =
  case r of
    AdaptRule -> return [PP.empty]
    NormalRule lhs rhs ->
      case Map.lookup scon vsTypeEnv of
        Nothing -> error $ "in mkNRule, invalid source type: " ++ scon
        Just (vtype,stype) ->
          case Map.lookup scon funNameEnv of
            Nothing -> error $ "cannot find function name regarding source type: " ++ scon
            Just funNamePre -> do
              freshserial_ <- getFreshName
              nextNameSerial <- lookFreshName
              procOutlineDoc <- mkProcOutline tdecl funNameEnv freshserial_
              let (typedVPat, typedVEnv) = State.evalState (toTypedViewPattern lhs vtype absEnv) (genSerial "biyacc")
                  typedSPat = toTypedSourcePatterns rhs scon absEnv conEnv typedVEnv
                  outDoc = mkOuts vcon typedVPat
                  innerDoc = mkInnerNRule typedVEnv typedVPat typedSPat funNameEnv nextNameSerial vsTypeEnv vcon scon r
                  nextSync = mkOutNextSync vcon scon (funNamePre ++ nextNameSerial)
                  iDoc = outDoc <+> rArrow $+$ mkOutsInners scon innerDoc $+$ nestn2 ("|" <+> nextSync)
              -- trace ("\n mkNRule,typedSPat : " ++ print typedSPat)
              liftM ((procOutlineDoc $+$ nest 2 (lbrace <+> iDoc $+$ rbrace)) : )
                    (mkNRule absEnv conEnv funNameEnv vsTypeEnv tdecl rs)

--   | $arith ->
--       syncExprArith1($expr, {$arith})
mkOutNextSync :: String -> String -> String -> Doc
mkOutNextSync vcon scon nextFunName =
  "$" <> toLower' vcon <+> "AS" <+> "v:" <> toLower' vcon <+> rArrow $+$
    nest 2 (text nextFunName <> parens("$"<> toLower' scon <> comma <+> "$" <> toLower' vcon))


mkCRule :: AbsEnv -> ConEnv -> FunNameEnv -> VSTypeEnv -> TypeDecl -> [Rule] -> Rule -> Doc
mkCRule absEnv conEnv funNameEnv vsTypeEnv (TypeDecl (ViewCon vcon) (SourceCon scon)) allRules rule =
  case rule of
    AdaptRule -> ""
    NormalRule _ _ ->
      case Map.lookup scon vsTypeEnv of
        Nothing -> error $ "source type invalide in mkCRule : " ++ scon
        Just (vtype,stype) ->
          let (self:covereds) = sCoveredRules rule allRules
              NormalRule lhs rhs = self
              (typedVPat, typedVEnv) = State.evalState (toTypedViewPattern lhs vtype absEnv) (genSerial "biyacc")
              outDoc = mkOuts vcon typedVPat
              innerDoc = mkInnerCRule absEnv conEnv funNameEnv vsTypeEnv scon self (self:covereds)
          in  outDoc <+> rArrow $+$ mkOutsInners scon innerDoc


--   { arith[add[$lhsArith AS v:arith, $rhsAriths AS v:arith]] ->
mkOuts :: String -> TypedViewPattern -> Doc
mkOuts vcon typedVPat =
  -- trace ("\nvcon: " ++ vcon ++ "\n typedVPat: " ++ show typedVPat) $
  case typedVPat of
    TVVar vname vtype ->
      case vtype of
        "String" -> "biyaccpcdata" <> brackets ("$" <> text vname <+> "AS" <+> "String")
        _ -> "$" <> text vname <+> "AS" <+> "v:" <> toLower' vcon
    TVCon tvConName subpatterns tvConType ->
      -- trace (clearr (show subpatterns)) $
      toLower' tvConType <> brackets
      (toLower' tvConName <> brackets
      (hsep . punctuate comma . map (mkOuts vcon) $ subpatterns))
    TVLit str -> "biyaccpcdata" <> (brackets . doubleQuotes . text $ str)

-- the line between outs and inner
-- CASE $expr OF
mkOutsInners :: String -> Doc -> Doc
mkOutsInners scon innerDoc =
  nest2 ("CASE" <+> "$" <> toLower' scon <+> "OF" $+$ lbrace <+> nest2 innerDoc $+$ (rbrace) )


-- generate inner doc for normal rule.
mkInnerNRule :: TypedViewEnv -> TypedViewPattern -> TypedSourcePattern
                -> FunNameEnv -> NameSerial -> VSTypeEnv -> ViewType -> SourceType -> Rule -> Doc
mkInnerNRule typedVEnv typedVPat typedSPat funNameEnv nextNameSerial vsTypeEnv vcon scon rule =
  case Map.lookup scon vsTypeEnv of
    Nothing -> error $ "invalid source type: " ++ scon
    Just (vtype,stype) ->
      case rule of
        AdaptRule -> error $ "in mkInnerNRule, rule cannot be Creation Rule"
        NormalRule lhs rhs ->
          let syncDocs = State.evalState (mkInnerSync funNameEnv typedVEnv typedSPat) (genSerial "")
              pathDocs = State.evalState (mkInnerPath scon typedSPat syncDocs) (genSerial "")
              nextSynDoc = mkInnerNRuleNext vcon scon funNameEnv nextNameSerial typedVPat
          in  pathDocs $+$ nestn2 ("|" <+> nextSynDoc)

--   { arith[add[$lhsArith AS v:arith, $rhsAriths AS v:arith]] ->
mkInnerNRuleNext :: String -> String -> FunNameEnv -> NameSerial -> TypedViewPattern -> Doc
mkInnerNRuleNext vcon scon funNameEnv nameSerial typedVPat =
  case Map.lookup scon funNameEnv of
    Nothing -> error $ "cannot find function name according to source constructor: " ++ scon
    Just funName ->
      let a = "$" <> toLower' scon <+> rArrow
          b = text (funName ++ nameSerial) <> parens("$" <> toLower' scon <> comma <+> mkpath vcon typedVPat)
      in a $+$ nest2 b
  where
    mkpath :: String -> TypedViewPattern -> Doc
    mkpath vcon typedVPat =
      case typedVPat of
        TVVar vname vtype ->
          case vtype of
            "String" -> "<biyaccpcdata>" <> braces("$" <> text vname) <> "</biyaccpcdata>"
            _ -> braces("$" <> text vname)
        TVCon tvConName subpatterns tvConType ->
          let src1 = hcat . map (mkpath vcon) $ subpatterns
              src2 = wrapSETag src1 tvConName
          in  wrapSETag src2 tvConType
        TVLit str -> "<biyaccpcdata>" <> text str <> "</biyaccpcdata>"


-- parameter "self" is used in the AdaptRule
-- and, at the first time when the function is invoked, head (rule:covereds) == self
-- generate inner doc for creation rule.
mkInnerCRule :: AbsEnv -> ConEnv -> FunNameEnv -> VSTypeEnv -> String -> Rule -> [Rule] -> Doc
mkInnerCRule absEnv conEnv funNameEnv vsTypeEnv scon self [] = PP.empty
mkInnerCRule absEnv conEnv funNameEnv vsTypeEnv scon self (rule:covereds) =
  case Map.lookup scon vsTypeEnv of
    Nothing -> error $ "source type invalid in mkInnerCRule: " ++ scon
    Just (vtype,stype) ->
      case rule of
        AdaptRule -> case self of
          NormalRule selfLhs selfRhs ->
            let (typedVPat, typedVEnv) = State.evalState (toTypedViewPattern selfLhs vtype absEnv) (genSerial "biyacc")
                typedSPat = toTypedSourcePatterns selfRhs scon absEnv conEnv typedVEnv
                pre = "$" <> toLower' scon <+> rArrow -- "$expr ->"
            -- in  trace ("\n mkInnerCRule,AdaptRule typedSPat : " ++ show typedSPat) $
            in
                pre $+$ nest2 ("ADAPT SOURCE BY" $+$ nest2 ("CREATE VALUE" <+> mkSourcePat typedSPat))
          _ -> error "error in mkInnerCRule"
        --
        NormalRule ruleLhs ruleRhs ->
          case self of
            NormalRule selfLhs selfRhs ->
              let (typedSelfVPat, typedSelfVEnv) = State.evalState (toTypedViewPattern selfLhs vtype absEnv) (genSerial "biyacc")
                  (typedRuleVPat, xxx) = State.evalState (toTypedViewPattern ruleLhs vtype absEnv) (genSerial "biyacc")
                  typedRuleVEnv = if self /= rule then (toTypedViewEnv' typedSelfVPat typedRuleVPat) else xxx
                  typedRuleSPat = toTypedSourcePatterns ruleRhs scon absEnv conEnv typedRuleVEnv
                  syncDocs = State.evalState (mkInnerSync funNameEnv typedRuleVEnv typedRuleSPat) (genSerial "")
                  pathDocs = State.evalState (mkInnerPath scon typedRuleSPat syncDocs) (genSerial "")
              -- in  trace ("\n mkInnerCRule,NormalRule pathDocs : " ++ show pathDocs) $
              in  pathDocs $+$ (nestn2 ("|" <+> mkInnerCRule absEnv conEnv funNameEnv vsTypeEnv scon self covereds))

-- make source path for the creation rules:
-- <expr><sub><expr><null/></expr><term><null/></term></sub></expr>
mkSourcePat :: TypedSourcePattern -> Doc
mkSourcePat typedSPat =
  -- trace ("\nscon: " ++ scon ++ "\ntypedSPat: " ++ show typedSPat) $
  case typedSPat of
    TSVar _ tsVarName tsVarType ->
      case tsVarType of
        "String" -> "<biyaccpcdata></biyaccpcdata>"
        _ -> wrapSETag "<null/>" tsVarName
    TSCon tsConType tsConName tsSubPaterns ->
      let src1 = hcat (map mkSourcePat tsSubPaterns)
          src2 = wrapSETag src1 tsConName
      in
          -- trace ("\nwrapSETag scon : " ++ show ( wrapSETag src2 scon)) $
          wrapSETag src2 tsConType
    TSLit (Just (TVLit str)) tsLitName tsLitType ->
      -- trace ("\n\nmksourcepat:  " ++ tsLitName) $
      wrapSETag (text $ str) tsLitName

-- make inner source path:
-- expr[add[$lhsExpr AS s:expr, $rhsTerm AS s:term]]
mkInnerPath :: String -> TypedSourcePattern -> Doc -> GenName Doc
mkInnerPath scon typedSPat innerSyncDoc = do
  -- trace ("\n scon: " ++ scon ++ "\ntypedSPat : " ++ show typedSPat) $
  docs <- mkInnerPath' typedSPat
  return (docs <+> rArrow $+$ nest 2 innerSyncDoc)
  where mkInnerPath' :: TypedSourcePattern -> GenName Doc
        mkInnerPath' typedSPat =
          case typedSPat of
            TSVar _  tsVarName tsVarType ->
              case tsVarType of
                "String" -> do
                  freshserial_ <- getFreshName
                  return ( "biyaccpcdata" <> brackets ("$" <> toLower' (tsVarName ++ freshserial_) <+> "AS" <+> "String"))
                _        -> return ("$" <> toLower' tsVarName <+> "AS" <+> "s:" <> toLower' tsVarType)
            TSCon tsConType tsConName tsSubPaterns -> do
              subDocs <- liftM (hsep . punctuate comma) (mapM mkInnerPath' tsSubPaterns)
              return (toLower' tsConType <> brackets (toLower' tsConName <> brackets subDocs))
            -- TSLit _ _ _-> error "I do not know hot to deal with TSLit in function call mkInnerPath"
            TSLit _ _ _-> liftM ("$string" <> ) (liftM text getFreshName)


-- make doc of the sync function call in the CASE match: syncExpr($expr, <arith><add>{$lhsArith}</add></arith>)
mkInnerSync :: FunNameEnv -> TypedViewEnv -> TypedSourcePattern -> GenName Doc
mkInnerSync funNameEnv typedVEnv typedSPat  =
  -- trace ("\nTypedSPat: " ++ show typedSPat ++ "\ntypedVEnv: " ++ show typedVEnv) $
  case typedSPat of
    TSVar maybeTypedVPat svarname svartype ->
      case maybeTypedVPat of
        -- Nothing -> error "non replace. will be implemented later"
        Nothing -> return "{}"
        Just (TVVar vvarname vvartype) ->
          case Map.lookup vvarname typedVEnv of
            Nothing -> error $ "in mkInnerSync, cannot find variable: " ++ vvarname
            -- vPat for generate xml elements serials :
            -- <arith><sub><arith>..<arith>..</arith>..</arith></sub></arith>
            Just vPat ->
              -- problem here to be fixed. vPat: TVVar "n" "String". Not String
              -- trace ("\nvPat: " ++ show vPat) $
              case Map.lookup svartype funNameEnv of
                Nothing ->
                  if svartype == "String"
                     -- then "REPLACE $f WITH $m"
                    then  getFreshName >>= \freshserial_ ->
                          let vPaths = genTagSerials vPat
                          in  return (text "REPLACE" <+> "$" <> toLower' (svarname ++ freshserial_) <+> "WITH" <+> vPaths)
                    else error $ "cannot find source variable: " ++ "\nwe want: " ++ svarname ++ "  type:  " ++ svartype ++
                                  "\nfunNameEnv: " ++ show funNameEnv
                Just syncFunName ->
                  let vPaths = genTagSerials vPat
                  in  return (text (syncFunName ++ "0") <> parens ("$"<> toLower' svarname <> comma <+> vPaths))
        Just (TVCon _ _ _ ) -> error "mkInner 02. Currently I think that it cannot be a view constructor!"
        -- problematic
        Just (TVLit lit) ->
          case Map.lookup svartype funNameEnv of
            Nothing -> error "mkInnerSync 02"
            Just syncFunName ->
              return (text syncFunName <> parens ("$"<> text svarname <> comma <+> doubleQuotes (text lit)))
    TSCon tsConType tsConName subpatterns ->
      -- trace ("\tsConType: " ++ tsConType ++ "\tsConName: " ++ tsConName) $
      case Map.null typedVEnv of
        False -> liftM (vsep . (punctuate semi)) $ mapM (mkInnerSync funNameEnv typedVEnv) subpatterns
        True ->
          case null subpatterns of
            True -> return "{}"
            False -> liftM (vsep . (punctuate semi)) $ mapM (mkInnerSync funNameEnv typedVEnv) subpatterns

    -- problematic. is this possible?
    TSLit (Just (TVLit sstr))  str strt ->
      if strt == "String"
       -- then "REPLACE $f WITH $m"
        then getFreshName >>= \freshserial_ ->
             return (text "REPLACE" <+> "$" <> toLower' (str ++ freshserial_) <+> "WITH" <+> doubleQuotes (text sstr))
        else error "mkInnerSync 03"


-- call by innersync. to produce the xml elements serials in the "sync function call".
-- sync function call: syncExpr($expr, <arith><add>{$lhsArith}</add></arith>)
genTagSerials :: TypedViewPattern -> Doc
genTagSerials vPat =
  case vPat of
    -- may be problematic. do we need to look up the tvVarName in the typedVEnv recursively
    -- just in the case it is still a ASPattern(arith@(...), arith is a ASPattern).
    TVVar tvVarName tvVarType ->
      -- trace ("\nTVVarName : " ++ tvVarName ++ "\nTVVarType : " ++ tvVarType) $
      case tvVarType of
        -- "String" -> "<biyaccpcdata>" <> braces ("$" <> toLower' tvVarName) <> "</biyaccpcdata>"
        _ -> braces("$" <> toLower' tvVarName)
    TVCon tvConName tvSubPatterns tvConType ->
      let src1 = hcat . (map genTagSerials) $ tvSubPatterns
          src2 = wrapSETag src1 tvConName
      in  wrapSETag src2 tvConType
    TVLit str -> "<biyaccpcdata>" <> text str <> "</biyaccpcdata>"


-- sCoveredRules :: Rule -> [Rule]
-- sCoveredRules = flip (:) [AdaptRule]

sCoveredRules :: Rule -> [Rule] -> [Rule]
sCoveredRules AdaptRule _ = []
sCoveredRules c@(NormalRule lhs rhs) rs = c : (findAdaptRule c (dropWhile (/= c) rs))
  where
  findAdaptRule r rs =
    filter (\x -> case r of
                    AdaptRule -> False
                    NormalRule _ _ ->
                      case x of
                        AdaptRule -> True
                        NormalRule _ _ -> False
           ) rs

rArrow :: Doc
rArrow = "->"

toLower' :: String -> Doc
toLower' = text . (map toLower)

-- wrap start end tag. wrapSETag doc "expr" = <expr>doc</expr>
wrapSETag :: Doc -> String -> Doc
wrapSETag src dst = angles (toLower' dst) <> src <> closeAngles (toLower' dst)

angles :: Doc -> Doc
angles doc = "<" <> doc <> ">"

closeAngles :: Doc -> Doc
closeAngles doc = "</" <> doc <> ">"

vsep :: [Doc] -> Doc
vsep = foldr ($+$) PP.empty

nest2 :: Doc -> Doc
nest2 = nest 2

nestn2 :: Doc -> Doc
nestn2 = nest (-2)

delRHSLit :: [RHSUpdate] -> [RHSUpdate]
delRHSLit [] = []
delRHSLit (x:xs) =
  case x of
    l@(Update _ _)   -> l:delRHSLit xs
    l@(NonUpdate _)  -> l:delRHSLit xs
    RHSLiteral _      -> delRHSLit xs
    l@(DeepPat _ _) -> l:delRHSLit xs

